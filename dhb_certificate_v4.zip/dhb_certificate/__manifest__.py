{
    "name": "DHB Certificates",
    "version": "19.0.2.0.0",
    "summary": "Certificates from the pass to the learner's hands - NEBOSH, "
               "IOSH and our own",
    "description": """
DHB Certificates
================

A certificate is not one thing that happens once. It is an award, and then a
journey - and the journey is different for each awarding body:

* **NEBOSH** prints on a pass and ships to the centre by DHL, unasked. It is
  inside the course fee, so there is nothing to order and nothing to charge.
  The centre tells the learner and usually sends it on by Aramex.

* **IOSH** issues electronically, and that is inside the course fee too. A
  paper copy exists only if the learner asks for it, and then the learner
  pays the issue fee and the shipping - IOSH to the centre, centre to the
  learner. Nothing is ordered until that is paid.

* **Ours** we produce here: a PDF on the DHB template carrying a
  verification code and a QR square, and a public page that confirms it.
  An employer holding a DHB certificate has no awarding body to write to,
  so the check has to be on the document.

Two models, and the split is the point. ``dhb.certificate`` is the award -
who, what, when, and the number the body printed. ``dhb.certificate.movement``
is one journey of the paper. A certificate that is lost and sent again is one
certificate and two journeys; keeping the courier and the tracking number on
the certificate itself works exactly once, and the second time it erases the
evidence of the first.

What the app chases on its own, every night: certificates sitting at the
centre uncollected for a month, parcels that have been in transit longer
than any courier takes, and paper copies requested but never paid for.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Education",
    "license": "LGPL-3",
    "depends": [
        "base", "mail", "contacts",
        # The course carries the qualification and the awarding body, and
        # the batch is what a cohort of certificates is raised from.
        "dhb_batch",
        # Only for the one flow that charges anybody: the IOSH paper copy.
        "account",
    ],
    "data": [
        "security/certificate_groups.xml",
        "security/ir.model.access.csv",
        "data/certificate_data.xml",
        "report/certificate_report.xml",
        "views/certificate_views.xml",
        "views/movement_views.xml",
        "wizard/certificate_batch_wizard_views.xml",
        "views/batch_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
