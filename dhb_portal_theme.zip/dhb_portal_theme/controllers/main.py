# -*- coding: utf-8 -*-
"""Staged registration, and two data faults fixed on the way.

The form is split at the money:

  * before payment — legal name, date of birth, email, mobile, the policies.
    Enough to raise an invoice and hold a seat. No uploads.
  * after payment — nationality, address, identity document and number,
    photograph. What the awarding body's import needs, asked once the
    learner has something to lose.

The two faults, both of which affected every applicant who ever applied:

  1. The identity document number was never asked for at all.
  2. The nationality was stored only as a NEBOSH demonym, so the reviewer's
     Nationality field was empty for everyone.
"""
import base64
import logging

from odoo import _, fields, http
from odoo.http import request

from odoo.addons.dhb_registration.controllers.main import DhbRegistrationController
from odoo.addons.dhb_admission.controllers.apply import AdmissionApplyController

_logger = logging.getLogger(__name__)

MAX_UPLOAD_BYTES = 8 * 1024 * 1024
ALLOWED_UPLOAD = {"image/jpeg", "image/png", "image/webp", "application/pdf"}

# Asked after payment, not before. Their absence must not be an error on the
# first form, and must not wipe what a returning learner already gave us.
DEFERRED_REQUIRED = (
    "nebosh_nationality",
    "country_id",
    "id_document_type",
    "awareness_source",
)
DEFERRED_KEEP = (
    "learner_title",
    "gender",
    "nebosh_nationality",
    "street",
    "street2",
    "city",
    "zip",
    "country_id",
    "mail_address_type",
    "id_document_type",
    "id_document_other",
    "id_document_number",
    "awareness_source",
    "awareness_detail",
    "transfer_reason",
    "transferred_from_partner",
)

# NEBOSH demonym -> ISO 3166-1 alpha-2. Explicit rather than derived:
# "Emirian", "Basotho (Mosotho)" and "Trinidadian or Tobagonian" defeat every
# rule anyone has tried to write, and a wrong country on a certificate is a
# worse outcome than a blank one.
DEMONYM_TO_CODE = {
    "Afghan": "AF", "Albanian": "AL", "Algerian": "DZ", "American": "US",
    "Andorran": "AD", "Angolan": "AO", "Argentinian": "AR", "Armenian": "AM",
    "Aruban": "AW", "Australian": "AU", "Austrian": "AT", "Azerbaijani": "AZ",
    "Bahraini": "BH", "Bangladeshi": "BD", "Barbadian": "BB",
    "Basotho (Mosotho)": "LS", "Belarusian": "BY", "Belgian": "BE",
    "Bermudian": "BM", "Bhutanese": "BT", "Bosnian": "BA",
    "Botswanan (Motswana)": "BW", "Brazilian": "BR", "British": "GB",
    "Bruneian": "BN", "Bulgarian": "BG", "Burkinabe": "BF", "Burmese": "MM",
    "Cambodian": "KH", "Cameroonian": "CM", "Canadian": "CA", "Chadian": "TD",
    "Chilean": "CL", "Chinese": "CN", "Colombian": "CO", "Comorian": "KM",
    "Congolese": "CG", "Croat": "HR", "Cuban": "CU", "Cypriot": "CY",
    "Czech": "CZ", "Danish": "DK", "Dominican": "DO", "Dutch": "NL",
    "Ecuadorean": "EC", "Egyptian": "EG", "Emirian": "AE", "Estonian": "EE",
    "Ethiopian": "ET", "Fijian": "FJ", "Filipino": "PH", "Finnish": "FI",
    "French": "FR", "Gabonese": "GA", "Georgian": "GE", "German": "DE",
    "Ghanaian": "GH", "Gibraltarian": "GI", "Greek": "GR", "Guatemalan": "GT",
    "Guinean": "GN", "Guyanese": "GY", "Haitian": "HT", "Honduran": "HN",
    "Hungarian": "HU", "Icelander": "IS", "Indian": "IN", "Indonesian": "ID",
    "Iranian": "IR", "Iraqi": "IQ", "Irish": "IE", "Israeli": "IL",
    "Italian": "IT", "Ivorian": "CI", "Jamaican": "JM", "Japanese": "JP",
    "Jordanian": "JO", "Kazakh": "KZ", "Kenyan": "KE", "Kuwaiti": "KW",
    "Kyrgyzstani": "KG", "Latvian": "LV", "Lebanese": "LB", "Liberian": "LR",
    "Libyan": "LY", "Lithuanian": "LT", "Macedonian": "MK", "Malagasy": "MG",
    "Malawian": "MW", "Malaysian": "MY", "Malian": "ML", "Maltese": "MT",
    "Mauritian": "MU", "Mexican": "MX", "Moldovan": "MD", "Mongolian": "MN",
    "Moroccan": "MA", "Namibian": "NA", "Nepalese": "NP",
    "New Zealander": "NZ", "Nigerian": "NG", "North Korean": "KP",
    "Norwegian": "NO", "Omani": "OM", "Pakistani": "PK", "Palestinian": "PS",
    "Panamanian": "PA", "Paraguayan": "PY", "Peruvian": "PE", "Polish": "PL",
    "Portuguese": "PT", "Puerto Rican": "PR", "Qatari": "QA",
    "Romanian": "RO", "Russian": "RU", "Samoan": "WS", "Saudi Arabian": "SA",
    "Senegalese": "SN", "Serbian": "RS", "Singaporean": "SG", "Slovak": "SK",
    "Slovenian": "SI", "Somali": "SO", "South African": "ZA",
    "South Korean": "KR", "Spanish": "ES", "Sri Lankan": "LK",
    "Sudanese": "SD", "Swedish": "SE", "Swiss": "CH", "Syrian": "SY",
    "Tanzanian": "TZ", "Thai": "TH", "Togolese": "TG", "Tongan": "TO",
    "Trinidadian or Tobagonian": "TT", "Tunisian": "TN", "Turkish": "TR",
    "Turkmen": "TM", "Ugandan": "UG", "Ukrainian": "UA", "Uruguayan": "UY",
    "Uzbek": "UZ", "Venezuelan": "VE", "Vietnamese": "VN", "Yemeni": "YE",
    "Zambian": "ZM", "Zimbabwean": "ZW",
}


def country_for_demonym(demonym):
    """Best-effort country for a NEBOSH demonym. Never raises."""
    demonym = (demonym or "").strip()
    if not demonym:
        return False
    Country = request.env["res.country"].sudo()
    code = DEMONYM_TO_CODE.get(demonym)
    if code:
        country = Country.search([("code", "=", code)], limit=1)
        if country:
            return country
    country = Country.search([("name", "=ilike", demonym)], limit=1)
    if country:
        return country
    _logger.info("No country matched NEBOSH nationality %r.", demonym)
    return False


# ----------------------------------------------------------------- stage one

class DhbPortalApplyController(AdmissionApplyController):
    """Keep the applicant's phone number. A lead without one cannot be
    chased on the channel this centre actually uses."""

    @http.route()
    def apply_start(self, token, **post):
        response = super().apply_start(token, **post)

        phone = (post.get("phone") or "").strip()
        email = (post.get("email") or "").strip().lower()
        if not (phone and email):
            return response

        register = self._get_register(token)
        if not register:
            return response

        invite = request.env["dhb.registration.invite"].sudo().search([
            ("register_id", "=", register.id),
            ("email", "=ilike", email),
        ], order="id desc", limit=1)
        if invite and not invite.applicant_phone:
            invite.write({"applicant_phone": phone})
        return response


# ----------------------------------------------------------------- stage two

class DhbPortalRegistrationController(DhbRegistrationController):

    def _validate(self, post, policies):
        errors = super()._validate(post, policies)
        # These are asked after payment; their absence is not a fault here.
        for field_name in DEFERRED_REQUIRED:
            errors.pop(field_name, None)
        errors.pop("id_document_other", None)
        errors.pop("awareness_detail", None)
        return errors

    def _check_upload(self, upload, label):
        """No file at this stage is normal — the uploads come later."""
        if not upload or not upload.filename:
            return False
        return super()._check_upload(upload, label)

    def _save_partner(self, invite, post, id_file, photo_file):
        """Do not let a short form blank what a returning learner gave us.

        The base method writes every key it knows, so a field absent from
        this stage's form would be written as False — wiping the nationality
        and address of somebody who studied here before.
        """
        partner = invite.partner_id
        before = {}
        if partner:
            for name in DEFERRED_KEEP:
                value = partner[name]
                before[name] = value.id if hasattr(value, "id") else value

        partner = super()._save_partner(invite, post, id_file, photo_file)

        restore = {}
        for name, old in before.items():
            if not old:
                continue
            if post.get(name):
                continue
            current = partner[name]
            current = current.id if hasattr(current, "id") else current
            if not current:
                restore[name] = old
        if restore:
            partner.sudo().write(restore)

        # Phone taken at the enquiry, if the learner left the field alone.
        if invite.applicant_phone and not partner.mobile_phone:
            partner.sudo().write({
                "mobile_phone": invite.applicant_phone,
                "phone": invite.applicant_phone,
            })

        return partner


# --------------------------------------------------------------- stage three

class DhbLearnerDetailsController(http.Controller):
    """The rest of the details, asked once the learner has paid."""

    def _get_invite(self, token):
        if not token:
            return False
        invite = request.env["dhb.registration.invite"].sudo().search(
            [("details_token", "=", token)], limit=1
        )
        if not invite or not invite.partner_id:
            return False
        if invite.state in ("cancelled", "expired", "rejected", "withdrawn"):
            return False
        return invite

    def _render_form(self, invite, errors=None, values=None):
        env = request.env
        partner = invite.partner_id
        return request.render("dhb_portal_theme.learner_details", {
            "invite": invite,
            "event": invite.event_id,
            "partner": partner,
            "countries": env["res.country"].sudo().search([]),
            "titles": env["res.partner"]._fields["learner_title"].selection,
            "genders": env["res.partner"]._fields["gender"].selection,
            "id_types": env["res.partner"]._fields["id_document_type"].selection,
            "nationalities": env["res.partner"]._fields["nebosh_nationality"].selection,
            "awareness_sources": env["res.partner"]._fields["awareness_source"].selection,
            "error": errors or {},
            "values": values or {
                "learner_title": partner.learner_title or "",
                "gender": partner.gender or "",
                "nebosh_nationality": partner.nebosh_nationality or "",
                "street": partner.street or "",
                "street2": partner.street2 or "",
                "city": partner.city or "",
                "zip": partner.zip or "",
                "country_id": partner.country_id.id or "",
                "id_document_type": partner.id_document_type or "",
                "id_document_other": partner.id_document_other or "",
                "id_document_number": partner.id_document_number or "",
                "awareness_source": partner.awareness_source or "",
                "awareness_detail": partner.awareness_detail or "",
            },
        })

    @http.route(["/learner/details/<string:token>"], type="http",
                auth="public", website=True, sitemap=False)
    def details_form(self, token, **kw):
        invite = self._get_invite(token)
        if not invite:
            return request.render("dhb_portal_theme.details_link_not_valid")
        if invite.details_complete:
            return request.render("dhb_portal_theme.learner_details_thanks", {
                "invite": invite, "event": invite.event_id,
            })
        return self._render_form(invite)

    @http.route(["/learner/details/<string:token>/submit"], type="http",
                auth="public", website=True, csrf=True, methods=["POST"],
                sitemap=False)
    def details_submit(self, token, **post):
        invite = self._get_invite(token)
        if not invite:
            return request.render("dhb_portal_theme.details_link_not_valid")

        errors = {}
        required = {
            "nebosh_nationality": _("اختر جنسيتك."),
            "country_id": _("اختر دولة الإقامة."),
            "id_document_type": _("اختر نوع المستند."),
            "id_document_number": _("اكتب رقم المستند كما هو مطبوع عليه."),
        }
        for name, message in required.items():
            if not (post.get(name) or "").strip():
                errors[name] = message

        number = (post.get("id_document_number") or "").strip()
        if number and len(number) < 4:
            errors["id_document_number"] = _("رقم المستند قصير. تأكد أنك نسخته كاملًا.")

        if post.get("id_document_type") == "other" and not (
                post.get("id_document_other") or "").strip():
            errors["id_document_other"] = _("اكتب اسم المستند.")

        partner = invite.partner_id
        id_file = request.httprequest.files.get("id_document_file")
        photo_file = request.httprequest.files.get("photo_file")

        for field_name, upload, existing, label in (
            ("id_document_file", id_file, partner.id_document_file,
             _("صورة المستند")),
            ("photo_file", photo_file, partner.image_1920,
             _("الصورة الشخصية")),
        ):
            if upload and upload.filename:
                content = upload.read()
                upload.seek(0)
                if len(content) > MAX_UPLOAD_BYTES:
                    errors[field_name] = _("%s أكبر من 8 ميغابايت.") % label
                elif upload.mimetype not in ALLOWED_UPLOAD:
                    errors[field_name] = _("%s يجب أن تكون JPG أو PNG أو PDF.") % label
            elif not existing:
                errors[field_name] = _("أرفق %s.") % label

        if errors:
            return self._render_form(invite, errors, post)

        values = {
            "learner_title": post.get("learner_title") or partner.learner_title,
            "gender": post.get("gender") or partner.gender,
            "nebosh_nationality": (post.get("nebosh_nationality") or "").strip(),
            "street": post.get("street") or False,
            "street2": post.get("street2") or False,
            "city": post.get("city") or False,
            "zip": post.get("zip") or False,
            "country_id": int(post["country_id"]) if post.get("country_id") else False,
            "mail_address_type": post.get("mail_address_type") or "H",
            "id_document_type": post.get("id_document_type") or False,
            "id_document_other": post.get("id_document_other") or False,
            "id_document_number": number,
            "awareness_source": post.get("awareness_source") or partner.awareness_source,
            "awareness_detail": (post.get("awareness_detail") or "").strip() or partner.awareness_detail,
            "transferred_from_partner": bool(post.get("transferred_from_partner")),
            "transfer_reason": (post.get("transfer_reason") or "").strip() or False,
        }

        country = country_for_demonym(values["nebosh_nationality"])
        if country:
            values["nationality_id"] = country.id

        if id_file and id_file.filename:
            values["id_document_file"] = base64.b64encode(id_file.read())
            values["id_document_filename"] = id_file.filename
        if photo_file and photo_file.filename:
            values["image_1920"] = base64.b64encode(photo_file.read())

        partner.sudo().write(values)
        partner.sudo().message_post(body=_(
            "Details and documents completed by the learner from %s."
        ) % (request.httprequest.remote_addr or "?"))
        invite.sudo().message_post(body=_(
            "The learner completed their details and uploaded their documents."
        ))

        return request.render("dhb_portal_theme.learner_details_thanks", {
            "invite": invite, "event": invite.event_id,
        })
