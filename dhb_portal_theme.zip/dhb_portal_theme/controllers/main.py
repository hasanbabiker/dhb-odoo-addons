# -*- coding: utf-8 -*-
"""Two faults in the registration form, fixed without touching it.

1. The identity document number was never asked for. NEBOSH's student data
   import requires it, so every application had to be chased by hand.

2. The learner's nationality was written to `nebosh_nationality` — the closed
   list of 148 demonyms the import template accepts — and nowhere else. The
   reviewer's screen reads `nationality_id`, a country. So the field the
   reviewer looks at was empty for every applicant who ever applied, and the
   only way to notice was to read both models side by side.
"""
import logging

from odoo import _
from odoo.http import request

from odoo.addons.dhb_registration.controllers.main import DhbRegistrationController

_logger = logging.getLogger(__name__)


# NEBOSH demonym -> ISO 3166-1 alpha-2. Kept explicit rather than derived:
# "Emirian", "Basotho (Mosotho)" and "Trinidadian or Tobagonian" defeat every
# rule anyone has tried to write, and a wrong country on a certificate is a
# worse outcome than a blank one.
DEMONYM_TO_CODE = {
    "Afghan": "AF", "Albanian": "AL", "Algerian": "DZ", "American": "US",
    "Andorran": "AD", "Angolan": "AO", "Argentinian": "AR", "Armenian": "AM",
    "Aruban": "AW", "Australian": "AU", "Austrian": "AT", "Azerbaijani": "AZ",
    "Bahraini": "BH", "Bangladeshi": "BD", "Barbadian": "BB",
    "Basotho (Mosotho)": "LS", "Belarusian": "BY", "Belgian": "BE",
    "Bermudian": "BM", "Bhutanese": "BT", "Bosnian": "BA",
    "Botswanan (Motswana)": "BW", "Brazilian": "BR", "British": "GB",
    "Bruneian": "BN", "Bulgarian": "BG", "Burkinabe": "BF", "Burmese": "MM",
    "Cambodian": "KH", "Cameroonian": "CM", "Canadian": "CA", "Chadian": "TD",
    "Chilean": "CL", "Chinese": "CN", "Colombian": "CO", "Comorian": "KM",
    "Congolese": "CG", "Croat": "HR", "Cuban": "CU", "Cypriot": "CY",
    "Czech": "CZ", "Danish": "DK", "Dominican": "DO", "Dutch": "NL",
    "Ecuadorean": "EC", "Egyptian": "EG", "Emirian": "AE", "Estonian": "EE",
    "Ethiopian": "ET", "Fijian": "FJ", "Filipino": "PH", "Finnish": "FI",
    "French": "FR", "Gabonese": "GA", "Georgian": "GE", "German": "DE",
    "Ghanaian": "GH", "Gibraltarian": "GI", "Greek": "GR", "Guatemalan": "GT",
    "Guinean": "GN", "Guyanese": "GY", "Haitian": "HT", "Honduran": "HN",
    "Hungarian": "HU", "Icelander": "IS", "Indian": "IN", "Indonesian": "ID",
    "Iranian": "IR", "Iraqi": "IQ", "Irish": "IE", "Israeli": "IL",
    "Italian": "IT", "Ivorian": "CI", "Jamaican": "JM", "Japanese": "JP",
    "Jordanian": "JO", "Kazakh": "KZ", "Kenyan": "KE", "Kuwaiti": "KW",
    "Kyrgyzstani": "KG", "Latvian": "LV", "Lebanese": "LB", "Liberian": "LR",
    "Libyan": "LY", "Lithuanian": "LT", "Macedonian": "MK", "Malagasy": "MG",
    "Malawian": "MW", "Malaysian": "MY", "Malian": "ML", "Maltese": "MT",
    "Mauritian": "MU", "Mexican": "MX", "Moldovan": "MD", "Mongolian": "MN",
    "Moroccan": "MA", "Namibian": "NA", "Nepalese": "NP",
    "New Zealander": "NZ", "Nigerian": "NG", "North Korean": "KP",
    "Norwegian": "NO", "Omani": "OM", "Pakistani": "PK", "Palestinian": "PS",
    "Panamanian": "PA", "Paraguayan": "PY", "Peruvian": "PE", "Polish": "PL",
    "Portuguese": "PT", "Puerto Rican": "PR", "Qatari": "QA",
    "Romanian": "RO", "Russian": "RU", "Samoan": "WS", "Saudi Arabian": "SA",
    "Senegalese": "SN", "Serbian": "RS", "Singaporean": "SG", "Slovak": "SK",
    "Slovenian": "SI", "Somali": "SO", "South African": "ZA",
    "South Korean": "KR", "Spanish": "ES", "Sri Lankan": "LK",
    "Sudanese": "SD", "Swedish": "SE", "Swiss": "CH", "Syrian": "SY",
    "Tanzanian": "TZ", "Thai": "TH", "Togolese": "TG", "Tongan": "TO",
    "Trinidadian or Tobagonian": "TT", "Tunisian": "TN", "Turkish": "TR",
    "Turkmen": "TM", "Ugandan": "UG", "Ukrainian": "UA", "Uruguayan": "UY",
    "Uzbek": "UZ", "Venezuelan": "VE", "Vietnamese": "VN", "Yemeni": "YE",
    "Zambian": "ZM", "Zimbabwean": "ZW",
}


class DhbPortalRegistrationController(DhbRegistrationController):

    # ------------------------------------------------------------------
    def _validate(self, post, policies):
        errors = super()._validate(post, policies)

        number = (post.get("id_document_number") or "").strip()
        if not number:
            errors["id_document_number"] = _(
                "اكتب رقم المستند كما هو مطبوع عليه."
            )
        elif len(number) < 4:
            errors["id_document_number"] = _(
                "رقم المستند قصير. تأكد أنك نسخته كاملًا."
            )

        return errors

    # ------------------------------------------------------------------
    def _save_partner(self, invite, post, id_file, photo_file):
        partner = super()._save_partner(invite, post, id_file, photo_file)

        values = {}

        number = (post.get("id_document_number") or "").strip()
        if number:
            values["id_document_number"] = number

        country = self._country_for_demonym(post.get("nebosh_nationality"))
        if country and not partner.nationality_id:
            values["nationality_id"] = country.id

        if values:
            partner.sudo().write(values)

        return partner

    # ------------------------------------------------------------------
    def _country_for_demonym(self, demonym):
        """Best-effort country for a NEBOSH demonym. Never raises."""
        demonym = (demonym or "").strip()
        if not demonym:
            return False
        Country = request.env["res.country"].sudo()

        code = DEMONYM_TO_CODE.get(demonym)
        if code:
            country = Country.search([("code", "=", code)], limit=1)
            if country:
                return country

        # A demonym the table does not know: try the country name itself
        # before giving up, so a new NEBOSH entry is not silently dropped.
        country = Country.search([("name", "=ilike", demonym)], limit=1)
        if country:
            return country

        _logger.info(
            "No country matched NEBOSH nationality %r; leaving it blank.",
            demonym,
        )
        return False
