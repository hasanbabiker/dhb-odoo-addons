# -*- coding: utf-8 -*-
"""Staged data collection.

An applicant on a phone, who has not paid a dirham yet, is asked for a
passport scan and a photograph in the middle of a twenty-field form. That is
the moment the browser closes.

So the form is split at the money. Before payment the centre asks only what
it needs to raise an invoice and hold a seat. Everything the awarding body
needs — nationality, address, identity document, photograph — is asked once
the learner has paid, through a second link.
"""
import logging
import secrets

from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


class DhbRegistrationInvite(models.Model):
    _inherit = "dhb.registration.invite"

    applicant_phone = fields.Char(
        string="Phone given at enquiry",
        help="Taken on the public application page. A centre whose learners "
             "live on WhatsApp should not collect an email without a number.",
    )

    details_token = fields.Char(readonly=True, copy=False, index=True)
    details_url = fields.Char(
        string="Details link", compute="_compute_details_url"
    )
    details_sent_on = fields.Datetime(readonly=True)
    details_complete = fields.Boolean(
        string="Details complete",
        compute="_compute_details_complete",
        help="Everything NEBOSH's student data import needs is on the "
             "learner's contact.",
    )

    # Fields the learner supplies after payment, and what the form calls them.
    AFTER_PAYMENT_FIELDS = (
        "nebosh_nationality",
        "country_id",
        "id_document_type",
        "id_document_number",
        "id_document_file",
        "image_1920",
    )

    def _compute_details_url(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        for rec in self:
            rec.details_url = (
                f"{base}/learner/details/{rec.details_token}"
                if rec.details_token else False
            )

    @api.depends(
        "partner_id.nebosh_nationality",
        "partner_id.country_id",
        "partner_id.id_document_type",
        "partner_id.id_document_number",
        "partner_id.id_document_file",
        "partner_id.image_1920",
    )
    def _compute_details_complete(self):
        for rec in self:
            partner = rec.partner_id
            rec.details_complete = bool(
                partner
                and all(partner[f] for f in self.AFTER_PAYMENT_FIELDS)
            )

    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("details_token"):
                vals["details_token"] = secrets.token_urlsafe(32)
        return super().create(vals_list)

    def _ensure_details_token(self):
        for rec in self:
            if not rec.details_token:
                rec.sudo().write({"details_token": secrets.token_urlsafe(32)})
        return True

    # ------------------------------------------------------------------
    def action_send_details_link(self):
        """Ask the learner for the rest of their details."""
        template = self.env.ref(
            "dhb_portal_theme.mail_template_learner_details",
            raise_if_not_found=False,
        )
        for rec in self:
            if not rec.email:
                continue
            rec._ensure_details_token()
            if template:
                template.send_mail(rec.id, force_send=True)
            rec.sudo().write({"details_sent_on": fields.Datetime.now()})
            rec.message_post(body=_(
                "Payment received — asked the learner for the remaining "
                "details and documents."
            ))
        return True

    # ------------------------------------------------------------------
    @api.model
    def _cron_request_details_after_payment(self):
        """Once money has arrived, ask for what the awarding body needs.

        Deliberately keyed on payment rather than on acceptance: a learner
        who has paid answers; one who has only applied often does not.
        """
        candidates = self.search([
            ("state", "in", ("submitted", "review", "accepted", "enrolled")),
            ("amount_settled", ">", 0),
            ("details_sent_on", "=", False),
            ("partner_id", "!=", False),
        ])
        to_ask = candidates.filtered(lambda r: not r.details_complete)
        for invite in to_ask:
            try:
                invite.action_send_details_link()
            except Exception:  # noqa: BLE001
                _logger.warning(
                    "Could not send the details link for %s", invite.name,
                    exc_info=True,
                )
        return len(to_ask)
