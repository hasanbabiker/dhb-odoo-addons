# -*- coding: utf-8 -*-
{
    "name": "DHB learner portal: Arabic, bare layout, mobile",
    "summary": "The pages an applicant sees — stripped of site navigation, "
               "in Arabic and right-to-left, built for a phone.",
    "description": """
An applicant who opens a link from WhatsApp should see one thing: the form.
Site navigation, a Sign in button and a footer full of placeholder links are
all ways out of a form that has not been submitted yet.

This module gives the learner-facing pages a layout of their own — the DHB
logo, a step indicator, the form, nothing else — writes them in Arabic and
lays them out right-to-left, and fixes two data faults in the registration
form:

  * the identity document number was never asked for at all
  * the nationality the learner chose was stored only as a NEBOSH demonym,
    so the reviewer's Nationality field stayed empty for every applicant

Uninstalling restores the original pages untouched.
""",
    "version": "19.0.1.0.0",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "category": "Education",

    "depends": [
        "website",
        "dhb_registration",
        "dhb_admission",
        "dhb_learner_document",
    ],

    "data": [
        "views/layout.xml",
        "views/apply_templates.xml",
        "views/registration_templates.xml",
        "views/relayout.xml",
    ],

    "assets": {
        "web.assets_frontend": [
            "dhb_portal_theme/static/src/css/portal.css",
        ],
    },

    "installable": True,
    "application": False,
    "auto_install": False,
}
