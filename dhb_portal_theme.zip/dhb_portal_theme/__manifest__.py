# -*- coding: utf-8 -*-
{
    "name": "DHB learner portal: staged registration, Arabic, mobile",
    "summary": "Ask little before payment, everything after it — on pages "
               "stripped of site navigation, in Arabic, built for a phone.",
    "description": """
The form is split at the money.

Before payment the centre asks only what it needs to raise an invoice and
hold a seat: legal name, date of birth, email, mobile, and acceptance of the
policies. No uploads. Under a minute.

After payment, one link asks for what the awarding body's import needs:
nationality, address, identity document and its number, photograph. A learner
who has paid answers; one who has only clicked a WhatsApp link, and is being
asked to photograph a passport in the middle of a twenty-field form, closes
the browser — and the centre never learns why.

The pages themselves get a layout of their own: DHB's logo, a step
indicator, the form, nothing else. Arabic, right to left, mobile first.

Two data faults are fixed on the way, both of which affected every applicant
who ever applied:

  * the identity document number was never asked for at all
  * the nationality was stored only as a NEBOSH demonym, so the reviewer's
    Nationality field was empty for everyone

Uninstalling restores the original pages untouched.
""",
    "version": "19.0.2.0.0",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "category": "Education",

    "depends": [
        "website",
        "dhb_registration",
        "dhb_admission",
        "dhb_learner_document",
    ],

    "data": [
        "data/mail_template.xml",
        "data/ir_cron.xml",
        "views/layout.xml",
        "views/apply_templates.xml",
        "views/registration_templates.xml",
        "views/details_templates.xml",
        "views/relayout.xml",
        "views/invite_views.xml",
    ],

    "assets": {
        "web.assets_frontend": [
            "dhb_portal_theme/static/src/css/portal.css",
        ],
    },

    "installable": True,
    "application": False,
    "auto_install": False,
}
