import logging
import re

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

# Accounts that exist for the platform's own purposes, not for learning.
SYSTEM_USERNAMES = {"guest", "admin", "api-bot"}


class DhbMoodleUserImportWizard(models.TransientModel):
    """Bring existing Moodle users into Odoo as learner contacts.

    A platform that has been running for a while already holds the people the
    accreditation file is supposed to describe. Typing them in again invites
    the drift — a surname spelt differently here than there — that an audit
    picks up, so they are read across instead.

    What arrives is deliberately incomplete. Moodle knows a name, an email and
    a last login; it does not know a date of birth, a nationality in NEBOSH's
    wording, or an identity document. Imported contacts therefore show as
    incomplete files, which is honest: the gap is real and the registration
    form is how it gets closed.
    """

    _name = "dhb.moodle.user.import.wizard"
    _description = "Import learners from Moodle"

    search_text = fields.Char(
        string="Filter",
        help="Name, email or username. Leave empty to list everyone.",
    )
    include_suspended = fields.Boolean(string="Include suspended accounts")
    include_system = fields.Boolean(
        string="Include admin and system accounts",
        help="Moodle holds tutors, administrators and the API account "
             "alongside learners. They are hidden unless you ask.",
    )
    line_ids = fields.One2many(
        "dhb.moodle.user.import.line", "wizard_id", string="Moodle users"
    )
    summary = fields.Text(readonly=True)
    state = fields.Selection(
        [("draft", "Draft"), ("listed", "Listed")], default="draft"
    )

    # ------------------------------------------------------------------
    def action_fetch(self):
        self.ensure_one()
        api_client = self.env["dhb.moodle.api"]

        criteria = [{"key": "deleted", "value": "0"}]
        if self.search_text:
            # Moodle's own search across name, email and username.
            criteria = [{"key": "email", "value": "%%%s%%" % self.search_text.strip()}]

        try:
            response = api_client._call("core_user_get_users", {"criteria": criteria})
        except UserError:
            raise
        users = response.get("users", []) if isinstance(response, dict) else []

        if self.search_text and not users:
            # Fall back to a name search when the email search finds nothing.
            response = api_client._call("core_user_get_users", {
                "criteria": [{"key": "firstname", "value": "%%%s%%" % self.search_text.strip()}]
            })
            users = response.get("users", []) if isinstance(response, dict) else []

        self.line_ids.unlink()
        Partner = self.env["res.partner"].sudo()
        rows, hidden = [], 0

        for user in users:
            username = (user.get("username") or "").lower()
            if not self.include_system and username in SYSTEM_USERNAMES:
                hidden += 1
                continue
            if not self.include_suspended and user.get("suspended"):
                hidden += 1
                continue

            email = (user.get("email") or "").strip().lower()
            existing = Partner.search([("moodle_user_id", "=", user.get("id"))], limit=1)
            if not existing and email:
                existing = Partner.search([("email", "=ilike", email)], limit=1)

            rows.append((0, 0, {
                "moodle_user_id": user.get("id"),
                "username": user.get("username"),
                "firstname": user.get("firstname"),
                "lastname": user.get("lastname"),
                "email": email,
                "country_code": user.get("country") or "",
                "suspended": bool(user.get("suspended")),
                "existing_partner_id": existing.id if existing else False,
                "selected": not existing,
            }))

        self.line_ids = rows
        already = len([r for r in rows if r[2]["existing_partner_id"]])
        self.summary = _(
            "%(total)s users listed, %(already)s already in Odoo, "
            "%(hidden)s hidden by the filters above."
        ) % {"total": len(rows), "already": already, "hidden": hidden}
        self.state = "listed"
        return self._reopen()

    def action_select_all(self):
        self.ensure_one()
        self.line_ids.filtered(lambda l: not l.existing_partner_id).selected = True
        return self._reopen()

    def action_select_none(self):
        self.ensure_one()
        self.line_ids.selected = False
        return self._reopen()

    # ------------------------------------------------------------------
    def action_import(self):
        self.ensure_one()
        chosen = self.line_ids.filtered("selected")
        if not chosen:
            raise UserError(_("Nothing is selected."))

        Partner = self.env["res.partner"].sudo()
        created, linked = self.env["res.partner"], self.env["res.partner"]

        for line in chosen:
            if line.existing_partner_id:
                # Already here: just record the Moodle link rather than
                # making a second contact for the same person.
                line.existing_partner_id.write({
                    "moodle_user_id": line.moodle_user_id,
                    "moodle_username": line.username,
                    "moodle_state": "held" if line.suspended else "active",
                    "is_learner": True,
                })
                linked |= line.existing_partner_id
                continue

            country = self.env["res.country"].search(
                [("code", "=", (line.country_code or "").upper())], limit=1
            ) if line.country_code else self.env["res.country"]

            partner = Partner.create({
                "name": " ".join(filter(None, [line.firstname, line.lastname])) or line.username,
                "is_learner": True,
                "email": line.email or False,
                "legal_forenames": line.firstname or False,
                "legal_surname": line.lastname or False,
                "country_id": country.id if country else False,
                "moodle_user_id": line.moodle_user_id,
                "moodle_username": line.username,
                "moodle_state": "held" if line.suspended else "active",
                "moodle_message": _("Imported from Moodle."),
                # Imported addresses are whatever the learner typed into
                # Moodle, so the work-email rule would block the import for
                # no gain; the registration form re-asks properly.
                "work_email_accepted": True,
            })
            partner.message_post(body=_(
                "Imported from the learning platform (Moodle user %s). The "
                "accreditation fields are still missing — send a registration "
                "invitation to collect them."
            ) % line.moodle_user_id)
            created |= partner

        message = _(
            "%(created)s contacts created, %(linked)s existing contacts linked "
            "to their Moodle account."
        ) % {"created": len(created), "linked": len(linked)}
        _logger.info("Moodle import: %s", message)

        return {
            "type": "ir.actions.act_window",
            "name": _("Imported learners"),
            "res_model": "res.partner",
            "view_mode": "list,form",
            "domain": [("id", "in", (created | linked).ids)],
            "context": {"create": False},
        }

    def _reopen(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }


class DhbMoodleUserImportLine(models.TransientModel):
    _name = "dhb.moodle.user.import.line"
    _description = "Moodle user to import"
    _order = "lastname, firstname"

    wizard_id = fields.Many2one("dhb.moodle.user.import.wizard", ondelete="cascade")
    selected = fields.Boolean(string="Import")
    moodle_user_id = fields.Integer(string="Moodle ID", readonly=True)
    username = fields.Char(readonly=True)
    firstname = fields.Char(readonly=True)
    lastname = fields.Char(readonly=True)
    email = fields.Char(readonly=True)
    country_code = fields.Char(string="Country", readonly=True)
    suspended = fields.Boolean(readonly=True)
    existing_partner_id = fields.Many2one(
        "res.partner", string="Already in Odoo", readonly=True
    )
