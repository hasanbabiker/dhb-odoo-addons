{
    "name": "DHB LMS Accounts",
    "version": "19.0.4.0.2",
    "summary": "Create a suspended LMS account when a learner completes registration",
    "description": """
DHB LMS Accounts
===================

When a learner finishes the registration form, the account they will need is
created on the learning platform straight away — but held, so it cannot be
used until the centre has checked the identity document and the payment.

Holding the account rather than delaying its creation matters: the gap between
"registered" and "has a login" is where learners get forgotten, and a held
account is visible in both systems while an uncreated one is visible in
neither.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["dhb_learner", "dhb_registration", "event"],
    "data": [
        "security/ir.model.access.csv",
        "views/moodle_settings_views.xml",
        "wizard/moodle_user_import_wizard_views.xml",
        "views/res_partner_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
}
