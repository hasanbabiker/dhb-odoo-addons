import logging

from odoo import models, fields

_logger = logging.getLogger(__name__)


class DhbRegistrationInviteMoodle(models.Model):
    """Create the held Moodle account the moment registration completes.

    Hooked on the invitation rather than on the contact, because that is the
    single point where a learner has genuinely finished: details given,
    documents uploaded, policies accepted.
    """

    _inherit = "dhb.registration.invite"

    def write(self, values):
        result = super().write(values)
        if values.get("state") == "submitted":
            auto = self.env["ir.config_parameter"].sudo().get_param(
                "dhb_moodle.auto_create", "1") == "1"
            if auto:
                for invite in self:
                    partner = invite.partner_id
                    if not partner or partner.moodle_user_id:
                        continue
                    try:
                        partner._create_moodle_account(
                            course_id=invite.event_id.moodle_course_id or None
                        )
                    except Exception:  # noqa: BLE001
                        # A Moodle outage must not lose a completed
                        # registration; the account can be created by hand.
                        _logger.exception(
                            "Moodle account creation failed for invite %s", invite.id
                        )
        return result


class EventEventMoodle(models.Model):
    _inherit = "event.event"

    moodle_course_id = fields.Integer(
        string="Moodle course ID",
        help="The numeric course ID on the learning platform. Learners on "
             "this cohort are enrolled there when their account is released.",
    )
