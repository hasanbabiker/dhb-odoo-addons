import logging
import re
import secrets
import string
import unicodedata

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class ResPartnerLMS(models.Model):
    _inherit = "res.partner"

    moodle_user_id = fields.Integer(string="LMS user ID", copy=False, index=True)
    moodle_username = fields.Char(string="LMS username", copy=False)
    moodle_password = fields.Char(
        string="Initial password", copy=False,
        help="Shown so staff can pass it on. Cleared once the learner has "
             "logged in, and never the learner's current password after that.",
    )
    moodle_state = fields.Selection(
        [
            ("none", "No account"),
            ("held", "Created, on hold"),
            ("active", "Active"),
            ("error", "Failed"),
        ],
        default="none",
        string="LMS account",
        copy=False,
        index=True,
    )
    moodle_message = fields.Char(string="Last LMS message", copy=False, readonly=True)

    # ------------------------------------------------------------------
    def _moodle_username(self):
        """A username LMS will accept, derived from the email.

        LMS lowercases usernames and rejects most punctuation, so the local
        part of the email is transliterated and stripped rather than used raw.
        """
        self.ensure_one()
        base = (self.email or "").split("@")[0]
        base = unicodedata.normalize("NFKD", base).encode("ascii", "ignore").decode()
        base = re.sub(r"[^a-zA-Z0-9._-]", "", base).lower()
        if not base:
            base = "learner%s" % self.id
        return base[:90]

    def _moodle_password(self):
        """Meets LMS default policy: 8+, upper, lower, digit, symbol."""
        alphabet = string.ascii_letters + string.digits
        core = "".join(secrets.choice(alphabet) for _i in range(9))
        return "Dhb%s!%s" % (secrets.choice(string.digits), core)

    # ------------------------------------------------------------------
    def action_create_moodle_account(self):
        for partner in self:
            partner._create_moodle_account()
        return True

    def _create_moodle_account(self, course_id=None):
        """Create the account and hold it, according to the configured policy."""
        self.ensure_one()
        if self.moodle_user_id:
            return True

        # Check locally before calling out. LMS rejects incomplete data
        # with "invalidparameter", which says nothing about which parameter,
        # so the useful message has to be produced here.
        missing = []
        if not self.email:
            missing.append(_("email address"))
        if not self.legal_forenames:
            missing.append(_("first name"))
        if not self.legal_surname:
            missing.append(_("family name"))
        if missing:
            message = _(
                "LMS needs %s before an account can be created."
            ) % ", ".join(missing)
            self.write({"moodle_state": "error", "moodle_message": message})
            raise UserError(message)

        api_client = self.env["dhb.moodle.api"]
        icp = self.env["ir.config_parameter"].sudo()
        hold_mode = icp.get_param("dhb_moodle.hold_mode", "suspend")
        password_mode = icp.get_param("dhb_moodle.password_mode", "generated")

        try:
            existing = api_client.find_user_by_email(self.email)
            if existing:
                # Reuse rather than duplicate: a second LMS account for the
                # same person splits their course history in two.
                self.write({
                    "moodle_user_id": existing["id"],
                    "moodle_username": existing.get("username"),
                    "moodle_state": "held" if existing.get("suspended") else "active",
                    "moodle_message": _("Existing LMS account reused."),
                })
                self.message_post(body=_(
                    "Linked to an existing LMS account (%s)."
                ) % existing.get("username"))
                return True

            values = {
                "username": self._moodle_username(),
                "email": self.email.strip().lower(),
                "firstname": self.legal_forenames.strip()[:100],
                "lastname": self.legal_surname.strip()[:100],
                "auth": "manual",
            }
            if self.country_id and self.country_id.code:
                values["country"] = self.country_id.code

            if password_mode == "generated":
                password = self._moodle_password()
                values["password"] = password
            else:
                password = False
                values["createpassword"] = 1

            created = api_client.create_user(values)
            if not created:
                raise UserError(_("LMS created no user and reported no error."))

            # Suspend in a second call, which is the only way LMS accepts
            # it. If this fails the account exists and can log in, so the
            # failure is recorded loudly rather than swallowed.
            held = True
            if hold_mode == "suspend":
                try:
                    api_client.update_user({"id": created["id"], "suspended": 1})
                except UserError as exc:
                    held = False
                    _logger.error(
                        "Created LMS user %s but could not suspend: %s",
                        created["id"], exc,
                    )
                    self.message_post(body=_(
                        "The LMS account was created but could NOT be put "
                        "on hold, so the learner can log in. Suspend it by "
                        "hand in LMS.\n\n%s"
                    ) % exc)

            self.write({
                "moodle_user_id": created["id"],
                "moodle_username": created.get("username") or values["username"],
                "moodle_password": password or False,
                "moodle_state": "held" if held else "active",
                "moodle_message": _("Account created and held.") if held
                                  else _("Created, but the hold failed."),
            })

            target_course = course_id or icp.get_param("dhb_moodle.default_course_id")
            if target_course and hold_mode in ("suspend", "enrol_suspended"):
                api_client.enrol_user(
                    created["id"], int(target_course),
                    suspend=(hold_mode == "enrol_suspended"),
                )

            self.message_post(body=_(
                "LMS account created and held: %s"
            ) % self.moodle_username)
            return True

        except UserError as exc:
            self.write({"moodle_state": "error", "moodle_message": str(exc)[:250]})
            self.message_post(body=_("LMS account creation failed: %s") % exc)
            _logger.warning("LMS creation failed for partner %s: %s", self.id, exc)
            return False

    # ------------------------------------------------------------------
    def action_activate_moodle_account(self):
        """Release the hold once identity and payment have been checked."""
        for partner in self:
            if not partner.moodle_user_id:
                raise UserError(_("There is no LMS account to activate."))
            self.env["dhb.moodle.api"].update_user({
                "id": partner.moodle_user_id,
                "suspended": 0,
            })
            partner.write({
                "moodle_state": "active",
                "moodle_message": _("Activated by %s") % self.env.user.name,
            })
            partner.message_post(body=_(
                "LMS account activated by %s."
            ) % self.env.user.name)
        return True

    def action_hold_moodle_account(self):
        for partner in self:
            if not partner.moodle_user_id:
                raise UserError(_("There is no LMS account to hold."))
            self.env["dhb.moodle.api"].update_user({
                "id": partner.moodle_user_id,
                "suspended": 1,
            })
            partner.write({"moodle_state": "held"})
            partner.message_post(body=_(
                "LMS account put back on hold by %s."
            ) % self.env.user.name)
        return True

    def action_clear_moodle_password(self):
        """Stop storing the initial password once it has been handed over."""
        self.write({"moodle_password": False})
        return True
