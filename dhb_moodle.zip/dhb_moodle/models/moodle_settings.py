from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbLMSSettings(models.TransientModel):
    """LMS connection and account policy, on its own screen."""

    _name = "dhb.moodle.settings"
    _description = "LMS connection"

    url = fields.Char(
        string="Platform URL", required=True,
        default="https://elearning.dhbtraining.com",
    )
    token = fields.Char(string="Web service token", required=True)

    # The two questions that decide what "held" actually means. Made
    # configurable rather than fixed, because the right answer depends on how
    # the centre wants a half-registered learner to experience the platform,
    # and that is a policy decision, not a technical one.
    hold_mode = fields.Selection(
        [
            ("suspend", "Suspend the account — the learner cannot log in at all"),
            ("no_enrol", "Account works, but not enrolled — they log in and see nothing"),
            ("enrol_suspended", "Enrolled but suspended on the course"),
        ],
        default="suspend",
        required=True,
        string="How to hold a new account",
    )
    password_mode = fields.Selection(
        [
            ("generated", "Generate a password and show it to staff"),
            ("moodle_email", "Let LMS email the learner a link to set one"),
        ],
        default="generated",
        required=True,
        string="Password",
        help="LMS own email is only useful if the platform can send mail.",
    )
    auto_create = fields.Boolean(
        string="Create accounts automatically on registration", default=True,
    )
    default_course_id = fields.Char(
        string="LMS course ID",
        help="Optional. Used when the cohort has no LMS course of its own.",
    )
    status = fields.Text(string="Last test result", readonly=True)

    @api.model
    def default_get(self, fields_list):
        values = super().default_get(fields_list)
        icp = self.env["ir.config_parameter"].sudo()
        values.update({
            "url": icp.get_param("dhb_moodle.url", "https://elearning.dhbtraining.com"),
            "token": icp.get_param("dhb_moodle.token", ""),
            "hold_mode": icp.get_param("dhb_moodle.hold_mode", "suspend"),
            "password_mode": icp.get_param("dhb_moodle.password_mode", "generated"),
            "auto_create": icp.get_param("dhb_moodle.auto_create", "1") == "1",
            "default_course_id": icp.get_param("dhb_moodle.default_course_id", ""),
        })
        return values

    def action_save(self):
        self.ensure_one()
        icp = self.env["ir.config_parameter"].sudo()
        icp.set_param("dhb_moodle.url", (self.url or "").strip().rstrip("/"))
        icp.set_param("dhb_moodle.token", (self.token or "").strip())
        icp.set_param("dhb_moodle.hold_mode", self.hold_mode)
        icp.set_param("dhb_moodle.password_mode", self.password_mode)
        icp.set_param("dhb_moodle.auto_create", "1" if self.auto_create else "0")
        icp.set_param("dhb_moodle.default_course_id", (self.default_course_id or "").strip())
        return {"type": "ir.actions.act_window_close"}

    def action_test(self):
        self.ensure_one()
        self.action_save()
        try:
            info = self.env["dhb.moodle.api"].test_connection()
        except UserError as exc:
            self.status = _("Failed: %s") % exc
            return self._reopen()
        self.status = _(
            "Connected to %(site)s, LMS %(release)s, as %(user)s."
        ) % {
            "site": info.get("sitename") or "?",
            "release": info.get("release") or "?",
            "user": info.get("username") or "?",
        }
        return self._reopen()

    def action_list_courses(self):
        """Show the course IDs, which are otherwise awkward to find."""
        self.ensure_one()
        self.action_save()
        courses = self.env["dhb.moodle.api"].list_courses()
        lines = [
            "%s — %s (%s)" % (c.get("id"), c.get("fullname"), c.get("shortname"))
            for c in courses if c.get("id") != 1
        ]
        self.status = "\n".join(lines) or _("No courses found.")
        return self._reopen()

    def _reopen(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }
