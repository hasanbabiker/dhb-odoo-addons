import logging

import requests

from odoo import models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

TIMEOUT = 30


class LMSApi(models.AbstractModel):
    """Thin client over LMS REST web services.

    LMS answers every call with HTTP 200, including failures: an error is a
    JSON body carrying an `exception` key. So every response is inspected
    rather than trusted, because a silently failed account creation looks
    exactly like a successful one to the caller.
    """

    _name = "dhb.moodle.api"
    _description = "LMS web services client"

    def _settings(self):
        icp = self.env["ir.config_parameter"].sudo()
        url = (icp.get_param("dhb_moodle.url") or "").rstrip("/")
        token = icp.get_param("dhb_moodle.token")
        if not (url and token):
            raise UserError(_(
                "LMS is not configured. Go to Events > Registration > "
                "LMS connection and enter the platform URL and web service "
                "token."
            ))
        return url, token

    def _call(self, function, params=None):
        url, token = self._settings()
        payload = {
            "wstoken": token,
            "wsfunction": function,
            "moodlewsrestformat": "json",
        }
        payload.update(self._flatten(params or {}))

        try:
            response = requests.post(
                "%s/webservice/rest/server.php" % url,
                data=payload,
                timeout=TIMEOUT,
            )
        except requests.RequestException as exc:
            raise UserError(_("Could not reach LMS: %s") % exc) from exc

        if response.status_code != 200:
            raise UserError(_(
                "LMS returned HTTP %(code)s:\n%(body)s",
                code=response.status_code, body=response.text[:300],
            ))

        try:
            data = response.json()
        except ValueError as exc:
            raise UserError(_(
                "LMS sent something that is not JSON. This usually means "
                "the URL points at a page rather than the web service:\n%s"
            ) % response.text[:300]) from exc

        if isinstance(data, dict) and data.get("exception"):
            raise UserError(_(
                "LMS refused the request.\n\n%(message)s\n\n(%(code)s)",
                message=data.get("message") or "?",
                code=data.get("errorcode") or data.get("exception"),
            ))
        return data

    def _flatten(self, params, prefix=""):
        """LMS expects nested data as users[0][username], not JSON."""
        flat = {}
        for key, value in params.items():
            name = "%s[%s]" % (prefix, key) if prefix else str(key)
            if isinstance(value, dict):
                flat.update(self._flatten(value, name))
            elif isinstance(value, (list, tuple)):
                for index, item in enumerate(value):
                    if isinstance(item, dict):
                        flat.update(self._flatten(item, "%s[%s]" % (name, index)))
                    else:
                        flat["%s[%s]" % (name, index)] = item
            elif isinstance(value, bool):
                flat[name] = 1 if value else 0
            elif value is not None:
                flat[name] = value
        return flat

    # ------------------------------------------------------------------
    def test_connection(self):
        return self._call("core_webservice_get_site_info")

    def find_user_by_email(self, email):
        result = self._call("core_user_get_users_by_field", {
            "field": "email", "values": [email],
        })
        return result[0] if result else False

    def create_user(self, values):
        result = self._call("core_user_create_users", {"users": [values]})
        return result[0] if result else False

    def update_user(self, values):
        return self._call("core_user_update_users", {"users": [values]})

    def enrol_user(self, user_id, course_id, role_id=5, suspend=False):
        """Enrol, optionally in a suspended state.

        Role 5 is Student in a default LMS install.
        """
        enrolment = {
            "roleid": role_id,
            "userid": user_id,
            "courseid": course_id,
        }
        if suspend:
            enrolment["suspend"] = 1
        return self._call("enrol_manual_enrol_users", {"enrolments": [enrolment]})

    def list_courses(self):
        return self._call("core_course_get_courses")
