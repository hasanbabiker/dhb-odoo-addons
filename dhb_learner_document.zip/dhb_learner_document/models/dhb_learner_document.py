# -*- coding: utf-8 -*-
import secrets
from datetime import timedelta

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class DhbLearnerDocument(models.Model):
    """A single document asked of an applicant during review.

    The registration link is spent once the learner's place is created, so a
    reviewer who finds an unreadable passport scan has no way to ask for a
    better one. This gives them one: a link that accepts exactly one file,
    and, when the reviewer accepts it, writes it onto the learner's contact
    record so it shows both on the application and in Contacts.
    """

    _name = "dhb.learner.document"
    _description = "Document requested from a learner"
    _inherit = ["mail.thread"]
    _order = "create_date desc"
    _rec_name = "name"

    # Which field on res.partner an accepted file lands in.
    # (binary field, filename field or None)
    TARGET_FIELDS = {
        "id_document": ("id_document_file", "id_document_filename"),
        "photo": ("image_1920", None),
    }

    MAX_BYTES = 10 * 1024 * 1024
    ALLOWED_TYPES = (
        "image/jpeg",
        "image/png",
        "image/heic",
        "image/heif",
        "application/pdf",
    )

    name = fields.Char(string="Reference", readonly=True, copy=False, index=True)

    invite_id = fields.Many2one(
        "dhb.registration.invite",
        string="Application",
        required=True,
        ondelete="cascade",
        index=True,
    )
    partner_id = fields.Many2one(
        "res.partner",
        related="invite_id.partner_id",
        string="Learner",
        store=True,
        readonly=True,
    )
    event_id = fields.Many2one(
        related="invite_id.event_id", string="Cohort", store=True, readonly=True
    )
    email = fields.Char(related="invite_id.email", string="Email", readonly=True)

    doc_type = fields.Selection(
        [
            ("id_document", "Identity document"),
            ("photo", "Photograph"),
            ("other", "Something else"),
        ],
        string="What is being asked for",
        required=True,
        default="id_document",
        help="Identity document and Photograph are written onto the learner's "
             "contact record when you accept them. Anything else is kept on "
             "this request only.",
    )
    reason = fields.Char(
        string="Why",
        required=True,
        help="The learner reads this on the upload page. Say what was wrong "
             "with the first one, e.g. the corners are cut off.",
    )

    token = fields.Char(readonly=True, copy=False, index=True)
    url = fields.Char(string="Upload link", compute="_compute_url")
    expiry_date = fields.Date(
        string="Valid until",
        default=lambda self: fields.Date.today() + timedelta(days=14),
        help="An abandoned link should not still work a year later.",
    )

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("sent", "Waiting on the learner"),
            ("uploaded", "Uploaded, not checked"),
            ("accepted", "Accepted"),
            ("rejected", "Rejected"),
            ("cancelled", "Cancelled"),
        ],
        default="draft",
        required=True,
        tracking=True,
    )

    file = fields.Binary(string="File", attachment=True, copy=False)
    filename = fields.Char(string="File name")
    uploaded_on = fields.Datetime(readonly=True)
    uploaded_ip = fields.Char(string="From IP", readonly=True)

    requested_by = fields.Many2one(
        "res.users", readonly=True, default=lambda self: self.env.user
    )
    sent_on = fields.Datetime(readonly=True)
    reviewed_by = fields.Many2one("res.users", readonly=True)
    reviewed_on = fields.Datetime(readonly=True)
    review_note = fields.Text(string="Note")

    reminder_count = fields.Integer(readonly=True, default=0)
    last_reminder_on = fields.Datetime(readonly=True)

    _sql_constraints = [
        ("token_uniq", "unique(token)", "The upload token must be unique."),
    ]

    # ------------------------------------------------------------------ crud

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("name"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "dhb.learner.document"
                ) or "/"
            if not vals.get("token"):
                vals["token"] = secrets.token_urlsafe(32)
        return super().create(vals_list)

    def _compute_url(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        for rec in self:
            rec.url = f"{base}/learner/document/{rec.token}" if rec.token else False

    # --------------------------------------------------------------- helpers

    def _doc_type_label(self):
        self.ensure_one()
        return dict(self._fields["doc_type"].selection).get(self.doc_type, "")

    def _is_live(self):
        """True while the learner may still use the link."""
        self.ensure_one()
        if self.state in ("accepted", "cancelled"):
            return False
        if self.expiry_date and self.expiry_date < fields.Date.today():
            return False
        return True

    def _attachments(self):
        return self.env["ir.attachment"].sudo().search([
            ("res_model", "=", self._name),
            ("res_id", "in", self.ids),
            ("res_field", "=", "file"),
        ])

    # --------------------------------------------------------------- actions

    def action_send(self):
        """Mail the learner the link, or send it again."""
        template = self.env.ref(
            "dhb_learner_document.mail_template_learner_document_request",
            raise_if_not_found=False,
        )
        for rec in self:
            if rec.state in ("accepted", "cancelled"):
                raise UserError(_("This request is already closed."))
            if not rec.email:
                raise UserError(
                    _("The application has no email address to send to.")
                )
            resend = rec.state == "sent"
            if template:
                template.send_mail(rec.id, force_send=True)
            rec.write({
                "state": "sent",
                "sent_on": fields.Datetime.now(),
                "reminder_count": rec.reminder_count + (1 if resend else 0),
                "last_reminder_on": fields.Datetime.now() if resend else False,
            })
            rec.invite_id.message_post(
                body=_("Asked the learner for a document — %(kind)s: %(why)s")
                % {"kind": rec._doc_type_label(), "why": rec.reason}
            )
        return True

    def action_accept(self):
        """Put the file where it belongs and close the request."""
        for rec in self:
            if not rec.file:
                raise UserError(_("Nothing has been uploaded yet."))
            target = self.TARGET_FIELDS.get(rec.doc_type)
            if target and rec.partner_id:
                file_field, name_field = target
                values = {file_field: rec.file}
                if name_field:
                    values[name_field] = rec.filename
                rec.partner_id.sudo().write(values)
            rec.write({
                "state": "accepted",
                "reviewed_by": self.env.user.id,
                "reviewed_on": fields.Datetime.now(),
            })
            rec.invite_id.message_post(
                body=_("Accepted the replacement %s.") % rec._doc_type_label()
            )
        return True

    def action_reject(self):
        """Still not good enough. The same link keeps working."""
        for rec in self:
            if rec.state != "uploaded":
                raise UserError(_("There is nothing to reject."))
            rec.write({
                "state": "rejected",
                "reviewed_by": self.env.user.id,
                "reviewed_on": fields.Datetime.now(),
            })
            rec.invite_id.message_post(
                body=_("Rejected the document the learner sent. %s")
                % (rec.review_note or "")
            )
        return True

    def action_cancel(self):
        self.write({"state": "cancelled"})
        return True

    def action_reset_to_draft(self):
        self.write({"state": "draft"})
        return True

    def action_open_learner(self):
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_("No learner contact on this application yet."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "res.partner",
            "res_id": self.partner_id.id,
            "view_mode": "form",
            "target": "current",
        }

    # ----------------------------------------------------------- maintenance

    @api.autovacuum
    def _gc_expired(self):
        """Close links nobody used. Keeps the queue honest."""
        stale = self.search([
            ("state", "in", ("sent", "rejected")),
            ("expiry_date", "<", fields.Date.today()),
        ])
        stale.write({"state": "cancelled"})
