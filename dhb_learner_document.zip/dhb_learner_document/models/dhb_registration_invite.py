# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError


class DhbRegistrationInvite(models.Model):
    _inherit = "dhb.registration.invite"

    document_request_ids = fields.One2many(
        "dhb.learner.document",
        "invite_id",
        string="Documents asked for",
    )
    document_request_count = fields.Integer(
        compute="_compute_document_request_counts"
    )
    document_request_pending = fields.Integer(
        string="Awaiting documents",
        compute="_compute_document_request_counts",
        help="Requests the learner has not satisfied yet, plus uploads nobody "
             "has checked.",
    )

    @api.depends("document_request_ids.state")
    def _compute_document_request_counts(self):
        for rec in self:
            requests = rec.document_request_ids
            rec.document_request_count = len(requests)
            rec.document_request_pending = len(
                requests.filtered(
                    lambda r: r.state in ("sent", "uploaded", "rejected")
                )
            )

    # ------------------------------------------------------------------
    #  Put the application into the "chase documents" queue while a request
    #  is outstanding.
    #
    #  If the base module computes next_action under a different method name
    #  this override is simply never called, and nothing breaks.
    # ------------------------------------------------------------------
    def _compute_next_action(self):
        parent = getattr(super(), "_compute_next_action", None)
        if parent:
            parent()
        for rec in self:
            if rec.state in ("submitted", "review") and rec.document_request_pending:
                rec.next_action = "chase_documents"

    # --------------------------------------------------------------- actions

    def action_request_document(self):
        """Open a blank request already pointed at this application."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Ask the learner for a document"),
            "res_model": "dhb.learner.document",
            "view_mode": "form",
            "view_id": self.env.ref(
                "dhb_learner_document.view_dhb_learner_document_form"
            ).id,
            "target": "new",
            "context": {
                "default_invite_id": self.id,
                "default_doc_type": "id_document",
            },
        }

    def action_open_document_requests(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Documents asked for"),
            "res_model": "dhb.learner.document",
            "view_mode": "list,form",
            "domain": [("invite_id", "=", self.id)],
            "context": {"default_invite_id": self.id},
        }

    def action_open_learner(self):
        """The identity fields live on the contact. Do not make the reviewer
        go and look for it."""
        self.ensure_one()
        if not self.partner_id:
            raise UserError(
                _("No learner contact on this application yet. One is created "
                  "when the learner submits the registration form.")
            )
        return {
            "type": "ir.actions.act_window",
            "name": self.partner_id.display_name,
            "res_model": "res.partner",
            "res_id": self.partner_id.id,
            "view_mode": "form",
            "target": "current",
        }
