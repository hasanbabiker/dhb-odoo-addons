# -*- coding: utf-8 -*-
{
    "name": "DHB Admissions: ask the learner for a document",
    "summary": "Request a replacement or extra document from an applicant "
               "without reopening the whole registration form.",
    "version": "1.0.0",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "category": "Education",

    # ------------------------------------------------------------------
    #  ONE THING TO EDIT.
    #
    #  Replace "dhb_admissions" below with the technical name of your own
    #  admissions module - the one that defines dhb.registration.invite.
    #
    #  To find it: turn on developer mode, then
    #      Settings > Technical > Database Structure > Models
    #      search  dhb.registration.invite
    #      the "In Modules" column is the name you need.
    #
    #  Nothing else in this module needs changing.
    # ------------------------------------------------------------------
    "depends": [
        "mail",
        "website",
        "dhb_admissions",
    ],

    "data": [
        "security/ir.model.access.csv",
        "data/ir_sequence.xml",
        "data/mail_template.xml",
        "views/learner_document_templates.xml",
        "views/dhb_learner_document_views.xml",
        "views/dhb_registration_invite_views.xml",
    ],

    "installable": True,
    "application": False,
    "auto_install": False,
}
