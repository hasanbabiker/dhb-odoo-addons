# -*- coding: utf-8 -*-
import base64
import logging

from odoo import http, fields, _
from odoo.http import request

_logger = logging.getLogger(__name__)


class LearnerDocumentController(http.Controller):
    """The public page a learner uses to send one replacement document.

    Deliberately narrow: one file, no login, no way to see or change anything
    else about the application.
    """

    def _get_request(self, token):
        if not token:
            return None
        doc = request.env["dhb.learner.document"].sudo().search(
            [("token", "=", token)], limit=1
        )
        if not doc or not doc._is_live():
            return None
        return doc

    @http.route(
        "/learner/document/<string:token>",
        type="http",
        auth="public",
        website=True,
        sitemap=False,
    )
    def upload_form(self, token, **kw):
        doc = self._get_request(token)
        if not doc:
            return request.render("dhb_learner_document.document_link_not_valid")
        return request.render(
            "dhb_learner_document.learner_document_upload",
            {"req": doc, "error": kw.get("error")},
        )

    @http.route(
        "/learner/document/<string:token>/submit",
        type="http",
        auth="public",
        website=True,
        csrf=True,
        methods=["POST"],
    )
    def upload_submit(self, token, **post):
        doc = self._get_request(token)
        if not doc:
            return request.render("dhb_learner_document.document_link_not_valid")

        upload = post.get("file")
        if not upload or not upload.filename:
            return request.redirect(f"/learner/document/{token}?error=missing")

        content = upload.read()
        if not content:
            return request.redirect(f"/learner/document/{token}?error=missing")
        if len(content) > doc.MAX_BYTES:
            return request.redirect(f"/learner/document/{token}?error=too_big")
        if (upload.content_type or "").lower() not in doc.ALLOWED_TYPES:
            return request.redirect(f"/learner/document/{token}?error=type")

        doc.sudo().write({
            "file": base64.b64encode(content),
            "filename": upload.filename,
            "uploaded_on": fields.Datetime.now(),
            "uploaded_ip": request.httprequest.remote_addr,
            "state": "uploaded",
        })

        invite = doc.invite_id.sudo()
        invite.message_post(
            body=_("The learner uploaded a document: %s") % doc._doc_type_label()
        )
        try:
            invite.activity_schedule(
                "mail.mail_activity_data_todo",
                user_id=doc.requested_by.id or request.env.ref("base.user_admin").id,
                summary=_("Check the document the learner sent"),
                note=doc.reason or "",
            )
        except Exception:  # an activity is a convenience, not the point
            _logger.warning(
                "Could not schedule review activity for %s", doc.name, exc_info=True
            )

        return request.render(
            "dhb_learner_document.learner_document_thanks", {"req": doc}
        )
