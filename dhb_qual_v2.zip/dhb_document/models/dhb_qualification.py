from odoo import models, fields, api, _


class DhbQualification(models.Model):
    """Everything held for this qualification, gathered from its courses.

    A rollup, not a second link. Material stays attached to the course it is
    taught from, and that is the right place for it: the Arabic scheme of
    work is not the English one, and a syllabus that belonged to the
    qualification would have to be filed twice anyway once there are two
    languages.

    What the qualification needs is the question nobody could answer before:
    show me everything we hold for the IGC - every language, every mode -
    because that is the list an awarding body asks for, and the list that
    has to be replaced when the syllabus edition changes.
    """

    _inherit = "dhb.qualification"

    document_ids = fields.Many2many(
        "dhb.document", string="Material", compute="_compute_document_ids")
    document_count = fields.Integer(compute="_compute_document_ids")
    document_stale_count = fields.Integer(compute="_compute_document_ids")

    @api.depends("course_ids.document_ids",
                 "course_ids.document_ids.state",
                 "course_ids.document_ids.next_review_date")
    def _compute_document_ids(self):
        for qualification in self:
            documents = qualification.course_ids.mapped("document_ids")
            qualification.document_ids = documents
            qualification.document_count = len(documents)
            qualification.document_stale_count = len(
                documents.filtered("review_due"))

    def action_open_documents(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Material for %s") % self.display_name,
            "res_model": "dhb.document",
            "view_mode": "kanban,list,form",
            "domain": [("course_ids.qualification_id", "=", self.id)],
        }
