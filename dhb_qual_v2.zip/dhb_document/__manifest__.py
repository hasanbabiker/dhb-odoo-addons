{
    "name": "DHB Documents",
    "version": "19.0.2.0.0",
    "summary": "Controlled course material: one current version, a history "
               "behind it, and a change request for everything that moves",
    "description": """
DHB Documents
=============

Course books, schemes of work, presentations, mock papers, final tests and
their model answers, past papers, practical project templates. The material
a training centre lives on.

This is document control, not a filing cabinet. A shared folder answers
"where is the file". It cannot answer the four questions an awarding body
asks:

* **Which version is the current one?** - the one a tutor may hand out
  today, as opposed to the eleven files whose names end in "final v3".
* **Who approved it, and when?**
* **What changed, and why?** - and who asked: the awarding body, a tutor, a
  learner, or our own review.
* **When was it last looked at?** - a course book that nobody has reviewed
  in three years is a finding waiting to be written.

So the unit here is a *document* - an item of material that persists - and
the file is a *version* of it. Approving a version supersedes the one before
it and never overwrites it. Every change starts as a request, carries where
it came from, and ends attached to the version that delivered it.

Exam material
-------------
Final tests, model answers and live papers are marked exam-secure and are
readable only by the group that is allowed to hold them. A model answer
sitting in the same list as a course handout is how a paper leaks.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Education",
    "license": "LGPL-3",
    "depends": ["base", "mail", "contacts", "dhb_batch"],
    "data": [
        "security/document_groups.xml",
        "security/ir.model.access.csv",
        "security/document_rules.xml",
        "data/document_category_data.xml",
        "data/document_cron.xml",
        "views/document_category_views.xml",
        "views/document_version_views.xml",
        "views/document_change_views.xml",
        "views/document_views.xml",
        "views/course_views.xml",
        "views/qualification_views.xml",
        "report/document_register_report.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
