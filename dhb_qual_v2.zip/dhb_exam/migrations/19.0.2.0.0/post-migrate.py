"""Move the unit links from the course up to the qualification.

IG1 was tied to the IGC *course*. It is a fact about the IGC itself, so it
now ties to the qualification - which means it survives the day a second
course of the IGC is created, instead of quietly not applying to it.

The old many-to-many table is read here rather than in a pre-migrate step
because Odoo does not drop it: the field stops using it, the rows stay.
Reading it after the schema has settled is therefore safe, and it is the
only copy of this information that exists.

Nothing is invented. A unit linked to two courses of the same qualification
produces one link, not two; a unit linked to a course with no qualification
is left alone and reported, because the alternative is dropping it silently.
"""

import logging

_logger = logging.getLogger(__name__)

OLD_TABLE = "dhb_exam_unit_course_rel"
NEW_TABLE = "dhb_exam_unit_qualification_rel"


def migrate(cr, version):
    if not version:
        return

    cr.execute("SELECT to_regclass(%s)", (OLD_TABLE,))
    if not cr.fetchone()[0]:
        # ERROR, not INFO. If this table is not there under this name, the
        # only copy of the unit-to-course links has not been moved, every
        # course will report "Units" missing and refuse to be activated, and
        # the exam app will silently find nothing to chase. That is not a
        # note to leave at the bottom of an upgrade log.
        _logger.error(
            "Exam units: table %s not found. The unit links have NOT been "
            "moved onto the qualifications and have to be made by hand on "
            "Exams > Configuration > Units.", OLD_TABLE)
        return

    cr.execute("SELECT COUNT(*) FROM dhb_exam_unit_course_rel")
    source_rows = cr.fetchone()[0]

    # Orphans first, so they are reported even though the insert below would
    # simply skip them.
    cr.execute("""
        SELECT u.code, c.code
          FROM dhb_exam_unit_course_rel rel
          JOIN dhb_exam_unit u ON u.id = rel.unit_id
          JOIN dhb_course c ON c.id = rel.course_id
         WHERE c.qualification_id IS NULL
    """)
    orphans = cr.fetchall()
    for unit_code, course_code in orphans:
        _logger.warning(
            "Exam units: %s is linked to course %s, which has no "
            "qualification. That link could not be moved and has to be "
            "made by hand.", unit_code, course_code)

    cr.execute("""
        INSERT INTO dhb_exam_unit_qualification_rel
                    (unit_id, qualification_id)
        SELECT DISTINCT rel.unit_id, c.qualification_id
          FROM dhb_exam_unit_course_rel rel
          JOIN dhb_course c ON c.id = rel.course_id
         WHERE c.qualification_id IS NOT NULL
        ON CONFLICT DO NOTHING
    """)
    moved = cr.rowcount

    cr.execute("SELECT COUNT(*) FROM dhb_exam_unit_qualification_rel")
    final_rows = cr.fetchone()[0]

    if source_rows and not final_rows:
        _logger.error(
            "Exam units: %s links existed and none arrived. Every course "
            "will now report its units missing. Check "
            "dhb_exam_unit_qualification_rel before using the Exams app.",
            source_rows)
    else:
        _logger.info(
            "Exam units: %s source links, %s moved, %s left behind, %s now "
            "on qualifications.",
            source_rows, moved, len(orphans), final_rows)
