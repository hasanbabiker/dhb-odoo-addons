from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbExamEntryWizard(models.TransientModel):
    """Enter a batch for a sitting in one pass.

    Entering learners one at a time is how a deadline gets missed: twenty
    forms, each needing the sitting, the unit and the candidate number
    picked again. This asks for those three once and lists everybody who is
    not already entered, with the people who have nothing standing in their
    way already ticked.
    """

    _name = "dhb.exam.entry.wizard"
    _description = "Enter learners for a sitting"

    batch_id = fields.Many2one(
        "dhb.batch", string="Batch",
        help="Leave empty to enter learners from several batches - the list "
             "below then covers everyone the unit applies to.")
    course_id = fields.Many2one(
        related="batch_id.course_id", string="Course")
    # Carried for the unit dropdown's domain. It has to be the qualification
    # and not the course: the unit's `course_ids` is computed now, and a
    # domain on a field with no column behind it cannot be searched at all -
    # it raises rather than returning nothing, in the middle of a wizard
    # somebody opened to meet an entry deadline.
    qualification_id = fields.Many2one(
        related="batch_id.course_id.qualification_id",
        string="Qualification")
    unit_id = fields.Many2one(
        "dhb.exam.unit", string="Unit", required=True,
        compute="_compute_unit_id", store=True, readonly=False,
        precompute=True)
    sitting_id = fields.Many2one(
        "dhb.nebosh.sitting", string="Sitting", required=True)

    entry_deadline = fields.Date(
        related="sitting_id.booking_deadline", string="Entries close")
    assessment_date = fields.Date(
        related="sitting_id.assessment_date", string="Sits on")

    line_ids = fields.One2many(
        "dhb.exam.entry.wizard.line", "wizard_id", string="Learners",
        compute="_compute_line_ids", store=True, readonly=False)

    already_entered_count = fields.Integer(compute="_compute_line_ids",
                                           store=True)

    @api.depends("sitting_id", "batch_id")
    def _compute_unit_id(self):
        units = self.env["dhb.exam.unit"]
        for wizard in self:
            if wizard.unit_id:
                continue
            code = (wizard.sitting_id.unit_code or "").strip()
            if code:
                wizard.unit_id = units.search(
                    [("code", "=ilike", code)], limit=1)
            elif wizard.batch_id.course_id.qualification_id:
                candidates = units.search([
                    ("qualification_ids", "in",
                     wizard.batch_id.course_id.qualification_id.id)])
                # Only when there is no choice to make. Picking the first of
                # two units would be a guess dressed as a default.
                if len(candidates) == 1:
                    wizard.unit_id = candidates

    @api.depends("batch_id", "unit_id", "sitting_id")
    def _compute_line_ids(self):
        entries = self.env["dhb.exam.entry"]
        for wizard in self:
            wizard.line_ids = [(5, 0, 0)]
            wizard.already_entered_count = 0
            if not wizard.batch_id or not wizard.unit_id:
                continue
            places = wizard.batch_id.registration_ids.filtered(
                lambda line: line.state in ("open", "done"))
            existing = entries.search([
                ("unit_id", "=", wizard.unit_id.id),
                ("partner_id", "in", places.mapped("partner_id").ids),
                ("state", "!=", "withdrawn"),
            ])
            # Somebody who has already passed this unit does not sit it
            # again, and somebody already entered for this sitting is not
            # offered twice.
            done = existing.filtered(
                lambda e: e.outcome == "pass"
                or e.sitting_id == wizard.sitting_id)
            wizard.already_entered_count = len(done)
            settled = done.mapped("partner_id")
            wizard.line_ids = [
                (0, 0, {
                    "partner_id": place.partner_id.id,
                    "registration_id": place.id,
                    "selected": True,
                })
                for place in places
                if place.partner_id and place.partner_id not in settled
            ]

    def action_create_entries(self):
        self.ensure_one()
        chosen = self.line_ids.filtered("selected")
        if not chosen:
            raise UserError(_(
                "Nobody is ticked. Tick at least one learner, or close this "
                "and nothing happens."))
        entries = self.env["dhb.exam.entry"].create([
            {
                "sitting_id": self.sitting_id.id,
                "unit_id": self.unit_id.id,
                "partner_id": line.partner_id.id,
                "batch_id": self.batch_id.id or False,
                "registration_id": line.registration_id.id or False,
                "candidate_number": line.candidate_number or False,
                "state": "draft",
            }
            for line in chosen
        ])
        if self.batch_id:
            self.batch_id.message_post(body=_(
                "%(count)s learners put forward for %(unit)s at %(sitting)s.",
                count=len(entries), unit=self.unit_id.display_name,
                sitting=self.sitting_id.display_name,
            ))
        return {
            "type": "ir.actions.act_window",
            "name": _("Entries for %s") % self.sitting_id.display_name,
            "res_model": "dhb.exam.entry",
            "view_mode": "list,form",
            "domain": [("id", "in", entries.ids)],
        }


class DhbExamEntryWizardLine(models.TransientModel):
    _name = "dhb.exam.entry.wizard.line"
    _description = "Learner to enter"

    wizard_id = fields.Many2one(
        "dhb.exam.entry.wizard", required=True, ondelete="cascade")
    selected = fields.Boolean(string="Enter", default=True)
    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True)
    registration_id = fields.Many2one("dhb.batch.line", string="Place")
    candidate_number = fields.Char(string="Candidate number")
