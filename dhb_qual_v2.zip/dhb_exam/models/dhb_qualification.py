from odoo import models, fields, api, _


class DhbQualification(models.Model):
    """Which units a learner has to pass to hold this qualification.

    The other side of the link declared on the unit. It is here rather than
    on the course because a unit is a fact about what the awarding body
    assesses, and the awarding body has never heard of our Arabic evening
    Zoom variant.
    """

    _inherit = "dhb.qualification"

    exam_unit_ids = fields.Many2many(
        "dhb.exam.unit", "dhb_exam_unit_qualification_rel",
        "qualification_id", "unit_id", string="Assessed by")
    exam_unit_count = fields.Integer(compute="_compute_exam_unit_count")

    @api.depends("exam_unit_ids")
    def _compute_exam_unit_count(self):
        for qualification in self:
            qualification.exam_unit_count = len(qualification.exam_unit_ids)

    def action_open_exam_units(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Units of %s") % self.display_name,
            "res_model": "dhb.exam.unit",
            "view_mode": "list,form",
            "domain": [("qualification_ids", "in", self.id)],
            "context": {"default_qualification_ids": [(4, self.id)]},
        }
