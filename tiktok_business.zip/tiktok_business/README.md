# TikTok Business — وحدة أوديو 19

تكامل مستقل بين أوديو و TikTok. **لا يعتمد على تطبيق Social Marketing الخاص بنسخة Enterprise**،
لذلك يعمل على Community و Enterprise على حدّ سواء.

## المميزات

| | |
|---|---|
| ربط الحسابات | OAuth2 عبر TikTok Login Kit، عدة حسابات، تجديد تلقائي للتوكن |
| النشر | فيديو أو ألبوم صور، نشر مباشر أو إرسال إلى مسودات TikTok |
| مصدر الملف | رفع من أوديو (`FILE_UPLOAD`) أو سحب من رابط (`PULL_FROM_URL`) |
| الجدولة | تاريخ نشر + عرض تقويم + كرون ينشر عند الاستحقاق |
| متابعة الحالة | استعلام دوري عن `publish_id` حتى يصل إلى `PUBLISH_COMPLETE` |
| المزامنة | سحب الفيديوهات المنشورة مع المشاهدات والإعجابات والتعليقات والمشاركات |
| التحليلات | Reach، متوسط مدة المشاهدة، نسبة إكمال الفيديو (عبر Business Account API) |
| التعليقات | صندوق تعليقات داخل أوديو: رد، إعجاب، حذف |
| Webhooks | نقطة استقبال `/tiktok/webhook` مع تحقق من التوقيع |

## الهيكل

```
tiktok_business/
├── models/
│   ├── tiktok_api.py          طبقة HTTP لكل واجهات TikTok الثلاث
│   ├── tiktok_account.py      الحساب، التوكنات، المزامنة، الكرونات
│   ├── tiktok_post.py         المحرّر: بناء الـ payload والنشر والجدولة
│   ├── tiktok_publication.py  نتيجة النشر لكل حساب + متابعة الحالة
│   ├── tiktok_video.py        الفيديوهات المنشورة ومؤشراتها
│   └── tiktok_comment.py      التعليقات + معالج الرد
├── controllers/main.py        callback الخاص بـ OAuth + webhook
├── views/ security/ data/
```

## التثبيت

1. انسخ مجلد `tiktok_business` إلى مسار addons.
2. وضع المطوّر → **Apps → Update Apps List** → ثبّت `TikTok Business`.

## إعداد تطبيق TikTok

على [developers.tiktok.com](https://developers.tiktok.com) أنشئ تطبيقًا ثم:

1. **Login Kit → Web** وأضف الـ Redirect URI الذي يعرضه أوديو في
   **Settings → TikTok Business** (يكون بالشكل `https://your-domain.com/tiktok/oauth/callback`).
   لا بد أن يكون HTTPS ونطاقًا حقيقيًا؛ `localhost` مرفوض.
2. **Content Posting API** وفعّل `Direct Post` و`Upload`.
3. إن أردت نشر الصور أو استخدام `PULL_FROM_URL` فيجب توثيق النطاق
   عبر **Verify domains** بإضافة سجل DNS TXT.
4. انسخ **Client Key** و **Client Secret** إلى إعدادات أوديو.

ثم من أوديو: **TikTok → Configuration → Connect an Account**.

## تحذيرات مهمة قبل الإنتاج

**قبل مراجعة TikTok لتطبيقك (App Review) ستكون في وضع Sandbox:**

- النشر ممكن فقط بخصوصية **Private** (`SELF_ONLY`). لهذا القيمة الافتراضية في
  الوحدة هي Private وليست Public — تغييرها قبل الموافقة سيُرجع خطأ من TikTok.
- الحصص (quota) محدودة جدًا.
- للنشر العام يجب تقديم الطلب على
  `developers.tiktok.com/application/content-posting-api`.

**الصلاحيات (scopes):** الوحدة تطلب `user.info.*` و`video.list` و`video.publish`،
وعند تفعيل خيار Business API تضيف `comment.list` و`comment.list.manage`.
كل صلاحية تتجاوز `user.info.basic` تحتاج موافقة على تطبيقك.

**الإفصاح التجاري:** منذ أكتوبر 2025 تشترط TikTok وسم المحتوى الترويجي.
الحقول موجودة في تبويب TikTok Settings (`brand_organic_toggle` للترويج الذاتي،
`brand_content_toggle` للشراكة المدفوعة). TikTok ترفض المحتوى المدفوع على
المنشورات الخاصة، والوحدة تمنع هذه التركيبة قبل الإرسال.

**التعليقات والتحليلات المتقدمة** تمرّ عبر Business Account API
(`business-api.tiktok.com/open_api/v1.3`) وتحتاج حساب TikTok Business
و`Business ID` مضبوطًا على بطاقة الحساب في أوديو.

## نقطة تحتاج انتباهك

أسماء الحقول في Business Account API قد تتغير بين إصدارات TikTok. الكود يقرأ
الحقول بشكل متسامح (`comments` أو `list`، `item_id` أو `video_id`) لكن إن ظهر
خطأ من TikTok فسيصلك نصّه كاملًا في الواجهة، وهو كافٍ لتعديل التعيين.

## الرخصة

LGPL-3 — الكود مكتوب من الصفر، ولا يحتوي على شيء منقول من الوحدات التجارية
المنشورة على متجر أوديو.
