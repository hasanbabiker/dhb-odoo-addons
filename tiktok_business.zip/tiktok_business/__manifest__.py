# -*- coding: utf-8 -*-
{
    "name": "TikTok Business",
    "version": "19.0.1.0.0",
    "category": "Marketing",
    "summary": "Connect TikTok Business accounts to Odoo: publish videos and "
               "photos, sync posts and insights, manage comments, receive webhooks.",
    "description": """
TikTok Business for Odoo
========================

Standalone TikTok integration - works on Odoo Community and Enterprise, no
dependency on the Enterprise *Social Marketing* app.

* OAuth2 (TikTok Login Kit) connection of one or several accounts.
* Automatic access-token refresh.
* Publish videos and photo carousels through the Content Posting API
  (direct post or draft upload, file upload or pull-from-URL).
* Scheduling, with a cron that publishes when due and polls publish status.
* Sync your published videos with their insights (views, likes, comments,
  shares) into Odoo.
* Comment inbox: list, reply, like and delete comments (TikTok Business
  Account API).
* Webhook endpoint for post-status and comment events.
""",
    "author": "",
    "website": "",
    "license": "LGPL-3",
    "depends": ["base", "mail"],
    "external_dependencies": {"python": ["requests"]},
    "data": [
        "security/tiktok_security.xml",
        "security/ir.model.access.csv",
        "data/ir_cron.xml",
        "views/tiktok_comment_views.xml",
        "views/tiktok_video_views.xml",
        "views/tiktok_post_views.xml",
        "views/tiktok_account_views.xml",
        "views/res_config_settings_views.xml",
        "views/tiktok_menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
