# -*- coding: utf-8 -*-

from datetime import datetime

from odoo import _, api, fields, models

from .tiktok_api import TikTokAPI, TikTokError


class TikTokVideo(models.Model):
    _name = "tiktok.video"
    _description = "TikTok Video"
    _order = "published_date desc, id desc"

    account_id = fields.Many2one(
        "tiktok.account", string="Account", required=True,
        ondelete="cascade", index=True)
    company_id = fields.Many2one(related="account_id.company_id", store=True)

    video_id = fields.Char("TikTok Video ID", required=True, index=True)
    name = fields.Char("Title", required=True, default="TikTok video")
    caption = fields.Text("Caption")
    published_date = fields.Datetime("Published On")
    duration = fields.Integer("Duration (s)")
    cover_url = fields.Char("Cover Image URL")
    share_url = fields.Char("Share Link")
    embed_link = fields.Char("Embed Link")

    # basic metrics (Display API)
    view_count = fields.Integer("Views")
    like_count = fields.Integer("Likes")
    comment_count = fields.Integer("Comments")
    share_count = fields.Integer("Shares")

    # extended metrics (Business Account API)
    reach = fields.Integer("Reach")
    average_time_watched = fields.Float("Avg. Watch Time (s)")
    full_video_watched_rate = fields.Float("Completion Rate (%)")
    total_time_watched = fields.Float("Total Watch Time (s)")

    engagement = fields.Integer(
        "Engagement", compute="_compute_engagement", store=True)
    engagement_rate = fields.Float(
        "Engagement Rate (%)", compute="_compute_engagement", store=True,
        digits=(16, 2))

    comment_ids = fields.One2many("tiktok.comment", "video_id", string="Comments")
    comments_synced = fields.Datetime("Comments Last Synced", readonly=True)

    _sql_constraints = [
        ("video_account_uniq", "unique(video_id, account_id)",
         "This video is already synchronised for this account."),
    ]

    @api.depends("view_count", "like_count", "comment_count", "share_count")
    def _compute_engagement(self):
        for video in self:
            video.engagement = video.like_count + video.comment_count + video.share_count
            video.engagement_rate = (
                (video.engagement / video.view_count * 100.0)
                if video.view_count else 0.0
            )

    # ==================================================================
    # sync
    # ==================================================================
    @api.model
    def _upsert_from_tiktok(self, account, videos):
        existing = {
            video.video_id: video
            for video in self.search([
                ("account_id", "=", account.id),
                ("video_id", "in", [str(v.get("id")) for v in videos]),
            ])
        }
        to_create = []
        for payload in videos:
            values = self._values_from_display_api(account, payload)
            video = existing.get(values["video_id"])
            if video:
                video.write(values)
            else:
                to_create.append(values)
        if to_create:
            self.create(to_create)

    @api.model
    def _values_from_display_api(self, account, payload):
        create_time = payload.get("create_time")
        title = (payload.get("title")
                 or (payload.get("video_description") or "")[:80]
                 or _("TikTok video"))
        return {
            "account_id": account.id,
            "video_id": str(payload.get("id")),
            "name": title,
            "caption": payload.get("video_description"),
            "published_date": (
                datetime.utcfromtimestamp(int(create_time)) if create_time else False),
            "duration": payload.get("duration") or 0,
            "cover_url": payload.get("cover_image_url"),
            "share_url": payload.get("share_url"),
            "embed_link": payload.get("embed_link"),
            "view_count": payload.get("view_count") or 0,
            "like_count": payload.get("like_count") or 0,
            "comment_count": payload.get("comment_count") or 0,
            "share_count": payload.get("share_count") or 0,
        }

    @api.model
    def _apply_business_insights(self, account, videos):
        for payload in videos:
            item_id = str(payload.get("item_id") or payload.get("video_id") or "")
            if not item_id:
                continue
            video = self.search([
                ("account_id", "=", account.id),
                ("video_id", "=", item_id),
            ], limit=1)
            values = {
                "reach": payload.get("reach") or 0,
                "average_time_watched": payload.get("average_time_watched") or 0.0,
                "full_video_watched_rate": payload.get("full_video_watched_rate") or 0.0,
                "total_time_watched": payload.get("total_time_watched") or 0.0,
                "view_count": payload.get("video_views") or 0,
                "like_count": payload.get("likes") or 0,
                "comment_count": payload.get("comments") or 0,
                "share_count": payload.get("shares") or 0,
            }
            if video:
                video.write(values)
            else:
                create_time = payload.get("create_time")
                values.update({
                    "account_id": account.id,
                    "video_id": item_id,
                    "name": (payload.get("caption") or _("TikTok video"))[:80],
                    "caption": payload.get("caption"),
                    "cover_url": payload.get("thumbnail_url"),
                    "share_url": payload.get("share_url"),
                    "embed_link": payload.get("embed_url"),
                    "published_date": (
                        datetime.utcfromtimestamp(int(create_time))
                        if create_time else False),
                })
                self.create(values)

    def action_sync_comments(self):
        Comment = self.env["tiktok.comment"]
        for video in self:
            account = video.account_id
            if not (account.business_id and account._business_api_enabled()):
                continue
            token = account._token()
            cursor, fetched = 0, 0
            while fetched < 300:
                try:
                    data = TikTokAPI.comment_list(
                        token, account.business_id, video.video_id, cursor=cursor)
                except TikTokError:
                    break
                comments = data.get("comments") or data.get("list") or []
                if not comments:
                    break
                Comment._upsert_from_tiktok(video, comments)
                fetched += len(comments)
                cursor = data.get("cursor") or 0
                if not data.get("has_more"):
                    break
            video.comments_synced = fields.Datetime.now()
        return True

    def action_open_on_tiktok(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "new",
            "url": self.share_url or "https://www.tiktok.com/",
        }
