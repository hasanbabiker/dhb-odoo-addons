# -*- coding: utf-8 -*-

import logging
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .tiktok_api import TikTokAPI, TikTokError, DEFAULT_SCOPES, BUSINESS_SCOPES

_logger = logging.getLogger(__name__)

# Refresh a token when it has less than this left before expiry.
REFRESH_MARGIN = timedelta(hours=6)


class TikTokAccount(models.Model):
    _name = "tiktok.account"
    _description = "TikTok Account"
    _inherit = ["mail.thread"]
    _rec_name = "display_name_tiktok"
    _order = "display_name_tiktok, id"

    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        "res.company", string="Company", required=True,
        default=lambda self: self.env.company)

    # -- identity ------------------------------------------------------
    open_id = fields.Char("Open ID", required=True, readonly=True, copy=False, index=True)
    union_id = fields.Char("Union ID", readonly=True, copy=False)
    business_id = fields.Char(
        "Business ID",
        help="Required for the Business Account API (insights and comments). "
             "TikTok returns it as the account's open_id for business accounts.")
    display_name_tiktok = fields.Char("Display Name", readonly=True)
    username = fields.Char("Handle", readonly=True)
    avatar_url = fields.Char("Avatar URL", readonly=True)
    profile_url = fields.Char("Profile Link", readonly=True)
    is_verified = fields.Boolean("Verified", readonly=True)

    # -- tokens --------------------------------------------------------
    access_token = fields.Char(readonly=True, copy=False, groups="base.group_system")
    refresh_token = fields.Char(readonly=True, copy=False, groups="base.group_system")
    token_expiry = fields.Datetime("Token Expires On", readonly=True, copy=False)
    refresh_expiry = fields.Datetime("Refresh Token Expires On", readonly=True, copy=False)
    granted_scopes = fields.Char("Granted Scopes", readonly=True)
    state = fields.Selection(
        [("connected", "Connected"), ("expired", "Expired"), ("error", "Error")],
        default="connected", readonly=True, tracking=True)
    last_error = fields.Char(readonly=True)

    # -- stats ---------------------------------------------------------
    follower_count = fields.Integer(readonly=True)
    following_count = fields.Integer(readonly=True)
    likes_count = fields.Integer("Total Likes", readonly=True)
    video_count = fields.Integer(readonly=True)
    last_sync = fields.Datetime("Last Synchronisation", readonly=True)

    video_ids = fields.One2many("tiktok.video", "account_id", string="Videos")
    comment_ids = fields.One2many("tiktok.comment", "account_id", string="Comments")

    _sql_constraints = [
        ("open_id_company_uniq", "unique(open_id, company_id)",
         "This TikTok account is already connected for this company."),
    ]

    @api.depends("display_name_tiktok", "username", "open_id")
    def _compute_display_name(self):
        for account in self:
            handle = account.username and "@%s" % account.username
            account.display_name = account.display_name_tiktok or handle or account.open_id

    # ==================================================================
    # credentials
    # ==================================================================
    @api.model
    def _get_app_credentials(self):
        params = self.env["ir.config_parameter"].sudo()
        key = params.get_param("tiktok_business.client_key")
        secret = params.get_param("tiktok_business.client_secret")
        if not key or not secret:
            raise UserError(_(
                "Set the TikTok Client Key and Client Secret first "
                "(Settings > TikTok Business)."))
        return key, secret

    @api.model
    def _get_redirect_uri(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        if not base or base.startswith("http://localhost"):
            raise UserError(_(
                "TikTok only accepts an HTTPS, publicly reachable redirect URI. "
                "Set 'web.base.url' to your real domain first."))
        return "%s/tiktok/oauth/callback" % base

    @api.model
    def _get_scopes(self):
        scopes = list(DEFAULT_SCOPES)
        use_business = self.env["ir.config_parameter"].sudo().get_param(
            "tiktok_business.use_business_api")
        if use_business:
            scopes += BUSINESS_SCOPES
        return scopes

    def _token(self):
        """Return a valid access token, refreshing it first if needed."""
        self.ensure_one()
        account = self.sudo()
        if not account.access_token:
            raise UserError(_("%s has no access token. Reconnect it.") % self.display_name)
        if account.token_expiry and account.token_expiry - REFRESH_MARGIN <= fields.Datetime.now():
            account._refresh_access_token()
        return account.access_token

    def _refresh_access_token(self):
        self.ensure_one()
        account = self.sudo()
        if not account.refresh_token:
            account.write({"state": "expired",
                           "last_error": _("No refresh token stored.")})
            raise UserError(_("%s must be reconnected to TikTok.") % self.display_name)
        key, secret = self._get_app_credentials()
        try:
            body = TikTokAPI.refresh_token(key, secret, account.refresh_token)
        except TikTokError as err:
            account.write({"state": "expired",
                           "last_error": err.args[0] if err.args else str(err)})
            raise
        account._store_token(body)

    def _store_token(self, body):
        self.ensure_one()
        now = fields.Datetime.now()
        values = {
            "access_token": body.get("access_token"),
            "granted_scopes": body.get("scope"),
            "state": "connected",
            "last_error": False,
        }
        if body.get("refresh_token"):
            values["refresh_token"] = body["refresh_token"]
        if body.get("expires_in"):
            values["token_expiry"] = now + timedelta(seconds=int(body["expires_in"]))
        if body.get("refresh_expires_in"):
            values["refresh_expiry"] = now + timedelta(
                seconds=int(body["refresh_expires_in"]))
        self.sudo().write(values)

    # ==================================================================
    # connection lifecycle
    # ==================================================================
    @api.model
    def action_connect(self):
        """Open TikTok's consent screen."""
        import secrets
        key, _secret = self._get_app_credentials()
        redirect_uri = self._get_redirect_uri()
        csrf = secrets.token_urlsafe(24)
        self.env["ir.config_parameter"].sudo().set_param(
            "tiktok_business.oauth_state", csrf)
        return {
            "type": "ir.actions.act_url",
            "target": "self",
            "url": TikTokAPI.authorize_url(key, redirect_uri, self._get_scopes(), csrf),
        }

    def action_disconnect(self):
        key, secret = self._get_app_credentials()
        for account in self:
            token = account.sudo().access_token
            if token:
                TikTokAPI.revoke(key, secret, token)
            account.sudo().write({
                "access_token": False,
                "refresh_token": False,
                "state": "expired",
            })
            account.message_post(body=_("Disconnected from TikTok."))

    # ==================================================================
    # synchronisation
    # ==================================================================
    def action_sync_profile(self):
        for account in self:
            info = TikTokAPI.user_info(account._token())
            account.sudo().write({
                "union_id": info.get("union_id") or account.union_id,
                "display_name_tiktok": info.get("display_name"),
                "username": info.get("username"),
                "avatar_url": info.get("avatar_url"),
                "profile_url": info.get("profile_deep_link"),
                "is_verified": info.get("is_verified", False),
                "follower_count": info.get("follower_count") or 0,
                "following_count": info.get("following_count") or 0,
                "likes_count": info.get("likes_count") or 0,
                "video_count": info.get("video_count") or 0,
                "last_sync": fields.Datetime.now(),
            })
        return True

    def action_sync_videos(self):
        Video = self.env["tiktok.video"]
        for account in self:
            token = account._token()
            cursor, has_more, fetched = 0, True, 0
            while has_more and fetched < 200:
                videos, cursor, has_more = TikTokAPI.video_list(token, cursor=cursor)
                if not videos:
                    break
                fetched += len(videos)
                Video._upsert_from_tiktok(account, videos)
            account.sudo().last_sync = fields.Datetime.now()
            if account.business_id and self._business_api_enabled():
                account._sync_business_insights()
        return True

    def _business_api_enabled(self):
        return bool(self.env["ir.config_parameter"].sudo().get_param(
            "tiktok_business.use_business_api"))

    def _sync_business_insights(self):
        """Enrich videos with the metrics only the Business API exposes."""
        self.ensure_one()
        token = self._token()
        try:
            data = TikTokAPI.business_video_list(token, self.business_id)
        except TikTokError as err:
            _logger.warning("TikTok: business insights failed for %s (%s)",
                            self.display_name, err)
            return
        videos = data.get("videos") or data.get("list") or []
        self.env["tiktok.video"]._apply_business_insights(self, videos)

    def action_sync_comments(self):
        for account in self:
            account.video_ids.action_sync_comments()
        return True

    # ==================================================================
    # crons
    # ==================================================================
    @api.model
    def _cron_refresh_tokens(self):
        deadline = fields.Datetime.now() + REFRESH_MARGIN
        accounts = self.search([
            ("state", "=", "connected"),
            ("token_expiry", "<=", deadline),
        ])
        for account in accounts:
            try:
                account._refresh_access_token()
            except Exception as err:  # a bad account must not block the others
                _logger.warning("TikTok: token refresh failed for %s (%s)",
                                account.display_name, err)

    @api.model
    def _cron_sync_accounts(self):
        for account in self.search([("state", "=", "connected")]):
            try:
                account.action_sync_profile()
                account.action_sync_videos()
            except Exception as err:
                _logger.warning("TikTok: sync failed for %s (%s)",
                                account.display_name, err)
                account.sudo().write({
                    "state": "error",
                    "last_error": str(err)[:500],
                })

    # ==================================================================
    # helpers used by the OAuth controller
    # ==================================================================
    @api.model
    def _create_or_update_from_oauth(self, token_body):
        info = TikTokAPI.user_info(token_body["access_token"])
        open_id = token_body.get("open_id") or info.get("open_id")
        if not open_id:
            raise UserError(_("TikTok did not return an open_id for this user."))
        account = self.with_context(active_test=False).search([
            ("open_id", "=", open_id),
            ("company_id", "=", self.env.company.id),
        ], limit=1)
        values = {
            "open_id": open_id,
            "union_id": info.get("union_id"),
            "display_name_tiktok": info.get("display_name"),
            "username": info.get("username"),
            "avatar_url": info.get("avatar_url"),
            "profile_url": info.get("profile_deep_link"),
            "is_verified": info.get("is_verified", False),
            "follower_count": info.get("follower_count") or 0,
            "following_count": info.get("following_count") or 0,
            "likes_count": info.get("likes_count") or 0,
            "video_count": info.get("video_count") or 0,
            "last_sync": fields.Datetime.now(),
            "active": True,
        }
        if account:
            account.sudo().write(values)
        else:
            values["business_id"] = open_id
            account = self.sudo().create(values)
        account._store_token(token_body)
        account.message_post(body=_("Connected to TikTok."))
        return account
