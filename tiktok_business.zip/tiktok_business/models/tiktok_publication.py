# -*- coding: utf-8 -*-

import logging

from odoo import _, fields, models

from .tiktok_api import TikTokAPI, TikTokError

_logger = logging.getLogger(__name__)

# TikTok publish states -> our states
STATUS_MAP = {
    "PROCESSING_UPLOAD": "processing",
    "PROCESSING_DOWNLOAD": "processing",
    "SEND_TO_USER_INBOX": "published",
    "PUBLISH_COMPLETE": "published",
    "FAILED": "failed",
}


class TikTokPublication(models.Model):
    _name = "tiktok.publication"
    _description = "TikTok Publication"
    _order = "id desc"
    _rec_name = "publish_id"

    post_id = fields.Many2one(
        "tiktok.post", string="Post", required=True, ondelete="cascade", index=True)
    account_id = fields.Many2one(
        "tiktok.account", string="Account", required=True,
        ondelete="cascade", index=True)
    company_id = fields.Many2one(related="account_id.company_id", store=True)

    publish_id = fields.Char("Publish ID", readonly=True, copy=False, index=True)
    tiktok_video_id = fields.Char("TikTok Video ID", readonly=True, copy=False)
    video_ref_id = fields.Many2one("tiktok.video", string="Synced Video", readonly=True)
    share_url = fields.Char("Share Link", readonly=True)

    state = fields.Selection(
        [
            ("pending", "Pending"),
            ("processing", "Processing"),
            ("published", "Published"),
            ("failed", "Failed"),
        ],
        default="pending", required=True, readonly=True)
    error_message = fields.Char(readonly=True)
    message_note = fields.Char("Note", readonly=True)
    checked_on = fields.Datetime("Last Status Check", readonly=True)

    _sql_constraints = [
        ("post_account_uniq", "unique(post_id, account_id)",
         "This post already has a publication for that account."),
    ]

    def action_check_status(self):
        for publication in self:
            if not publication.publish_id:
                continue
            try:
                data = TikTokAPI.publish_status(
                    publication.account_id._token(), publication.publish_id)
            except TikTokError as err:
                publication.write({
                    "state": "failed",
                    "error_message": err.args[0] if err.args else str(err),
                    "checked_on": fields.Datetime.now(),
                })
                continue

            status = data.get("status")
            values = {
                "state": STATUS_MAP.get(status, "processing"),
                "checked_on": fields.Datetime.now(),
            }
            publicly_available = data.get("publicaly_available_post_id") or \
                data.get("publicly_available_post_id")
            if publicly_available:
                video_id = str(publicly_available[0])
                values["tiktok_video_id"] = video_id
                values["share_url"] = "https://www.tiktok.com/@%s/video/%s" % (
                    publication.account_id.username or "", video_id)
            if status == "FAILED":
                values["error_message"] = data.get("fail_reason") or _("TikTok reported a failure.")
            publication.write(values)

            if values["state"] == "published":
                publication.post_id.message_post(body=_(
                    "Published on %(account)s.%(link)s",
                    account=publication.account_id.display_name,
                    link=(" %s" % values.get("share_url")) if values.get("share_url") else "",
                ))
        # roll the parent post state up
        for post in self.mapped("post_id"):
            states = set(post.publication_ids.mapped("state"))
            if states == {"published"}:
                post.state = "posted"
            elif states and states <= {"failed"}:
                post.state = "failed"
        return True

    def action_open_video(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "new",
            "url": self.share_url or "https://www.tiktok.com/",
        }
