# -*- coding: utf-8 -*-
"""HTTP layer for the TikTok APIs used by this module.

Three different TikTok surfaces are involved and they do NOT share the same
host, version or error format:

1. OAuth 2.0 / Login Kit      -> https://www.tiktok.com/v2/auth/authorize/
                                 https://open.tiktokapis.com/v2/oauth/token/
2. Display + Content Posting  -> https://open.tiktokapis.com/v2/...
3. Business Account API       -> https://business-api.tiktok.com/open_api/v1.3/business/...
   (account insights and comment management; requires a TikTok Business
   account linked to the app)

Everything here is stateless; the token handling lives on ``tiktok.account``.
"""

import json
import logging
from urllib.parse import urlencode

import requests

from odoo import _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/"
REVOKE_URL = "https://open.tiktokapis.com/v2/oauth/revoke/"

OPEN_API = "https://open.tiktokapis.com/v2"
BUSINESS_API = "https://business-api.tiktok.com/open_api/v1.3"

TIMEOUT = 60

# Scopes. Anything beyond user.info.basic requires TikTok app review.
DEFAULT_SCOPES = [
    "user.info.basic",
    "user.info.profile",
    "user.info.stats",
    "video.list",
    "video.upload",
    "video.publish",
]
BUSINESS_SCOPES = [
    "biz.creation.query",
    "biz.creation.publish",
    "comment.list",
    "comment.list.manage",
]


class TikTokError(UserError):
    """Raised when TikTok answers with an error payload."""


class TikTokAPI:
    """Stateless helper. Pass the access token to each authenticated call."""

    # ------------------------------------------------------------------
    # OAuth
    # ------------------------------------------------------------------
    @staticmethod
    def authorize_url(client_key, redirect_uri, scopes, state):
        params = {
            "client_key": client_key,
            "response_type": "code",
            "scope": ",".join(scopes),
            "redirect_uri": redirect_uri,
            "state": state,
        }
        return "%s?%s" % (AUTH_URL, urlencode(params))

    @classmethod
    def exchange_code(cls, client_key, client_secret, code, redirect_uri):
        return cls._token_call({
            "client_key": client_key,
            "client_secret": client_secret,
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": redirect_uri,
        })

    @classmethod
    def refresh_token(cls, client_key, client_secret, refresh_token):
        return cls._token_call({
            "client_key": client_key,
            "client_secret": client_secret,
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        })

    @classmethod
    def revoke(cls, client_key, client_secret, access_token):
        try:
            requests.post(
                REVOKE_URL,
                data={
                    "client_key": client_key,
                    "client_secret": client_secret,
                    "token": access_token,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=TIMEOUT,
            )
        except requests.exceptions.RequestException as err:
            _logger.warning("TikTok: token revoke failed (%s)", err)

    @staticmethod
    def _token_call(data):
        try:
            response = requests.post(
                TOKEN_URL, data=data,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Cache-Control": "no-cache",
                },
                timeout=TIMEOUT,
            )
            body = response.json()
        except requests.exceptions.RequestException as err:
            raise TikTokError(_("Could not reach TikTok: %s") % err)
        except ValueError:
            raise TikTokError(_("TikTok returned a non-JSON token response."))
        if body.get("error"):
            raise TikTokError(_(
                "TikTok refused the token request: %(error)s - %(desc)s",
                error=body.get("error"),
                desc=body.get("error_description") or "",
            ))
        return body

    # ------------------------------------------------------------------
    # Display / Content Posting API (open.tiktokapis.com)
    # ------------------------------------------------------------------
    @classmethod
    def open_call(cls, access_token, path, method="POST", params=None, payload=None):
        url = "%s%s" % (OPEN_API, path)
        headers = {
            "Authorization": "Bearer %s" % access_token,
            "Content-Type": "application/json; charset=UTF-8",
        }
        body = cls._request(method, url, headers=headers, params=params, json=payload)
        error = body.get("error") or {}
        # TikTok always returns an "error" object; code "ok" means success.
        if error.get("code") and error["code"] != "ok":
            raise TikTokError(_(
                "TikTok API error on %(path)s: %(code)s - %(message)s\n(log id %(log)s)",
                path=path, code=error.get("code"),
                message=error.get("message") or "",
                log=error.get("log_id") or "-",
            ))
        return body

    @classmethod
    def user_info(cls, access_token, fields=None):
        fields = fields or [
            "open_id", "union_id", "avatar_url", "display_name", "username",
            "bio_description", "profile_deep_link", "is_verified",
            "follower_count", "following_count", "likes_count", "video_count",
        ]
        body = cls.open_call(
            access_token, "/user/info/", method="GET",
            params={"fields": ",".join(fields)},
        )
        return (body.get("data") or {}).get("user") or {}

    @classmethod
    def video_list(cls, access_token, cursor=0, max_count=20, fields=None):
        fields = fields or [
            "id", "title", "video_description", "create_time", "cover_image_url",
            "share_url", "embed_link", "duration", "like_count", "comment_count",
            "share_count", "view_count",
        ]
        body = cls.open_call(
            access_token, "/video/list/", method="POST",
            params={"fields": ",".join(fields)},
            payload={"cursor": cursor, "max_count": max_count},
        )
        data = body.get("data") or {}
        return data.get("videos") or [], data.get("cursor") or 0, data.get("has_more")

    @classmethod
    def creator_info(cls, access_token):
        """Mandatory pre-flight call before a direct post."""
        body = cls.open_call(access_token, "/post/publish/creator_info/query/")
        return body.get("data") or {}

    @classmethod
    def publish_video_init(cls, access_token, post_info, source_info, draft=False):
        path = "/post/publish/inbox/video/init/" if draft else "/post/publish/video/init/"
        payload = {"source_info": source_info}
        if not draft:
            payload["post_info"] = post_info
        body = cls.open_call(access_token, path, payload=payload)
        return body.get("data") or {}

    @classmethod
    def publish_content_init(cls, access_token, payload):
        """Photo posts (and video posts in the unified endpoint)."""
        body = cls.open_call(access_token, "/post/publish/content/init/", payload=payload)
        return body.get("data") or {}

    @classmethod
    def publish_status(cls, access_token, publish_id):
        body = cls.open_call(
            access_token, "/post/publish/status/fetch/",
            payload={"publish_id": publish_id},
        )
        return body.get("data") or {}

    @classmethod
    def upload_file(cls, upload_url, content, mime_type="video/mp4"):
        """PUT the whole file in a single chunk to the URL TikTok handed us."""
        size = len(content)
        headers = {
            "Content-Type": mime_type,
            "Content-Length": str(size),
            "Content-Range": "bytes 0-%d/%d" % (size - 1, size),
        }
        try:
            response = requests.put(upload_url, data=content, headers=headers,
                                    timeout=TIMEOUT * 5)
            response.raise_for_status()
        except requests.exceptions.RequestException as err:
            raise TikTokError(_("Uploading the media to TikTok failed: %s") % err)
        return True

    # ------------------------------------------------------------------
    # Business Account API (business-api.tiktok.com)
    # ------------------------------------------------------------------
    @classmethod
    def business_call(cls, access_token, path, method="GET", params=None, payload=None):
        url = "%s%s" % (BUSINESS_API, path)
        headers = {
            "Access-Token": access_token,
            "Content-Type": "application/json",
        }
        body = cls._request(method, url, headers=headers, params=params, json=payload)
        if body.get("code") not in (0, "0", None):
            raise TikTokError(_(
                "TikTok Business API error on %(path)s: %(code)s - %(message)s",
                path=path, code=body.get("code"), message=body.get("message") or "",
            ))
        return body.get("data") or {}

    @classmethod
    def business_get(cls, access_token, business_id, fields, start_date=None, end_date=None):
        params = {"business_id": business_id, "fields": cls._json(fields)}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        return cls.business_call(access_token, "/business/get/", params=params)

    @classmethod
    def business_video_list(cls, access_token, business_id, cursor=0, max_count=20, fields=None):
        fields = fields or [
            "item_id", "create_time", "thumbnail_url", "share_url", "embed_url",
            "caption", "video_views", "likes", "comments", "shares",
            "reach", "full_video_watched_rate", "total_time_watched",
            "average_time_watched", "impression_sources", "audience_countries",
        ]
        params = {
            "business_id": business_id,
            "fields": cls._json(fields),
            "cursor": cursor,
            "max_count": max_count,
        }
        return cls.business_call(access_token, "/business/video/list/", params=params)

    @classmethod
    def comment_list(cls, access_token, business_id, video_id, cursor=0, max_count=30):
        params = {
            "business_id": business_id,
            "video_id": video_id,
            "cursor": cursor,
            "max_count": max_count,
            "status": "PUBLIC",
            "sort_field": "create_time",
            "sort_order": "desc",
        }
        return cls.business_call(access_token, "/business/comment/list/", params=params)

    @classmethod
    def comment_reply(cls, access_token, business_id, video_id, comment_id, text):
        return cls.business_call(
            access_token, "/business/comment/reply/create/", method="POST",
            payload={
                "business_id": business_id,
                "video_id": video_id,
                "comment_id": comment_id,
                "text": text,
            },
        )

    @classmethod
    def comment_like(cls, access_token, business_id, comment_id, like=True):
        return cls.business_call(
            access_token, "/business/comment/like/", method="POST",
            payload={
                "business_id": business_id,
                "comment_id": comment_id,
                "action": "LIKE" if like else "UNLIKE",
            },
        )

    @classmethod
    def comment_delete(cls, access_token, business_id, comment_id):
        return cls.business_call(
            access_token, "/business/comment/delete/", method="POST",
            payload={"business_id": business_id, "comment_id": comment_id},
        )

    # ------------------------------------------------------------------
    # plumbing
    # ------------------------------------------------------------------
    @staticmethod
    def _json(value):
        return json.dumps(value)

    @staticmethod
    def _request(method, url, headers=None, params=None, json=None):  # noqa: A002
        try:
            response = requests.request(
                method, url, headers=headers, params=params, json=json,
                timeout=TIMEOUT,
            )
        except requests.exceptions.Timeout:
            raise TikTokError(_("TikTok did not answer within %s seconds.") % TIMEOUT)
        except requests.exceptions.RequestException as err:
            raise TikTokError(_("Could not reach TikTok: %s") % err)
        try:
            return response.json()
        except ValueError:
            raise TikTokError(_(
                "TikTok returned HTTP %(code)s with a non-JSON body for %(url)s.",
                code=response.status_code, url=url,
            ))
