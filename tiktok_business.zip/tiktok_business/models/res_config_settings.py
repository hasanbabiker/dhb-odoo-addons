# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    tiktok_client_key = fields.Char(
        "TikTok Client Key",
        config_parameter="tiktok_business.client_key",
        help="From your app on developers.tiktok.com.")
    tiktok_client_secret = fields.Char(
        "TikTok Client Secret",
        config_parameter="tiktok_business.client_secret")
    tiktok_webhook_secret = fields.Char(
        "Webhook Secret",
        config_parameter="tiktok_business.webhook_secret",
        help="Used to verify the signature of incoming TikTok webhooks.")
    tiktok_use_business_api = fields.Boolean(
        "Enable Business Account API",
        config_parameter="tiktok_business.use_business_api",
        help="Turn on to pull audience insights and manage comments. "
             "Requires a TikTok Business account and the matching scopes "
             "approved on your developer app.")
    tiktok_redirect_uri = fields.Char(
        "Redirect URI", readonly=True, compute="_compute_tiktok_redirect_uri",
        help="Copy this into Login Kit > Web > Redirect URI on your TikTok app.")

    @api.depends("company_id")
    def _compute_tiktok_redirect_uri(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        for record in self:
            record.tiktok_redirect_uri = "%s/tiktok/oauth/callback" % (base or "")
