# -*- coding: utf-8 -*-

from datetime import datetime

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .tiktok_api import TikTokAPI


class TikTokComment(models.Model):
    _name = "tiktok.comment"
    _description = "TikTok Comment"
    _order = "create_time desc, id desc"

    video_id = fields.Many2one(
        "tiktok.video", string="Video", required=True,
        ondelete="cascade", index=True)
    account_id = fields.Many2one(
        related="video_id.account_id", store=True, index=True)
    company_id = fields.Many2one(related="account_id.company_id", store=True)

    comment_id = fields.Char("TikTok Comment ID", required=True, index=True)
    parent_comment_id = fields.Char("Reply To")
    name = fields.Text("Comment", required=True)
    author_name = fields.Char("Author")
    author_avatar = fields.Char("Author Avatar")
    like_count = fields.Integer("Likes")
    reply_count = fields.Integer("Replies")
    create_time = fields.Datetime("Posted On")

    liked_by_us = fields.Boolean("Liked", readonly=True)
    replied = fields.Boolean("Replied", readonly=True)
    hidden = fields.Boolean("Deleted on TikTok", readonly=True)

    _sql_constraints = [
        ("comment_uniq", "unique(comment_id, video_id)",
         "This comment is already stored."),
    ]

    @api.model
    def _upsert_from_tiktok(self, video, comments):
        ids = [str(c.get("comment_id") or c.get("id")) for c in comments]
        existing = {
            comment.comment_id: comment
            for comment in self.search([
                ("video_id", "=", video.id), ("comment_id", "in", ids)])
        }
        to_create = []
        for payload in comments:
            comment_id = str(payload.get("comment_id") or payload.get("id") or "")
            if not comment_id:
                continue
            create_time = payload.get("create_time")
            values = {
                "video_id": video.id,
                "comment_id": comment_id,
                "parent_comment_id": payload.get("parent_comment_id"),
                "name": payload.get("text") or payload.get("content") or "",
                "author_name": (payload.get("username")
                                or payload.get("user_name")
                                or payload.get("display_name")),
                "author_avatar": payload.get("profile_image")
                                 or payload.get("avatar_url"),
                "like_count": payload.get("like_count") or payload.get("likes") or 0,
                "reply_count": payload.get("reply_count") or 0,
                "create_time": (
                    datetime.utcfromtimestamp(int(create_time))
                    if create_time else False),
            }
            comment = existing.get(comment_id)
            if comment:
                comment.write(values)
            else:
                to_create.append(values)
        if to_create:
            self.create(to_create)

    # ==================================================================
    # actions
    # ==================================================================
    def _check_business(self):
        self.ensure_one()
        account = self.account_id
        if not (account.business_id and account._business_api_enabled()):
            raise UserError(_(
                "Comment management needs the Business Account API. Enable it in "
                "Settings and make sure the account has a Business ID and the "
                "comment.list.manage scope."))
        return account

    def action_like(self):
        for comment in self:
            account = comment._check_business()
            TikTokAPI.comment_like(
                account._token(), account.business_id, comment.comment_id,
                like=not comment.liked_by_us)
            comment.liked_by_us = not comment.liked_by_us
        return True

    def action_delete(self):
        for comment in self:
            account = comment._check_business()
            TikTokAPI.comment_delete(
                account._token(), account.business_id, comment.comment_id)
            comment.hidden = True
        return True

    def action_reply_wizard(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Reply on TikTok"),
            "res_model": "tiktok.comment.reply",
            "view_mode": "form",
            "target": "new",
            "context": {"default_comment_id": self.id},
        }

    def _post_reply(self, text):
        self.ensure_one()
        account = self._check_business()
        TikTokAPI.comment_reply(
            account._token(), account.business_id,
            self.video_id.video_id, self.comment_id, text)
        self.replied = True
        return True


class TikTokCommentReply(models.TransientModel):
    _name = "tiktok.comment.reply"
    _description = "Reply to a TikTok Comment"

    comment_id = fields.Many2one("tiktok.comment", required=True, ondelete="cascade")
    original_text = fields.Text(related="comment_id.name", readonly=True)
    text = fields.Text("Your Reply", required=True)

    def action_send(self):
        self.ensure_one()
        self.comment_id._post_reply(self.text)
        return {"type": "ir.actions.act_window_close"}
