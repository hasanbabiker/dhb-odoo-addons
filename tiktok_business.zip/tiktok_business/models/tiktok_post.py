# -*- coding: utf-8 -*-

import base64
import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from .tiktok_api import TikTokAPI, TikTokError

_logger = logging.getLogger(__name__)

MAX_CAPTION = 2200


class TikTokPost(models.Model):
    _name = "tiktok.post"
    _description = "TikTok Post"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "schedule_date desc, id desc"

    name = fields.Char(
        "Internal Reference", required=True, default=lambda self: _("New post"),
        tracking=True)
    company_id = fields.Many2one(
        "res.company", required=True, default=lambda self: self.env.company)
    account_ids = fields.Many2many(
        "tiktok.account", string="Publish On", required=True,
        domain="[('state', '=', 'connected'), ('company_id', '=', company_id)]")

    # -- content -------------------------------------------------------
    media_type = fields.Selection(
        [("video", "Video"), ("photo", "Photo carousel")],
        default="video", required=True)
    post_mode = fields.Selection(
        [("direct", "Publish directly"), ("draft", "Send to TikTok drafts")],
        default="direct", required=True,
        help="Direct posting requires an approved Content Posting API app. "
             "Drafts land in the creator's TikTok inbox for manual publishing.")
    source = fields.Selection(
        [("file", "Upload a file from Odoo"), ("url", "Pull from a public URL")],
        default="file", required=True,
        help="Pull-from-URL requires the domain to be verified on your "
             "TikTok developer app.")

    title = fields.Char("Title", help="Photo posts only. Max 90 characters.")
    caption = fields.Text("Caption", tracking=True)

    video_file = fields.Binary("Video File", attachment=True)
    video_filename = fields.Char("Video Filename")
    video_url = fields.Char("Video URL")

    image_ids = fields.Many2many(
        "ir.attachment", "tiktok_post_image_rel", "post_id", "attachment_id",
        string="Images", domain=[("mimetype", "like", "image/")])
    photo_urls = fields.Text(
        "Photo URLs", help="One public image URL per line, in display order.")
    photo_cover_index = fields.Integer("Cover Image Index", default=0)

    # -- TikTok settings ----------------------------------------------
    privacy_level = fields.Selection(
        [
            ("PUBLIC_TO_EVERYONE", "Public"),
            ("MUTUAL_FOLLOW_FRIENDS", "Friends"),
            ("FOLLOWER_OF_CREATOR", "Followers"),
            ("SELF_ONLY", "Private"),
        ],
        default="SELF_ONLY", required=True,
        help="An app that has not passed TikTok's audit can only post as Private.")
    disable_comment = fields.Boolean("Disable Comments")
    disable_duet = fields.Boolean("Disable Duet")
    disable_stitch = fields.Boolean("Disable Stitch")
    auto_add_music = fields.Boolean("Auto-add Music", default=True,
                                    help="Photo posts only.")
    video_cover_timestamp_ms = fields.Integer("Cover Frame (ms)", default=1000)

    brand_organic_toggle = fields.Boolean(
        "Promoting your own brand",
        help="Labels the post as promotional content.")
    brand_content_toggle = fields.Boolean(
        "Paid partnership",
        help="Labels the post as branded content. TikTok forbids branded "
             "content on private posts.")

    # -- workflow ------------------------------------------------------
    schedule_date = fields.Datetime(
        "Scheduled For", tracking=True,
        help="Leave empty to publish as soon as you press Publish.")
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("scheduled", "Scheduled"),
            ("posting", "Posting"),
            ("posted", "Posted"),
            ("failed", "Failed"),
        ],
        default="draft", required=True, tracking=True)
    publication_ids = fields.One2many(
        "tiktok.publication", "post_id", string="Publications")
    published_count = fields.Integer(compute="_compute_counts")
    failed_count = fields.Integer(compute="_compute_counts")

    @api.depends("publication_ids.state")
    def _compute_counts(self):
        for post in self:
            post.published_count = len(
                post.publication_ids.filtered(lambda p: p.state == "published"))
            post.failed_count = len(
                post.publication_ids.filtered(lambda p: p.state == "failed"))

    # ==================================================================
    # constraints
    # ==================================================================
    @api.constrains("caption", "title")
    def _check_lengths(self):
        for post in self:
            if post.caption and len(post.caption) > MAX_CAPTION:
                raise ValidationError(_(
                    "TikTok captions are limited to %s characters.") % MAX_CAPTION)
            if post.title and len(post.title) > 90:
                raise ValidationError(_("Photo post titles are limited to 90 characters."))

    @api.constrains("brand_content_toggle", "privacy_level")
    def _check_branded_content(self):
        for post in self:
            if post.brand_content_toggle and post.privacy_level == "SELF_ONLY":
                raise ValidationError(_(
                    "TikTok does not allow branded content on private posts."))

    def _check_ready(self):
        self.ensure_one()
        if self.media_type == "video":
            if self.source == "file" and not self.video_file:
                raise UserError(_("Attach a video file first."))
            if self.source == "url" and not self.video_url:
                raise UserError(_("Fill in the video URL first."))
        else:
            if not (self.image_ids or self.photo_urls):
                raise UserError(_("Add at least one image."))
            if self.source == "file" and not self.image_ids:
                raise UserError(_("Attach the images first."))

    # ==================================================================
    # payload builders
    # ==================================================================
    def _post_info(self):
        self.ensure_one()
        info = {
            "title": (self.title or self.caption or "")[:90]
                     if self.media_type == "photo" else (self.caption or "")[:MAX_CAPTION],
            "privacy_level": self.privacy_level,
            "disable_comment": self.disable_comment,
            "brand_content_toggle": self.brand_content_toggle,
            "brand_organic_toggle": self.brand_organic_toggle,
        }
        if self.media_type == "video":
            info.update({
                "disable_duet": self.disable_duet,
                "disable_stitch": self.disable_stitch,
                "video_cover_timestamp_ms": self.video_cover_timestamp_ms,
            })
        else:
            info.update({
                "description": (self.caption or "")[:MAX_CAPTION],
                "auto_add_music": self.auto_add_music,
            })
        return info

    def _photo_urls(self):
        """Public URLs for the images, either typed in or served from Odoo."""
        self.ensure_one()
        urls = [u.strip() for u in (self.photo_urls or "").splitlines() if u.strip()]
        if urls:
            return urls
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        for attachment in self.image_ids:
            attachment.sudo().generate_access_token()
            urls.append("%s/web/content/%s?access_token=%s&download=true" % (
                base, attachment.id, attachment.sudo().access_token))
        return urls

    # ==================================================================
    # publishing
    # ==================================================================
    def action_schedule(self):
        for post in self:
            post._check_ready()
            if not post.schedule_date:
                raise UserError(_("Set a scheduled date, or use Publish Now."))
            post.state = "scheduled"
        return True

    def action_publish(self):
        for post in self:
            post._check_ready()
            post.state = "posting"
            post._publish()
        return True

    def action_reset_draft(self):
        self.write({"state": "draft"})
        return True

    def _publish(self):
        self.ensure_one()
        Publication = self.env["tiktok.publication"]
        for account in self.account_ids:
            publication = Publication.search([
                ("post_id", "=", self.id), ("account_id", "=", account.id),
            ], limit=1)
            if not publication:
                publication = Publication.create({
                    "post_id": self.id, "account_id": account.id})
            if publication.state == "published":
                continue
            try:
                self._publish_on(account, publication)
            except (TikTokError, UserError) as err:
                message = err.args[0] if err.args else str(err)
                publication.write({"state": "failed", "error_message": message})
                _logger.warning("TikTok: publishing %s on %s failed: %s",
                                self.name, account.display_name, message)
        states = set(self.publication_ids.mapped("state"))
        if states == {"published"}:
            self.state = "posted"
        elif "failed" in states and "pending" not in states and "processing" not in states:
            self.state = "failed"
        return True

    def _publish_on(self, account, publication):
        self.ensure_one()
        token = account._token()
        draft = self.post_mode == "draft"

        if not draft:
            # TikTok requires reading the creator's current settings first.
            creator = TikTokAPI.creator_info(token)
            allowed = creator.get("privacy_level_options") or []
            if allowed and self.privacy_level not in allowed:
                raise UserError(_(
                    "%(account)s cannot post with privacy level %(level)s. "
                    "TikTok allows: %(allowed)s.",
                    account=account.display_name, level=self.privacy_level,
                    allowed=", ".join(allowed)))
            if creator.get("comment_disabled") and not self.disable_comment:
                publication.message_note = _(
                    "The creator has comments disabled account-wide.")

        if self.media_type == "video":
            data = self._publish_video(token, draft)
        else:
            data = self._publish_photo(token, draft)

        publication.write({
            "publish_id": data.get("publish_id"),
            "state": "processing",
            "error_message": False,
        })
        publication.action_check_status()
        return True

    def _publish_video(self, token, draft):
        self.ensure_one()
        if self.source == "url":
            source_info = {"source": "PULL_FROM_URL", "video_url": self.video_url}
            return TikTokAPI.publish_video_init(
                token, self._post_info(), source_info, draft=draft)

        content = base64.b64decode(self.video_file)
        size = len(content)
        source_info = {
            "source": "FILE_UPLOAD",
            "video_size": size,
            "chunk_size": size,
            "total_chunk_count": 1,
        }
        data = TikTokAPI.publish_video_init(
            token, self._post_info(), source_info, draft=draft)
        upload_url = data.get("upload_url")
        if not upload_url:
            raise UserError(_("TikTok did not return an upload URL."))
        TikTokAPI.upload_file(upload_url, content, mime_type="video/mp4")
        return data

    def _publish_photo(self, token, draft):
        self.ensure_one()
        urls = self._photo_urls()
        if not urls:
            raise UserError(_("No usable image URL could be built for this post."))
        payload = {
            "media_type": "PHOTO",
            "post_mode": "MEDIA_UPLOAD" if draft else "DIRECT_POST",
            "source_info": {
                "source": "PULL_FROM_URL",
                "photo_cover_index": max(0, min(self.photo_cover_index, len(urls) - 1)),
                "photo_images": urls,
            },
        }
        if not draft:
            payload["post_info"] = self._post_info()
        return TikTokAPI.publish_content_init(token, payload)

    # ==================================================================
    # crons
    # ==================================================================
    @api.model
    def _cron_publish_scheduled(self):
        due = self.search([
            ("state", "=", "scheduled"),
            ("schedule_date", "<=", fields.Datetime.now()),
        ])
        for post in due:
            try:
                post.state = "posting"
                post._publish()
            except Exception as err:
                _logger.warning("TikTok: scheduled publish of %s failed (%s)",
                                post.name, err)
                post.write({"state": "failed"})

    @api.model
    def _cron_check_publish_status(self):
        pending = self.env["tiktok.publication"].search([
            ("state", "in", ("pending", "processing")),
            ("publish_id", "!=", False),
        ])
        for publication in pending:
            try:
                publication.action_check_status()
            except Exception as err:
                _logger.warning("TikTok: status check failed for %s (%s)",
                                publication.publish_id, err)
