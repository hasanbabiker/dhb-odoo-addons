# -*- coding: utf-8 -*-

import hashlib
import hmac
import json
import logging

from odoo import _, http
from odoo.http import request

from ..models.tiktok_api import TikTokAPI, TikTokError

_logger = logging.getLogger(__name__)


class TikTokController(http.Controller):

    # ------------------------------------------------------------------
    # OAuth
    # ------------------------------------------------------------------
    @http.route("/tiktok/oauth/callback", type="http", auth="user",
                methods=["GET"], website=False, csrf=False)
    def tiktok_oauth_callback(self, **kwargs):
        """Redirect URI registered on the TikTok developer app."""
        if kwargs.get("error"):
            return self._render_message(
                _("TikTok refused the connection"),
                "%s: %s" % (kwargs.get("error"),
                            kwargs.get("error_description") or ""),
                success=False)

        code = kwargs.get("code")
        state = kwargs.get("state")
        expected = request.env["ir.config_parameter"].sudo().get_param(
            "tiktok_business.oauth_state")
        if not code:
            return self._render_message(
                _("Missing authorisation code"),
                _("TikTok did not send an authorisation code back."),
                success=False)
        if not expected or state != expected:
            return self._render_message(
                _("Invalid state"),
                _("The anti-CSRF state does not match. Start the connection "
                  "again from Odoo."),
                success=False)
        request.env["ir.config_parameter"].sudo().set_param(
            "tiktok_business.oauth_state", "")

        Account = request.env["tiktok.account"]
        try:
            key, secret = Account._get_app_credentials()
            body = TikTokAPI.exchange_code(
                key, secret, code, Account._get_redirect_uri())
            account = Account._create_or_update_from_oauth(body)
        except TikTokError as err:
            return self._render_message(
                _("Connection failed"),
                err.args[0] if err.args else str(err), success=False)
        except Exception as err:  # noqa: BLE001 - show the user something useful
            _logger.exception("TikTok: OAuth callback failed")
            return self._render_message(
                _("Connection failed"), str(err), success=False)

        action = request.env.ref(
            "tiktok_business.action_tiktok_account", raise_if_not_found=False)
        url = "/odoo/action-%s/%s" % (action.id, account.id) if action else "/odoo"
        return request.redirect(url)

    def _render_message(self, title, message, success=True):
        return request.render("tiktok_business.oauth_result", {
            "title": title,
            "message": message,
            "success": success,
        })

    # ------------------------------------------------------------------
    # Webhooks
    # ------------------------------------------------------------------
    @http.route("/tiktok/webhook", type="http", auth="public",
                methods=["GET", "POST"], csrf=False, save_session=False)
    def tiktok_webhook(self, **kwargs):
        if request.httprequest.method == "GET":
            # TikTok verifies the endpoint by echoing a challenge.
            return kwargs.get("challenge", "ok")

        raw = request.httprequest.get_data()
        if not self._verify_signature(raw):
            _logger.warning("TikTok: webhook with an invalid signature was rejected")
            return request.make_response("invalid signature", status=401)

        try:
            payload = json.loads(raw or b"{}")
        except ValueError:
            return request.make_response("bad payload", status=400)

        try:
            self._handle_event(payload)
        except Exception:  # never let TikTok retry forever on our bug
            _logger.exception("TikTok: webhook handling failed for %s", payload)
        return request.make_response("ok", headers=[("Content-Type", "text/plain")])

    def _verify_signature(self, raw_body):
        secret = request.env["ir.config_parameter"].sudo().get_param(
            "tiktok_business.webhook_secret")
        if not secret:
            # No secret configured: accept, but say so in the log.
            _logger.info("TikTok: webhook accepted without signature check "
                         "(no webhook secret set)")
            return True
        header = request.httprequest.headers.get("TikTok-Signature") or ""
        parts = dict(
            piece.split("=", 1) for piece in header.split(",") if "=" in piece)
        timestamp, signature = parts.get("t"), parts.get("s")
        if not (timestamp and signature):
            return False
        expected = hmac.new(
            secret.encode(),
            ("%s.%s" % (timestamp, raw_body.decode())).encode(),
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(expected, signature)

    def _handle_event(self, payload):
        env = request.env(su=True)
        event = payload.get("event")
        content = payload.get("content")
        if isinstance(content, str):
            try:
                content = json.loads(content)
            except ValueError:
                content = {}
        content = content or {}

        if event in ("post.publish.complete", "post.publish.failed",
                     "post.publish.publicly_available", "post.publish.inbox_delivered"):
            publish_id = content.get("publish_id")
            publication = env["tiktok.publication"].search(
                [("publish_id", "=", publish_id)], limit=1)
            if publication:
                publication.action_check_status()
            return

        if event and event.startswith("comment"):
            open_id = payload.get("user_openid") or content.get("open_id")
            video_id = content.get("video_id") or content.get("item_id")
            video = env["tiktok.video"].search([
                ("video_id", "=", str(video_id or "")),
                ("account_id.open_id", "=", open_id),
            ], limit=1)
            if video:
                video.action_sync_comments()
            return

        _logger.info("TikTok: unhandled webhook event %s", event)
