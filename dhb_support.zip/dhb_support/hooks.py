"""Rename the app on the home screen, without guessing an XML id.

Helpdesk's own root menu is called "Helpdesk", which is Odoo's word and not
the centre's. Staff here say support, and a learner writing in does not know
what a helpdesk is.

Done in Python rather than as a data record on purpose. Overriding another
module's menu means naming its XML id, and a wrong id does not degrade - it
fails the install. Here the id is tried first and a search is the fallback,
so the worst case is an app that keeps Odoo's name.
"""

import logging

_logger = logging.getLogger(__name__)


def rename_helpdesk_app(env):
    menu = env.ref("helpdesk.menu_helpdesk_root", raise_if_not_found=False)
    if not menu:
        menu = env["ir.ui.menu"].search([
            ("parent_id", "=", False),
            ("name", "ilike", "helpdesk"),
        ], limit=1)
    if not menu:
        _logger.info("dhb_support: no Helpdesk root menu found, leaving the "
                     "home screen alone.")
        return
    menu.write({
        "name": "Support",
        "web_icon": "dhb_support,static/description/icon.png",
    })
