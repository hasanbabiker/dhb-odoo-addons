{
    "name": "DHB Support",
    "version": "19.0.1.0.0",
    "summary": "Helpdesk tickets that know which learner, batch, certificate "
               "and parcel they are about",
    "description": """
DHB Support
===========

This is not a ticket system. Odoo already has one, and it is better than
anything worth writing here: teams, stages, SLA, an inbox per team that turns
an email into a ticket, a portal the learner can see their own ticket in, and
a satisfaction rating. None of it is rebuilt.

What Helpdesk cannot know is what the ticket is **about**. "My certificate
never arrived" is about certificate CE/2026/0117, in a parcel Aramex has had
for eleven days, for a learner on IGC-2608-G1. Without those links, answering
it means opening three apps and searching each by a name spelled two ways.

So this module adds five links and the smart buttons that read them - and one
thing that only exists once they are read backwards:

* **From the learner**, how many times they have written in. Four tickets is
  a person being let down, and nobody sees it one ticket at a time.
* **From the batch**, how many of its learners have. Six tickets on one
  course is a problem with the course - a tutor, a link, a room - and it is
  invisible until it is counted.

Four teams, because four different people answer: learners, corporate
clients, tutors, internal. Each has its own inbox, so a message becomes a
ticket without anybody retyping it.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Services",
    "license": "LGPL-3",
    "depends": [
        # Everything about a ticket is Odoo's. This module only adds links.
        "helpdesk",
        # What the links point at.
        "dhb_batch",
        "dhb_certificate",
        "dhb_shipping",
        "dhb_contract",
    ],
    "data": [
        "data/support_data.xml",
        "views/helpdesk_views.xml",
    ],
    "post_init_hook": "rename_helpdesk_app",
    "installable": True,
    "application": False,
    "auto_install": False,
}
