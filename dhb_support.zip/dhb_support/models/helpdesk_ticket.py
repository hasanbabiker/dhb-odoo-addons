"""What the ticket is actually about.

Helpdesk already knows who wrote in, when, which team and how urgent. What it
cannot know is that "my certificate never arrived" is about certificate
CE/2026/0117, which is in a parcel that Aramex has had for eleven days - and
without that, answering the question means opening three apps and searching
each one by the learner's name, badly spelled.

So this module adds links and nothing else. No second ticket model, no
parallel state machine, no duplicate of a field Helpdesk already has: the
partner, the stage, the SLA, the rating and the portal are Odoo's and stay
Odoo's. Five Many2ones and the smart buttons that read them backwards.

The backwards direction is the part that pays. One learner with four tickets
is a learner being let down; four tickets on one batch is a problem with the
batch - a tutor, a room, a link that does not work - and nobody finds that by
reading tickets one at a time.
"""

from odoo import models, fields, api, _


class HelpdeskTicket(models.Model):
    _inherit = "helpdesk.ticket"

    batch_id = fields.Many2one(
        "dhb.batch", string="Batch", index=True, ondelete="set null",
        tracking=True,
        help="The course the learner is on. Setting it is what makes a "
             "pattern visible: four tickets on one batch is a problem with "
             "the batch, not with four people.")
    course_id = fields.Many2one(
        related="batch_id.course_id", string="Course", store=True,
        index=True, readonly=True)

    certificate_id = fields.Many2one(
        "dhb.certificate", string="Certificate", index=True,
        ondelete="set null")
    shipment_id = fields.Many2one(
        "dhb.shipment", string="Shipment", index=True, ondelete="set null")
    contract_id = fields.Many2one(
        "dhb.contract", string="Under contract", index=True,
        ondelete="set null",
        help="Set when the person writing in is covered by a company "
             "agreement. It is the difference between one unhappy learner "
             "and a client relationship.")

    # Stored, so it can be a filter. "Tickets with nothing attached" is the
    # queue an officer should work through, and a warning nobody can search
    # for is a warning nobody finds.
    is_linked = fields.Boolean(
        string="Linked to something", compute="_compute_is_linked",
        store=True)

    # Read off the shipment rather than copied onto the ticket. A tracking
    # number typed here would be a second copy of a number that changes,
    # and the copy is never the one that gets corrected.
    tracking_ref = fields.Char(
        related="shipment_id.tracking_ref", string="Tracking number",
        readonly=True)
    shipment_state = fields.Selection(
        related="shipment_id.state", string="Parcel is", readonly=True)

    @api.depends("batch_id", "certificate_id", "shipment_id", "contract_id")
    def _compute_is_linked(self):
        for ticket in self:
            ticket.is_linked = bool(
                ticket.batch_id or ticket.certificate_id
                or ticket.shipment_id or ticket.contract_id)

    @api.onchange("partner_id")
    def _onchange_partner_id_dhb(self):
        """Offer the batch the learner is actually on.

        Not set automatically, because a learner on three courses would get
        the wrong one silently. Narrowing the dropdown to their own batches
        is the honest help: it saves the search without making the choice.
        """
        if not self.partner_id:
            return {}
        batches = self.env["dhb.batch.line"].search([
            ("partner_id", "=", self.partner_id.id),
            ("state", "!=", "cancel"),
        ]).mapped("event_id")
        if len(batches) == 1 and not self.batch_id:
            self.batch_id = batches
        return {"domain": {"batch_id": [("id", "in", batches.ids)]}} \
            if batches else {}

    @api.onchange("certificate_id")
    def _onchange_certificate_id(self):
        """A certificate knows its own parcel, so stop asking for it."""
        if self.certificate_id and not self.shipment_id:
            shipments = self.certificate_id.shipment_ids
            if len(shipments) == 1:
                self.shipment_id = shipments

    # ------------------------------------------------------------------
    def action_open_related_batch(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.batch",
            "res_id": self.batch_id.id,
            "view_mode": "form",
        }

    def action_open_related_certificate(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.certificate",
            "res_id": self.certificate_id.id,
            "view_mode": "form",
        }

    def action_open_related_shipment(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.shipment",
            "res_id": self.shipment_id.id,
            "view_mode": "form",
        }
