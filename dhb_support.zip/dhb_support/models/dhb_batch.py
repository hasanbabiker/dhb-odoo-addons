"""Tickets, read backwards from the batch.

A coordinator looking at a batch should be able to see that six people on it
have written in this week. That fact exists nowhere else: it is spread across
six tickets that each look like one person's problem.
"""

from odoo import models, fields, api, _


class DhbBatch(models.Model):
    _inherit = "dhb.batch"

    ticket_ids = fields.One2many(
        "helpdesk.ticket", "batch_id", string="Tickets", copy=False)
    ticket_count = fields.Integer(compute="_compute_ticket_count")
    ticket_open_count = fields.Integer(compute="_compute_ticket_count")

    def _compute_ticket_count(self):
        """Two numbers, because only one of them is a problem.

        Twenty tickets over a finished six-month course is a busy batch.
        Twenty still open is a batch nobody is answering, and a single
        total hides the difference.
        """
        tickets = self.env["helpdesk.ticket"].search(
            [("batch_id", "in", self.ids)])
        for batch in self:
            mine = tickets.filtered(lambda t: t.batch_id == batch)
            batch.ticket_count = len(mine)
            # `fold` is Helpdesk's own field on the ticket, true for the
            # stages it treats as finished. Reading it beats keeping a list
            # of stage names here, which would go wrong the first time
            # somebody renames a column.
            batch.ticket_open_count = len(mine.filtered(lambda t: not t.fold))

    def action_open_tickets(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Tickets from %s") % self.display_name,
            "res_model": "helpdesk.ticket",
            "view_mode": "list,kanban,form",
            "domain": [("batch_id", "=", self.id)],
            "context": {"default_batch_id": self.id},
        }
