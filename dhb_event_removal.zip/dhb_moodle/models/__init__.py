from . import moodle_api
from . import moodle_settings
from . import res_partner
from . import registration_hook
from . import moodle_group
