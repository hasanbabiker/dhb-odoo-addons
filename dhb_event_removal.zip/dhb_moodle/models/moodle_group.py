import logging

from odoo import models, fields, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class EventEventLMSGroup(models.Model):
    """One platform group per cohort, inside the course the cohort runs on.

    The centre runs the same NEBOSH course several times a year, and the
    platform has one course for it. Without groups every intake lands in the
    same room: a tutor opening the grade book in September sees March's
    learners, attendance reports mix intakes, and an announcement meant for
    one cohort reaches four hundred people.

    The group is found by its id number rather than its name. The id number
    is ours and never changes; the name is what a tutor may rewrite on the
    platform one afternoon, and matching on it would quietly make a second
    group the next time somebody enrolled.
    """

    _inherit = "dhb.batch"

    moodle_group_name = fields.Char(
        string="LMS group",
        help="Left empty, the cohort's own name is used. Set it only when "
             "the group on the platform must read differently.",
    )
    moodle_group_state = fields.Char(
        string="LMS group status", readonly=True, copy=False)

    # ------------------------------------------------------------------
    def _moodle_course_ids(self):
        """Every platform course this cohort runs on.

        The explicit map wins, because a qualification split into units sits
        in more than one course. Then the single ID on the cohort, then the
        default configured for the platform.
        """
        self.ensure_one()
        course_ids = []

        if "dhb.moodle.course.map" in self.env:
            maps = self.env["dhb.moodle.course.map"].search([
                ("event_id", "=", self.id),
            ])
            course_ids = [m.moodle_course_id for m in maps if m.moodle_course_id]

        if not course_ids and self.moodle_course_id:
            course_ids = [self.moodle_course_id]

        if not course_ids:
            default = self.env["ir.config_parameter"].sudo().get_param(
                "dhb_moodle.default_course_id")
            if default:
                try:
                    course_ids = [int(default)]
                except (TypeError, ValueError):
                    course_ids = []

        # Dedupe, keeping the order, so a cohort mapped twice to one course
        # is not processed twice.
        seen, ordered = set(), []
        for course_id in course_ids:
            if course_id not in seen:
                seen.add(course_id)
                ordered.append(course_id)
        return ordered

    def _moodle_group_idnumber(self):
        """Ours, stable, and unique within any one course."""
        self.ensure_one()
        return "dhb-cohort-%s" % self.id

    def _moodle_group_name_for(self, course_id):
        """What the group is called on that course.

        A course map row may name it, for a course that already carried a
        group before any of this existed. Otherwise the cohort's name, which
        is what staff say out loud.
        """
        self.ensure_one()
        if self.moodle_group_name:
            return self.moodle_group_name
        if "dhb.moodle.course.map" in self.env:
            mapping = self.env["dhb.moodle.course.map"].search([
                ("event_id", "=", self.id),
                ("moodle_course_id", "=", course_id),
                ("moodle_group", "!=", False),
            ], limit=1)
            if mapping.moodle_group:
                return mapping.moodle_group
        return self.name

    # ------------------------------------------------------------------
    def _ensure_moodle_groups(self):
        """{course id: group id}, creating any group that is not there yet."""
        self.ensure_one()
        api_client = self.env["dhb.moodle.api"]
        groups = {}
        for course_id in self._moodle_course_ids():
            group = api_client.ensure_group(
                course_id,
                self._moodle_group_name_for(course_id),
                idnumber=self._moodle_group_idnumber(),
            )
            if group and group.get("id"):
                groups[course_id] = group["id"]
        return groups

    def _moodle_add_learner(self, partner, groups=None):
        """Put one learner into this cohort's group on every course.

        Returns True only if every group took them. Adding somebody twice is
        accepted by the platform and changes nothing, so this is safe to run
        again over a whole cohort.
        """
        self.ensure_one()
        if not partner or not partner.moodle_user_id:
            return False
        api_client = self.env["dhb.moodle.api"]
        if groups is None:
            groups = self._ensure_moodle_groups()
        if not groups:
            return False
        for group_id in groups.values():
            api_client.add_group_member(group_id, partner.moodle_user_id)
        return True

    def _moodle_remove_learner(self, partner, groups=None):
        self.ensure_one()
        if not partner or not partner.moodle_user_id:
            return False
        api_client = self.env["dhb.moodle.api"]
        if groups is None:
            groups = self._ensure_moodle_groups()
        for group_id in groups.values():
            try:
                api_client.remove_group_member(group_id, partner.moodle_user_id)
            except Exception:  # noqa: BLE001
                # Leaving somebody in a group they no longer belong to is
                # untidy; failing the withdrawal over it would be worse.
                _logger.exception(
                    "Could not remove %s from group %s", partner.id, group_id)
        return True

    # ------------------------------------------------------------------
    def action_sync_moodle_group(self):
        """Put every confirmed learner on this cohort into its group.

        This is the one to press after importing an intake, or the first time
        a cohort that predates groups needs sorting out. It reports what it
        did rather than claiming success: a learner with no platform account
        cannot be put in a group, and staff need their names.
        """
        self.ensure_one()
        courses = self._moodle_course_ids()
        if not courses:
            raise UserError(_(
                "No platform course is set for %s, so there is nowhere to "
                "make the group. Set the LMS course ID on the cohort, or map "
                "the cohort to a course."
            ) % self.name)

        groups = self._ensure_moodle_groups()
        if not groups:
            raise UserError(_(
                "The platform did not return a group for %s. Check that the "
                "web service token is allowed to read and create groups."
            ) % self.name)

        registrations = self.registration_ids.filtered(
            lambda r: r.state != "cancel")
        added, skipped = 0, []
        for registration in registrations:
            partner = registration.partner_id
            if not partner or not partner.moodle_user_id:
                skipped.append(partner.display_name if partner else _("?"))
                continue
            try:
                self._moodle_add_learner(partner, groups=groups)
                added += 1
            except Exception as exc:  # noqa: BLE001
                _logger.exception(
                    "Group add failed for partner %s", partner.id)
                skipped.append("%s (%s)" % (partner.display_name, exc))

        summary = _(
            "%(added)s learner(s) in the group on %(courses)s course(s); "
            "%(skipped)s could not be added."
        ) % {"added": added, "courses": len(groups), "skipped": len(skipped)}
        self.moodle_group_state = summary

        if skipped:
            self.message_post(body=_(
                "Platform group sync. These learners have no platform "
                "account yet, so they are not in the group:<br/>%s"
            ) % "<br/>".join(skipped[:50]))

        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Platform group"),
                "message": summary,
                "sticky": bool(skipped),
                "type": "warning" if skipped else "success",
            },
        }
