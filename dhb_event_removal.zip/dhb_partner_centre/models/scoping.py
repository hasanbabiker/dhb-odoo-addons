from odoo import models, fields, api


def _default_centre(env):
    """The centre of whoever is doing this, or nothing for DHB staff."""
    return env.user.partner_centre_id.id or False


class PartnerScoped(models.Model):
    """The learner belongs to the centre that recruited them."""

    _inherit = "res.partner"

    partner_centre_id = fields.Many2one(
        "dhb.partner.centre", string="Partner centre", index=True,
        default=lambda self: _default_centre(self.env),
        help="Which centre this learner is with. Filled in from whoever "
             "created the record, so nobody has to remember it.",
    )


class EventScoped(models.Model):
    """A cohort belongs to one centre, or to DHB when it is empty."""

    _inherit = "dhb.batch"

    partner_centre_id = fields.Many2one(
        "dhb.partner.centre", string="Partner centre", index=True,
        default=lambda self: _default_centre(self.env),
        help="Empty means this is DHB's own cohort.",
    )


class RegistrationScoped(models.Model):
    """A place on a cohort is scoped by the cohort it is on.

    Stored rather than looked up each time: a record rule runs on every
    read, and a rule that has to walk a relation to decide is a rule that
    slows every list in the system.
    """

    _inherit = "dhb.batch.line"

    partner_centre_id = fields.Many2one(
        "dhb.partner.centre", string="Partner centre", index=True,
        compute="_compute_partner_centre", store=True, readonly=False,
    )

    @api.depends("event_id.partner_centre_id", "partner_id.partner_centre_id")
    def _compute_partner_centre(self):
        for registration in self:
            registration.partner_centre_id = (
                registration.event_id.partner_centre_id
                or registration.partner_id.partner_centre_id
            )


class InviteScoped(models.Model):
    """The application, which is where a partner does most of their work."""

    _inherit = "dhb.registration.invite"

    partner_centre_id = fields.Many2one(
        "dhb.partner.centre", string="Partner centre", index=True,
        default=lambda self: _default_centre(self.env),
        tracking=True,
    )

    @api.model_create_multi
    def create(self, vals_list):
        """Stamp the centre from the person creating it, always.

        Not left to the default alone: an application can be created by a
        controller, an import or a button, and any of those can pass values
        that skip defaults. The centre is what the isolation rule reads, so
        it must never be absent by accident.
        """
        for values in vals_list:
            if not values.get("partner_centre_id"):
                centre = _default_centre(self.env)
                if centre:
                    values["partner_centre_id"] = centre
        applications = super().create(vals_list)
        for application in applications:
            if application.partner_id and not application.partner_id.partner_centre_id \
                    and application.partner_centre_id:
                # The learner belongs to whoever recruited them. Written here
                # because a partner's learner created through the public form
                # has no user behind it to take a centre from.
                application.partner_id.partner_centre_id = \
                    application.partner_centre_id
        return applications


class RegisterScoped(models.Model):
    """The intake a centre publishes applications through."""

    _inherit = "dhb.admission.register"

    partner_centre_id = fields.Many2one(
        "dhb.partner.centre", string="Partner centre", index=True,
        default=lambda self: _default_centre(self.env),
    )
