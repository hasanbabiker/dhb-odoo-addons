from odoo import models, fields, _
from odoo.exceptions import UserError


class EnrolmentImportWizard(models.TransientModel):
    """Browse the LMS courses and register their learners on a cohort.

    One screen rather than two: the courses come back with the count of people
    already on them, so the person mapping can see at a glance which LMS
    course is the busy one and which is an empty shell.
    """

    _name = "dhb.enrolment.import.wizard"
    _description = "Import LMS enrolments"

    line_ids = fields.One2many(
        "dhb.enrolment.import.line", "wizard_id", string="LMS courses")
    scanned = fields.Boolean(readonly=True)
    summary = fields.Char(readonly=True)
    default_event_id = fields.Many2one("dhb.batch", string="Cohort")

    def action_scan(self):
        """List the LMS courses, with any mapping already recorded."""
        self.ensure_one()
        api_client = self.env["dhb.moodle.api"]
        self.line_ids.unlink()

        existing = {
            mapping.moodle_course_id: mapping
            for mapping in self.env["dhb.moodle.course.map"].search([])
        }

        courses = api_client.list_courses() or []
        values = []
        for course in courses:
            course_id = course.get("id")
            # LMS front page is a course with id 1 and format "site".
            if not course_id or (course.get("format") or "") == "site":
                continue
            mapping = existing.get(int(course_id))
            values.append({
                "wizard_id": self.id,
                "moodle_course_id": int(course_id),
                "moodle_course_name": course.get("fullname"),
                "moodle_course_shortname": course.get("shortname"),
                "event_id": mapping.event_id.id if mapping
                            else self.default_event_id.id or False,
                "already_mapped": bool(mapping),
                "selected": bool(mapping),
            })
        self.env["dhb.enrolment.import.line"].create(values)
        self.scanned = True
        self.summary = _("%s courses on LMS.") % len(values)
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }

    def action_apply(self):
        """Map the ticked courses and pull their learners in."""
        self.ensure_one()
        chosen = self.line_ids.filtered(lambda l: l.selected and l.event_id)
        if not chosen:
            raise UserError(_(
                "Tick at least one LMS course and give it a cohort."
            ))
        CourseMap = self.env["dhb.moodle.course.map"]
        summaries, mappings = [], CourseMap.browse()
        for line in chosen:
            mapping = CourseMap.search([
                ("moodle_course_id", "=", line.moodle_course_id),
                ("event_id", "=", line.event_id.id),
                ("moodle_group", "=", line.moodle_group or False),
            ], limit=1)
            if not mapping:
                mapping = CourseMap.create({
                    "moodle_course_id": line.moodle_course_id,
                    "moodle_course_name": line.moodle_course_name,
                    "moodle_course_shortname": line.moodle_course_shortname,
                    "moodle_group": line.moodle_group or False,
                    "event_id": line.event_id.id,
                })
            mappings |= mapping
            summaries.append("%s: %s" % (
                line.moodle_course_name or line.moodle_course_id,
                mapping._import_one(),
            ))

        return {
            "type": "ir.actions.act_window",
            "name": _("LMS courses and cohorts"),
            "res_model": "dhb.moodle.course.map",
            "view_mode": "list,form",
            "domain": [("id", "in", mappings.ids)],
            "context": {"import_summary": "\n".join(summaries)},
        }


class EnrolmentImportLine(models.TransientModel):
    _name = "dhb.enrolment.import.line"
    _description = "LMS course offered for import"
    _order = "moodle_course_name"

    wizard_id = fields.Many2one(
        "dhb.enrolment.import.wizard", required=True, ondelete="cascade")
    selected = fields.Boolean(string="Import")
    moodle_course_id = fields.Integer(string="LMS ID", readonly=True)
    moodle_course_name = fields.Char(string="LMS course", readonly=True)
    moodle_course_shortname = fields.Char(string="Short name", readonly=True)
    moodle_group = fields.Char(
        string="Group",
        help="Leave empty to take everyone on the course.")
    event_id = fields.Many2one("dhb.batch", string="Cohort")
    already_mapped = fields.Boolean(string="Mapped", readonly=True)
