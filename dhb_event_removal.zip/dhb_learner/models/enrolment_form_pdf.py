import base64
import io
import logging
import os

from odoo import models, fields, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

TEMPLATE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "static", "src", "doc", "DHB_NEBOSH_Enrolment_Form_Fillable.pdf",
)

# Values the form's own widgets accept. Read off the template rather than
# guessed: a value outside these is silently ignored by most PDF readers,
# which would leave a tick box looking untouched on a document sent to the
# awarding body.
TITLE_OPTIONS = {
    "Mr": "/Mr", "Mrs": "/Mrs", "Miss": "/Miss", "Ms": "/Ms", "N/A": "/NA",
}
ID_OPTIONS = {
    "passport": "/Passport",
    "driving_licence": "/DrivingLicence",
    "national_id": "/NationalID",
    "birth_certificate": "/BirthCertificate",
    "other": "/Other",
}
# The registration form's own options predate the current NEBOSH study modes,
# so the four modes are mapped onto the five boxes the form actually has.
STUDY_OPTIONS = {
    "full_time": "/F2F",
    "part_time": "/F2F",
    "virtual": "/Online",
    "elearning": "/Elearning",
}
GENDER_OPTIONS = {"Male": "M", "Female": "F", "Unspecified": "N"}

CONSENT_ON = "/Yes_ecxb"
OPTOUT_ON = "/Yes_lmba"
POLICY_ON = "/Yes_lvau"


class ResPartnerEnrolmentPdf(models.Model):
    _inherit = "res.partner"

    def _enrolment_values(self, registration=None):
        """Everything the enrolment form asks for, keyed by its field names."""
        self.ensure_one()
        event = registration.event_id if registration else self.env["dhb.batch"]

        address = ", ".join(filter(None, [
            self.street, self.street2, self.city, self.zip,
            self.country_id.name,
        ]))

        values = {
            "FullLegalName": (self.certificate_name_format or self.legal_name or self.name or "").upper(),
            "LearnerNumber": self.nebosh_learner_number or "",
            "DateOfBirth": self.date_of_birth.strftime("%d/%m/%Y") if self.date_of_birth else "",
            "EmailAddress": (self.email or "").upper(),
            "PhoneNumber1": self.mobile_phone or self.phone or "",
            "PhoneNumber2": self.work_phone or self.home_phone or "",
            "Address": address.upper(),
            "Nationality": self.nebosh_nationality or "",
            "IDType_Other": (self.id_document_other or "").upper(),
        }

        title = self.learner_title if self.learner_title in TITLE_OPTIONS else "Other"
        values["Title"] = TITLE_OPTIONS.get(title, "/Other")
        values["IDType"] = ID_OPTIONS.get(self.id_document_type, "/Other")
        if self.gender:
            values["Gender"] = GENDER_OPTIONS.get(self.gender, "N")
        if self.nebosh_consent:
            values["Consent_Registration"] = CONSENT_ON
        if self.nebosh_marketing_opt_out:
            values["OptOut_Marketing"] = OPTOUT_ON

        if event:
            values["CourseRequired"] = dict(
                event._fields["qualification"].selection
            ).get(event.qualification, event.name or "")
            if event.delivery_mode:
                values["StudyMethod"] = STUDY_OPTIONS.get(event.delivery_mode, "/Other")
            if event.date_begin:
                values["CourseStartDate"] = fields.Datetime.context_timestamp(
                    self, event.date_begin
                ).strftime("%d/%m/%Y")

        # Policy page: filled from the acceptance actually recorded, not from
        # a tick the centre adds on the learner's behalf.
        acceptance = self.env["dhb.policy.acceptance"].sudo().search(
            [("partner_id", "=", self.id)], order="accepted_on desc", limit=1
        ) if "dhb.policy.acceptance" in self.env else None
        if acceptance:
            values["Policy_Name"] = (self.legal_name or self.name or "").upper()
            values["Policy_Date"] = acceptance.accepted_on.strftime("%d/%m/%Y")
            values["Policy_Agree"] = POLICY_ON
            values["Policy_Signature"] = _("Accepted online on %s (IP %s)") % (
                acceptance.accepted_on.strftime("%d/%m/%Y %H:%M"),
                acceptance.ip_address or "-",
            )

        return values

    def _enrolment_fill_pdf(self, registration=None):
        """Write the values into the official fillable form."""
        self.ensure_one()
        if not os.path.exists(TEMPLATE_PATH):
            raise UserError(_("The enrolment form template is missing from the module."))

        try:
            from pypdf import PdfReader, PdfWriter
        except ImportError as exc:
            raise UserError(_(
                "The pypdf library is not available in the Odoo container."
            )) from exc

        reader = PdfReader(TEMPLATE_PATH)
        writer = PdfWriter()
        writer.append(reader)

        values = {k: v for k, v in self._enrolment_values(registration).items() if v}

        # Fields live on different pages, so every page is offered the whole
        # set; pypdf writes only the ones it finds there.
        for page in writer.pages:
            try:
                writer.update_page_form_field_values(page, values)
            except Exception:  # noqa: BLE001
                _logger.debug("No form fields on one page of the enrolment form")

        # Make the entered values visible in readers that would otherwise show
        # an empty form until each field is clicked.
        try:
            writer.set_need_appearances_writer(True)
        except Exception:  # noqa: BLE001
            pass

        buffer = io.BytesIO()
        writer.write(buffer)
        return buffer.getvalue()

    # ------------------------------------------------------------------
    def action_enrolment_form_pdf(self):
        """Download the learner's own enrolment form, filled in."""
        self.ensure_one()
        registration = self.env["dhb.batch.line"].search(
            [("partner_id", "=", self.id)], order="create_date desc", limit=1
        )
        content = self._enrolment_fill_pdf(registration)
        filename = "NEBOSH_Enrolment_%s.pdf" % (
            (self.legal_name or self.name or "learner").replace(" ", "_")
        )
        attachment = self.env["ir.attachment"].create({
            "name": filename,
            "type": "binary",
            "datas": base64.b64encode(content),
            "res_model": "res.partner",
            "res_id": self.id,
            "mimetype": "application/pdf",
        })
        self.message_post(
            body=_("Enrolment form generated."),
            attachment_ids=[attachment.id],
        )
        return {
            "type": "ir.actions.act_url",
            "url": "/web/content/%s?download=true" % attachment.id,
            "target": "self",
        }
