from odoo import models, api, _
from odoo.exceptions import UserError


class EventRegistrationBlock(models.Model):
    """Stops a blocked learner being registered, rather than warning about it.

    A learner under NEBOSH investigation, or barred by a sanction, must not be
    entered for a further assessment. Left as a flag on the contact, that gets
    missed the next time someone fills a cohort — and a missed one is a breach
    in front of the awarding body, not an administrative slip.
    """

    _inherit = "dhb.batch.line"

    @api.model_create_multi
    def create(self, vals_list):
        partner_ids = [v.get("partner_id") for v in vals_list if v.get("partner_id")]
        if partner_ids:
            blocked = self.env["res.partner"].browse(partner_ids).filtered(
                "registration_blocked"
            )
            if blocked:
                raise UserError(_(
                    "These learners cannot be registered:\n\n%s\n\n"
                    "If NEBOSH has agreed in writing that a learner may sit "
                    "while under investigation, record their reference on the "
                    "contact first."
                ) % "\n".join(
                    "• %s — %s" % (p.display_name, p.registration_block_reason or "")
                    for p in blocked
                ))
        return super().create(vals_list)

    def write(self, values):
        if values.get("partner_id"):
            partner = self.env["res.partner"].browse(values["partner_id"])
            if partner.registration_blocked:
                raise UserError(_(
                    "%(name)s cannot be registered: %(reason)s",
                    name=partner.display_name,
                    reason=partner.registration_block_reason or "",
                ))
        return super().write(values)
