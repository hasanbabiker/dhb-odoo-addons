import base64
import io
import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

# The template's own column order, taken from the file NEBOSH publishes.
# Column A holds the row number; the data starts at column B.
COLUMNS = [
    "StudentNo",
    "Title",
    "Forenames/GivenName",
    "Surname/FamilyName",
    "Gender",
    "DOB",
    "Nationality",
    "MailAddress",
    "AddressLine1",
    "AddressLine2",
    "AddressLine3",
    "AddressLine4",
    "Town/City",
    "County",
    "Postcode",
    "Country",
    "WorkPhone",
    "HomePhone",
    "MobilePhone",
    "Email",
]

# The single worked example NEBOSH ships in row 1, kept so the file a course
# provider opens looks exactly like the one they are used to.
EXAMPLE_ROW = [
    "EXAMPLE", "Mr", "John", "Smith", "Male", "15/01/1980", "UK", "H",
    "12 Main Street", "Charles Town", "", "", "IOWA", "", "", "US",
    "641-257-1234", "", "", "info@theoffice.com",
]

# NEBOSH splits an upload into files of 39 learners.
ROWS_PER_FILE = 39


class DhbNeboshExportWizard(models.TransientModel):
    """Export a cohort's learners in the NEBOSH student data import layout.

    The point is not to save typing. It is that a hand-typed import file
    carries transcription errors into the awarding body's records, and a
    learner whose date of birth or surname differs between Odoo and NEBOSH is
    exactly the discrepancy an audit picks up.
    """

    _name = "dhb.nebosh.export.wizard"
    _description = "NEBOSH student data export"

    event_id = fields.Many2one("dhb.batch", string="Cohort", required=True)
    partner_ids = fields.Many2many(
        "res.partner", string="Learners",
        domain="[('is_learner', '=', True)]",
    )
    include_example_row = fields.Boolean(
        string="Keep the EXAMPLE row", default=True,
        help="NEBOSH ships one worked example in the first row. Keeping it "
             "makes the file look like the template they expect.",
    )
    file_format = fields.Selection(
        [("xlsx", "Excel (.xlsx)"), ("csv", "CSV")],
        default="xlsx",
        required=True,
        string="Format",
    )

    problem_report = fields.Text(string="Problems found", readonly=True)
    output_file = fields.Binary(string="File", readonly=True, attachment=False)
    output_filename = fields.Char(string="Filename", readonly=True)
    state = fields.Selection(
        [("draft", "Draft"), ("checked", "Checked"), ("done", "Ready")],
        default="draft",
    )

    @api.onchange("event_id")
    def _onchange_event_id(self):
        for wizard in self:
            registrations = wizard.event_id.registration_ids
            wizard.partner_ids = registrations.mapped("partner_id").filtered("is_learner")

    # ------------------------------------------------------------------
    # validation before export, not after rejection
    # ------------------------------------------------------------------
    def action_check(self):
        self.ensure_one()
        if not self.partner_ids:
            raise UserError(_("No learners selected."))

        titles = dict(self.env["res.partner"]._fields["learner_title"].selection)
        problems = []

        for partner in self.partner_ids:
            issues = []
            if not partner.legal_forenames:
                issues.append(_("no forenames"))
            if not partner.legal_surname:
                issues.append(_("no surname"))
            if not partner.date_of_birth:
                issues.append(_("no date of birth"))
            if not partner.gender:
                issues.append(_("no gender"))
            if partner.learner_title and partner.learner_title not in titles:
                issues.append(_("title not on the NEBOSH list"))
            if not partner.nebosh_nationality:
                issues.append(_("no NEBOSH nationality"))
            if not partner.email:
                issues.append(_("no email"))
            if not partner.country_id:
                issues.append(_("no country"))
            if issues:
                problems.append("• %s — %s" % (partner.display_name, ", ".join(issues)))

        if problems:
            self.problem_report = _(
                "%(count)s of %(total)s learners would be rejected on upload:\n\n%(list)s\n\n"
                "Fix these first. A file that fails halfway leaves some "
                "learners registered and others not, which is harder to "
                "unpick than fixing it now.",
                count=len(problems), total=len(self.partner_ids),
                list="\n".join(problems),
            )
        else:
            self.problem_report = _(
                "All %s learners have the fields NEBOSH requires."
            ) % len(self.partner_ids)

        self.state = "checked"
        return self._reopen()

    # ------------------------------------------------------------------
    # building the rows
    # ------------------------------------------------------------------
    def _partner_row(self, partner):
        """One learner as the template's twenty columns."""
        return [
            partner.nebosh_learner_number or "",
            partner.learner_title or "",
            partner.legal_forenames or "",
            partner.legal_surname or "",
            partner.gender or "",
            partner.date_of_birth.strftime("%d/%m/%Y") if partner.date_of_birth else "",
            partner.nebosh_nationality or "",
            partner.mail_address_type or "H",
            partner.street or "",
            partner.street2 or "",
            "",
            "",
            partner.city or "",
            partner.state_id.name or "",
            partner.zip or "",
            partner.country_id.name or "",
            partner.work_phone or "",
            partner.home_phone or partner.phone or "",
            partner.mobile_phone or "",
            partner.email or "",
        ]

    def action_export(self):
        self.ensure_one()
        if not self.partner_ids:
            raise UserError(_("No learners selected."))
        if len(self.partner_ids) > ROWS_PER_FILE:
            raise UserError(_(
                "NEBOSH takes %(limit)s learners per import file and you have "
                "selected %(count)s. Split the selection and export each part "
                "separately.",
                limit=ROWS_PER_FILE, count=len(self.partner_ids),
            ))

        rows = [self._partner_row(p) for p in self.partner_ids]
        if self.include_example_row:
            rows.insert(0, list(EXAMPLE_ROW))

        base = "NEBOSH_import_%s" % (self.event_id.name or "learners").replace(" ", "_")[:40]

        if self.file_format == "csv":
            content = self._build_csv(rows)
            filename = base + ".csv"
        else:
            content = self._build_xlsx(rows)
            filename = base + ".xlsx"

        self.output_file = base64.b64encode(content)
        self.output_filename = filename
        self.state = "done"
        return self._reopen()

    def _build_csv(self, rows):
        import csv
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow([""] + COLUMNS)
        for index, row in enumerate(rows, start=1):
            writer.writerow([index] + row)
        return buffer.getvalue().encode("utf-8-sig")

    def _build_xlsx(self, rows):
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font
        except ImportError as exc:  # pragma: no cover
            raise UserError(_(
                "openpyxl is not available on this server, so only CSV export "
                "is possible."
            )) from exc

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Sheet1"

        # Column A is the row number in the template; the headers start at B.
        for column, header in enumerate(COLUMNS, start=2):
            cell = sheet.cell(row=1, column=column, value=header)
            cell.font = Font(name="Arial", bold=True)

        for index, row in enumerate(rows, start=1):
            sheet.cell(row=index + 1, column=1, value=index)
            for column, value in enumerate(row, start=2):
                sheet.cell(row=index + 1, column=column, value=value).font = Font(name="Arial")

        widths = [5, 12, 8, 20, 20, 12, 12, 14, 12, 22, 22, 16, 16, 18, 14, 12, 18, 16, 16, 16, 26]
        for position, width in enumerate(widths, start=1):
            sheet.column_dimensions[sheet.cell(row=1, column=position).column_letter].width = width

        buffer = io.BytesIO()
        workbook.save(buffer)
        return buffer.getvalue()

    def _reopen(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }
