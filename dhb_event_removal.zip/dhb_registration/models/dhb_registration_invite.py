import secrets

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbRegistrationInvite(models.Model):
    """A single-use link that lets one learner complete their own record.

    A wide-open public form would fill the database with junk contacts and
    leave no way to tie a submission to anything the centre actually issued.
    An invitation carries the cohort with it, so a completed form lands on the
    right course without the learner having to pick one.
    """

    _name = "dhb.registration.invite"
    _description = "Learner registration invitation"
    _order = "create_date desc"
    _inherit = ["mail.thread"]

    name = fields.Char(string="Reference", readonly=True, copy=False, default="/")
    token = fields.Char(string="Token", readonly=True, copy=False, index=True)
    event_id = fields.Many2one(
        "dhb.batch", string="Cohort", required=True, tracking=True
    )
    partner_id = fields.Many2one(
        "res.partner", string="Learner", tracking=True,
        help="Left empty for a new learner; the form creates the contact on "
             "submission.",
    )
    email = fields.Char(string="Email", required=True, tracking=True)
    learner_name = fields.Char(string="Name given when inviting")

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("sent", "Sent"),
            ("opened", "Opened"),
            ("submitted", "Submitted"),
            ("expired", "Expired"),
            ("cancelled", "Cancelled"),
        ],
        default="draft",
        required=True,
        tracking=True,
        index=True,
    )
    expiry_date = fields.Date(
        string="Valid until",
        default=lambda self: fields.Date.add(fields.Date.today(), days=30),
        help="A stale link is a small risk, not a large one, but an expiry "
             "date means an abandoned invitation cannot be used a year later.",
    )
    opened_on = fields.Datetime(readonly=True)
    submitted_on = fields.Datetime(readonly=True)
    submitted_ip = fields.Char(readonly=True)
    registration_id = fields.Many2one(
        "dhb.batch.line", string="Registration created", readonly=True
    )
    url = fields.Char(string="Link", compute="_compute_url")

    # The one that matters most here. A registration link IS the learner's
    # identity on the public form; two applications sharing a token means one
    # learner opening another's application.
    _unique_token = models.Constraint(
        "unique(token)",
        "Token collision — try again.",
    )

    @api.model_create_multi
    def create(self, vals_list):
        for values in vals_list:
            if not values.get("token"):
                values["token"] = secrets.token_urlsafe(32)
            if values.get("name", "/") == "/":
                values["name"] = self.env["ir.sequence"].next_by_code(
                    "dhb.registration.invite"
                ) or "/"
        return super().create(vals_list)

    @api.depends("token")
    def _compute_url(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url", "")
        for invite in self:
            invite.url = "%s/learner/register/%s" % (base, invite.token) if invite.token else False

    def _is_usable(self):
        self.ensure_one()
        if self.state in ("cancelled", "submitted"):
            return False
        if self.expiry_date and self.expiry_date < fields.Date.today():
            return False
        return True

    def action_send(self):
        """Queue the invitation email.

        Deliberately does not raise when mail is not configured: DHB's outgoing
        mail server has been pending for weeks, and the link is still usable by
        copying it out of this record.
        """
        template = self.env.ref(
            "dhb_registration.mail_template_registration_invite",
            raise_if_not_found=False,
        )
        for invite in self:
            if not invite._is_usable():
                raise UserError(_("This invitation is expired or already used."))
            if template:
                template.send_mail(invite.id, force_send=False)
            invite.state = "sent"
            invite.message_post(body=_(
                "Invitation link issued to %s. If mail is not yet configured, "
                "copy the link from this record and send it by WhatsApp."
            ) % invite.email)
        return True

    def action_cancel(self):
        self.write({"state": "cancelled"})
        return True

    def action_open_registration(self):
        self.ensure_one()
        if not self.registration_id:
            raise UserError(_("Nothing has been submitted against this invitation yet."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.batch.line",
            "res_id": self.registration_id.id,
            "view_mode": "form",
        }

    @api.model
    def _cron_expire(self):
        stale = self.search([
            ("state", "in", ("draft", "sent", "opened")),
            ("expiry_date", "<", fields.Date.today()),
        ])
        stale.write({"state": "expired"})
        return True
