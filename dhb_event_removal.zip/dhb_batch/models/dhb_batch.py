import pytz

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


def _tz_get(self):
    return [
        (tz, tz)
        for tz in sorted(
            pytz.all_timezones,
            key=lambda tz: tz if not tz.startswith("Etc/") else "_",
        )
    ]


class DhbBatch(models.Model):
    """A cohort of learners taking one qualification together.

    The field names on the relation side are deliberately the ones the rest
    of the system already uses - `registration_ids` here, `event_id` on the
    place. Nobody sees a technical field name; what people read on screen is
    the label. Keeping the names means the nine modules that read the cohort
    today keep working when they are pointed at this model, instead of
    needing two hundred edits that each carry their own chance of a typo.
    """

    _name = "dhb.batch"
    _description = "Batch"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_begin desc, id desc"

    name = fields.Char(
        string="Batch", required=True, tracking=True, index="trigram",
        help="How staff refer to this cohort. For example "
             "\"IGC February 2026 - Group 1\".",
    )
    code = fields.Char(
        string="Reference", tracking=True, index=True, copy=False,
        help="A short code for registers and file names, such as "
             "IGC-2602-G1. Optional, but it has to be unique when set.",
    )
    # An empty Char is stored as NULL, and Postgres allows many NULLs in a
    # unique index, so this constrains only the codes that are actually set.
    _unique_code = models.Constraint(
        "unique(code)",
        "Another batch already uses that reference.",
    )

    state = fields.Selection(
        [
            ("planned", "Planned"),
            ("open", "Open for applications"),
            ("running", "Running"),
            ("exams", "Exams"),
            ("done", "Finished"),
            ("cancelled", "Cancelled"),
        ],
        string="Stage", default="planned", required=True, tracking=True,
        index=True, group_expand="_group_expand_state",
        help="Where the batch is in its life. The board is grouped by this, "
             "so one glance answers which cohorts are live.",
    )

    date_begin = fields.Datetime(
        string="Starts", required=True, tracking=True, index=True,
        default=lambda self: fields.Datetime.now(),
    )
    date_end = fields.Datetime(string="Ends", required=True, tracking=True)
    date_tz = fields.Selection(
        _tz_get, string="Time zone", required=True,
        default=lambda self: self.env.user.tz or "Asia/Dubai",
    )
    duration_days = fields.Integer(
        string="Days", compute="_compute_duration_days", store=True,
    )

    seats_limited = fields.Boolean(
        string="Limit the places", default=False,
        help="Turn this on to cap how many learners the batch takes.",
    )
    seats_max = fields.Integer(
        string="Places", help="Maximum number of learners on this batch.",
    )
    # Kept under this name because a stored compute in the attendance module
    # depends on it. The label is what people read.
    seats_taken = fields.Integer(
        string="Registered", compute="_compute_seats", store=True,
    )
    seats_available = fields.Integer(
        string="Places left", compute="_compute_seats", store=True,
    )
    is_full = fields.Boolean(compute="_compute_seats", store=True)

    registration_ids = fields.One2many(
        "dhb.batch.line", "event_id", string="Learners",
    )

    user_id = fields.Many2one(
        "res.users", string="Coordinator", tracking=True,
        default=lambda self: self.env.user,
        help="Who runs this batch day to day.",
    )
    address_id = fields.Many2one(
        "res.partner", string="Venue",
        help="Where it is held. Leave empty for a batch delivered online.",
    )
    company_id = fields.Many2one(
        "res.company", string="Company", required=True,
        default=lambda self: self.env.company,
    )

    description = fields.Html(string="Description")
    note = fields.Html(
        string="Internal notes",
        help="Not shown to learners.",
    )
    active = fields.Boolean(default=True)

    # ------------------------------------------------------------------
    @api.model
    def _group_expand_state(self, states, domain):
        """Show every stage as a column, including the empty ones.

        A board that hides "Exams" until a batch reaches it makes the stage
        look like it does not exist.
        """
        return [key for key, _label in self._fields["state"].selection]

    @api.depends("date_begin", "date_end")
    def _compute_duration_days(self):
        for batch in self:
            if batch.date_begin and batch.date_end:
                delta = batch.date_end - batch.date_begin
                batch.duration_days = delta.days + 1
            else:
                batch.duration_days = 0

    @api.depends("registration_ids.state", "seats_max", "seats_limited")
    def _compute_seats(self):
        for batch in self:
            taken = len(batch.registration_ids.filtered(
                lambda line: line.state in ("draft", "open", "done")))
            batch.seats_taken = taken
            if batch.seats_limited and batch.seats_max:
                batch.seats_available = max(batch.seats_max - taken, 0)
                batch.is_full = taken >= batch.seats_max
            else:
                batch.seats_available = 0
                batch.is_full = False

    @api.constrains("date_begin", "date_end")
    def _check_dates(self):
        for batch in self:
            if batch.date_begin and batch.date_end \
                    and batch.date_end < batch.date_begin:
                raise ValidationError(_(
                    "%s ends before it starts.") % batch.display_name)

    @api.constrains("seats_limited", "seats_max")
    def _check_seats(self):
        for batch in self:
            if batch.seats_limited and batch.seats_max <= 0:
                raise ValidationError(_(
                    "%s limits the places but the number of places is not "
                    "set.") % batch.display_name)

    @api.depends("name", "code")
    def _compute_display_name(self):
        for batch in self:
            batch.display_name = \
                "[%s] %s" % (batch.code, batch.name) if batch.code \
                else (batch.name or "")

    # ------------------------------------------------------------------
    def action_open_applications(self):
        self.write({"state": "open"})

    def action_start(self):
        self.write({"state": "running"})

    def action_exams(self):
        self.write({"state": "exams"})

    def action_finish(self):
        self.write({"state": "done"})

    def action_cancel(self):
        self.write({"state": "cancelled"})

    def action_back_to_planned(self):
        self.write({"state": "planned"})

    def action_open_learners(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learners on %s") % self.display_name,
            "res_model": "dhb.batch.line",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }
