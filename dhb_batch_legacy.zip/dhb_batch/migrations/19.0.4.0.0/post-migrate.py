"""Give the ten qualifications a status, and do not guess anything else.

The qualifications created by the previous migration were born without a
status field, so they would all default to Draft - and a Draft qualification
is one nobody has confirmed we are approved to deliver. That is the correct
default for a qualification created from now on, and precisely the wrong
thing to assert about ten qualifications the centre is delivering today.

So: anything the centre has courses for is Active. Nothing else is touched.
The approval dates and the syllabus window stay empty, because inventing a
renewal date is worse than having none - an empty field says "look this up",
a wrong one says "you have until March".
"""

import logging

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    if not version:
        return

    cr.execute("""
        UPDATE dhb_qualification q
           SET status = 'active'
         WHERE (q.status IS NULL OR q.status = 'draft')
           AND EXISTS (SELECT 1 FROM dhb_course c
                        WHERE c.qualification_id = q.id)
    """)
    activated = cr.rowcount

    # TQT is stored and computed. Odoo recomputes it on upgrade, but only
    # for rows it knows are stale; these rows have never had the column at
    # all, so it is filled here and the recompute confirms it.
    cr.execute("""
        UPDATE dhb_qualification
           SET tqt_hours = COALESCE(guided_hours, 0)
                         + COALESCE(private_study_hours, 0)
         WHERE tqt_hours IS NULL
    """)

    # Somebody has to be answerable, or the first renewal reminder is filed
    # on OdooBot's activity list and read by nobody. The administrator is
    # not a guess at who should own these - it is the only user this script
    # can know exists - and it is meant to be changed on each record.
    cr.execute("""
        UPDATE dhb_qualification q
           SET manager_id = d.res_id
          FROM ir_model_data d
         WHERE d.module = 'base' AND d.name = 'user_admin'
           AND d.model = 'res.users'
           AND q.manager_id IS NULL
    """)
    assigned = cr.rowcount

    _logger.info(
        "Qualifications: %s set to Active (they have courses), "
        "%s given an owner for approval reminders.", activated, assigned)
