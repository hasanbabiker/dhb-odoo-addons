"""Split the qualification out of the course, without guessing.

Every course in the catalogue today is a qualification and a way of
delivering it, fused into one row. This gives each of them a qualification
of its own and points the course at it - strictly one for one.

It deliberately does NOT try to be clever. It does not merge two courses
that look like the same qualification, and it does not invent the classroom
version of a course the centre only delivers online. Both would be the
system deciding what the centre sells, which it is not entitled to do. What
comes out is exactly what went in, with the layer separated; the second
course of a qualification is created by a person, on the day they decide to
sell it.
"""

import logging

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    if not version:
        return

    # Courses that have not been given a qualification yet. Written as a
    # condition rather than assumed, so that re-running this - which Odoo
    # will not normally do, but a restored database might - cannot produce a
    # second qualification for the same course.
    cr.execute("""
        SELECT id, name, code, awarding_body, qualification, sequence
          FROM dhb_course
         WHERE qualification_id IS NULL
      ORDER BY sequence, id
    """)
    courses = cr.fetchall()
    if not courses:
        _logger.info("Qualifications: nothing to split, every course "
                     "already points at one.")
        return

    created = 0
    for course_id, name, code, body, legacy_key, sequence in courses:
        # The code is unique on the course, so it is unique here too. If a
        # qualification with it somehow exists already - a half-finished
        # earlier run - it is reused rather than duplicated.
        cr.execute(
            "SELECT id FROM dhb_qualification WHERE code = %s", (code,))
        row = cr.fetchone()
        if row:
            qualification_id = row[0]
        else:
            cr.execute("""
                INSERT INTO dhb_qualification
                    (name, code, awarding_body, selection_key, sequence,
                     active, registration_validity_months, status,
                     create_uid, create_date, write_uid, write_date)
                VALUES (%s, %s, %s, %s, %s, TRUE, 60, 'active',
                        1, NOW() AT TIME ZONE 'UTC',
                        1, NOW() AT TIME ZONE 'UTC')
                RETURNING id
            """, (name, code, body or "nebosh", legacy_key, sequence or 10))
            qualification_id = cr.fetchone()[0]
            created += 1

        cr.execute(
            "UPDATE dhb_course SET qualification_id = %s WHERE id = %s",
            (qualification_id, course_id))

    _logger.info(
        "Qualifications: %s created, %s courses linked.",
        created, len(courses))
