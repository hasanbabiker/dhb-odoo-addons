"""Give the existing catalogue an honest status.

A new selection column arrives with its default on every existing row, and
the default here is Draft. That would mark IGC, DI2 and EMC as drafts while
batches of them are running, which is not merely untidy - Draft refuses to
open a new batch, so the first thing the centre would meet on Monday is a
refusal on a course it has been teaching for weeks.

So: a course that has ever run is Active, and everything else stays Draft,
which for a course with no fee and no length is the truth.

Deliberately not checked here: whether an Active course is fully set up. It
is in use; saying so is the point. The list still shows what is missing on
it, and the Activate button refuses to promote anything else until it is
filled in.
"""


def migrate(cr, version):
    if not version:
        return
    cr.execute("""
        UPDATE dhb_course c
           SET status = 'active'
         WHERE c.status = 'draft'
           AND EXISTS (SELECT 1 FROM dhb_batch b WHERE b.course_id = c.id)
    """)
