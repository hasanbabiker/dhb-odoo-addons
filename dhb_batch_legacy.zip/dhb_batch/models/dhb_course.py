from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

from .constants import (
    AWARDING_BODIES, LANGUAGES, QUALIFICATIONS, STUDY_MODES,
)


class DhbCourse(models.Model):
    """A course the centre offers, described once.

    Before this, every batch asked for the qualification, the language, the
    study mode, the number of lectures, the length and the fee - ten fields,
    every time, from memory. What that produces is visible in any database
    that has run a while: batches named after whoever typed them, dates left
    on their defaults, and a qualification field that is blank because the
    person creating the batch did not know which of ten codes to pick.

    A course is the answer to all of those at once. Describe it here, and a
    batch is a course plus a start date.
    """

    _name = "dhb.course"
    _description = "Course"
    _order = "sequence, name"

    name = fields.Char(
        required=True, translate=False,
        help="As it should read on a certificate, an invoice and a schedule "
             "sent to the awarding body. For example \"NEBOSH IGC - Arabic\".",
    )
    code = fields.Char(
        required=True, copy=False,
        help="Short, and used to build every batch reference. \"IGC\" gives "
             "IGC-2609-G1.",
    )
    _unique_code = models.Constraint(
        "unique(code)", "Another course already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    # Where the course stands with us and with the awarding body. Four
    # states rather than an active/inactive flag, because two of the four
    # are real situations a flag cannot tell apart:
    #
    #   Suspended - we still hold the course, but something is wrong at the
    #     awarding body's end: an approval lapsed, a spec is being replaced.
    #     No new batch may open. The running ones carry on.
    #   Retired - we no longer sell it. The record stays because the
    #     learners who took it are still ours to account for.
    #
    # Archiving (the `active` flag above) remains what it always was, and is
    # a different question: whether the record is in the way. A retired
    # course is usually not archived - it is still consulted.
    status = fields.Selection(
        [
            ("draft", "Draft"),
            ("active", "Active"),
            ("suspended", "Suspended"),
            ("retired", "Retired"),
        ],
        default="draft", required=True, index=True,
        group_expand="_group_expand_status",
        help="A course can only be made Active once everything a batch "
             "needs is filled in.",
    )

    # No `tracking` here. I put it on when this field was added and it did
    # nothing but log a warning on every startup: tracking needs mail.thread
    # and this model does not carry it. A course is edited by two people and
    # does not need an audit trail; the qualification, which does, has one.
    qualification_id = fields.Many2one(
        "dhb.qualification", string="Qualification", index=True,
        ondelete="restrict",
        help="What the awarding body awards. This course is one way of "
             "delivering it - in one language, in one mode.")
    qualification_status = fields.Selection(
        related="qualification_id.status", string="Qualification status")

    # Deliberately a plain stored field and NOT related to the qualification.
    #
    # The tempting version is related=..., store=True. It is also the one
    # that destroys data on the way in: the moment the field becomes
    # related, Odoo schedules it for recomputation, and it recomputes from a
    # qualification_id that the migration has not filled in yet. The column
    # is blanked, and the migration then reads it to decide which awarding
    # body each new qualification belongs to - and finds nothing.
    #
    # So it stays an ordinary column, and is kept in step by the onchange
    # and by create/write below. Slower to write, impossible to lose.
    awarding_body = fields.Selection(
        AWARDING_BODIES, string="Awarded by", default="nebosh", required=True)

    # The old selection. Four other modules still read it - admissions,
    # interviews, surveys and attendance - so it is filled from the
    # qualification rather than removed, and removed in a later pass when
    # those four have been moved over. It is hidden on the form: a field
    # nobody should type into should not be offered to be typed into.
    qualification = fields.Selection(QUALIFICATIONS, string="Qualification")
    delivery_language = fields.Selection(
        LANGUAGES, string="Language of delivery", default="ar")
    delivery_mode = fields.Selection(
        STUDY_MODES, string="Study mode", default="virtual")

    duration_days = fields.Integer(
        string="Length in days", default=1,
        help="How many days a batch of this course runs. The batch works out "
             "its end date from this, so nobody has to.",
    )
    # How the length reads, rather than how it is stored.
    #
    # `duration_days` stays the single stored truth, because the batch works
    # its end date out from it and a second stored field for the same fact
    # is a second field to keep in step. But nobody at the centre - or at
    # NEBOSH - describes a course as forty-two days. They say six weeks.
    # So the days are what is typed and the weeks are what is read.
    duration_display = fields.Char(
        string="Length", compute="_compute_duration_display")
    guided_hours = fields.Integer(
        string="Hours",
        help="Guided learning hours - the taught time the awarding body "
             "expects for this qualification. It is quoted on a schedule "
             "submitted for approval, and it is not the same as the number "
             "of days.",
    )
    total_lectures = fields.Integer(
        string="Lectures", default=0,
        help="How many lectures the course has. Attendance is measured "
             "against it.",
    )
    max_absences = fields.Integer(
        string="Maximum absences", default=2,
        help="Above this, exam registration is blocked unless a manager "
             "records an override with a reason.",
    )

    currency_id = fields.Many2one(
        "res.currency", default=lambda self: self.env.company.currency_id)
    list_price = fields.Monetary(
        string="Fee", help="What a learner normally pays for this course.")

    description = fields.Html(
        help="Shown to applicants. Kept with the course so every batch of it "
             "says the same thing.",
    )
    note = fields.Text(string="Internal notes")

    # copy=False, and it is not a detail. A one2many is copied by default,
    # so duplicating a course to make its English variant would also
    # duplicate every batch that has ever run of the Arabic one - with their
    # dates, their learners' places and their references.
    batch_ids = fields.One2many(
        "dhb.batch", "course_id", string="Batches", copy=False)
    batch_count = fields.Integer(compute="_compute_batch_count")

    # The list of what is missing, and its length, as two fields rather than
    # one sentence. A column headed "Still to set up" that then repeats
    # "5 still to set up:" inside every cell spends half its width saying
    # what the header already said, and the names - which are the only part
    # anybody can act on - fall off the end.
    setup_warning = fields.Char(compute="_compute_setup_warning")
    setup_missing_count = fields.Integer(compute="_compute_setup_warning")
    setup_ready = fields.Boolean(compute="_compute_setup_warning")

    @api.depends("batch_ids")
    def _compute_batch_count(self):
        for course in self:
            course.batch_count = len(course.batch_ids)

    @api.depends("duration_days")
    def _compute_duration_display(self):
        for course in self:
            days = course.duration_days or 0
            if days and days % 7 == 0:
                weeks = days // 7
                course.duration_display = _("%s weeks", weeks) \
                    if weeks > 1 else _("1 week")
            elif days == 1:
                course.duration_display = _("1 day")
            elif days:
                course.duration_display = _("%s days", days)
            else:
                course.duration_display = False

    # ------------------------------------------------------------------
    @api.constrains("qualification_id", "delivery_language", "delivery_mode",
                    "active")
    def _check_variant_is_unique(self):
        """One qualification, one language, one mode - one course.

        Two courses that agree on all three are the same product entered
        twice, and the pair is discovered the day they disagree on the fee.
        The check is a refusal rather than a warning because there is no
        reading of two identical variants that is correct.

        Three exclusions, and each one is a workflow this check would
        otherwise break:

        * Archived courses. A retired-and-archived Arabic Zoom IGC must not
          stop a new one being created.
        * Retired courses. Replacing a retired course with its successor is
          the ordinary reason to create one, and the old record stays
          because its learners do.
        * Courses with no language or no mode yet. A new variant is created
          blank on both, deliberately, so that the person has to choose -
          and two half-finished variants would otherwise collide with each
          other on a pair of empty values and lock the qualification.
        """
        for course in self:
            if not course.active or not course.qualification_id:
                continue
            if not course.delivery_language or not course.delivery_mode:
                continue
            twin = self.search([
                ("id", "!=", course.id),
                ("qualification_id", "=", course.qualification_id.id),
                ("delivery_language", "=", course.delivery_language),
                ("delivery_mode", "=", course.delivery_mode),
                ("status", "!=", "retired"),
            ], limit=1)
            if twin:
                raise ValidationError(_(
                    "%(twin)s is already the %(qualification)s in this "
                    "language and this study mode. Change the language or "
                    "the mode, or edit that course instead of making a "
                    "second one.",
                    twin=twin.display_name,
                    qualification=course.qualification_id.display_name,
                ))

    # ------------------------------------------------------------------
    def _sync_from_qualification(self):
        """Copy down what the qualification decides.

        Two fields only, and both of them exist for other code to read: the
        awarding body, which the list and the left-hand filter use, and the
        legacy selection that four other modules still depend on.
        """
        for course in self:
            qualification = course.qualification_id
            if not qualification:
                continue
            course.awarding_body = qualification.awarding_body
            if qualification.selection_key:
                course.qualification = qualification.selection_key

    @api.onchange("qualification_id")
    def _onchange_qualification_id(self):
        self._sync_from_qualification()

    @api.model_create_multi
    def create(self, vals_list):
        courses = super().create(vals_list)
        courses._sync_from_qualification()
        return courses

    def write(self, vals):
        result = super().write(vals)
        if "qualification_id" in vals:
            self._sync_from_qualification()
        return result

    def _setup_missing(self):
        """What still has to be filled in before batches of this course work.

        Written as a list of names rather than a score. A course that is 80%
        set up tells nobody what to do next; "Days, Fee, Tutors" does.

        The names are kept short deliberately: they are read in a narrow
        column on the course list, and a name that is cut in half is a name
        nobody can act on.
        """
        self.ensure_one()
        missing = []
        if not self.qualification_id:
            missing.append(_("Qualification"))
        if not self.duration_days:
            missing.append(_("Days"))
        if not self.guided_hours:
            missing.append(_("Hours"))
        if not self.total_lectures:
            missing.append(_("Lectures"))
        if not self.list_price:
            missing.append(_("Fee"))
        if not self.delivery_language:
            missing.append(_("Language"))
        return missing

    @api.depends("duration_days", "guided_hours", "total_lectures",
                 "list_price", "qualification_id", "delivery_language")
    def _compute_setup_warning(self):
        for course in self:
            missing = course._setup_missing()
            course.setup_ready = not missing
            course.setup_missing_count = len(missing)
            course.setup_warning = ", ".join(missing) if missing else False

    @api.model
    def _group_expand_status(self, statuses, domain):
        return [key for key, _label in self._fields["status"].selection]

    # ------------------------------------------------------------------
    def action_activate(self):
        """Refuse to make a course sellable while it is not usable.

        This is one of the few places where a refusal beats a warning. A
        course with no fee and no length does not merely look unfinished:
        the batch built from it has no end date and its invoice line is
        zero, and both of those are discovered by the learner.
        """
        for course in self:
            missing = course._setup_missing()
            if missing:
                raise UserError(_(
                    "%(name)s cannot be made active yet. Still to fill in: "
                    "%(items)s.",
                    name=course.display_name, items=", ".join(missing),
                ))
            qualification = course.qualification_id
            if qualification and qualification._blocks_new_batches():
                raise UserError(_(
                    "%(name)s cannot be made active while %(qualification)s "
                    "is %(status)s with the awarding body.",
                    name=course.display_name,
                    qualification=qualification.display_name,
                    status=dict(
                        qualification._fields["status"].selection
                    )[qualification.status].lower(),
                ))
            course.status = "active"

    def action_suspend(self):
        self.write({"status": "suspended"})

    def action_retire(self):
        self.write({"status": "retired"})

    def action_back_to_draft(self):
        self.write({"status": "draft"})

    def action_open_batch_wizard(self):
        """Open a batch - unless the status says the course may not run.

        This is what makes the status more than a colour on a list. A
        suspended course is one the awarding body has a problem with, and
        the batch that must not be opened is the next one, not the ones
        already running.
        """
        self.ensure_one()
        # The awarding body's position is checked before ours, because it
        # is the one that cannot be overruled by anybody in this building.
        # This is also the whole point of the qualification carrying a
        # status of its own: suspending it stops all three courses under it,
        # including the one somebody forgot about.
        qualification = self.qualification_id
        if qualification and qualification._blocks_new_batches():
            raise UserError(_(
                "%(qualification)s is %(status)s with the awarding body, so "
                "no new batch of any of its courses may open - including "
                "%(name)s. The batches already running are not affected.",
                qualification=qualification.display_name,
                status=dict(
                    qualification._fields["status"].selection
                )[qualification.status].lower(),
                name=self.display_name,
            ))
        if self.status == "suspended":
            raise UserError(_(
                "%s is suspended, so no new batch of it may open. The "
                "batches already running are not affected.")
                % self.display_name)
        if self.status == "retired":
            raise UserError(_(
                "%s has been retired. Put it back to Draft and make it "
                "active again if the centre is offering it once more.")
                % self.display_name)
        if self.status == "draft":
            raise UserError(_(
                "%(name)s is still a draft. Finish setting it up and press "
                "Activate - otherwise the batch would inherit a course with "
                "%(items)s missing.",
                name=self.display_name,
                items=", ".join(self._setup_missing()) or _("nothing"),
            ))
        # Active and still empty - a state no person can reach.
        #
        # action_activate refuses it. What produced it is the migration that
        # made every course with batches Active on the day of the split, so
        # that the three courses the centre actually runs did not wake up as
        # drafts and freeze the catalogue. That was right, but it carried
        # them past this gate rather than through it, and all three are
        # still sitting at zero days and zero fee.
        #
        # So the gate is checked here as well as on the button. A batch
        # opened from a course with no length has no end date, and one with
        # no fee invoices nothing - and both are discovered by the learner,
        # not by us.
        missing = self._setup_missing()
        if missing:
            raise UserError(_(
                "%(name)s is active, but it still has no %(items)s. A batch "
                "opened from it now would have no end date and a fee of "
                "zero.\n\nThe numbers can be typed straight into the row on "
                "the Courses list - no need to open anything.",
                name=self.display_name, items=", ".join(missing).lower(),
            ))
        return {
            "type": "ir.actions.act_window",
            "name": _("Open a batch of %s") % self.display_name,
            "res_model": "dhb.course.batch.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"active_id": self.id},
        }

    @api.depends("name", "code")
    def _compute_display_name(self):
        for course in self:
            course.display_name = "[%s] %s" % (course.code, course.name) \
                if course.code else (course.name or "")

    def _next_variant_code(self):
        """A free code, because the column will not accept an empty one.

        Not a clever code. "IGC-2" is a placeholder that looks like a
        placeholder, which is the point: it should be obvious on the form
        that it is waiting to be replaced with something the finance office
        will recognise on an invoice.
        """
        self.ensure_one()
        base = self.code or "COURSE"
        suffix = 2
        while suffix < 100:
            candidate = "%s-%s" % (base, suffix)
            # active_test off: the unique index covers archived courses too,
            # so a code freed only by archiving is not free.
            if not self.with_context(active_test=False).search_count(
                    [("code", "=", candidate)]):
                return candidate
            suffix += 1
        return "%s-%s" % (base, self.id)

    def action_duplicate_variant(self):
        """Sell the same qualification another way.

        The English classroom IGC differs from the Arabic Zoom one in three
        fields and agrees with it in twelve - the lecture count, the absence
        limit, the description, the qualification behind it. Retyping the
        twelve to change the three is how the two drift apart, and the first
        anybody notices is a learner quoting a description that no longer
        matches what we run.

        The copy opens as a Draft with the language and the study mode
        deliberately blanked. They are the two fields that make it a
        different course at all, and leaving them filled would hand back a
        record that the duplicate-variant check refuses to save anyway.
        """
        self.ensure_one()
        variant = self.copy({
            "name": _("%s (new variant)", self.name),
            "code": self._next_variant_code(),
            "status": "draft",
            "delivery_language": False,
            "delivery_mode": False,
        })
        return {
            "type": "ir.actions.act_window",
            "name": _("New variant of %s") % self.display_name,
            "res_model": "dhb.course",
            "res_id": variant.id,
            "view_mode": "form",
            "target": "current",
        }

    def action_open_batches(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Batches of %s") % self.display_name,
            "res_model": "dhb.batch",
            "view_mode": "kanban,list,form",
            "domain": [("course_id", "=", self.id)],
            "context": {"default_course_id": self.id},
        }
