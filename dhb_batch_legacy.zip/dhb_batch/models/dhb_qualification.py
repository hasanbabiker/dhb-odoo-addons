from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _, SUPERUSER_ID
from odoo.exceptions import UserError, ValidationError

from .constants import AWARDING_BODIES

# How long before a centre approval lapses the system starts saying so.
# Ninety days is not a round number chosen for neatness: it is roughly what
# an awarding body's renewal takes end to end - the form, their review, the
# questions that come back - and a reminder that arrives with thirty days
# left is a reminder that arrives too late to be acted on calmly.
APPROVAL_WARNING_DAYS = 90

# The same idea for a syllabus being replaced. A centre that learns in
# August that it may not teach the old edition after September has a month
# to rewrite its material, which is not enough.
SPEC_WARNING_DAYS = 90


class DhbQualification(models.Model):
    """What the awarding body awards. Not what the centre sells.

    These two were one record until now, and the cost of that showed up the
    moment somebody asked an ordinary question: can we run the IGC both in a
    classroom and on Zoom? A single record cannot answer it, because it has
    one length, one lecture count and one fee - and a fifteen-day classroom
    IGC and a self-paced one are not the same product at any of them.

    So they separate:

        Qualification   what NEBOSH awards - the syllabus, its units, its
                        edition, how long a registration lasts, and whether
                        we are approved to deliver it at all. Theirs.
        Course          what we sell - a qualification in one language and
                        one mode, with its own length and price. Ours.
        Batch           a course with a start date.

    One qualification, several courses, many batches. And the catalogue
    grows by what the centre actually offers rather than by multiplication:
    two modes of the IGC in Arabic is two courses, not eight.

    The approval and syllabus dates further down are the reason this model
    is worth having beyond tidiness. Approval is granted per qualification,
    not to the centre as a whole, and it expires. A syllabus is replaced on
    a published date with a teach-out window after it. Both are facts with
    deadlines that arrive by post, get filed, and are remembered late. They
    belong on the record that everything else hangs off.
    """

    _name = "dhb.qualification"
    _description = "Qualification"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "sequence, code"

    name = fields.Char(
        required=True, translate=False, tracking=True,
        help="The official title, exactly as the awarding body writes it. "
             "It goes on a certificate and on every form they receive, so a "
             "shortened version here is a query from them later.")
    code = fields.Char(
        required=True, copy=False, tracking=True,
        help="Short - IGC, DI1. Used wherever the full title will not fit.")
    _unique_code = models.Constraint(
        "unique(code)", "Another qualification already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    # Where the qualification stands, and it is not the same question as
    # where a course stands. A course is suspended because we chose to stop
    # selling it; a qualification is suspended because the awarding body
    # said so, and that reaches every course underneath it at once. Which is
    # exactly the mistake this prevents: suspending the Arabic IGC by hand
    # and leaving the English one open.
    status = fields.Selection(
        [
            ("draft", "Draft"),
            ("active", "Active"),
            ("suspended", "Suspended"),
            ("withdrawn", "Withdrawn"),
        ],
        default="draft", required=True, index=True, tracking=True,
        group_expand="_group_expand_status",
        help="Suspended or Withdrawn stops a new batch opening on every "
             "course of this qualification. Batches already running are not "
             "touched.")

    awarding_body = fields.Selection(
        AWARDING_BODIES, string="Awarded by", default="nebosh",
        required=True, tracking=True)
    level = fields.Char(
        tracking=True,
        help="As the awarding body states it - \"Level 3\", \"Level 6\".")

    manager_id = fields.Many2one(
        "res.users", string="Answerable for approval", tracking=True,
        default=lambda self: self.env.user,
        help="Who deals with the awarding body about this qualification. "
             "Renewal and syllabus reminders are scheduled on them - a "
             "reminder addressed to nobody is a reminder nobody reads.")

    # ------------------------------------------------------------------
    # Our approval to deliver it
    #
    # Approval is per qualification. A centre approved for the IGC is not
    # thereby approved for the Diploma, and the two renew on different
    # dates. Keeping one "we are a Learning Partner" fact somewhere central
    # is how a centre teaches a qualification it is no longer approved for
    # and finds out when the learners cannot be registered.
    # ------------------------------------------------------------------
    approval_reference = fields.Char(
        string="Approval reference", tracking=True,
        help="The awarding body's own number for our approval to deliver "
             "this qualification, if it differs from the centre number.")
    date_approved = fields.Date(string="Approved on", tracking=True)
    date_approval_renewal = fields.Date(
        string="Renewal due", tracking=True,
        help="The date our approval to deliver this lapses if it has not "
             "been renewed.")

    approval_state = fields.Selection(
        [
            ("none", "Not recorded"),
            ("valid", "Valid"),
            ("expiring", "Renewal due"),
            ("expired", "Lapsed"),
        ],
        compute="_compute_approval_state", string="Approval")
    approval_days_left = fields.Integer(compute="_compute_approval_state")

    # Which renewal date a reminder has already gone out for. One field, and
    # it is what stops the cron posting the same warning every night for
    # ninety nights until people stop reading any of them.
    approval_reminder_for = fields.Date(copy=False, readonly=True)

    # ------------------------------------------------------------------
    # The syllabus edition, and the window it closes in
    # ------------------------------------------------------------------
    spec_edition = fields.Char(
        string="Syllabus edition", tracking=True,
        help="\"IG 6th Edition\". Material written for an older edition is "
             "material that has to be replaced, and this is where the "
             "Documents app learns which edition is current.")
    spec_valid_from = fields.Date(string="Edition in force from")
    spec_last_teaching = fields.Date(
        string="Last date we may teach it", tracking=True,
        help="Published by the awarding body when an edition is replaced. "
             "After it, a batch of this edition may not start.")
    spec_last_assessment = fields.Date(
        string="Last date it may be assessed", tracking=True,
        help="The end of the teach-out window. Learners still holding this "
             "edition must sit by then or be moved to the new one.")
    material_licence = fields.Char(
        string="Material licence",
        help="The licence number under which the centre holds the awarding "
             "body's material for this qualification.")

    spec_state = fields.Selection(
        [
            ("none", "Not recorded"),
            ("current", "Current"),
            ("ending", "Being replaced"),
            ("teach_out", "Teach-out only"),
            ("closed", "Closed"),
        ],
        compute="_compute_spec_state", string="Syllabus")
    spec_reminder_for = fields.Date(copy=False, readonly=True)

    # ------------------------------------------------------------------
    # What it takes
    # ------------------------------------------------------------------
    guided_hours = fields.Integer(
        string="Guided learning hours",
        help="The taught time the awarding body specifies. A course may "
             "deliver more, never meaningfully less.")
    private_study_hours = fields.Integer(string="Private study hours")
    # Total Qualification Time. Stored because it is quoted on the approval
    # paperwork and people filter on it, and because two integers added
    # together is not worth recomputing on every read of every list.
    tqt_hours = fields.Integer(
        string="Total qualification time", store=True,
        compute="_compute_tqt_hours",
        help="Guided learning hours plus private study. The figure the "
             "awarding body asks for on an approval submission.")

    registration_validity_months = fields.Integer(
        string="Registration valid for (months)", default=60,
        help="How long a learner has to complete after registering. NEBOSH "
             "gives five years; after it the registration lapses and the "
             "units already passed are lost.")

    entry_requirement = fields.Text(
        string="Entry requirements",
        help="In the awarding body's words. Read at admission.")
    prerequisite_ids = fields.Many2many(
        "dhb.qualification", "dhb_qualification_prerequisite_rel",
        "qualification_id", "prerequisite_id", string="Requires first",
        help="A Diploma that requires the Certificate says so here, and "
             "admissions can check it instead of remembering it.")

    # ------------------------------------------------------------------
    # What hangs off it
    # ------------------------------------------------------------------
    course_ids = fields.One2many(
        "dhb.course", "qualification_id", string="Courses")
    course_count = fields.Integer(compute="_compute_rollups")
    batch_count = fields.Integer(compute="_compute_rollups")
    learner_count = fields.Integer(compute="_compute_rollups")

    note = fields.Text(string="Internal notes")

    # The key the old selection field used - igc, di1, emc. Kept so the four
    # modules that still read that selection keep working while it is
    # retired in a later pass. It is a bridge, and it is meant to be
    # removed; saying so here is the difference between a bridge and a
    # second source of truth nobody remembers to delete.
    selection_key = fields.Char(
        string="Legacy key", copy=False,
        help="Maps to the qualification selection the older modules still "
             "read. Do not rely on it in anything new.")

    # ------------------------------------------------------------------
    # Computes
    # ------------------------------------------------------------------
    @api.depends("guided_hours", "private_study_hours")
    def _compute_tqt_hours(self):
        for qualification in self:
            qualification.tqt_hours = (
                (qualification.guided_hours or 0)
                + (qualification.private_study_hours or 0))

    @api.depends("date_approval_renewal")
    def _compute_approval_state(self):
        today = fields.Date.context_today(self)
        for qualification in self:
            renewal = qualification.date_approval_renewal
            if not renewal:
                qualification.approval_state = "none"
                qualification.approval_days_left = 0
                continue
            days = (renewal - today).days
            qualification.approval_days_left = days
            if days < 0:
                qualification.approval_state = "expired"
            elif days <= APPROVAL_WARNING_DAYS:
                qualification.approval_state = "expiring"
            else:
                qualification.approval_state = "valid"

    @api.depends("spec_last_teaching", "spec_last_assessment")
    def _compute_spec_state(self):
        """Where this edition sits in its own life.

        Read from the two dates rather than set by hand, because a state
        somebody has to remember to change is a state that is wrong by the
        time it matters.
        """
        today = fields.Date.context_today(self)
        for qualification in self:
            last_teaching = qualification.spec_last_teaching
            last_assessment = qualification.spec_last_assessment
            if not last_teaching and not last_assessment:
                qualification.spec_state = "none"
            elif last_assessment and today > last_assessment:
                qualification.spec_state = "closed"
            elif last_teaching and today > last_teaching:
                # Past the last teaching date but still assessable: the
                # learners already on it finish, and nobody new starts.
                qualification.spec_state = "teach_out"
            elif last_teaching and \
                    (last_teaching - today).days <= SPEC_WARNING_DAYS:
                qualification.spec_state = "ending"
            else:
                qualification.spec_state = "current"

    @api.depends("course_ids")
    def _compute_rollups(self):
        """Courses, batches and learners under this qualification.

        The learner figure is the one that cannot be got at any other way:
        it crosses three models, and the question behind it - how many
        people are we carrying on the IGC right now, across every language
        and mode - is asked every time the awarding body writes.

        Counted with search_count rather than by walking the relations. The
        readable version - courses.mapped("batch_ids").mapped(
        "registration_ids") - pulls every batch and every enrolment of every
        qualification on the page into memory to produce two integers, and
        this is a list column: on a centre with a few years of cohorts it is
        the whole enrolment table on every page load.
        """
        batches = self.env["dhb.batch"]
        lines = self.env["dhb.batch.line"]
        for qualification in self:
            qualification.course_count = len(qualification.course_ids)
            if not qualification.id:
                qualification.batch_count = 0
                qualification.learner_count = 0
                continue
            qualification.batch_count = batches.search_count(
                [("course_id.qualification_id", "=", qualification.id)])
            qualification.learner_count = lines.search_count(
                [("event_id.course_id.qualification_id", "=",
                  qualification.id)])

    @api.constrains("prerequisite_ids")
    def _check_prerequisite_cycle(self):
        """A qualification cannot require itself, directly or round a loop.

        Written by hand rather than with the framework's recursion helper
        because that helper is for parent/child hierarchies and this is a
        many-to-many: a qualification can require two others, and each of
        those can require more.
        """
        for qualification in self:
            seen = set()
            frontier = qualification.prerequisite_ids
            while frontier:
                if qualification in frontier:
                    raise ValidationError(_(
                        "%s would end up requiring itself.")
                        % qualification.display_name)
                seen.update(frontier.ids)
                frontier = frontier.mapped("prerequisite_ids").filtered(
                    lambda q: q.id not in seen)

    @api.depends("name", "code")
    def _compute_display_name(self):
        for qualification in self:
            qualification.display_name = "[%s] %s" % (
                qualification.code, qualification.name) \
                if qualification.code else (qualification.name or "")

    @api.model
    def _group_expand_status(self, statuses, domain):
        return [key for key, _label in self._fields["status"].selection]

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------
    def action_activate(self):
        self.write({"status": "active"})

    def action_suspend(self):
        """Stop every course of this qualification at once.

        Deliberately not cascaded onto the courses as a write. The courses
        keep their own status - which is ours to decide - and the block is
        read from here at the moment a batch is opened. Cascading would
        overwrite what the centre decided with what the awarding body
        decided, and there would be no way back to it when the suspension
        lifts.
        """
        self.write({"status": "suspended"})

    def action_withdraw(self):
        self.write({"status": "withdrawn"})

    def action_back_to_draft(self):
        self.write({"status": "draft"})

    def _blocks_new_batches(self):
        """Whether the awarding body's position stops a batch opening."""
        self.ensure_one()
        return self.status in ("suspended", "withdrawn")

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def action_open_courses(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Courses of %s") % self.display_name,
            "res_model": "dhb.course",
            "view_mode": "list,form",
            "domain": [("qualification_id", "=", self.id)],
            "context": {"default_qualification_id": self.id},
        }

    def action_open_batches(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Batches of %s") % self.display_name,
            "res_model": "dhb.batch",
            "view_mode": "list,form",
            "domain": [("course_id.qualification_id", "=", self.id)],
        }

    def action_open_learners(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learners on %s") % self.display_name,
            "res_model": "dhb.batch.line",
            "view_mode": "list,form",
            # event_id, not batch_id. The field kept its old name when the
            # cohort stopped being an Odoo event, and this is the second
            # time that has caught something.
            "domain": [
                ("event_id.course_id.qualification_id", "=", self.id)],
        }

    def action_add_course(self):
        """Open a blank course already pointing at this qualification.

        The alternative - going to the Courses list and picking the
        qualification from a dropdown of ten - is the same number of clicks
        and one chance to pick the wrong one.
        """
        self.ensure_one()
        if self.status == "withdrawn":
            raise UserError(_(
                "%s has been withdrawn, so there is nothing to sell. Put it "
                "back to Active if the centre is offering it again.")
                % self.display_name)
        return {
            "type": "ir.actions.act_window",
            "name": _("New course of %s") % self.display_name,
            "res_model": "dhb.course",
            "view_mode": "form",
            "target": "current",
            "context": {
                "default_qualification_id": self.id,
                "default_awarding_body": self.awarding_body,
                # Blank, not defaulted. The course model defaults these to
                # Arabic and Virtual, which is exactly what the existing
                # course of this qualification already is - so a new one
                # created here would be refused as a duplicate variant the
                # moment it was saved, on the very button the whole split
                # exists to make useful.
                "default_delivery_language": False,
                "default_delivery_mode": False,
            },
        }

    # ------------------------------------------------------------------
    # The reminders
    # ------------------------------------------------------------------
    @api.model
    def _cron_compliance_reminders(self):
        """Say something before a deadline rather than after it.

        Two deadlines, one pass, and both of them arrive by post months
        early and are then filed: the date our approval to deliver lapses,
        and the date we may no longer teach the current syllabus. Neither
        has ever been visible in this system, and both stop a centre
        trading in the qualification if they pass unnoticed.

        The two `_reminder_for` fields make this safe to run nightly. A
        reminder is raised once per date; move the date and it is raised
        again for the new one.
        """
        today = fields.Date.context_today(self)
        horizon = today + relativedelta(days=APPROVAL_WARNING_DAYS)

        approaching = self.search([
            ("status", "in", ("draft", "active")),
            ("date_approval_renewal", "!=", False),
            ("date_approval_renewal", "<=", horizon),
        ])
        for qualification in approaching:
            renewal = qualification.date_approval_renewal
            if qualification.approval_reminder_for == renewal:
                continue
            days = (renewal - today).days
            if days < 0:
                body = _(
                    "Approval to deliver %(name)s lapsed on %(date)s. No "
                    "learner can be registered against it until it is "
                    "renewed.",
                    name=qualification.display_name,
                    date=fields.Date.to_string(renewal))
            else:
                body = _(
                    "Approval to deliver %(name)s is due for renewal on "
                    "%(date)s - %(days)s days from now.",
                    name=qualification.display_name,
                    date=fields.Date.to_string(renewal), days=days)
            qualification._raise_reminder(body, renewal, "approval")

        spec_horizon = today + relativedelta(days=SPEC_WARNING_DAYS)
        ending = self.search([
            ("status", "in", ("draft", "active")),
            ("spec_last_teaching", "!=", False),
            ("spec_last_teaching", "<=", spec_horizon),
        ])
        for qualification in ending:
            last_teaching = qualification.spec_last_teaching
            if qualification.spec_reminder_for == last_teaching:
                continue
            body = _(
                "%(name)s may not be taught on the %(edition)s syllabus "
                "after %(date)s. Batches starting after that date need the "
                "new edition, and the material has to be replaced before "
                "then.",
                name=qualification.display_name,
                edition=qualification.spec_edition or _("current"),
                date=fields.Date.to_string(last_teaching))
            qualification._raise_reminder(body, last_teaching, "spec")

    def _raise_reminder(self, body, deadline, kind):
        """Post the warning and put it on somebody's list.

        A message in the chatter is a record; an activity is a thing that
        appears on a person's own screen until they deal with it. This does
        both, because the first is what an auditor reads and the second is
        what actually gets it done.
        """
        self.ensure_one()
        self.message_post(body=body)
        # Never the cron's own user. These ten qualifications were created
        # by a migration in raw SQL, so manager_id is empty on all of them
        # and env.user during a cron run is OdooBot - which would file every
        # reminder on a list nobody opens, stamp it as sent, and never raise
        # it again.
        user = self.manager_id or self.create_uid
        if not user or user.id == SUPERUSER_ID:
            user = self.env.ref("base.user_admin", raise_if_not_found=False) \
                or self.env.user
        try:
            self.activity_schedule(
                "mail.mail_activity_data_todo",
                date_deadline=deadline,
                summary=(_("Approval renewal") if kind == "approval"
                         else _("Syllabus edition ends")),
                note=body,
                user_id=user.id,
            )
        except ValueError:
            # The activity type is a standard Odoo record, but a database
            # where it has been removed should not stop the message that
            # already went out.
            pass
        if kind == "approval":
            self.approval_reminder_for = deadline
        else:
            self.spec_reminder_for = deadline
