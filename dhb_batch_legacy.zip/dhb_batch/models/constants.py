"""The vocabulary a batch and a course share.

Declared once. Two copies of a selection list is two lists that drift: a
qualification added to the course catalogue and forgotten on the batch would
silently stop matching, and nothing would say so.
"""

QUALIFICATIONS = [
    ("igc", "NEBOSH IGC"),
    ("di1", "NEBOSH Diploma DI1"),
    ("di2", "NEBOSH Diploma DI2"),
    ("di3", "NEBOSH Diploma DI3"),
    ("emc", "NEBOSH Environmental Management"),
    ("fire", "NEBOSH Fire"),
    ("hse", "NEBOSH HSE Incident Investigation"),
    ("award", "NEBOSH Health and Safety at Work Award"),
    ("psm", "NEBOSH Process Safety Management"),
    ("iosh_ms", "IOSH Managing Safely"),
]

LANGUAGES = [
    ("en", "English"),
    ("ar", "Arabic"),
    ("ru", "Russian"),
    ("tr", "Turkish"),
    ("pt", "Portuguese (European)"),
    ("es", "Spanish (European)"),
    ("fr", "French"),
]

# NEBOSH recognises exactly four study modes (C026a v1). Blended and
# in-company are not among them: in-company is a *place*, and a course held
# at a client site is still Full Time or Part Time depending on its
# timetable. Offering modes the awarding body does not accept only produces
# applications it will reject.
#
# The labels are short on purpose. They were written as sentences, which
# read well on a form and were cut off in every list and every dropdown
# ("Virtual Delivery - Zoom or Teams, sched..."). A label a person cannot
# finish reading is not a label. The explanation lives in the field's help
# text, where it is available and costs no width.
STUDY_MODES = [
    ("full_time", "Full time (classroom)"),
    ("part_time", "Part time (classroom)"),
    ("virtual", "Virtual (Zoom or Teams)"),
    ("elearning", "E-learning (self-paced)"),
]

AWARDING_BODIES = [
    ("nebosh", "NEBOSH"),
    ("iosh", "IOSH"),
    ("dhb", "DHB - our own course"),
    ("other", "Other"),
]
