{
    "name": "DHB Batches",
    "version": "19.0.2.1.0",
    "summary": "Cohorts of learners: one qualification, one language, one "
               "group, with the places on them",
    "description": """
DHB Batches
===========

A batch is a cohort of learners taking one qualification together, in one
language, starting and ending on known dates, with a list of places on it.

Until now the cohort was Odoo's Events model. That worked, but it spoke the
wrong language: an event has tickets, sponsors, a website page and a
"registration" that could be a conference attendee. A training centre has
batches, tutors, lectures, absences and exam sittings. Reading "Event" on
every screen and "Attendee" on every learner made the system feel borrowed.

So this is a batch, named as one, with only what a batch actually needs:

* The batch itself - name, code, qualification, language, study mode, dates,
  tutors, venue, places.
* A place on the batch, with the same lifecycle the rest of the system
  already reads: Unconfirmed, Registered, Attended, Cancelled.
* A stage a batch moves through - planned, open for applications, running,
  exams, finished - so a glance at the board answers "what is live".

Deliberately not included: tickets, sponsors, event types, a public events
website. None of them were ever used.

This installs on its own and changes nothing else. The modules that read the
cohort today are moved over in a separate step, so nothing is half-migrated.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["base", "mail", "contacts"],
    "data": [
        "security/batch_groups.xml",
        "security/ir.model.access.csv",
        "data/course_data.xml",
        "views/course_views.xml",
        "views/batch_views.xml",
        "views/batch_line_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
