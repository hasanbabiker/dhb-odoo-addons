# -*- coding: utf-8 -*-

import base64
import json
import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .aramex_request import AramexRequest, AramexError, TRACKING_URL

_logger = logging.getLogger(__name__)


class DeliveryCarrier(models.Model):
    _inherit = "delivery.carrier"

    delivery_type = fields.Selection(
        selection_add=[("aramex", "Aramex")],
        ondelete={"aramex": lambda recs: recs.write({
            "delivery_type": "fixed", "fixed_price": 0,
        })},
    )

    # -- credentials ---------------------------------------------------
    aramex_username = fields.Char(
        "Aramex Username", groups="base.group_system",
        help="The API user Aramex gave you (usually an email address).")
    aramex_password = fields.Char("Aramex Password", groups="base.group_system")
    aramex_account_number = fields.Char("Account Number", groups="base.group_system")
    aramex_account_pin = fields.Char("Account PIN", groups="base.group_system")
    aramex_account_entity = fields.Char(
        "Account Entity", groups="base.group_system",
        help="Three-letter station code of your Aramex account, e.g. AUH, DXB, RUH.")
    aramex_account_country_code = fields.Char(
        "Account Country Code", size=2, groups="base.group_system",
        help="ISO country code of your Aramex account, e.g. AE.")
    aramex_environment = fields.Selection(
        [("test", "Test"), ("prod", "Production")],
        string="Environment", default="test", required=True,
        help="Keep this on Test until your credentials are validated. "
             "Shipments created in Production are real and billable.")

    # -- shipment defaults ---------------------------------------------
    aramex_product_group = fields.Selection(
        [("DOM", "Domestic"), ("EXP", "Express / International")],
        string="Product Group", default="EXP", required=True)
    aramex_product_type = fields.Selection(
        [
            ("OND", "OND - Domestic Overnight"),
            ("CDS", "CDS - Domestic Same Day"),
            ("CDA", "CDA - Domestic Deferred"),
            ("PPX", "PPX - Priority Parcel Express"),
            ("PDX", "PDX - Priority Document Express"),
            ("PLX", "PLX - Priority Letter Express"),
            ("DPX", "DPX - Deferred Parcel Express"),
            ("EPX", "EPX - Economy Parcel Express"),
            ("GPX", "GPX - Ground Parcel Express"),
        ],
        string="Product Type", default="PPX", required=True)
    aramex_payment_type = fields.Selection(
        [("P", "Prepaid"), ("C", "Collect"), ("3", "Third Party")],
        string="Payment Type", default="P", required=True)
    aramex_payment_options = fields.Selection(
        [
            ("", "None"),
            ("ASCC", "ASCC - Account Shipper, Cash Consignee"),
            ("ARCC", "ARCC - Account Receiver, Cash Consignee"),
            ("CACC", "CACC - Cash Shipper, Cash Consignee"),
            ("ACCT", "ACCT - Account"),
            ("PPST", "PPST - Prepaid Stock"),
            ("CASH", "CASH - Cash"),
        ],
        string="Payment Options", default="")
    aramex_services = fields.Char(
        "Additional Services",
        help="Comma separated Aramex service codes, e.g. CODS,SIG. "
             "Leave empty if you do not use additional services.")
    aramex_description_of_goods = fields.Char(
        "Default Description of Goods", default="Goods",
        help="Used when rating, and as a fallback when the delivery order "
             "contains no product description.")
    aramex_pickup_location = fields.Char("Pickup Location", default="Reception")

    # -- label ---------------------------------------------------------
    aramex_label_report_id = fields.Integer(
        "Label Report ID", default=9729,
        help="Aramex report template for the label. 9729 = A4 PDF, "
             "9201 = thermal 10x15. Ask Aramex which IDs your account may use.")
    aramex_label_report_type = fields.Selection(
        [("URL", "URL"), ("RPT", "Embedded file")],
        string="Label Format", default="URL", required=True)

    # -- pricing -------------------------------------------------------
    aramex_extra_charge_type = fields.Selection(
        [("none", "None"), ("fixed", "Fixed amount"), ("percentage", "Percentage")],
        string="Extra Charge", default="none", required=True,
        help="Added on top of the rate returned by Aramex.")
    aramex_extra_charge_value = fields.Float("Extra Charge Value", default=0.0)
    aramex_default_weight = fields.Float(
        "Default Weight (kg)", default=0.5,
        help="Used when the products carry no weight. Aramex rejects a "
             "shipment weighing zero.")

    # ==================================================================
    # helpers
    # ==================================================================
    def _aramex_debug(self, payload, name):
        self.ensure_one()
        try:
            self.log_xml(json.dumps(payload, indent=2, default=str), name)
        except Exception:  # never let logging break a shipment
            _logger.debug("Aramex: could not log %s", name)

    def _aramex_client(self):
        self.ensure_one()
        return AramexRequest(self.sudo(), debug_logger=self._aramex_debug)

    def _aramex_check_credentials(self):
        self.ensure_one()
        carrier = self.sudo()
        missing = [
            label for label, value in [
                (_("Username"), carrier.aramex_username),
                (_("Password"), carrier.aramex_password),
                (_("Account Number"), carrier.aramex_account_number),
                (_("Account PIN"), carrier.aramex_account_pin),
                (_("Account Entity"), carrier.aramex_account_entity),
                (_("Account Country Code"), carrier.aramex_account_country_code),
            ] if not value
        ]
        if missing:
            raise UserError(_(
                "The Aramex delivery method %(name)s is missing: %(fields)s.",
                name=self.name, fields=", ".join(missing),
            ))

    @api.model
    def _aramex_check_address(self, partner, role):
        problems = []
        if not partner.street:
            problems.append(_("street"))
        if not partner.city:
            problems.append(_("city"))
        if not partner.country_id:
            problems.append(_("country"))
        if not (partner.phone or partner.mobile):
            problems.append(_("phone number"))
        if problems:
            raise UserError(_(
                "Aramex needs a complete %(role)s address. "
                "%(partner)s is missing: %(fields)s.",
                role=role, partner=partner.display_name,
                fields=", ".join(problems),
            ))

    def _aramex_apply_extra_charge(self, amount):
        self.ensure_one()
        if self.aramex_extra_charge_type == "fixed":
            return amount + self.aramex_extra_charge_value
        if self.aramex_extra_charge_type == "percentage":
            return amount * (1.0 + self.aramex_extra_charge_value / 100.0)
        return amount

    def _aramex_weight(self, weight):
        self.ensure_one()
        return weight if weight > 0 else (self.aramex_default_weight or 0.5)

    # ==================================================================
    # provider API expected by Odoo
    # ==================================================================
    def aramex_rate_shipment(self, order):
        self.ensure_one()
        self._aramex_check_credentials()
        shipper = order.warehouse_id.partner_id or order.company_id.partner_id
        recipient = order.partner_shipping_id
        try:
            self._aramex_check_address(shipper, _("shipper"))
            self._aramex_check_address(recipient, _("recipient"))
        except UserError as err:
            return {
                "success": False, "price": 0.0,
                "error_message": err.args[0] if err.args else str(err),
                "warning_message": False,
            }

        weight = self._aramex_weight(order._get_estimated_weight())
        try:
            result = self._aramex_client().rate(
                shipper_partner=shipper,
                recipient_partner=recipient,
                total_weight=weight,
                number_of_pieces=1,
                currency_code=order.currency_id.name,
                reference=order.name,
            )
        except AramexError as err:
            return {
                "success": False, "price": 0.0,
                "error_message": err.args[0] if err.args else str(err),
                "warning_message": False,
            }

        price = self._aramex_apply_extra_charge(result["amount"])
        quoted_currency = self.env["res.currency"].search(
            [("name", "=", result["currency"])], limit=1)
        if quoted_currency and quoted_currency != order.currency_id:
            price = quoted_currency._convert(
                price, order.currency_id, order.company_id,
                fields.Date.context_today(self))
        return {
            "success": True,
            "price": price,
            "error_message": False,
            "warning_message": False,
        }

    def aramex_send_shipping(self, pickings):
        self.ensure_one()
        self._aramex_check_credentials()
        client = self._aramex_client()
        results = []
        for picking in pickings:
            shipper = (
                picking.picking_type_id.warehouse_id.partner_id
                or picking.company_id.partner_id
            )
            recipient = picking.partner_id
            self._aramex_check_address(shipper, _("shipper"))
            self._aramex_check_address(recipient, _("recipient"))

            currency = picking.sale_id.currency_id or picking.company_id.currency_id
            weight = self._aramex_weight(picking.shipping_weight or picking.weight)
            description = ", ".join(
                picking.move_ids.mapped("product_id.name")[:5]
            ) or self.aramex_description_of_goods
            customs_value = sum(
                move.product_id.list_price * move.product_uom_qty
                for move in picking.move_ids
            )

            shipment = client.create_shipment(
                shipper_partner=shipper,
                recipient_partner=recipient,
                total_weight=weight,
                number_of_pieces=max(len(picking.package_ids), 1),
                currency_code=currency.name,
                reference=picking.name,
                description=description[:250],
                customs_value=customs_value,
                cod_amount=0.0,
                comments=picking.note or "" if "note" in picking._fields else "",
            )

            tracking_number = shipment["tracking_number"]
            if not tracking_number:
                raise UserError(_(
                    "Aramex did not return an AWB number for %s.") % picking.name)

            self._aramex_attach_label(picking, shipment, client)

            # Aramex bills the shipper afterwards; the rate call is the best
            # estimate we have at validation time.
            exact_price = 0.0
            if picking.sale_id:
                exact_price = picking.carrier_price or 0.0

            picking.message_post(body=_(
                "Shipment created with Aramex.<br/>AWB: <b>%s</b>", tracking_number))
            results.append({
                "exact_price": exact_price,
                "tracking_number": tracking_number,
            })
        return results

    def _aramex_attach_label(self, picking, shipment, client):
        """Store the Aramex label as a PDF attachment on the delivery order."""
        self.ensure_one()
        datas = False
        if shipment.get("label_contents"):
            datas = shipment["label_contents"]
            if isinstance(datas, str):
                datas = datas.encode()
        elif shipment.get("label_url"):
            datas = client.fetch_label(shipment["label_url"])
        if not datas:
            picking.message_post(body=_(
                "Aramex returned no printable label. "
                "You can retrieve it from the Aramex portal with AWB %s."
            ) % shipment["tracking_number"])
            return
        picking.message_post(
            body=_("Aramex label for AWB %s") % shipment["tracking_number"],
            attachments=[(
                "AramexLabel-%s.pdf" % shipment["tracking_number"],
                base64.b64decode(datas),
            )],
        )

    def aramex_cancel_shipment(self, pickings):
        """Aramex V2 has no CancelShipment operation.

        We clear the reference in Odoo and warn the user so the shipment is
        also voided on the Aramex side, otherwise it stays billable.
        """
        self.ensure_one()
        for picking in pickings:
            awb = picking.carrier_tracking_ref
            picking.message_post(body=_(
                "The Aramex reference was removed from this delivery order. "
                "Aramex does not expose a cancellation API, so AWB <b>%s</b> "
                "must also be cancelled from the Aramex portal or with your "
                "account manager, otherwise it remains billable."
            ) % (awb or _("unknown")))
            picking.write({"carrier_tracking_ref": False, "carrier_price": 0.0})

    def aramex_get_tracking_link(self, picking):
        return TRACKING_URL % (picking.carrier_tracking_ref or "")

    # ==================================================================
    # UI action
    # ==================================================================
    def action_aramex_test_connection(self):
        """Ping Aramex with a trivial rate request to validate credentials."""
        self.ensure_one()
        self._aramex_check_credentials()
        partner = self.env.company.partner_id
        self._aramex_check_address(partner, _("company"))
        self._aramex_client().rate(
            shipper_partner=partner,
            recipient_partner=partner,
            total_weight=1.0,
            currency_code=self.env.company.currency_id.name,
            reference="ODOO-TEST",
        )
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "type": "success",
                "title": _("Aramex"),
                "message": _("Connection to the %s environment succeeded.")
                           % dict(self._fields["aramex_environment"].selection)[
                               self.aramex_environment],
                "sticky": False,
            },
        }
