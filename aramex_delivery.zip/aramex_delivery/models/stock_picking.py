# -*- coding: utf-8 -*-

from odoo import _, fields, models
from odoo.exceptions import UserError


class StockPicking(models.Model):
    _inherit = "stock.picking"

    delivery_type = fields.Selection(related="carrier_id.delivery_type")
    aramex_last_status = fields.Char("Aramex Status", readonly=True, copy=False)
    aramex_last_status_date = fields.Datetime(
        "Aramex Status Date", readonly=True, copy=False)

    def action_aramex_refresh_tracking(self):
        """Pull the latest tracking event from Aramex into the chatter."""
        for picking in self:
            carrier = picking.carrier_id
            if carrier.delivery_type != "aramex":
                raise UserError(_(
                    "%s is not shipped with Aramex.") % picking.name)
            if not picking.carrier_tracking_ref:
                raise UserError(_(
                    "%s has no Aramex AWB number yet.") % picking.name)

            results = carrier._aramex_client().track([picking.carrier_tracking_ref])
            events = []
            if isinstance(results, dict):
                for value in results.values():
                    events.extend(value or [])
            else:
                for entry in results:
                    events.extend(entry.get("Value") or [])
            if not events:
                picking.message_post(body=_("Aramex has no update for this AWB yet."))
                continue

            latest = events[-1]
            description = latest.get("UpdateDescription") or latest.get("UpdateCode") or ""
            location = latest.get("UpdateLocation") or ""
            picking.write({
                "aramex_last_status": description,
                "aramex_last_status_date": fields.Datetime.now(),
            })
            picking.message_post(body=_(
                "Aramex update: <b>%(desc)s</b>%(loc)s",
                desc=description,
                loc=(" — %s" % location) if location else "",
            ))
