# -*- coding: utf-8 -*-
"""Thin client around the Aramex Shipping API (V2, JSON endpoints).

Only the four calls Odoo needs are implemented:
  * CalculateRate   -> rate shopping
  * CreateShipments -> AWB + label
  * TrackShipments  -> tracking history
  * CreatePickup    -> optional pickup request

Endpoint reference: https://www.aramex.com/developers/aramex-apis
"""

import base64
import logging
import time

import requests

from odoo import _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

BASE_URL = {
    "test": "https://ws.dev.aramex.net/ShippingAPI.V2",
    "prod": "https://ws.aramex.net/ShippingAPI.V2",
}

SERVICE_PATH = {
    "rate": "/RateCalculator/Service_1_0.svc/json/CalculateRate",
    "create": "/Shipping/Service_1_0.svc/json/CreateShipments",
    "pickup": "/Shipping/Service_1_0.svc/json/CreatePickup",
    "cancel_pickup": "/Shipping/Service_1_0.svc/json/CancelPickup",
    "track": "/Tracking/Service_1_0.svc/json/TrackShipments",
}

# "Source" identifies the calling channel to Aramex. 24 is the value Aramex
# documents for third-party JSON integrations.
API_SOURCE = 24
API_VERSION = "v1.0"

TRACKING_URL = "https://www.aramex.com/track/results?ShipmentNumber=%s"

TIMEOUT = 30


class AramexError(UserError):
    """Raised when Aramex answers with HasErrors=true or the call fails."""


class AramexRequest:
    def __init__(self, carrier, debug_logger=None):
        """:param carrier: a ``delivery.carrier`` record configured for Aramex."""
        self.carrier = carrier
        self.environment = carrier.aramex_environment or "test"
        self._debug = debug_logger or (lambda payload, kind: None)

    # ------------------------------------------------------------------
    # low level
    # ------------------------------------------------------------------
    def _url(self, service):
        return BASE_URL[self.environment] + SERVICE_PATH[service]

    def _client_info(self):
        c = self.carrier
        return {
            "UserName": c.aramex_username or "",
            "Password": c.aramex_password or "",
            "Version": API_VERSION,
            "AccountNumber": c.aramex_account_number or "",
            "AccountPin": c.aramex_account_pin or "",
            "AccountEntity": c.aramex_account_entity or "",
            "AccountCountryCode": c.aramex_account_country_code or "",
            "Source": API_SOURCE,
        }

    @staticmethod
    def _transaction(reference=""):
        return {
            "Reference1": reference or "",
            "Reference2": "",
            "Reference3": "",
            "Reference4": "",
            "Reference5": "",
        }

    def _call(self, service, payload):
        url = self._url(service)
        self._debug(payload, "aramex_%s_request" % service)
        try:
            response = requests.post(
                url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=TIMEOUT,
            )
            response.raise_for_status()
            body = response.json()
        except requests.exceptions.Timeout:
            raise AramexError(_("Aramex did not answer within %s seconds.") % TIMEOUT)
        except requests.exceptions.HTTPError as err:
            raise AramexError(
                _("Aramex returned HTTP %(code)s for %(url)s.",
                  code=err.response.status_code, url=url)
            )
        except requests.exceptions.RequestException as err:
            raise AramexError(_("Could not reach Aramex: %s") % err)
        except ValueError:
            raise AramexError(_("Aramex returned a response that is not valid JSON."))

        self._debug(body, "aramex_%s_response" % service)
        self._raise_on_error(body)
        return body

    @staticmethod
    def _raise_on_error(body):
        if not body.get("HasErrors"):
            return
        messages = []
        for notification in body.get("Notifications") or []:
            messages.append("[%s] %s" % (
                notification.get("Code", "?"),
                notification.get("Message", ""),
            ))
        # Per-shipment notifications (CreateShipments)
        for shipment in body.get("Shipments") or []:
            for notification in shipment.get("Notifications") or []:
                messages.append("[%s] %s" % (
                    notification.get("Code", "?"),
                    notification.get("Message", ""),
                ))
        for shipment in body.get("NonExistingShipments") or []:
            messages.append(_("Unknown shipment: %s") % shipment)
        raise AramexError(
            _("Aramex rejected the request:\n%s") % ("\n".join(messages) or _("no detail returned"))
        )

    # ------------------------------------------------------------------
    # payload builders
    # ------------------------------------------------------------------
    @staticmethod
    def _wcf_date(dt=None):
        """WCF date literal expected by the JSON endpoints: /Date(ms)/."""
        stamp = int((dt.timestamp() if dt else time.time()) * 1000)
        return "/Date(%s)/" % stamp

    @staticmethod
    def address(partner):
        """Map a ``res.partner`` to an Aramex PartyAddress."""
        return {
            "Line1": partner.street or "",
            "Line2": partner.street2 or "",
            "Line3": "",
            "City": partner.city or "",
            "StateOrProvinceCode": partner.state_id.code or "",
            "PostCode": partner.zip or "",
            "CountryCode": partner.country_id.code or "",
            "Longitude": 0,
            "Latitude": 0,
            "BuildingNumber": "",
            "BuildingName": "",
            "Floor": "",
            "Apartment": "",
            "POBox": "",
            "Description": "",
        }

    @staticmethod
    def contact(partner):
        """Map a ``res.partner`` to an Aramex Contact."""
        phone = partner.phone or partner.mobile or ""
        return {
            "Department": "",
            "PersonName": (partner.name or "")[:50],
            "Title": "",
            "CompanyName": (partner.commercial_company_name or partner.name or "")[:50],
            "PhoneNumber1": phone,
            "PhoneNumber1Ext": "",
            "PhoneNumber2": "",
            "PhoneNumber2Ext": "",
            "FaxNumber": "",
            "CellPhone": partner.mobile or phone,
            "EmailAddress": partner.email or "",
            "Type": "",
        }

    @staticmethod
    def weight(value, unit="KG"):
        return {"Unit": unit, "Value": round(max(value or 0.0, 0.5), 3)}

    @staticmethod
    def money(amount, currency_code):
        return {"CurrencyCode": currency_code, "Value": round(amount or 0.0, 2)}

    # ------------------------------------------------------------------
    # public calls
    # ------------------------------------------------------------------
    def rate(self, shipper_partner, recipient_partner, total_weight,
             number_of_pieces=1, currency_code="AED", reference=""):
        carrier = self.carrier
        payload = {
            "ClientInfo": self._client_info(),
            "Transaction": self._transaction(reference),
            "OriginAddress": self.address(shipper_partner),
            "DestinationAddress": self.address(recipient_partner),
            "ShipmentDetails": {
                "PaymentType": carrier.aramex_payment_type,
                "ProductGroup": carrier.aramex_product_group,
                "ProductType": carrier.aramex_product_type,
                "ActualWeight": self.weight(total_weight),
                "ChargeableWeight": self.weight(total_weight),
                "NumberOfPieces": number_of_pieces,
                "Dimensions": None,
                "DescriptionOfGoods": carrier.aramex_description_of_goods or "Goods",
                "GoodsOriginCountry": shipper_partner.country_id.code or "",
            },
            "PreferredCurrencyCode": currency_code,
        }
        body = self._call("rate", payload)
        total = body.get("TotalAmount") or {}
        return {
            "amount": float(total.get("Value") or 0.0),
            "currency": total.get("CurrencyCode") or currency_code,
            "raw": body,
        }

    def create_shipment(self, shipper_partner, recipient_partner, total_weight,
                        number_of_pieces=1, currency_code="AED", reference="",
                        description="Goods", customs_value=0.0, cod_amount=0.0,
                        ship_date=None, comments=""):
        carrier = self.carrier
        details = {
            "Dimensions": None,
            "ActualWeight": self.weight(total_weight),
            "ChargeableWeight": self.weight(total_weight),
            "DescriptionOfGoods": description or "Goods",
            "GoodsOriginCountry": shipper_partner.country_id.code or "",
            "NumberOfPieces": number_of_pieces,
            "ProductGroup": carrier.aramex_product_group,
            "ProductType": carrier.aramex_product_type,
            "PaymentType": carrier.aramex_payment_type,
            "PaymentOptions": carrier.aramex_payment_options or "",
            "Services": carrier.aramex_services or "",
            "CustomsValueAmount": (
                self.money(customs_value, currency_code)
                if carrier.aramex_product_group == "EXP" else None
            ),
            "CashOnDeliveryAmount": (
                self.money(cod_amount, currency_code) if cod_amount else None
            ),
            "InsuranceAmount": None,
            "CashAdditionalAmount": None,
            "CashAdditionalAmountDescription": "",
            "CollectAmount": None,
            "Items": [],
        }
        shipment = {
            "Reference1": reference or "",
            "Reference2": "",
            "Reference3": "",
            "Shipper": {
                "Reference1": "",
                "Reference2": "",
                "AccountNumber": carrier.aramex_account_number or "",
                "PartyAddress": self.address(shipper_partner),
                "Contact": self.contact(shipper_partner),
            },
            "Consignee": {
                "Reference1": "",
                "Reference2": "",
                "AccountNumber": "",
                "PartyAddress": self.address(recipient_partner),
                "Contact": self.contact(recipient_partner),
            },
            "ThirdParty": None,
            "ShippingDateTime": self._wcf_date(ship_date),
            "DueDate": self._wcf_date(ship_date),
            "Comments": comments or "",
            "PickupLocation": carrier.aramex_pickup_location or "Reception",
            "OperationsInstructions": "",
            "AccountingInstrcutions": "",  # sic - Aramex spells it this way
            "Details": details,
            "Attachments": [],
            "ForeignHAWB": "",
            "TransportType": 0,
            "PickupGUID": "",
            "Number": None,
            "ScheduledDelivery": None,
        }
        payload = {
            "ClientInfo": self._client_info(),
            "Transaction": self._transaction(reference),
            "Shipments": [shipment],
            "LabelInfo": {
                "ReportID": int(carrier.aramex_label_report_id or 9729),
                "ReportType": carrier.aramex_label_report_type or "URL",
            },
        }
        body = self._call("create", payload)
        processed = body.get("Shipments") or []
        if not processed:
            raise AramexError(_("Aramex accepted the call but returned no shipment."))
        result = processed[0]
        label = result.get("ShipmentLabel") or {}
        return {
            "tracking_number": result.get("ID") or "",
            "label_url": label.get("LabelURL") or "",
            "label_contents": label.get("LabelFileContents") or "",
            "raw": body,
        }

    def track(self, tracking_numbers):
        payload = {
            "ClientInfo": self._client_info(),
            "Transaction": self._transaction(),
            "Shipments": list(tracking_numbers),
            "GetLastTrackingUpdateOnly": False,
        }
        body = self._call("track", payload)
        return body.get("TrackingResults") or []

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    def fetch_label(self, label_url):
        """Download the PDF label Aramex published and return it base64-encoded."""
        try:
            response = requests.get(label_url, timeout=TIMEOUT)
            response.raise_for_status()
        except requests.exceptions.RequestException as err:
            _logger.warning("Aramex: could not download label %s (%s)", label_url, err)
            return False
        return base64.b64encode(response.content)
