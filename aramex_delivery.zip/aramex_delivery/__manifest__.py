# -*- coding: utf-8 -*-
{
    "name": "Aramex Delivery Carrier",
    "version": "19.0.1.0.0",
    "category": "Inventory/Delivery",
    "summary": "Aramex shipping integration: live rates, shipment creation, "
               "labels, tracking and eCommerce checkout rates.",
    "description": """
Aramex Delivery Carrier
=======================

Adds *Aramex* as a delivery provider in Odoo, using the public Aramex
Shipping API (V2, JSON endpoints).

Features
--------
* Live rate calculation on sales orders and on the eCommerce checkout.
* Shipment creation from the delivery order ("Send to Shipper").
* Shipping label automatically attached to the delivery order (PDF).
* Tracking number + tracking link on the delivery order and customer portal.
* Domestic (DOM) and Express/International (EXP) product groups.
* Extra margin (fixed amount or percentage) on top of the Aramex rate.
* Separate Test / Production environments.
""",
    "author": "",
    "website": "",
    "license": "LGPL-3",
    "depends": [
        "delivery",
        "stock_delivery",
        "mail",
    ],
    "data": [
        "data/aramex_data.xml",
        "views/delivery_aramex_views.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
