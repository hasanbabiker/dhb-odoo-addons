from odoo import models, fields


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    dhb_interview_anthropic_key = fields.Char(
        string="Anthropic API key",
        config_parameter="dhb_interview.anthropic_api_key",
        help="Used to write the English record sheet from the Arabic "
             "transcript. Without it the form is filled with the details Odoo "
             "already holds and the notes are typed by hand.",
    )
    dhb_interview_anthropic_model = fields.Char(
        string="Model",
        config_parameter="dhb_interview.anthropic_model",
        default="claude-opus-5",
    )
    dhb_interview_store_video = fields.Boolean(
        string="Keep the recording in Odoo",
        config_parameter="dhb_interview.store_video",
        help="Zoom deletes cloud recordings on its own retention schedule. "
             "Keeping a copy costs disk but survives that deletion.",
    )
