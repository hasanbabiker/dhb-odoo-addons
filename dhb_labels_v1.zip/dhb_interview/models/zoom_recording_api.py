import logging

import requests

from odoo import models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

TIMEOUT = 120
# Zoom refuses a download that is not explicitly asked for as a file.
DOWNLOAD_HEADERS = {"Accept": "*/*"}
MAX_DOWNLOAD_BYTES = 512 * 1024 * 1024


class ZoomApiRecordings(models.AbstractModel):
    """Cloud-recording endpoints, added to the attendance module's client.

    Extending the existing abstract model rather than writing a second client
    keeps one set of credentials and one cached token. Everything here is the
    Cloud Recording API, which is separate from the Dashboard API the
    attendance module uses and needs the recording:read scopes on the same
    Server-to-Server OAuth app.
    """

    _inherit = "dhb.zoom.api"

    # ------------------------------------------------------------------
    # listing
    # ------------------------------------------------------------------
    def list_cloud_recordings(self, date_from, date_to, user_id="me"):
        """Cloud recordings for a host between two dates.

        Zoom caps this endpoint at one month per call, so a longer range is
        walked month by month rather than silently returning the first month
        and nothing else.
        """
        from datetime import timedelta

        meetings, cursor = [], date_from
        while cursor <= date_to:
            window_end = min(cursor + timedelta(days=29), date_to)
            meetings.extend(self._request_paged(
                f"/users/{user_id}/recordings",
                {
                    "from": cursor.strftime("%Y-%m-%d"),
                    "to": window_end.strftime("%Y-%m-%d"),
                    "page_size": 300,
                },
                key="meetings",
            ))
            cursor = window_end + timedelta(days=1)
        return meetings

    def get_meeting_recordings(self, meeting_id):
        """Recording files for one meeting ID or UUID."""
        return self._request(f"/meetings/{meeting_id}/recordings")

    # ------------------------------------------------------------------
    # downloading
    # ------------------------------------------------------------------
    def download_recording_file(self, download_url):
        """Fetch one recording file and return its bytes.

        The download URL is absolute and outside the API base, so it cannot go
        through _request. The bearer token still applies, and Zoom answers a
        request without one with an HTML login page rather than an error code,
        which is why the content type is checked instead of trusted.
        """
        if not download_url:
            return b""
        token = self._get_token()
        headers = dict(DOWNLOAD_HEADERS)
        headers["Authorization"] = f"Bearer {token}"
        try:
            response = requests.get(
                download_url, headers=headers, timeout=TIMEOUT, stream=True,
                allow_redirects=True,
            )
        except requests.RequestException as exc:
            raise UserError(_("Could not download from Zoom: %s") % exc) from exc

        if response.status_code == 401:
            self._get_token(force_refresh=True)
            headers["Authorization"] = f"Bearer {self._get_token()}"
            try:
                response = requests.get(
                    download_url, headers=headers, timeout=TIMEOUT, stream=True,
                    allow_redirects=True,
                )
            except requests.RequestException as exc:
                raise UserError(_("Could not download from Zoom: %s") % exc) from exc

        if response.status_code != 200:
            raise UserError(_(
                "Zoom returned HTTP %(code)s for the recording download:\n%(body)s",
                code=response.status_code,
                body=response.text[:300],
            ))

        content_type = (response.headers.get("Content-Type") or "").lower()
        if "text/html" in content_type:
            raise UserError(_(
                "Zoom answered the download with a web page instead of a file. "
                "That normally means the Server-to-Server OAuth app is missing "
                "the recording:read:admin scope, or the Client Secret in "
                "Settings is stale."
            ))

        chunks, total = [], 0
        for chunk in response.iter_content(chunk_size=1024 * 256):
            if not chunk:
                continue
            total += len(chunk)
            if total > MAX_DOWNLOAD_BYTES:
                raise UserError(_(
                    "The recording is larger than %s MB. Store the video as a "
                    "link instead of a file, or trim it in Zoom first."
                ) % (MAX_DOWNLOAD_BYTES // (1024 * 1024)))
            chunks.append(chunk)
        return b"".join(chunks)

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    @staticmethod
    def pick_recording_file(meeting_payload, file_type):
        """Return the first completed file of a type, or False.

        Zoom keeps failed and still-processing files in the same list, and a
        file whose status is not 'completed' has a download URL that answers
        with an error.
        """
        for item in (meeting_payload or {}).get("recording_files", []):
            if (item.get("file_type") or "").upper() != file_type.upper():
                continue
            if (item.get("status") or "completed").lower() != "completed":
                continue
            return item
        return False
