"""Fill the two official NEBOSH interview record sheets.

The forms are the awarding body's own files and are treated as read-only
furniture: nothing is added, removed, reordered or reworded. The only writes
are text into the empty answer cells and ticks into the checkboxes that are
already there.

The module is deliberately free of Odoo imports so it can be run and tested on
its own, which is how the cell map below was verified against both templates.
"""

import copy
import io
import os
import re
import zipfile

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
W14 = "{http://schemas.microsoft.com/office/word/2010/wordml}"

TEMPLATE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "static", "src", "doc",
)
TEMPLATES = {
    "as043d": "AS043d_Closing_Interview_Record_Sheet_Template_v4.docx",
    "diploma": "Diploma_Professional_Discussion_Record_Sheet_Template.docx",
}

# Part 2 rows, in the order they appear in table 1 of both forms. Each entry is
# the row index and how many checkboxes that row carries.
PART2_ROWS = {
    "intro": (0, 1),
    "structure": (1, 1),
    "passport": (3, 1),
    "licence": (4, 1),
    "national_id": (5, 1),
    "id_satisfactory": (6, 2),
    "room": (7, 2),
    "resources": (8, 2),
    "assistance": (9, 2),
}
ID_TYPE_ROW = {"passport": "passport", "licence": "licence", "national_id": "national_id"}


def template_path(form_type):
    name = TEMPLATES.get(form_type)
    if not name:
        raise ValueError("Unknown form type %r" % (form_type,))
    return os.path.join(TEMPLATE_DIR, name)


# ----------------------------------------------------------------------
# low level helpers
# ----------------------------------------------------------------------
def _unique_cells(row):
    """Row cells with horizontally merged duplicates collapsed.

    python-docx repeats the same cell object for every grid column a merged
    cell spans. Part 1 is full of merges, so a plain index into row.cells
    lands on the wrong thing; identity of the underlying tc element is what
    distinguishes a real cell.
    """
    seen, cells = set(), []
    for cell in row.cells:
        key = id(cell._tc)
        if key in seen:
            continue
        seen.add(key)
        cells.append(cell)
    return cells


def _norm(text):
    return re.sub(r"\s+", " ", (text or "")).strip().lower().rstrip(":")


def _write(cell, text):
    """Put text into an answer cell without disturbing its formatting.

    The cell's first paragraph is kept, so its style, alignment and the table's
    look survive. Line breaks become real <w:br/> runs rather than separate
    paragraphs, which would change the row height rules of the original form.
    """
    if text is None:
        return
    text = str(text)
    if not text.strip():
        return
    paragraph = cell.paragraphs[0]
    for run in list(paragraph.runs):
        run._r.getparent().remove(run._r)
    lines = text.split("\n")
    run = paragraph.add_run(lines[0])
    # Word applies the paragraph mark's run properties to text typed into an
    # empty cell. Copying them onto the run makes the filled text come out in
    # the font the form was built to be filled in, rather than the document
    # default.
    mark = paragraph._p.find(f"{W}pPr")
    if mark is not None:
        mark_rpr = mark.find(f"{W}rPr")
        if mark_rpr is not None:
            existing = run._r.find(f"{W}rPr")
            if existing is not None:
                run._r.remove(existing)
            copied = copy.deepcopy(mark_rpr)
            # A paragraph mark may carry revision marks, which are not legal
            # inside a run's properties.
            for tag in ("ins", "del", "moveFrom", "moveTo"):
                for node in copied.findall(f"{W}{tag}"):
                    copied.remove(node)
            run._r.insert(0, copied)
    for line in lines[1:]:
        run.add_break()
        run.add_text(line)


def _set_by_label(table, label, value):
    """Write value into the answer cell that follows a labelled cell."""
    target = _norm(label)
    for row in table.rows:
        cells = _unique_cells(row)
        for index, cell in enumerate(cells):
            if _norm(cell.text) == target and index + 1 < len(cells):
                _write(cells[index + 1], value)
                return True
    return False


def _row_checkboxes(row):
    """Every checkbox content control in a row, in document order."""
    boxes, seen = [], set()
    for cell in _unique_cells(row):
        for sdt in cell._tc.iter(f"{W}sdt"):
            if sdt.find(f".//{W14}checkbox") is None:
                continue
            key = id(sdt)
            if key in seen:
                continue
            seen.add(key)
            boxes.append(sdt)
    return boxes


def _tick(sdt, checked=True):
    """Tick a Word checkbox content control.

    Word decides what to draw from the glyph in the run, and what the field is
    worth from w14:checked. Setting only one of the two produces a form that
    looks ticked and reads unticked, or the reverse, so both are set.
    """
    box = sdt.find(f".//{W14}checkbox")
    if box is None:
        return False
    state = box.find(f"{W14}checked")
    if state is None:
        state = copy.deepcopy(box.find(f"{W14}checkedState"))
        state.tag = f"{W14}checked"
        box.insert(0, state)
    state.set(f"{W14}val", "1" if checked else "0")
    for node in sdt.iter(f"{W}t"):
        if node.text and ("☐" in node.text or "☒" in node.text):
            node.text = node.text.replace(
                "☐" if checked else "☒",
                "☒" if checked else "☐",
            )
    return True


def _set_part2(table, key, value):
    """value: True/False for single boxes, 'yes'/'no'/None for Yes-No pairs."""
    row_index, count = PART2_ROWS[key]
    boxes = _row_checkboxes(table.rows[row_index])
    if len(boxes) < count:
        return False
    if count == 1:
        if value:
            _tick(boxes[0], True)
        return True
    if value == "yes":
        _tick(boxes[0], True)
    elif value == "no":
        _tick(boxes[1], True)
    return True


# ----------------------------------------------------------------------
# public entry point
# ----------------------------------------------------------------------
def fill_form(form_type, data, output_path):
    """Write a completed copy of the official form.

    data keys are documented on dhb.interview._form_data. Anything absent is
    left empty: the form never gets a placeholder, because a placeholder in an
    awarding body's record is worse than a blank.
    """
    from docx import Document

    document = Document(template_path(form_type))
    part1, part2, part3 = document.tables[0], document.tables[1], document.tables[2]

    # --- Part 1 -------------------------------------------------------
    _set_by_label(part1, "Learner name", data.get("learner_name"))
    _set_by_label(part1, "NEBOSH learner number", data.get("learner_number"))
    _set_by_label(part1, "Date of birth", data.get("date_of_birth"))
    _set_by_label(part1, "Learning Partner name", data.get("lp_name"))
    _set_by_label(part1, "Learning Partner number", data.get("lp_number"))
    _set_by_label(part1, "Date of assessment", data.get("assessment_date"))
    _set_by_label(part1, "Name of Interviewer", data.get("interviewer_name"))
    if form_type == "diploma":
        _set_by_label(part1, "Unit", data.get("unit"))
        _set_by_label(part1, "Date of professional discussion", data.get("interview_date"))
        _set_by_label(part1, "Time of professional discussion", data.get("interview_time"))
    else:
        _set_by_label(part1, "Date of closing interview", data.get("interview_date"))
        _set_by_label(part1, "Time of closing interview", data.get("interview_time"))

    # --- Part 2 -------------------------------------------------------
    _set_part2(part2, "intro", data.get("intro_done"))
    _set_part2(part2, "structure", data.get("structure_explained"))
    id_type = data.get("id_type")
    if id_type in ID_TYPE_ROW:
        _set_part2(part2, ID_TYPE_ROW[id_type], True)
    _set_part2(part2, "id_satisfactory", data.get("id_satisfactory"))
    _set_part2(part2, "room", data.get("room_ok"))
    _set_part2(part2, "resources", data.get("no_resources"))
    _set_part2(part2, "assistance", data.get("no_assistance"))
    # The Notes label sits in row 10; row 11 is the box under it.
    _write(_unique_cells(part2.rows[11])[0], data.get("identity_notes"))

    # --- Part 3 -------------------------------------------------------
    if form_type == "diploma":
        _write(_unique_cells(part3.rows[1])[0], data.get("diploma_notes"))
    else:
        for offset, question in enumerate(data.get("questions") or []):
            if offset > 2:
                break
            cells = _unique_cells(part3.rows[1 + offset])
            _write(cells[0], question.get("task_number"))
            if len(cells) > 1:
                _write(cells[1], question.get("notes"))
        _write(_unique_cells(part3.rows[5])[0], data.get("other_notes"))

    # Part 4 is guidance and Part 5 is the malpractice referral: both are left
    # exactly as the awarding body wrote them.
    buffer = io.BytesIO()
    document.save(buffer)
    _repackage(template_path(form_type), buffer.getvalue(), output_path)
    return output_path


def _repackage(template_file, written_package, output_path):
    """Write the original .docx back out with only document.xml replaced.

    Saving through python-docx re-serialises every part of the package, which
    rewrites styles, headers, footers and the content types even though none of
    them were touched. Nothing visible changes, but the file stops being the
    awarding body's file byte for byte, and that is the one thing this must not
    do. So the answers are taken from the rewritten package and dropped back
    into an otherwise untouched copy of the original.
    """
    with zipfile.ZipFile(io.BytesIO(written_package)) as written:
        document_xml = written.read("word/document.xml")

    with zipfile.ZipFile(template_file) as source:
        items = source.infolist()
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as target:
            for item in items:
                data = (document_xml if item.filename == "word/document.xml"
                        else source.read(item.filename))
                # Keep each part's own compression and timestamp so the parts
                # that were not touched come out identical.
                info = zipfile.ZipInfo(item.filename, date_time=item.date_time)
                info.compress_type = item.compress_type
                info.external_attr = item.external_attr
                info.internal_attr = item.internal_attr
                info.create_system = item.create_system
                target.writestr(info, data)
