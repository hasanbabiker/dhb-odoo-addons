from odoo import models, fields, api, _
from odoo.exceptions import UserError

from .dhb_interview import term_for

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"


class EventRegistration(models.Model):
    """The certificate gate.

    NEBOSH will not issue a certificate for a learner with no closing
    interview on file, so requesting one before the interview is recorded
    creates work that comes back. The chosen behaviour is a red warning rather
    than a hard stop, with the override reserved to a manager and requiring a
    written reason, which is the same shape as the attendance override already
    in use.
    """

    _inherit = "dhb.batch.line"

    interview_ids = fields.One2many(
        "dhb.interview", "registration_id",
        string="Closing interview / professional discussion",
    )
    interview_term = fields.Char(
        string="Required session", compute="_compute_interview_display",
        help="A certificate learner has a closing interview; a Diploma "
             "learner has a professional discussion.",
    )
    # Stored and unstored fields are computed by separate methods on purpose:
    # Odoo warns when one method mixes them, because the stored one is written
    # on change while the others are recomputed on every read, and sharing a
    # method makes that difference invisible to whoever edits it next.
    interview_on_file = fields.Boolean(
        string="Interview on file", compute="_compute_interview_on_file",
        store=True,
    )
    interview_count = fields.Integer(compute="_compute_interview_display")
    interview_warning = fields.Char(compute="_compute_interview_display")

    certificate_requested = fields.Date(
        string="Certificate requested on", readonly=True, copy=False,
    )
    certificate_override = fields.Boolean(
        string="Interview requirement overridden", copy=False,
        help="A manager may request the certificate before the interview is "
             "on file. The reason is kept with the record.",
    )
    certificate_override_by = fields.Many2one(
        "res.users", string="Certificate override by",
        readonly=True, copy=False)
    certificate_override_date = fields.Datetime(
        string="Certificate override on", readonly=True, copy=False)
    certificate_override_reason = fields.Text(
        string="Certificate override reason", copy=False)

    @api.depends("interview_ids.is_complete")
    def _compute_interview_on_file(self):
        for registration in self:
            registration.interview_on_file = bool(
                registration.interview_ids.filtered("is_complete"))

    @api.depends(
        "interview_ids.is_complete",
        "interview_ids.state",
        "interview_ids.has_video",
        "interview_ids.has_report",
        "event_id.qualification",
        "event_id.sitting_interview_deadline",
    )
    def _compute_interview_display(self):
        today = fields.Date.today()
        for registration in self:
            interviews = registration.interview_ids
            complete = interviews.filtered("is_complete")
            registration.interview_count = len(interviews)
            term = term_for(registration.event_id.qualification)
            registration.interview_term = term.capitalize()

            warning = False
            if not complete:
                deadline = registration.event_id.sitting_interview_deadline
                if not interviews:
                    warning = _(
                        "No %(term)s has been recorded for this learner. "
                        "NEBOSH requires one before the certificate."
                    ) % {"term": term}
                else:
                    missing = []
                    for interview in interviews:
                        if not interview.has_video:
                            missing.append(_("the recording"))
                        if not interview.has_report:
                            missing.append(_("the completed record sheet"))
                    detail = ", ".join(sorted(set(missing))) or _("the record sheet")
                    warning = _(
                        "The %(term)s is started but not on file yet: "
                        "%(detail)s is still missing."
                    ) % {"term": term, "detail": detail}
                if deadline:
                    if deadline < today:
                        warning = _("%(warning)s The deadline passed on "
                                    "%(date)s.") % {
                            "warning": warning,
                            "date": deadline.strftime("%d/%m/%Y"),
                        }
                    else:
                        days = (deadline - today).days
                        if days <= 21:
                            warning = _(
                                "%(warning)s The deadline is in %(days)s days, on "
                                "%(date)s."
                            ) % {"warning": warning, "days": days,
                                 "date": deadline.strftime("%d/%m/%Y")}
            registration.interview_warning = warning

    @api.constrains("certificate_override", "certificate_override_reason")
    def _check_certificate_override_reason(self):
        for registration in self:
            if registration.certificate_override and not (
                    registration.certificate_override_reason or "").strip():
                raise UserError(_(
                    "An override needs a written reason. An auditor accepts a "
                    "documented exception; a silent one is a finding."
                ))

    def write(self, values):
        if "certificate_override" in values:
            if values.get("certificate_override"):
                if not self.env.user.has_group(MANAGER_GROUP):
                    raise UserError(_(
                        "Only a DHB Attendance Manager can override the "
                        "closing interview / professional discussion "
                        "requirement."
                    ))
                values.setdefault("certificate_override_by", self.env.user.id)
                values.setdefault("certificate_override_date", fields.Datetime.now())
            else:
                values.setdefault("certificate_override_by", False)
                values.setdefault("certificate_override_date", False)
        return super().write(values)

    # ------------------------------------------------------------------
    # actions
    # ------------------------------------------------------------------
    def action_request_certificate(self):
        """Record that the certificate has been asked for from NEBOSH."""
        for registration in self:
            if not registration.interview_on_file and not registration.certificate_override:
                term = term_for(registration.event_id.qualification)
                if not self.env.user.has_group(MANAGER_GROUP):
                    raise UserError(_(
                        "%(learner)s has no %(term)s on file.\n\n%(warning)s\n\n"
                        "Record the %(term)s first, or ask a manager to "
                        "override the requirement with a reason."
                    ) % {
                        "learner": registration.partner_id.name,
                        "term": term,
                        "warning": registration.interview_warning or "",
                    })
                raise UserError(_(
                    "%(learner)s has no %(term)s on file.\n\n%(warning)s\n\n"
                    "As a manager you may proceed by ticking \"Interview "
                    "requirement overridden\" and writing the reason, then "
                    "requesting the certificate again."
                ) % {
                    "learner": registration.partner_id.name,
                    "term": term,
                    "warning": registration.interview_warning or "",
                })
            registration.certificate_requested = fields.Date.today()
        return True

    def action_open_interviews(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Closing interview / professional discussion"),
            "res_model": "dhb.interview",
            "view_mode": "list,form",
            "domain": [("registration_id", "=", self.id)],
            "context": {
                "default_registration_id": self.id,
                "default_interviewer_name": "Dr. Hassan Babiker",
            },
        }

    def action_create_interview(self):
        self.ensure_one()
        interview = self.env["dhb.interview"].create({
            "registration_id": self.id,
        })
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.interview",
            "res_id": interview.id,
            "view_mode": "form",
        }
