from odoo import models, fields, api, _


class EventEvent(models.Model):
    """Cohort-level view of where the interviews stand."""

    _inherit = "dhb.batch"

    interview_ids = fields.One2many(
        "dhb.interview", "event_id", string="Closing interviews / professional discussions")
    interview_total = fields.Integer(compute="_compute_interview_progress")
    interview_done_count = fields.Integer(compute="_compute_interview_progress")
    interview_missing_count = fields.Integer(compute="_compute_interview_progress")

    @api.depends("registration_ids.interview_on_file", "registration_ids.state")
    def _compute_interview_progress(self):
        for event in self:
            registrations = event.registration_ids.filtered(
                lambda r: r.state != "cancel")
            done = registrations.filtered("interview_on_file")
            event.interview_total = len(registrations)
            event.interview_done_count = len(done)
            event.interview_missing_count = len(registrations) - len(done)

    def action_open_interviews(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Interviews and professional discussions"),
            "res_model": "dhb.interview",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }

    def action_fetch_interviews_from_zoom(self):
        """Open the wizard that matches Zoom recordings to this cohort."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Fetch interviews from Zoom"),
            "res_model": "dhb.interview.fetch.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_event_id": self.id},
        }
