from odoo import models, fields, api, _

DONE_STATE = "done"


class ResPartner(models.Model):
    """The learner's own file, read-only about interviews.

    A learner can sit more than one qualification with DHB, and each one
    carries its own session under its own name: a closing interview for a
    certificate, a professional discussion for each Diploma unit. One person
    may therefore hold an IGC closing interview and three professional
    discussions at once, so the learner file shows them as a list rather than
    a single yes or no.

    Nothing here is editable. The interview is recorded against the
    registration, because that is what ties it to a cohort, a sitting and a
    deadline; showing it on the contact as well is for the person opening the
    accreditation file and asking "is this learner's evidence complete?".
    """

    _inherit = "res.partner"

    dhb_interview_ids = fields.One2many(
        "dhb.interview", "partner_id", string="Interviews and discussions",
        readonly=True,
    )
    dhb_interview_count = fields.Integer(
        string="Sessions recorded", compute="_compute_dhb_interviews")
    dhb_interview_done_count = fields.Integer(
        string="On file", compute="_compute_dhb_interviews")
    dhb_interview_missing_count = fields.Integer(
        string="Incomplete", compute="_compute_dhb_interviews")
    dhb_interview_summary = fields.Text(
        string="Interview evidence", compute="_compute_dhb_interviews",
        help="One line per qualification, so a complete file can be seen at a "
             "glance without opening each cohort.",
    )
    dhb_interview_all_done = fields.Boolean(
        string="All interviews on file", compute="_compute_dhb_interviews",
        help="True when every session recorded for this learner holds both "
             "the recording and the completed record sheet. It says nothing "
             "about a qualification whose session was never recorded at all.",
    )

    @api.depends(
        "dhb_interview_ids.state",
        "dhb_interview_ids.is_complete",
        "dhb_interview_ids.has_video",
        "dhb_interview_ids.has_report",
        "dhb_interview_ids.form_type",
        "dhb_interview_ids.unit",
        "dhb_interview_ids.interview_datetime",
    )
    def _compute_dhb_interviews(self):
        qualification_labels = dict(
            self.env["dhb.batch"]._fields["qualification"].selection)
        for partner in self:
            interviews = partner.dhb_interview_ids
            done = interviews.filtered("is_complete")
            partner.dhb_interview_count = len(interviews)
            partner.dhb_interview_done_count = len(done)
            partner.dhb_interview_missing_count = len(interviews) - len(done)
            partner.dhb_interview_all_done = bool(interviews) and not (
                len(interviews) - len(done))

            lines = []
            for interview in interviews:
                if interview.form_type == "diploma":
                    what = _("professional discussion")
                    subject = interview.unit or qualification_labels.get(
                        interview.qualification, _("Diploma"))
                else:
                    what = _("closing interview")
                    subject = qualification_labels.get(
                        interview.qualification, "") or _("certificate")

                if interview.state == DONE_STATE and interview.is_complete:
                    status = _("on file")
                else:
                    gaps = []
                    if not interview.has_video:
                        gaps.append(_("recording"))
                    if not interview.has_report:
                        gaps.append(_("record sheet"))
                    if gaps:
                        status = _("missing the %s") % " and ".join(gaps)
                    else:
                        status = _("not filed yet")

                when = ""
                local = interview._local()
                if local:
                    when = " - %s" % local.strftime("%d/%m/%Y")
                lines.append("%s: %s - %s%s" % (subject, what, status, when))
            partner.dhb_interview_summary = "\n".join(lines)

    def action_open_dhb_interviews(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Interviews and professional discussions"),
            "res_model": "dhb.interview",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
        }
