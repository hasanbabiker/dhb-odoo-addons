"""Turn an interview transcript into the content of the record sheet.

The transcript is usually Arabic speech; the awarding body's form must be in
English. That is a translation-and-summary job, so it is done by a language
model over the Anthropic API, with the same rules the desk process follows.

Two things are load-bearing here:

* The model is told to return null for anything the transcript does not
  evidence. An empty cell is a true record; an invented one is malpractice.
* Nothing this returns is written to the form without passing through
  dhb.interview, which drops keys it does not know and re-checks the Yes/No
  values. A model that answers oddly cannot put arbitrary content into an
  official file.
"""

import json
import logging
import re

import requests

_logger = logging.getLogger(__name__)

API_URL = "https://api.anthropic.com/v1/messages"
API_VERSION = "2023-06-01"
DEFAULT_MODEL = "claude-opus-5"
TIMEOUT = 180
MAX_TRANSCRIPT_CHARS = 400000


class AiFillError(Exception):
    """Raised when the transcript could not be turned into form content."""


SYSTEM_PROMPT = """\
You prepare NEBOSH interview record sheets for a Learning Partner.

You are given the transcript of one learner interview and must return the
content that goes into the official form. Follow these rules exactly.

1. All output text must be in clear, professional English. The transcript is
   often Arabic; translate rather than transcribe.
2. Never invent anything. If the transcript does not evidence a detail, return
   null for it. Do not write "N/A", "not stated" or any placeholder.
3. Notes on a learner's response are a paraphrase, not a transcription. Two to
   four sentences each, factual and neutral.
4. If the learner answered poorly or not at all, record that plainly.
5. Tick a checkbox only on evidence in the transcript. The one exception is
   no_unauthorised_resources, which is the interviewer's own attestation and is
   "yes" unless the transcript shows the interviewer raising a concern.
6. Return JSON only. No commentary, no code fence.
"""

SCHEMA_CERTIFICATE = """\
{
  "learner_name": string|null,
  "learner_number": string|null,
  "date_of_birth": "dd/mm/yyyy"|null,
  "interviewer_name": string|null,
  "intro_done": true|false,
  "structure_explained": true|false,
  "id_type": "passport"|"licence"|"national_id"|null,
  "id_satisfactory": "yes"|"no"|null,
  "room_ok": "yes"|"no"|null,
  "no_resources": "yes"|"no"|null,
  "no_assistance": "yes"|"no"|null,
  "identity_notes": string|null,
  "questions": [
    {"task_number": string|null, "notes": string|null},
    {"task_number": string|null, "notes": string|null},
    {"task_number": string|null, "notes": string|null}
  ],
  "other_notes": string|null
}

"questions" holds the three specific questions asked, in the order asked.
"task_number" is the task the question relates to, e.g. "Task 2", and is null
if the interviewer never names one. If fewer than three questions were asked,
return the ones that were and leave the rest with null values.
"other_notes" covers any further questions or observations, else null.
"""

SCHEMA_DIPLOMA = """\
{
  "learner_name": string|null,
  "learner_number": string|null,
  "date_of_birth": "dd/mm/yyyy"|null,
  "interviewer_name": string|null,
  "unit": "DI1"|"DI2"|"DI3"|null,
  "intro_done": true|false,
  "structure_explained": true|false,
  "id_type": "passport"|"licence"|"national_id"|null,
  "id_satisfactory": "yes"|"no"|null,
  "room_ok": "yes"|"no"|null,
  "no_resources": "yes"|"no"|null,
  "no_assistance": "yes"|"no"|null,
  "identity_notes": string|null,
  "diploma_notes": string|null
}

"diploma_notes" is the whole of Part 3 as one block of text: one short
paragraph per question asked, each giving the question and a summary of the
learner's response, separated by single newlines.
"""


def _extract_json(text):
    """Pull the JSON object out of a reply, fenced or not."""
    text = (text or "").strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if fence:
        text = fence.group(1).strip()
    try:
        return json.loads(text)
    except ValueError:
        pass
    start, depth = text.find("{"), 0
    if start == -1:
        raise AiFillError("The model did not return JSON.")
    for index in range(start, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:index + 1])
                except ValueError as exc:
                    raise AiFillError("The model returned malformed JSON.") from exc
    raise AiFillError("The model returned an incomplete reply.")


def extract(transcript, form_type, context=None, api_key=None,
            model=DEFAULT_MODEL, timeout=TIMEOUT):
    """Return the form content for one transcript as a plain dict."""
    if not api_key:
        raise AiFillError(
            "No Anthropic API key is set. Enter one under Settings > DHB "
            "Closing Interview to fill the form automatically, or type the "
            "notes on the interview record by hand."
        )
    transcript = (transcript or "").strip()
    if len(transcript) < 200:
        raise AiFillError(
            "The transcript is too short to fill a form from. Check that Zoom "
            "finished producing the audio transcript for this meeting."
        )
    if len(transcript) > MAX_TRANSCRIPT_CHARS:
        transcript = transcript[:MAX_TRANSCRIPT_CHARS]

    schema = SCHEMA_DIPLOMA if form_type == "diploma" else SCHEMA_CERTIFICATE
    known = json.dumps(context or {}, ensure_ascii=False, indent=2)
    form_name = (
        "Diploma Professional Discussion Record Sheet"
        if form_type == "diploma"
        else "AS043d Closing Interview Record Sheet"
    )
    prompt = (
        f"Form: {form_name}\n\n"
        f"Already known from the learner's record (do not contradict it, and "
        f"do not repeat it back unless the transcript confirms it):\n{known}\n\n"
        f"Return exactly this JSON shape:\n{schema}\n\n"
        f"Transcript:\n<transcript>\n{transcript}\n</transcript>"
    )

    try:
        response = requests.post(
            API_URL,
            headers={
                "x-api-key": api_key,
                "anthropic-version": API_VERSION,
                "content-type": "application/json",
            },
            json={
                "model": model or DEFAULT_MODEL,
                "max_tokens": 4096,
                "system": SYSTEM_PROMPT,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=timeout,
        )
    except requests.RequestException as exc:
        raise AiFillError("Could not reach the Anthropic API: %s" % exc) from exc

    if response.status_code == 401:
        raise AiFillError("The Anthropic API key was rejected.")
    if response.status_code != 200:
        raise AiFillError(
            "The Anthropic API returned HTTP %s: %s"
            % (response.status_code, response.text[:300])
        )

    payload = response.json()
    text = "".join(
        block.get("text", "")
        for block in payload.get("content", [])
        if block.get("type") == "text"
    )
    return _extract_json(text)
