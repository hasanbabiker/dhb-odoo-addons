import base64
import logging
from datetime import datetime

from odoo import http, fields, _
from odoo.http import request

_logger = logging.getLogger(__name__)

MAX_UPLOAD_BYTES = 8 * 1024 * 1024
ALLOWED_UPLOAD = {"image/jpeg", "image/png", "image/webp", "application/pdf"}


class DhbRegistrationController(http.Controller):
    """The learner-facing form.

    Everything here runs as sudo because the visitor is not a portal user, so
    each handler starts by resolving a valid invitation token. No token, no
    write — that check is the whole access control model.
    """

    # ------------------------------------------------------------------
    def _get_invite(self, token):
        if not token:
            return False
        invite = request.env["dhb.registration.invite"].sudo().search(
            [("token", "=", token)], limit=1
        )
        if not invite or not invite._is_usable():
            return False
        return invite

    def _render_error(self, message):
        return request.render("dhb_registration.registration_closed", {
            "message": message,
        })

    # ------------------------------------------------------------------
    @http.route(["/learner/register/<string:token>"], type="http", auth="public",
                website=True, sitemap=False)
    def registration_form(self, token, **kwargs):
        invite = self._get_invite(token)
        if not invite:
            return self._render_error(_(
                "This registration link is not valid any more. It may have "
                "expired, already been used, or been cancelled. Please contact "
                "DHB Training and Consulting for a new one."
            ))

        if invite.state in ("draft", "sent"):
            invite.sudo().write({
                "state": "opened",
                "opened_on": fields.Datetime.now(),
            })

        env = request.env
        policies = env["dhb.policy"].sudo().search([
            ("required_for_registration", "=", True),
        ])
        partner = invite.partner_id

        return request.render("dhb_registration.registration_form", {
            "invite": invite,
            "event": invite.event_id,
            "partner": partner,
            "policies": policies,
            "countries": env["res.country"].sudo().search([]),
            "titles": env["res.partner"]._fields["learner_title"].selection,
            "genders": env["res.partner"]._fields["gender"].selection,
            "id_types": env["res.partner"]._fields["id_document_type"].selection,
            "nationalities": env["res.partner"]._fields["nebosh_nationality"].selection,
            "phone_countries": env["res.country"].sudo().search(
                [("phone_code", "!=", 0)], order="name"),
            "error": {},
            "values": self._prefill(invite),
        })

    def _prefill(self, invite):
        partner = invite.partner_id
        if not partner:
            return {"email": invite.email or "", "name": invite.learner_name or ""}
        return {
            "email": partner.email or invite.email or "",
            "learner_title": partner.learner_title or "",
            "legal_forenames": partner.legal_forenames or "",
            "legal_surname": partner.legal_surname or "",
            "date_of_birth": partner.date_of_birth and partner.date_of_birth.isoformat() or "",
            "gender": partner.gender or "",
            "nebosh_nationality": partner.nebosh_nationality or "",
            "nebosh_learner_number": partner.nebosh_learner_number or "",
            "street": partner.street or "",
            "street2": partner.street2 or "",
            "city": partner.city or "",
            "zip": partner.zip or "",
            "country_id": partner.country_id.id or "",
            "mobile_phone": partner.mobile_phone or partner.phone or "",
            "work_phone": partner.work_phone or "",
        }

    # ------------------------------------------------------------------
    @http.route(["/learner/register/<string:token>/submit"], type="http",
                auth="public", website=True, methods=["POST"], csrf=True,
                sitemap=False)
    def registration_submit(self, token, **post):
        invite = self._get_invite(token)
        if not invite:
            return self._render_error(_("This registration link is no longer valid."))

        env = request.env
        policies = env["dhb.policy"].sudo().search([
            ("required_for_registration", "=", True),
        ])

        errors = self._validate(post, policies)

        id_file = request.httprequest.files.get("id_document_file")
        photo_file = request.httprequest.files.get("photo_file")
        for field_name, upload, label in (
            ("id_document_file", id_file, _("identity document")),
            ("photo_file", photo_file, _("photograph")),
        ):
            problem = self._check_upload(upload, label)
            if problem:
                errors[field_name] = problem

        if errors:
            return request.render("dhb_registration.registration_form", {
                "invite": invite,
                "event": invite.event_id,
                "partner": invite.partner_id,
                "policies": policies,
                "countries": env["res.country"].sudo().search([]),
                "titles": env["res.partner"]._fields["learner_title"].selection,
                "genders": env["res.partner"]._fields["gender"].selection,
                "id_types": env["res.partner"]._fields["id_document_type"].selection,
            "nationalities": env["res.partner"]._fields["nebosh_nationality"].selection,
            "phone_countries": env["res.country"].sudo().search(
                [("phone_code", "!=", 0)], order="name"),
                "error": errors,
                "values": post,
            })

        partner = self._save_partner(invite, post, id_file, photo_file)
        self._record_acceptances(partner, policies, invite)
        registration = self._ensure_registration(invite, partner)

        invite.sudo().write({
            "state": "submitted",
            "submitted_on": fields.Datetime.now(),
            "submitted_ip": request.httprequest.remote_addr,
            "partner_id": partner.id,
            "registration_id": registration.id if registration else False,
        })

        return request.render("dhb_registration.registration_thanks", {
            "partner": partner,
            "event": invite.event_id,
        })

    # ------------------------------------------------------------------
    def _validate(self, post, policies):
        errors = {}
        required = {
            "legal_forenames": _("Please give the first name as it appears on the ID document."),
            "legal_surname": _("Please give the family name as it appears on the ID document."),
            "date_of_birth": _("Please give the date of birth."),
            "email": _("Please give a personal email address."),
            "mobile_phone": _("Please give a mobile number."),
            "nebosh_nationality": _("Please give the nationality."),
            "country_id": _("Please choose the country."),
            "id_document_type": _("Please say which document you are providing."),
        }
        for field_name, message in required.items():
            if not (post.get(field_name) or "").strip():
                errors[field_name] = message

        dob = (post.get("date_of_birth") or "").strip()
        if dob:
            try:
                parsed = datetime.strptime(dob, "%Y-%m-%d").date()
                today = fields.Date.today()
                age = today.year - parsed.year - (
                    (today.month, today.day) < (parsed.month, parsed.day)
                )
                if age < 14 or age > 100:
                    errors["date_of_birth"] = _(
                        "That date gives an age of %s. Please check the year."
                    ) % age
            except ValueError:
                errors["date_of_birth"] = _("Please use the date picker.")

        if post.get("id_document_type") == "other" and not (post.get("id_document_other") or "").strip():
            errors["id_document_other"] = _("Please say what the document is.")

        for policy in policies:
            if not post.get("policy_%s" % policy.id):
                errors["policies"] = _(
                    "Please read and accept each policy before submitting."
                )
                break

        return errors

    def _check_upload(self, upload, label):
        if not upload or not upload.filename:
            return _("Please attach your %s.") % label
        content = upload.read()
        upload.seek(0)
        if len(content) > MAX_UPLOAD_BYTES:
            return _("The %(label)s is larger than 8 MB. Please send a smaller file.",
                     label=label)
        if upload.mimetype not in ALLOWED_UPLOAD:
            return _("The %(label)s must be a JPG, PNG or PDF.", label=label)
        return False

    # ------------------------------------------------------------------
    def _save_partner(self, invite, post, id_file, photo_file):
        Partner = request.env["res.partner"].sudo()
        values = {
            "is_learner": True,
            "learner_title": post.get("learner_title") or False,
            "legal_forenames": (post.get("legal_forenames") or "").strip(),
            "legal_surname": (post.get("legal_surname") or "").strip(),
            "date_of_birth": post.get("date_of_birth") or False,
            "gender": post.get("gender") or False,
            "nebosh_nationality": (post.get("nebosh_nationality") or "").strip(),
            "nebosh_learner_number": (post.get("nebosh_learner_number") or "").strip() or False,
            "nebosh_number_unknown": bool(post.get("nebosh_number_unknown")),
            "email": (post.get("email") or "").strip().lower(),
            "street": post.get("street") or False,
            "street2": post.get("street2") or False,
            "city": post.get("city") or False,
            "zip": post.get("zip") or False,
            "country_id": int(post["country_id"]) if post.get("country_id") else False,
            "phone_country_id": int(post["phone_country_id"]) if post.get("phone_country_id") else False,
            "mobile_phone": post.get("mobile_phone") or False,
            "phone": post.get("mobile_phone") or False,
            "work_phone": post.get("work_phone") or False,
            "mail_address_type": post.get("mail_address_type") or "H",
            "id_document_type": post.get("id_document_type") or False,
            "id_document_other": post.get("id_document_other") or False,
            "nebosh_consent": bool(post.get("nebosh_consent")),
            "nebosh_marketing_opt_out": bool(post.get("nebosh_marketing_opt_out")),
            # The learner typed this themselves, so the work-email rule is
            # relaxed: refusing their own address mid-form helps nobody.
            "work_email_accepted": True,
        }

        if id_file and id_file.filename:
            values["id_document_file"] = base64.b64encode(id_file.read())
            values["id_document_filename"] = id_file.filename
        if photo_file and photo_file.filename:
            values["image_1920"] = base64.b64encode(photo_file.read())

        partner = invite.partner_id
        if not partner:
            existing = Partner.search([
                ("email", "=ilike", values["email"]),
                ("is_learner", "=", True),
            ], limit=1)
            partner = existing or False

        if partner:
            partner.write(values)
        else:
            values["name"] = " ".join(filter(None, [
                values["legal_forenames"], values["legal_surname"]
            ])) or invite.email
            partner = Partner.create(values)

        partner.message_post(body=_(
            "Registration form completed by the learner from %s."
        ) % (request.httprequest.remote_addr or "?"))
        return partner

    def _record_acceptances(self, partner, policies, invite):
        Acceptance = request.env["dhb.policy.acceptance"].sudo()
        now = fields.Datetime.now()
        ip = request.httprequest.remote_addr
        agent = (request.httprequest.user_agent.string or "")[:255]
        for policy in policies:
            Acceptance.create({
                "partner_id": partner.id,
                "policy_id": policy.id,
                "policy_code": policy.code,
                "policy_version": policy.version,
                "policy_text": policy.body,
                "accepted_on": now,
                "ip_address": ip,
                "user_agent": agent,
                "event_id": invite.event_id.id,
            })

    def _ensure_registration(self, invite, partner):
        Registration = request.env["event.registration"].sudo()
        existing = Registration.search([
            ("event_id", "=", invite.event_id.id),
            ("partner_id", "=", partner.id),
        ], limit=1)
        if existing:
            return existing
        return Registration.create({
            "event_id": invite.event_id.id,
            "partner_id": partner.id,
            "email": partner.email,
            "name": partner.legal_name or partner.name,
        })
