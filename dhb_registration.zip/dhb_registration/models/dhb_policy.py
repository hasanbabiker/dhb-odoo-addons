from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbPolicy(models.Model):
    """A centre policy the learner must accept.

    Policies are versioned because the question an auditor asks is not
    "did they agree" but "what did they agree to". DHB's own policies show
    why: the data protection policy is dated 2023 and says it is reviewed
    annually, and the meal policy exists in two versions with different dates.
    """

    _name = "dhb.policy"
    _description = "Centre policy"
    _order = "sequence, name"

    name = fields.Char(string="Policy", required=True)
    sequence = fields.Integer(default=10)
    code = fields.Char(
        string="Code", required=True,
        help="Short stable key, e.g. data_protection. Used to match "
             "acceptances across versions.",
    )
    active = fields.Boolean(default=True)
    version = fields.Char(string="Version", required=True, default="1.0")
    effective_date = fields.Date(string="Effective from", required=True,
                                 default=fields.Date.today)
    review_due = fields.Date(string="Next review due")
    body = fields.Html(
        string="Policy text", required=True, sanitize=False,
        help="The full text shown to the learner. A copy is stored with each "
             "acceptance, so later edits never rewrite what someone agreed to.",
    )
    required_for_registration = fields.Boolean(
        string="Required at registration", default=True
    )
    acceptance_count = fields.Integer(compute="_compute_acceptance_count")

    _unique_code_version = models.Constraint(
        "unique(code, version)",
        "That policy code already exists at that version.",
    )

    def _compute_acceptance_count(self):
        Acceptance = self.env["dhb.policy.acceptance"]
        for policy in self:
            policy.acceptance_count = Acceptance.search_count([("policy_id", "=", policy.id)])

    @api.constrains("review_due", "effective_date")
    def _check_review_due(self):
        for policy in self:
            if policy.review_due and policy.review_due < policy.effective_date:
                raise UserError(_("The review date is before the effective date."))

    def action_open_acceptances(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Acceptances"),
            "res_model": "dhb.policy.acceptance",
            "view_mode": "list,form",
            "domain": [("policy_id", "=", self.id)],
        }


class DhbPolicyAcceptance(models.Model):
    """One learner accepting one version of one policy.

    Immutable by design: the whole point is that it records a moment.
    """

    _name = "dhb.policy.acceptance"
    _description = "Policy acceptance"
    _order = "accepted_on desc"
    _rec_name = "display_name"

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True, ondelete="cascade", index=True
    )
    policy_id = fields.Many2one(
        "dhb.policy", string="Policy", required=True, ondelete="restrict"
    )
    policy_code = fields.Char(string="Policy code", required=True)
    policy_version = fields.Char(string="Version accepted", required=True)
    policy_text = fields.Html(
        string="Text as accepted", required=True, sanitize=False, readonly=True,
        help="A snapshot. This is what the learner actually saw.",
    )
    accepted_on = fields.Datetime(string="Accepted at", required=True, readonly=True)
    ip_address = fields.Char(string="IP address", readonly=True)
    user_agent = fields.Char(string="Browser", readonly=True)
    event_id = fields.Many2one("event.event", string="Cohort", readonly=True)
    display_name = fields.Char(compute="_compute_display_name", store=True)

    @api.depends("partner_id.display_name", "policy_id.name", "policy_version")
    def _compute_display_name(self):
        for record in self:
            record.display_name = "%s — %s v%s" % (
                record.partner_id.display_name or "?",
                record.policy_id.name or "?",
                record.policy_version or "?",
            )

    def write(self, values):
        raise UserError(_(
            "A policy acceptance records what happened at a moment in time "
            "and cannot be edited. If it was recorded in error, delete it and "
            "note why in the learner's chatter."
        ))
