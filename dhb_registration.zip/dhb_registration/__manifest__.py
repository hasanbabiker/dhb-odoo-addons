{
    "name": "DHB Learner Registration Form",
    "version": "19.0.1.0.0",
    "summary": "Learners complete their own NEBOSH registration, upload ID and accept policies",
    "description": """
DHB Learner Registration Form
=============================

Replaces the paper round-trip: learner fills in their own details, uploads
their identity document and photograph, and accepts the centre's policies.

Two things here exist for the auditor rather than for convenience:

* Policy acceptance stores the policy text as it stood at that moment, with
  the timestamp and IP address. A boolean "agreed" cannot answer the question
  NEBOSH actually asks two years later, which is *what* the learner agreed to.
* The form is reached through a single-use invitation link tied to a cohort,
  so a public URL cannot fill the database with junk contacts, and every
  submission is traceable to an invitation the centre issued.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["dhb_learner", "website", "event", "mail"],
    "data": [
        "security/ir.model.access.csv",
        "data/policy_data.xml",
        "views/policy_views.xml",
        "views/invite_views.xml",
        "views/registration_templates.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
}
