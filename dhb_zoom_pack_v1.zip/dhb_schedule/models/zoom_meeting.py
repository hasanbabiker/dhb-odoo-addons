import logging

import requests

from odoo import models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

ZOOM_API_BASE = "https://api.zoom.us/v2"
TIMEOUT = 30


class ZoomApi(models.AbstractModel):
    """Teach the existing Zoom client to write, not only to read.

    Everything the attendance module does is a GET - dashboards, reports,
    participants - so its `_request` is a GET and nothing else. Creating a
    meeting is a POST, and this adds one rather than reaching around the
    client and building a second set of credentials handling beside it. The
    token, its cache and its refresh-on-401 all stay where they were.
    """

    _inherit = "dhb.zoom.api"

    def _post(self, path, payload, _retried=False):
        token = self._get_token()
        try:
            response = requests.post(
                "%s%s" % (ZOOM_API_BASE, path),
                headers={
                    "Authorization": "Bearer %s" % token,
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=TIMEOUT,
            )
        except requests.RequestException as exc:
            raise UserError(_("Could not reach Zoom: %s") % exc) from exc

        if response.status_code == 401 and not _retried:
            self._get_token(force_refresh=True)
            return self._post(path, payload, _retried=True)

        if response.status_code in (200, 201):
            return response.json()

        # The one failure worth naming precisely. The credentials already in
        # this database were issued for the dashboard and report endpoints;
        # writing needs a scope that was never asked for, and Zoom's own
        # message ("Invalid access token, does not contain scopes") does not
        # say which one or where to add it.
        body = response.text[:500]
        if response.status_code in (400, 401, 403) and "scope" in body.lower():
            raise UserError(_(
                "Zoom refused to create the meeting because the app is not "
                "allowed to.\n\n"
                "Add the scope  meeting:write:admin  to the same "
                "Server-to-Server OAuth app whose keys are in Settings, then "
                "press Activate on the app again - Zoom does not apply a new "
                "scope until the app is re-activated.\n\n"
                "Zoom said: %s") % body)

        raise UserError(_(
            "Zoom returned HTTP %(code)s:\n%(body)s",
            code=response.status_code, body=body,
        ))

    # ------------------------------------------------------------------
    def create_meeting(self, topic, timezone, agenda=None):
        """Create a recurring meeting with no fixed time.

        Type 3 on purpose. The alternative is a fixed-time recurrence, and
        that needs to know which days of the week the course runs - which
        nobody has told us. Inventing a pattern would put forty occurrences
        including weekends into the tutor's calendar, and the one thing that
        actually matters is identical either way: the joining link is the
        same for every session of the course.

        Returns the raw Zoom payload, which carries the numeric passcode -
        the piece a lookup cannot give you, because the ?pwd= value in a
        join link is an encrypted token and not the code learners type.
        """
        payload = {
            "topic": topic[:200],
            "type": 3,
            "timezone": timezone or "Asia/Dubai",
            "agenda": (agenda or "")[:2000],
            "settings": {
                "waiting_room": True,
                "join_before_host": False,
                "mute_upon_entry": True,
                # NEBOSH may ask for evidence that a session was delivered.
                "auto_recording": "cloud",
                "approval_type": 2,
            },
        }
        return self._post("/users/me/meetings", payload)

    def list_scheduled_meetings(self, user_id="me"):
        """Upcoming meetings on the account, for matching an existing one."""
        return self._request_paged(
            "/users/%s/meetings" % user_id,
            {"type": "scheduled"},
            key="meetings",
        )
