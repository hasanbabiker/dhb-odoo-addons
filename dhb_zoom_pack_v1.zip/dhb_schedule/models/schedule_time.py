"""Turning a local class time into the two columns NEBOSH actually checks.

The UK columns are the reason a schedule gets rejected, or - worse - gets
accepted with a wrong time and a learner joins an hour late. The Gulf never
moves its clocks; the UK moves twice a year, on the last Sunday in March and
the last Sunday in October. A course at 7:00 PM Dubai is 4:00 PM BST in July
and 3:00 PM GMT in December.

So none of it is typed, and none of it is a fixed offset table either. The
conversion goes through pytz, from the batch's own time zone to
Europe/London, which gets both ends right including the two weeks a year
when a northern-hemisphere assumption would be wrong.
"""

import pytz

# What NEBOSH's file calls each zone. The column reads "07:00 PM UAE Time",
# not "07:00 PM Asia/Dubai" - an Olson name in a form sent to an awarding
# body looks like a database leaked into a document.
ZONE_LABELS = {
    "Asia/Dubai": "UAE Time",
    "Asia/Muscat": "Oman Time",
    "Asia/Riyadh": "KSA Time",
    "Asia/Qatar": "Qatar Time",
    "Asia/Kuwait": "Kuwait Time",
    "Asia/Bahrain": "Bahrain Time",
    "Asia/Baghdad": "Iraq Time",
    "Asia/Amman": "Jordan Time",
    "Asia/Aden": "Yemen Time",
    "Africa/Cairo": "Egypt Time",
    "Africa/Khartoum": "Sudan Time",
    "Europe/London": "UK Time",
}

UK = pytz.timezone("Europe/London")


def zone_label(tz_name):
    """A readable name for a time zone, falling back to the city."""
    if not tz_name:
        return ""
    if tz_name in ZONE_LABELS:
        return ZONE_LABELS[tz_name]
    return tz_name.split("/")[-1].replace("_", " ") + " Time"


def float_to_hm(value):
    """Odoo stores a time of day as a float. 19.5 is half past seven."""
    hours = int(value)
    minutes = int(round((value - hours) * 60))
    if minutes == 60:
        hours, minutes = hours + 1, 0
    return hours % 24, minutes


def format_local(value, tz_name):
    """\"07:00 PM UAE Time\" - the column exactly as NEBOSH prints it."""
    hours, minutes = float_to_hm(value)
    suffix = "AM" if hours < 12 else "PM"
    display = hours % 12 or 12
    return "%02d:%02d %s %s" % (display, minutes, suffix, zone_label(tz_name))


def to_uk(value, tz_name, on_date):
    """Convert a local time of day to UK time on a given date.

    Returns (text, label) where label is BST or GMT - which is also what the
    column heading has to say, so it is returned rather than worked out
    twice.
    """
    import datetime

    local_zone = pytz.timezone(tz_name or "Asia/Dubai")
    hours, minutes = float_to_hm(value)
    naive = datetime.datetime.combine(
        on_date, datetime.time(hour=hours, minute=minutes))
    # localize(), not replace(tzinfo=...): the second quietly attaches the
    # zone's *first historical* offset, which for several zones is a number
    # of minutes nobody has used since 1900.
    localised = local_zone.localize(naive)
    in_uk = localised.astimezone(UK)
    label = "BST" if in_uk.dst() else "GMT"
    return "%s %s" % (in_uk.strftime("%I:%M %p"), label), label


def format_meeting_id(value):
    """Group a bare Zoom number the way Zoom itself displays it.

    The API returns 84563869286; the form shows 845 6386 9286. Anything
    already spaced is left as the person typed it.
    """
    text = (value or "").strip()
    if not text or " " in text or not text.isdigit():
        return text
    if len(text) == 11:
        return "%s %s %s" % (text[:3], text[3:7], text[7:])
    if len(text) in (9, 10):
        return "%s %s %s" % (text[:3], text[3:6], text[6:])
    return text
