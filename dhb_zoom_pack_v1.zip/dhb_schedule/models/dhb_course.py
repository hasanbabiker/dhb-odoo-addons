from odoo import models, fields


class DhbCourse(models.Model):
    """The class times a course usually runs at.

    Put on the course so a coordinator opening the November batch of the
    IGC does not have to remember that it runs seven to nine. Copied onto
    the batch, not read through it: a batch that moved to a different hour
    for one month must be able to say so without changing the course.
    """

    _inherit = "dhb.course"

    session_start = fields.Float(
        string="Class starts",
        help="The usual local start time. 19.0 is 7:00 PM. A batch of this "
             "course starts here and can be changed.")
    session_end = fields.Float(string="Class ends")
    platform = fields.Char(
        string="Platform", default="Zoom",
        help="Zoom, Teams, or the venue for a classroom course.")
