from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

# How long before an expiry date a certificate should start shouting. Six
# weeks is the shortest notice that is still useful: re-sitting a first aid
# course or an IOSH refresher takes a month to book.
WARNING_DAYS = 42


class DhbTutorQualification(models.Model):
    """One certificate held by one tutor.

    Stored as rows rather than as a pile of attachments on the tutor, because
    the question an auditor asks is not "do you have the certificates" but
    "is any of them out of date" - and only a date in a field can answer
    that.
    """

    _name = "dhb.tutor.qualification"
    _description = "Tutor qualification"
    _order = "date_expiry asc, id desc"

    tutor_id = fields.Many2one(
        "hr.employee", string="Tutor", required=True, ondelete="cascade",
        index=True)
    name = fields.Char(
        string="Qualification", required=True,
        help="As it reads on the certificate. For example \"NEBOSH "
             "International Diploma\" or \"IOSH Approved Trainer\".")
    kind = fields.Selection(
        [
            ("teaching", "Teaching or assessing qualification"),
            ("subject", "Subject qualification"),
            ("membership", "Professional membership"),
            ("training", "Training or refresher"),
            ("other", "Other"),
        ],
        string="Type", default="subject", required=True)
    awarding_body = fields.Char(
        string="Awarded by",
        help="NEBOSH, IOSH, a university, a ministry.")
    reference = fields.Char(
        string="Certificate number",
        help="The number printed on the certificate, so it can be verified "
             "without pulling the file.")
    date_issued = fields.Date(string="Issued")
    date_expiry = fields.Date(
        string="Expires",
        help="Leave empty for a qualification that does not expire - a "
             "diploma does not, a first aid certificate does.")

    document = fields.Binary(string="Certificate", attachment=True)
    document_filename = fields.Char()

    state = fields.Selection(
        [
            ("valid", "Valid"),
            ("expiring", "Expiring soon"),
            ("expired", "Expired"),
            ("permanent", "Does not expire"),
        ],
        compute="_compute_state", store=True, index=True)
    days_to_expiry = fields.Integer(compute="_compute_state", store=True)
    note = fields.Text()

    @api.depends("date_expiry")
    def _compute_state(self):
        """Work the state out from today, which is why a cron re-runs this.

        A stored compute that depends on the calendar and on nothing else
        never becomes stale by being written to - it becomes stale by the
        sun coming up. The daily cron in this module is the only thing that
        can correct that.
        """
        today = fields.Date.context_today(self)
        for record in self:
            if not record.date_expiry:
                record.state = "permanent"
                record.days_to_expiry = 0
                continue
            days = (record.date_expiry - today).days
            record.days_to_expiry = days
            if days < 0:
                record.state = "expired"
            elif days <= WARNING_DAYS:
                record.state = "expiring"
            else:
                record.state = "valid"

    @api.constrains("date_issued", "date_expiry")
    def _check_dates(self):
        for record in self:
            if record.date_issued and record.date_expiry \
                    and record.date_expiry < record.date_issued:
                raise ValidationError(_(
                    "%s expires before it was issued.") % record.name)

    @api.model
    def _cron_refresh_state(self):
        """Re-read the calendar for everything that has an expiry date."""
        records = self.search([("date_expiry", "!=", False)])
        records._compute_state()
        # A certificate that has just tipped over deserves more than a colour
        # on a list nobody has open. The tutor's followers are told once, on
        # the day it happens.
        for qualification in records.filtered(
                lambda q: q.state == "expired" and q.days_to_expiry == -1):
            qualification.tutor_id.message_post(body=_(
                "%(name)s expired yesterday. %(tutor)s should not be "
                "timetabled on anything that depends on it until it is "
                "renewed.",
                name=qualification.name,
                tutor=qualification.tutor_id.display_name,
            ))
