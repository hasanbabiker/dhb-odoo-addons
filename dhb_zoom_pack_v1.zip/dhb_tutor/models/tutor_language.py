from odoo import models, fields


class DhbTutorLanguage(models.Model):
    """A language a tutor can teach in.

    A small table rather than a selection list, for one reason: a tutor
    teaches in more than one language and Odoo has no multi-select field.
    The `code` deliberately carries the same keys the batch and the course
    already use for their language, so "who can teach this batch" is a
    comparison and not a translation table.
    """

    _name = "dhb.tutor.language"
    _description = "Teaching language"
    _order = "sequence, name"

    name = fields.Char(required=True, translate=True)
    code = fields.Char(
        required=True,
        help="Must match the language code the courses and batches use - "
             "en, ar, ru and so on - or the system cannot tell whether a "
             "tutor may teach a given batch.",
    )
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    _unique_code = models.Constraint(
        "unique(code)", "Another language already uses that code.")
