from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class DhbTutorCpd(models.Model):
    """One piece of continuing professional development.

    Kept as short rows on purpose. A CPD log that asks for a reflective essay
    per entry is a CPD log nobody fills in, and an empty log is worse at a
    visit than a thin one.
    """

    _name = "dhb.tutor.cpd"
    _description = "Tutor CPD record"
    _order = "date desc, id desc"

    tutor_id = fields.Many2one(
        "hr.employee", string="Tutor", required=True, ondelete="cascade",
        index=True)
    date = fields.Date(
        required=True, default=fields.Date.context_today, index=True)
    name = fields.Char(
        string="Activity", required=True,
        help="What was done. \"NEBOSH standardisation webinar\", \"Read "
             "HSG65\", \"Observed IG2 marking\".")
    kind = fields.Selection(
        [
            ("course", "Course or webinar"),
            ("conference", "Conference or seminar"),
            ("reading", "Reading or research"),
            ("standardisation", "Standardisation or moderation"),
            ("shadowing", "Shadowing or observing"),
            ("other", "Other"),
        ],
        string="Type", default="course", required=True)
    hours = fields.Float(
        string="Hours", default=1.0, required=True,
        help="Counted towards the tutor's yearly total.")
    year = fields.Integer(
        compute="_compute_year", store=True, index=True,
        help="Taken from the date, so a year's total is one grouping and "
             "not a search by range.")
    evidence = fields.Binary(attachment=True)
    evidence_filename = fields.Char()
    note = fields.Text()

    @api.depends("date")
    def _compute_year(self):
        for record in self:
            record.year = record.date.year if record.date else 0

    @api.constrains("hours")
    def _check_hours(self):
        for record in self:
            if record.hours <= 0:
                raise ValidationError(_(
                    "A CPD entry with no hours on it counts for nothing. "
                    "Put the time in, or delete the entry."))
