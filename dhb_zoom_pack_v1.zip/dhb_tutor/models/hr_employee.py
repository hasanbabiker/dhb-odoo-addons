from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _

from .tutor_observation import OBSERVATION_INTERVAL_MONTHS


class HrEmployee(models.Model):
    """A member of staff, plus what the centre knows about them as a tutor.

    A note on `groups` - Odoo's own model carries this warning::

        NB: Any field only available on the model hr.employee (i.e. not on
        the hr.employee.public model) should have `groups="hr.group_hr_user"`
        on its definition ...

    The fields below deliberately do not follow it, and the reason is the
    whole point of putting tutors here. A batch coordinator has to see who is
    teaching, in which language, and whether their certificate has run out.
    Guarding these behind the HR officer group would mean handing every
    coordinator the payroll in order to read a timetable.

    Nothing is given away by that. Everything genuinely private on an
    employee - the salary, the visa, the identity card, the private address -
    carries the guard on its own definition in Odoo's source, and those
    guards are enforced on read, export and API, not merely in the form. The
    security file in this module opens read access to the employee record,
    and only read.
    """

    _inherit = "hr.employee"

    is_tutor = fields.Boolean(
        string="Teaches for us", index=True, tracking=True,
        help="Tick this and the person appears in Tutors, and can be put on "
             "a batch.")

    # ------------------------------------------------------------------
    # What they are allowed to do. Four separate roles rather than one
    # selection, because one person is routinely three of them: a tutor who
    # also marks, and sits in on somebody else's marking as the internal
    # verifier.
    role_tutor = fields.Boolean(string="Tutor", default=True)
    role_assessor = fields.Boolean(string="Assessor")
    role_iv = fields.Boolean(
        string="Internal verifier",
        help="Samples and signs off other people's assessment decisions. A "
             "person cannot verify their own marking.")
    role_invigilator = fields.Boolean(string="Invigilator")

    course_ids = fields.Many2many(
        "dhb.course", "dhb_tutor_course_rel", "employee_id", "course_id",
        string="Approved to deliver",
        help="The courses this person may be timetabled on. A batch whose "
             "tutor is not approved for its course says so on the batch.")
    tutor_language_ids = fields.Many2many(
        "dhb.tutor.language", "dhb_tutor_language_rel", "employee_id",
        "language_id", string="Teaches in")

    qualification_ids = fields.One2many(
        "dhb.tutor.qualification", "tutor_id", string="Qualifications")
    cpd_ids = fields.One2many("dhb.tutor.cpd", "tutor_id", string="CPD")
    observation_ids = fields.One2many(
        "dhb.tutor.observation", "tutor_id", string="Observations")

    cpd_target_hours = fields.Float(
        string="CPD target (hours a year)", default=10.0,
        help="What this tutor is expected to log in a calendar year. Ten "
             "hours is a defensible minimum; set it higher for a lead tutor.")

    tutor_note = fields.Text(
        string="Tutor notes",
        help="Standardisation points, subjects to avoid, anything the next "
             "coordinator needs to know.")

    # ------------------------------------------------------------------
    # The rollups below are deliberately NOT stored. Every one of them
    # depends on today's date as much as on the data, and a stored field
    # that depends on the calendar is a field that is wrong every morning
    # until something writes to it. Computed on read, they cannot go stale.
    qualification_expired_count = fields.Integer(
        compute="_compute_tutor_alerts")
    qualification_expiring_count = fields.Integer(
        compute="_compute_tutor_alerts")
    next_expiry_date = fields.Date(compute="_compute_tutor_alerts")
    cpd_hours_year = fields.Float(
        string="CPD this year", compute="_compute_tutor_alerts")
    cpd_short = fields.Boolean(compute="_compute_tutor_alerts")
    last_observation_date = fields.Date(compute="_compute_tutor_alerts")
    observation_due = fields.Boolean(compute="_compute_tutor_alerts")
    tutor_alert = fields.Char(
        string="Needs attention", compute="_compute_tutor_alerts")
    tutor_ready = fields.Boolean(
        string="Nothing outstanding", compute="_compute_tutor_alerts")

    batch_count = fields.Integer(compute="_compute_batch_count")

    def _tutor_alert_items(self):
        """What is outstanding on this tutor, as counted obstacles.

        Same shape as the batch blockers - a list of named things with
        numbers - so the two screens read the same way and neither of them
        shows a readiness percentage nobody can act on.
        """
        self.ensure_one()
        items = []
        if self.qualification_expired_count:
            items.append({
                "label": _("expired certificates"),
                "count": self.qualification_expired_count,
            })
        if self.qualification_expiring_count:
            items.append({
                "label": _("certificates expiring soon"),
                "count": self.qualification_expiring_count,
            })
        if self.cpd_short:
            items.append({
                "label": _("CPD hours short of the target"),
                "count": int(round(
                    max(self.cpd_target_hours - self.cpd_hours_year, 0))),
            })
        if self.observation_due:
            items.append({
                "label": _("observation overdue"), "count": 1})
        if self.is_tutor and not self.course_ids:
            items.append({
                "label": _("no course approved yet"), "count": 1})
        return items

    @api.depends(
        "qualification_ids.state", "qualification_ids.date_expiry",
        "cpd_ids.hours", "cpd_ids.year", "cpd_target_hours",
        "observation_ids.date", "course_ids", "is_tutor",
    )
    def _compute_tutor_alerts(self):
        today = fields.Date.context_today(self)
        this_year = today.year
        due_before = today - relativedelta(
            months=OBSERVATION_INTERVAL_MONTHS)
        for employee in self:
            certificates = employee.qualification_ids
            employee.qualification_expired_count = len(
                certificates.filtered(lambda q: q.state == "expired"))
            employee.qualification_expiring_count = len(
                certificates.filtered(lambda q: q.state == "expiring"))
            upcoming = certificates.filtered("date_expiry").sorted(
                "date_expiry")
            employee.next_expiry_date = \
                upcoming[0].date_expiry if upcoming else False

            employee.cpd_hours_year = sum(
                employee.cpd_ids.filtered(
                    lambda c: c.year == this_year).mapped("hours"))
            employee.cpd_short = bool(
                employee.is_tutor and employee.cpd_target_hours
                and employee.cpd_hours_year < employee.cpd_target_hours)

            observations = employee.observation_ids.filtered("date").sorted(
                "date", reverse=True)
            employee.last_observation_date = \
                observations[0].date if observations else False
            employee.observation_due = bool(
                employee.is_tutor
                and (not employee.last_observation_date
                     or employee.last_observation_date < due_before))

            items = employee._tutor_alert_items()
            employee.tutor_alert = " · ".join(
                "%s %s" % (item["count"], item["label"]) for item in items
            ) or False
            employee.tutor_ready = not items

    @api.depends("is_tutor")
    def _compute_batch_count(self):
        """Counted with a search: a batch points at the tutor, not the other
        way round, and a one2many here would need a second inverse field for
        the same relation."""
        batches = self.env["dhb.batch"]
        for employee in self:
            employee.batch_count = batches.search_count([
                ("tutor_ids", "in", employee.id)]) if employee.id else 0

    # ------------------------------------------------------------------
    def action_open_batches(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Batches taught by %s") % self.display_name,
            "res_model": "dhb.batch",
            "view_mode": "list,kanban,form",
            "domain": [("tutor_ids", "in", self.id)],
        }

    def action_open_qualifications(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Qualifications of %s") % self.display_name,
            "res_model": "dhb.tutor.qualification",
            "view_mode": "list,form",
            "domain": [("tutor_id", "=", self.id)],
            "context": {"default_tutor_id": self.id},
        }

    def action_open_observations(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Observations of %s") % self.display_name,
            "res_model": "dhb.tutor.observation",
            "view_mode": "list,form",
            "domain": [("tutor_id", "=", self.id)],
            "context": {"default_tutor_id": self.id},
        }

    def action_open_cpd(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("CPD of %s") % self.display_name,
            "res_model": "dhb.tutor.cpd",
            "view_mode": "list,form",
            "domain": [("tutor_id", "=", self.id)],
            "context": {"default_tutor_id": self.id},
        }
