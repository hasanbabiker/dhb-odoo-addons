from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _

# NEBOSH expects a tutor to have been watched teaching within the last year.
# Twelve months is the interval the record is judged against.
OBSERVATION_INTERVAL_MONTHS = 12


class DhbTutorObservation(models.Model):
    """A record of somebody watching a tutor teach.

    This is the part of a centre's quality file that is hardest to produce
    after the fact and easiest to produce at the time. One row, written on
    the day, with an outcome and an action - not a form so long that the
    observer writes it "later" and never does.
    """

    _name = "dhb.tutor.observation"
    _description = "Tutor observation"
    _order = "date desc, id desc"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char(
        compute="_compute_name", store=True, string="Observation")
    tutor_id = fields.Many2one(
        "hr.employee", string="Tutor", required=True, ondelete="cascade",
        index=True, tracking=True)
    date = fields.Date(
        required=True, default=fields.Date.context_today, index=True,
        tracking=True)
    observer_id = fields.Many2one(
        "res.users", string="Observed by", required=True, tracking=True,
        default=lambda self: self.env.user)
    batch_id = fields.Many2one(
        "dhb.batch", string="Batch",
        help="Which session was watched. Leave empty for an observation "
             "outside a batch.")
    course_id = fields.Many2one(
        "dhb.course", string="Course", compute="_compute_course_id",
        store=True, readonly=False)

    mode = fields.Selection(
        [
            ("live", "In the room"),
            ("virtual", "Online session"),
            ("recording", "Recording"),
        ],
        string="How", default="virtual", required=True)

    outcome = fields.Selection(
        [
            ("good", "Good practice"),
            ("satisfactory", "Satisfactory"),
            ("development", "Development needed"),
            ("unsatisfactory", "Unsatisfactory"),
        ],
        required=True, default="satisfactory", tracking=True, index=True)

    strengths = fields.Text(
        help="What was done well, in enough detail to be repeated.")
    development = fields.Text(
        string="To develop",
        help="What should change, written as something the tutor can do.")
    actions = fields.Text(string="Agreed actions")
    follow_up_date = fields.Date(
        string="Follow up by",
        help="Set this when an action was agreed. It is what turns an "
             "observation into an improvement.")
    follow_up_done = fields.Boolean(string="Followed up")

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("shared", "Shared with the tutor"),
            ("closed", "Closed"),
        ],
        default="draft", required=True, tracking=True)

    @api.depends("tutor_id", "date")
    def _compute_name(self):
        for record in self:
            if record.tutor_id and record.date:
                record.name = "%s - %s" % (
                    record.tutor_id.display_name, record.date)
            else:
                record.name = _("Observation")

    @api.depends("batch_id")
    def _compute_course_id(self):
        for record in self:
            if record.batch_id:
                record.course_id = record.batch_id.course_id

    def action_share(self):
        """Send it to the tutor rather than filing it where only we look."""
        for record in self:
            record.state = "shared"
            if record.tutor_id.work_email:
                record.message_post(
                    body=_("Observation of %s on %s shared with the tutor.",
                           record.tutor_id.display_name, record.date),
                    partner_ids=record.tutor_id.work_contact_id.ids,
                )

    def action_close(self):
        self.write({"state": "closed", "follow_up_done": True})

    def action_draft(self):
        self.write({"state": "draft"})

    @api.model
    def _cron_follow_up(self):
        """Nudge the observer when an agreed action has gone quiet."""
        today = fields.Date.context_today(self)
        overdue = self.search([
            ("follow_up_date", "<=", today),
            ("follow_up_done", "=", False),
            ("state", "!=", "closed"),
        ])
        for record in overdue:
            record.activity_schedule(
                "mail.mail_activity_data_todo",
                user_id=record.observer_id.id,
                summary=_("Follow up on the observation of %s")
                % record.tutor_id.display_name,
            )
            # Scheduling it twice a day for a month helps nobody.
            record.follow_up_date = today + relativedelta(months=1)
