from odoo import models, fields, api, _


class DhbBatch(models.Model):
    """Who is teaching this batch, and whether they should be.

    The check is deliberately a warning on the batch and not a refusal to
    save. A centre does put an unapproved tutor on a batch sometimes - cover
    for illness, a co-delivery, a new tutor being brought on. What must never
    happen is that nobody notices. So the batch says so, on the batch, where
    the coordinator is already looking.
    """

    _inherit = "dhb.batch"

    # `tutor_ids` is NOT declared here. The attendance module has carried it
    # on this model since before batches were a model of their own:
    #
    #     # dhb_zoom_attendance/models/event_event.py
    #     tutor_ids = fields.Many2many("hr.employee", string="Tutors", ...)
    #
    # with no relation table named, which means Odoo generated one for it -
    # dhb_batch_hr_employee_rel - and every tutor recorded on a batch is
    # sitting in it. Declaring the field again here with an explicit
    # relation would win the merge, move the field to a new and empty table,
    # and strand that data without an error. It would also break
    # tutor_ratio, the NEBOSH 20-learners-per-tutor warning, which reads it.
    #
    # So this module depends on that one, uses the field that exists, and
    # adds only what is missing: which of them leads.
    tutor_id = fields.Many2one(
        "hr.employee", string="Lead tutor", tracking=True, index=True,
        domain="[('is_tutor', '=', True)]",
        help="The tutor who owns this batch. Co-tutors go in Tutors.")

    tutor_unapproved_ids = fields.Many2many(
        "hr.employee", "dhb_batch_tutor_unapproved_rel", "batch_id",
        "employee_id", compute="_compute_tutor_checks")
    tutor_expired_count = fields.Integer(compute="_compute_tutor_checks")

    @api.onchange("tutor_id")
    def _onchange_tutor_id(self):
        """Put the lead into the teaching team if they are not in it.

        Done as an onchange rather than a compute for the reason above: a
        compute on tutor_ids would mean re-declaring the field, and the
        field is not this module's to re-declare. This only ever adds, and
        never removes anybody a coordinator put there.
        """
        if self.tutor_id and self.tutor_id not in self.tutor_ids:
            self.tutor_ids = self.tutor_ids | self.tutor_id

    @api.model_create_multi
    def create(self, vals_list):
        batches = super().create(vals_list)
        batches._add_lead_to_team()
        return batches

    def write(self, vals):
        result = super().write(vals)
        if "tutor_id" in vals:
            self._add_lead_to_team()
        return result

    def _add_lead_to_team(self):
        """The same rule as the onchange, for records created in code.

        A batch made by the course wizard or by an import never goes through
        an onchange, and a lead tutor who is not in the teaching team would
        be left out of the learners-per-tutor ratio.
        """
        for batch in self:
            if batch.tutor_id and batch.tutor_id not in batch.tutor_ids:
                batch.tutor_ids = [(4, batch.tutor_id.id)]

    @api.depends("tutor_ids", "tutor_ids.course_ids", "course_id",
                 "tutor_ids.qualification_expired_count")
    def _compute_tutor_checks(self):
        for batch in self:
            team = batch.tutor_ids
            if batch.course_id:
                batch.tutor_unapproved_ids = team.filtered(
                    lambda t: batch.course_id not in t.course_ids)
            else:
                batch.tutor_unapproved_ids = team.browse()
            batch.tutor_expired_count = len(
                team.filtered(lambda t: t.qualification_expired_count))

    def _batch_blockers(self):
        items = super()._batch_blockers()
        if not self.tutor_id:
            items.append({
                "label": _("tutor still to be assigned"), "count": 1})
        if self.tutor_unapproved_ids:
            items.append({
                "label": _("on the team but not approved for this course"),
                "count": len(self.tutor_unapproved_ids),
            })
        if self.tutor_expired_count:
            items.append({
                "label": _("tutors with an expired certificate"),
                "count": self.tutor_expired_count,
            })
        return items

    def _apply_course_defaults(self):
        """Suggest a tutor when the course has exactly one approved for it.

        Only when there is exactly one. Picking the first of four would be a
        guess wearing the clothes of a default, and the coordinator would
        stop reading the field.
        """
        super()._apply_course_defaults()
        for batch in self:
            if batch.tutor_id or not batch.course_id:
                continue
            candidates = self.env["hr.employee"].search([
                ("is_tutor", "=", True),
                ("course_ids", "in", batch.course_id.id),
            ])
            if batch.delivery_language:
                matching = candidates.filtered(
                    lambda t: batch.delivery_language
                    in t.tutor_language_ids.mapped("code"))
                candidates = matching or candidates
            if len(candidates) == 1:
                batch.tutor_id = candidates

    def action_open_tutors(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Teaching %s") % self.display_name,
            "res_model": "hr.employee",
            "view_mode": "kanban,list,form",
            "domain": [("id", "in", self.tutor_ids.ids)],
        }
