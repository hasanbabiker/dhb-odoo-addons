from odoo import models, fields, api, _


class DhbCourse(models.Model):
    """Who can teach this course.

    The other half of the relation on the employee. Kept here rather than as
    a search every time, because the question "can we actually run a second
    group of this in March" is asked of the course, not of the staff list.
    """

    _inherit = "dhb.course"

    tutor_ids = fields.Many2many(
        "hr.employee", "dhb_tutor_course_rel", "course_id", "employee_id",
        string="Approved tutors", domain="[('is_tutor', '=', True)]")
    tutor_count = fields.Integer(compute="_compute_tutor_count")

    @api.depends("tutor_ids")
    def _compute_tutor_count(self):
        for course in self:
            course.tutor_count = len(course.tutor_ids)

    def _setup_missing(self):
        """A course nobody is approved to teach is not ready to sell."""
        missing = super()._setup_missing()
        if not self.tutor_ids:
            missing.append(_("Tutors"))
        return missing

    # `_compute_setup_warning` is deliberately NOT re-decorated here.
    #
    # The tempting move is to repeat the base @api.depends with this
    # module's field added, so the warning refreshes the moment a tag is
    # dropped in. It does not survive a second module doing the same thing:
    # Odoo reads _depends from the one method that ends up on the model, so
    # whichever of them loads last wins and the other's field is silently
    # dropped from the trigger list. Two modules now extend _setup_missing -
    # this one and the other one - and neither can know about the other.
    #
    # Leaving the base decoration alone costs a live refresh and nothing
    # else: setup_warning is not stored, so it is recomputed whenever the
    # record is re-read, which includes the save.

    def action_open_tutors(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Tutors approved for %s") % self.display_name,
            "res_model": "hr.employee",
            "view_mode": "kanban,list,form",
            "domain": [("id", "in", self.tutor_ids.ids)],
        }
