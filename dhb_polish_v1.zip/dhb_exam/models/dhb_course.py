from odoo import models, fields, api, _


class DhbCourse(models.Model):
    """Which units a learner has to pass to hold this course."""

    _inherit = "dhb.course"

    exam_unit_ids = fields.Many2many(
        "dhb.exam.unit", "dhb_exam_unit_course_rel", "course_id", "unit_id",
        string="Assessed by")
    exam_unit_count = fields.Integer(compute="_compute_exam_unit_count")

    @api.depends("exam_unit_ids")
    def _compute_exam_unit_count(self):
        for course in self:
            course.exam_unit_count = len(course.exam_unit_ids)

    def _setup_missing(self):
        """A course with no unit against it cannot chase an entry.

        Everything this app does for a batch - who is not entered, who was
        referred - starts from the list of units the course is assessed by.
        An empty list makes the whole thing silently do nothing, which is
        worse than an error.
        """
        missing = super()._setup_missing()
        if not self.exam_unit_ids:
            missing.append(_("Units"))
        return missing

    # `_compute_setup_warning` is deliberately NOT re-decorated here.
    #
    # The tempting move is to repeat the base @api.depends with this
    # module's field added, so the warning refreshes the moment a tag is
    # dropped in. It does not survive a second module doing the same thing:
    # Odoo reads _depends from the one method that ends up on the model, so
    # whichever of them loads last wins and the other's field is silently
    # dropped from the trigger list. Two modules now extend _setup_missing -
    # this one and the other one - and neither can know about the other.
    #
    # Leaving the base decoration alone costs a live refresh and nothing
    # else: setup_warning is not stored, so it is recomputed whenever the
    # record is re-read, which includes the save.

    def action_open_exam_units(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Units of %s") % self.display_name,
            "res_model": "dhb.exam.unit",
            "view_mode": "list,form",
            "domain": [("course_ids", "in", self.id)],
            "context": {"default_course_ids": [(4, self.id)]},
        }
