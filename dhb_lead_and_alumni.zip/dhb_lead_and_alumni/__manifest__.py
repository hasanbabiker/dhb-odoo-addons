# -*- coding: utf-8 -*-
{
    "name": "DHB: enquiry channels, course brochure, alumni",
    "summary": "The two ends of the journey — where a learner came from, "
               "and what they become after the certificate.",
    "description": """
Closes three gaps in the admissions journey:

  * The channels most enquiries actually arrive on — WhatsApp, Telegram,
    Instagram, walking in — were not on the list, so the busiest source of
    learners was recorded as nothing at all.

  * The introductory course PDF was sent by hand with no trace, so nobody
    could say who had received it or when.

  * Alumni and ambassadors, the last stage of the process, had no
    representation anywhere. A graduate is the cheapest source of the next
    learner, and the referral question is already on the registration form.

Alumni are marked from a fact, not a button somebody remembers to press: a
certificate exists for the learner and has not been cancelled.
""",
    "version": "19.0.1.0.0",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "category": "Education",

    "depends": [
        "crm",
        "utm",
        "dhb_batch",
        "dhb_certificate",
        "dhb_learner",
        "dhb_apps",
    ],

    "data": [
        "data/utm_medium.xml",
        "data/mail_template.xml",
        "data/ir_cron.xml",
        "views/dhb_course_views.xml",
        "views/crm_lead_views.xml",
        "views/res_partner_views.xml",
    ],

    "installable": True,
    "application": False,
    "auto_install": False,
}
