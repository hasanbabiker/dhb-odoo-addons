# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class DhbCertificate(models.Model):
    _inherit = "dhb.certificate"

    # A certificate in any of these states means the awarding body has
    # issued, or is issuing, a qualification to this learner. 'pending' is
    # before that; 'cancelled' and 'lost' are not evidence of anything.
    ALUMNI_STATES = (
        "electronic",
        "requested",
        "ordered",
        "at_centre",
        "notified",
        "in_transit",
        "delivered",
    )

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        records._mark_alumni()
        return records

    def write(self, vals):
        result = super().write(vals)
        if "state" in vals or "partner_id" in vals:
            self._mark_alumni()
        return result

    def _mark_alumni(self):
        today = fields.Date.today()
        for certificate in self:
            partner = certificate.partner_id
            if not partner or certificate.state not in self.ALUMNI_STATES:
                continue
            if partner.is_alumni:
                continue
            partner.sudo().write({"is_alumni": True, "alumni_since": today})
            partner.message_post(
                body=_("Recorded as an alumnus: certificate %s.")
                % certificate.name
            )
