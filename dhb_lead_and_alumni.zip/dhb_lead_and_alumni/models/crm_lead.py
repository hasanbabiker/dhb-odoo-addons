# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError


class CrmLead(models.Model):
    _inherit = "crm.lead"

    brochure_sent_on = fields.Datetime(
        string="Brochure sent",
        readonly=True,
        help="When the course PDF went out. Without this nobody can say "
             "whether a quiet enquiry was ever answered.",
    )
    brochure_sent_by = fields.Many2one(
        "res.users", string="Brochure sent by", readonly=True
    )
    brochure_course_id = fields.Many2one(
        "dhb.course",
        string="Course sent about",
        compute="_compute_brochure_course_id",
        store=False,
        help="Taken from the intake the enquiry is about.",
    )

    @api.depends("register_id")
    def _compute_brochure_course_id(self):
        for lead in self:
            event = lead.register_id.event_id if lead.register_id else False
            lead.brochure_course_id = event.course_id if event else False

    # ------------------------------------------------------------------
    def action_send_course_brochure(self):
        """Email the course PDF and record that it went."""
        self.ensure_one()

        if not self.email_from:
            raise UserError(_(
                "This enquiry has no email address. Add one, or send the "
                "brochure over WhatsApp from the message box instead."
            ))

        course = self.brochure_course_id
        if not course:
            raise UserError(_(
                "Pick the intake this enquiry is about first — the brochure "
                "comes from its course."
            ))
        if not course.brochure:
            raise UserError(_(
                "No brochure is attached to %s yet. Upload one on the course "
                "and it will be sent from there every time."
            ) % course.display_name)

        template = self.env.ref(
            "dhb_lead_and_alumni.mail_template_course_brochure",
            raise_if_not_found=False,
        )
        if not template:
            raise UserError(_("The brochure email template is missing."))

        attachment = self.env["ir.attachment"].sudo().create({
            "name": course.brochure_filename or (
                "%s.pdf" % (course.display_name or "brochure")
            ),
            "datas": course.brochure,
            "res_model": "crm.lead",
            "res_id": self.id,
            "mimetype": "application/pdf",
        })

        template.send_mail(
            self.id,
            force_send=True,
            email_values={"attachment_ids": [(6, 0, [attachment.id])]},
        )

        self.write({
            "brochure_sent_on": fields.Datetime.now(),
            "brochure_sent_by": self.env.user.id,
        })
        self.message_post(
            body=_("Course brochure sent to %(email)s for %(course)s.")
            % {"email": self.email_from, "course": course.display_name}
        )
        return True
