# -*- coding: utf-8 -*-
from . import res_partner
from . import dhb_course
from . import crm_lead
from . import dhb_certificate
