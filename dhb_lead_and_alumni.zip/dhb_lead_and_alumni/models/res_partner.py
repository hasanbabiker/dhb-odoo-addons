# -*- coding: utf-8 -*-
from odoo import api, fields, models


class ResPartner(models.Model):
    _inherit = "res.partner"

    is_alumni = fields.Boolean(
        string="Alumnus",
        index=True,
        help="Set automatically once a certificate exists for this learner "
             "and has not been cancelled. It is a fact about the learner, "
             "not a decision somebody makes.",
    )
    alumni_since = fields.Date(
        string="Graduated on",
        help="The day the first certificate was recorded, not the day this "
             "box was ticked.",
    )
    is_ambassador = fields.Boolean(
        string="Ambassador",
        index=True,
        help="A graduate who has agreed to speak for the centre. Unlike "
             "Alumnus, this one is a decision, so it is set by hand.",
    )
    ambassador_since = fields.Date(string="Ambassador since")
    ambassador_note = fields.Text(
        string="Ambassador note",
        help="What they have agreed to do — a testimonial, a talk, taking "
             "calls from prospective learners.",
    )

    @api.onchange("is_ambassador")
    def _onchange_is_ambassador(self):
        for partner in self:
            if partner.is_ambassador and not partner.ambassador_since:
                partner.ambassador_since = fields.Date.today()

    # ------------------------------------------------------------------
    @api.model
    def _cron_mark_alumni(self):
        """Mark every learner who has a certificate.

        Runs nightly, and its first run backfills everyone who graduated
        before this module existed.
        """
        Certificate = self.env["dhb.certificate"].sudo()
        states = self.env["dhb.certificate"].ALUMNI_STATES
        certificates = Certificate.search([
            ("state", "in", list(states)),
            ("partner_id", "!=", False),
            ("partner_id.is_alumni", "=", False),
        ])
        count = 0
        for certificate in certificates:
            certificate.partner_id.sudo().write({
                "is_alumni": True,
                "alumni_since": (
                    certificate.partner_id.alumni_since
                    or fields.Date.today()
                ),
            })
            count += 1
        return count
