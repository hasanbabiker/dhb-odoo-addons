# -*- coding: utf-8 -*-
from odoo import fields, models


class DhbCourse(models.Model):
    _inherit = "dhb.course"

    brochure = fields.Binary(
        string="Course brochure",
        attachment=True,
        help="The introductory PDF sent to anyone who asks about this course. "
             "Kept on the course so nobody sends last intake's prices.",
    )
    brochure_filename = fields.Char(string="Brochure filename")
    brochure_updated_on = fields.Date(
        string="Brochure updated",
        help="A brochure carrying a price is only as good as its date.",
    )

    def write(self, vals):
        if "brochure" in vals and vals.get("brochure"):
            vals.setdefault("brochure_updated_on", fields.Date.today())
        return super().write(vals)
