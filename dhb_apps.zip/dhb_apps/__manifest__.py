{
    "name": "DHB App Cards",
    "version": "19.0.1.0.2",
    "summary": "Put the DHB modules on Odoo's home screen as their own apps",
    "description": """
DHB App Cards
=============

Everything DHB built lives inside the Events app, several menus deep. That is
where it belongs for whoever works from a cohort, but it means a new member of
staff has to be told where to look, and the system looks smaller than it is.

This module adds nothing but doorways: a root menu with an icon for each area,
pointing at the screens that already exist. No model, no field, no second copy
of any record. The menus inside Events stay exactly where they are, so both
routes lead to the same place.

Uninstalling it removes the cards and leaves every module untouched.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": [
        "dhb_learner",
        "dhb_zoom_attendance",
        "dhb_moodle",
        "dhb_registration",
        "dhb_interview",
        "dhb_enrolment",
    ],
    "data": [
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
