# -*- coding: utf-8 -*-
import base64
import logging
import os

_logger = logging.getLogger(__name__)


def _dhb_theme_post_init(env):
    """Set the company logo and favicon from the bundled brand assets.

    Done in Python rather than XML data so it runs once at install and does not
    fight the user if they later upload something else.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    images = os.path.join(here, "static", "src", "img")
    company = env.company

    def _read(name):
        path = os.path.join(images, name)
        if not os.path.exists(path):
            return None
        with open(path, "rb") as handle:
            return base64.b64encode(handle.read())

    values = {}
    logo = _read("logo_login.png")
    favicon = _read("favicon.png")
    if logo:
        values["logo"] = logo
    if favicon and "favicon" in company._fields:
        values["favicon"] = favicon
    if values:
        company.sudo().write(values)
        _logger.info("DHB theme: company logo and favicon applied.")
