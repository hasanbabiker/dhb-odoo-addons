# -*- coding: utf-8 -*-
{
    "name": "DHB website: live course calendar",
    "summary": "The public page that lists the intakes actually open, read "
               "from the admission registers rather than typed by hand.",
    "description": """
Every competitor publishes a course calendar, and every one of them is a page
somebody edits by hand — which is why they carry intakes that closed last
month and seat counts nobody has checked.

This one reads the admission registers at the moment the page is opened. An
intake that is published and open appears; one that fills or closes leaves;
the seats remaining are the real ones; and the Register button opens that
intake's own application link.

It brings its own header and footer. Odoo's default ones still carry a
placeholder American phone number and links that go nowhere, and that is the
first thing a visitor reads.
""",
    "version": "19.0.1.0.0",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "category": "Website",

    "depends": [
        "website",
        "dhb_admission",
        "dhb_batch",
    ],

    "data": [
        "views/layout.xml",
        "views/calendar_templates.xml",
    ],

    "assets": {
        "web.assets_frontend": [
            "dhb_website/static/src/css/site.css",
        ],
    },

    "installable": True,
    "application": False,
    "auto_install": False,
}
