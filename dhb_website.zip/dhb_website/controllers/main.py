# -*- coding: utf-8 -*-
"""The public course calendar.

Every competitor's calendar is a page somebody edits by hand, which is why
theirs carry dates that have passed. This one reads the admission registers:
an intake that is open appears, one that fills or closes leaves, and the
seats remaining are the real ones.
"""
from odoo import http
from odoo.http import request


class DhbWebsiteController(http.Controller):

    @http.route(["/courses", "/courses/calendar"], type="http", auth="public",
                website=True, sitemap=True)
    def course_calendar(self, **kw):
        Register = request.env["dhb.admission.register"].sudo()

        registers = Register.search(
            [("state", "=", "published")],
            order="course_date_begin asc, start_date asc",
        ).filtered(lambda r: r.is_open and r.event_id)

        qualification = kw.get("q")
        if qualification:
            registers = registers.filtered(
                lambda r: r.event_id.course_id
                and r.event_id.course_id.code == qualification
            )

        courses = request.env["dhb.course"].sudo().search(
            [("active", "=", True)], order="code"
        )

        company = request.env.company
        return request.render("dhb_website.course_calendar", {
            "registers": registers,
            "courses": courses,
            "selected": qualification or "",
            "company": company,
            # A template's body renders in the caller's context, so the
            # layout's own variables do not reach it. Pass it explicitly.
            "wa": whatsapp_number(company),
        })


def whatsapp_number(company):
    """The company phone as wa.me wants it: digits only."""
    raw = company.phone or company.mobile or ""
    return "".join(ch for ch in raw if ch.isdigit())
