{
    "name": "DHB Exams",
    "version": "19.0.1.0.0",
    "summary": "Who is entered for what, and what came back",
    "description": """
DHB Exams
=========

The centre already had two of the three pieces:

* the published timetable - ``dhb.nebosh.sitting``, with every date NEBOSH
  sets, in the attendance module;
* the results that came back - ``dhb.nebosh.result``, the Unit Result
  Notification as NEBOSH prints it, in the learner module.

Between them sat the piece nobody could see, and it is the one with a
deadline on it: **who we have actually entered, and who we have not entered
yet**. That is what this adds.

This module does not keep a second timetable and does not keep a second copy
of a result. An entry points at the sitting and at the result row, and reads
the outcome from there. Two copies of a result is one copy too many.

It also adds the **unit** - IG1, IG2 - as a record rather than free text, and
ties it to the courses it belongs to. Everything else follows from that one
link: a batch can now be asked how many of its learners are missing an entry
for a unit their course requires, and answer.

Three screens earn their place:

* **Entries** - the whole list, filtered to "still to enter" or "waiting for
  a result".
* **Referrals to re-enter** - referred, may be re-sat, and no later entry
  exists. A referral nobody re-enters is a learner who quietly never
  completes, and a pass rate that quietly falls.
* **Enter learners** on a batch - the whole cohort put forward in one pass,
  with anyone who has already passed left off the list.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Education",
    "license": "LGPL-3",
    "depends": [
        "base", "mail", "contacts",
        "dhb_batch",
        # For dhb.nebosh.sitting - the published timetable.
        "dhb_zoom_attendance",
        # For dhb.nebosh.result - the Unit Result Notification rows.
        "dhb_learner",
    ],
    "data": [
        "security/exam_groups.xml",
        "security/ir.model.access.csv",
        "data/exam_unit_data.xml",
        "views/exam_unit_views.xml",
        "views/exam_entry_views.xml",
        "views/exam_sitting_views.xml",
        "wizard/exam_entry_wizard_views.xml",
        "views/batch_views.xml",
        "views/course_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
