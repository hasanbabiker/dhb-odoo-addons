from odoo import models, fields, api, _
from odoo.exceptions import UserError

from .exam_entry import FAILING, PASSING


class DhbNeboshSitting(models.Model):
    """The published timetable, with the entries we have made against it.

    The sitting model already existed and already carried every date NEBOSH
    publishes. What it could not answer was the only question a coordinator
    asks between the publication and the exam: how many of ours are in, and
    who is not.
    """

    _inherit = "dhb.nebosh.sitting"

    unit_id = fields.Many2one(
        "dhb.exam.unit", string="Unit (catalogue)", index=True,
        compute="_compute_unit_id", store=True, readonly=False,
        help="Matched from the unit code. Linking the sitting to the "
             "catalogue is what lets a batch know it is short of entries.")

    entry_ids = fields.One2many(
        "dhb.exam.entry", "sitting_id", string="Entries")
    entry_count = fields.Integer(compute="_compute_entry_counts", store=True)
    entered_count = fields.Integer(compute="_compute_entry_counts", store=True)
    entry_draft_count = fields.Integer(
        compute="_compute_entry_counts", store=True)
    absent_count = fields.Integer(compute="_compute_entry_counts", store=True)
    pass_count = fields.Integer(compute="_compute_entry_counts", store=True)
    refer_count = fields.Integer(compute="_compute_entry_counts", store=True)
    result_pending_count = fields.Integer(
        compute="_compute_entry_counts", store=True)
    pass_rate = fields.Float(
        compute="_compute_entry_counts", store=True,
        help="Passes as a share of the results that have come back. "
             "Learners still waiting are counted on neither side.")

    batch_entry_ids = fields.Many2many(
        "dhb.batch", string="Batches entered",
        compute="_compute_batch_entry_ids")

    @api.depends("unit_code")
    def _compute_unit_id(self):
        units = self.env["dhb.exam.unit"]
        for sitting in self:
            if sitting.unit_id:
                continue
            code = (sitting.unit_code or "").strip()
            sitting.unit_id = units.search(
                [("code", "=ilike", code)], limit=1) if code else False

    @api.depends("entry_ids.state", "entry_ids.outcome")
    def _compute_entry_counts(self):
        for sitting in self:
            live = sitting.entry_ids.filtered(
                lambda e: e.state != "withdrawn")
            sitting.entry_count = len(live)
            sitting.entry_draft_count = len(
                live.filtered(lambda e: e.state == "draft"))
            sitting.entered_count = len(
                live.filtered(lambda e: e.state in ("entered", "sat")))
            sitting.absent_count = len(
                live.filtered(lambda e: e.state == "absent"))
            sitting.pass_count = len(
                live.filtered(lambda e: e.outcome in PASSING))
            sitting.refer_count = len(
                live.filtered(lambda e: e.outcome in FAILING))
            sitting.result_pending_count = len(
                live.filtered(lambda e: e.outcome == "pending"))
            decided = sitting.pass_count + sitting.refer_count
            sitting.pass_rate = (
                100.0 * sitting.pass_count / decided) if decided else 0.0

    @api.depends("entry_ids.batch_id")
    def _compute_batch_entry_ids(self):
        for sitting in self:
            sitting.batch_entry_ids = sitting.entry_ids.mapped("batch_id")

    # ------------------------------------------------------------------
    def action_open_entries(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Entries for %s") % self.display_name,
            "res_model": "dhb.exam.entry",
            "view_mode": "list,form",
            "domain": [("sitting_id", "=", self.id)],
            "context": {"default_sitting_id": self.id},
        }

    def action_enter_learners(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Enter learners for %s") % self.display_name,
            "res_model": "dhb.exam.entry.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_sitting_id": self.id},
        }

    def action_confirm_entries(self):
        """Move everything still on the to-enter list into Entered.

        Pressed once, after the list has been submitted to the awarding
        body. Anything the coordinator has not decided about is still in
        draft and is not swept along: it is left where it is and reported.
        """
        for sitting in self:
            drafts = sitting.entry_ids.filtered(
                lambda e: e.state == "draft")
            if not drafts:
                raise UserError(_(
                    "Nothing is waiting to be entered on %s.")
                    % sitting.display_name)
            drafts.action_enter()

    def action_match_results(self):
        self.ensure_one()
        return self.entry_ids.action_match_results()
