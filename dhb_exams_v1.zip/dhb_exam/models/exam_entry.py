from datetime import timedelta

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

# NEBOSH's own vocabulary, taken from the Unit Result Notification rather
# than invented here: Refer, not Fail. The centre already stores results in
# dhb.nebosh.result, and this app does not keep a second copy of them - an
# entry points at the result row and reads its status.
PASSING = ("pass",)
FAILING = ("refer",)

# How far either side of the sitting date to look when matching an imported
# result to an entry. NEBOSH dates a result by the assessment, but a resit
# or a late submission can sit a few weeks off.
MATCH_WINDOW_DAYS = 60


class DhbExamEntry(models.Model):
    """One learner, in one sitting, for one unit.

    This is the row the system was missing. The centre already had the
    published timetable (dhb.nebosh.sitting) and the results that came back
    (dhb.nebosh.result). Between them sat the part nobody could see: who we
    have actually entered, and who we have not entered yet while the
    deadline runs down.

    The entry owns the *entry* facts - the candidate number, whether they
    turned up, what it cost. It does not own the outcome. That belongs to
    the result row, because that row is the awarding body's document and
    two copies of a result is one copy too many.
    """

    _name = "dhb.exam.entry"
    _description = "Exam entry"
    _inherit = ["mail.thread"]
    _order = "date_exam desc, partner_name asc"
    _rec_name = "partner_name"

    sitting_id = fields.Many2one(
        "dhb.nebosh.sitting", string="Sitting", required=True, index=True,
        ondelete="restrict", tracking=True)
    unit_id = fields.Many2one(
        "dhb.exam.unit", string="Unit", required=True, index=True,
        ondelete="restrict", tracking=True,
        compute="_compute_unit_id", store=True, readonly=False,
        precompute=True,
        help="Taken from the sitting where its unit code matches one we "
             "know. Change it only if the sitting is mixed.")
    date_exam = fields.Date(
        related="sitting_id.assessment_date", store=True, string="Sits on")
    entry_deadline = fields.Date(
        related="sitting_id.booking_deadline", string="Entries close")

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True, index=True,
        ondelete="restrict", tracking=True)
    partner_name = fields.Char(
        related="partner_id.name", store=True, string="Name")
    batch_id = fields.Many2one(
        "dhb.batch", string="Batch", index=True, tracking=True,
        help="Which cohort the learner is sitting from. One sitting carries "
             "learners from several.")
    registration_id = fields.Many2one(
        "dhb.batch.line", string="Place on the batch")

    candidate_number = fields.Char(
        string="Candidate number", tracking=True,
        help="The number the awarding body gave the learner. Without it a "
             "result cannot be matched back.")
    attempt = fields.Integer(
        string="Attempt", default=1, required=True,
        compute="_compute_attempt", store=True, readonly=False,
        precompute=True,
        help="Counted from the learner's earlier entries for the same unit.")
    is_resit = fields.Boolean(compute="_compute_attempt", store=True,
                              precompute=True)

    state = fields.Selection(
        [
            ("draft", "To enter"),
            ("entered", "Entered"),
            ("sat", "Sat"),
            ("absent", "Absent"),
            ("withdrawn", "Withdrawn"),
        ],
        default="draft", required=True, tracking=True, index=True,
        group_expand="_group_expand_state")

    # The outcome, read from the awarding body's own row rather than typed
    # again here.
    result_id = fields.Many2one(
        "dhb.nebosh.result", string="Result", tracking=True,
        help="The Unit Result Notification row this entry produced. Linked "
             "by hand, or by the Match results button after a URN import.")
    outcome = fields.Selection(
        [
            ("pending", "Awaited"),
            ("pass", "Pass"),
            ("refer", "Refer"),
            ("absent", "Absent"),
            ("void", "Void"),
        ],
        compute="_compute_outcome", store=True, index=True, string="Outcome")
    mark = fields.Integer(related="result_id.mark", store=True)
    result_date = fields.Date(related="result_id.exam_date", store=True)

    resit_outstanding = fields.Boolean(
        compute="_compute_resit_outstanding", store=True,
        help="Referred, the unit may be re-sat, and no later entry exists "
             "for it. This is the number that quietly costs a pass rate.")

    fee = fields.Monetary(
        string="Entry fee", currency_field="currency_id",
        help="What the awarding body charges for this entry, so a sitting "
             "can be reconciled against its invoice.")
    currency_id = fields.Many2one(
        "res.currency", default=lambda self: self.env.company.currency_id)

    note = fields.Text()

    _unique_entry = models.Constraint(
        "unique(sitting_id, partner_id, unit_id)",
        "That learner is already entered for this unit in this sitting.",
    )

    # ------------------------------------------------------------------
    @api.model
    def _group_expand_state(self, states, domain):
        return [key for key, _label in self._fields["state"].selection]

    @api.depends("sitting_id")
    def _compute_unit_id(self):
        """Read the sitting's unit code and find the unit it names.

        The sitting model stores its unit as free text - it was written
        before there was a unit catalogue to point at. Rather than change
        that model, the code is matched here, and a sitting whose code we do
        not recognise simply leaves the field for a person to fill in.
        """
        units = self.env["dhb.exam.unit"]
        for entry in self:
            code = (entry.sitting_id.unit_code or "").strip()
            if not code or entry.unit_id:
                continue
            match = units.search([("code", "=ilike", code)], limit=1)
            if match:
                entry.unit_id = match

    @api.depends("partner_id", "unit_id")
    def _compute_attempt(self):
        for entry in self:
            if not entry.partner_id or not entry.unit_id:
                entry.attempt = entry.attempt or 1
                entry.is_resit = False
                continue
            earlier = self.search_count([
                ("partner_id", "=", entry.partner_id.id),
                ("unit_id", "=", entry.unit_id.id),
                ("state", "!=", "withdrawn"),
                ("id", "!=", entry._origin.id or 0),
            ])
            entry.attempt = earlier + 1
            entry.is_resit = earlier > 0

    @api.depends("result_id", "result_id.status", "state")
    def _compute_outcome(self):
        """Read the outcome off the result row, guarding the vocabulary.

        The statuses belong to another module. If it ever gains a value this
        one has not heard of, an unguarded assignment would raise on a
        selection field and make the entry unreadable. Falling back to
        "awaited" is wrong in a way somebody notices and corrects; a traceback
        on a list view is wrong in a way that stops the day.
        """
        known = dict(self._fields["outcome"].selection)
        for entry in self:
            if entry.state == "absent":
                entry.outcome = "absent"
                continue
            status = entry.result_id.status if entry.result_id else False
            entry.outcome = status if status in known else "pending"

    @api.depends("outcome", "partner_id", "unit_id", "state", "date_exam")
    def _compute_resit_outstanding(self):
        for entry in self:
            if entry.outcome not in FAILING or entry.state == "withdrawn":
                entry.resit_outstanding = False
                continue
            if not entry.unit_id.resit_allowed:
                entry.resit_outstanding = False
                continue
            later = self.search_count([
                ("partner_id", "=", entry.partner_id.id),
                ("unit_id", "=", entry.unit_id.id),
                ("state", "!=", "withdrawn"),
                ("date_exam", ">", entry.date_exam),
            ]) if entry.partner_id and entry.unit_id and entry.date_exam else 0
            entry.resit_outstanding = not later

    # `resit_outstanding` is stored, because the screen that lists outstanding
    # referrals has to be searchable, and it depends on rows other than its
    # own: a referral stops being outstanding the moment a later entry is
    # created for the same learner and unit. Odoo cannot see that
    # dependency, so it is declared by hand. Without this the flag would be
    # right on the day it was written and wrong afterwards - the worst kind
    # of wrong, because it looks maintained.
    def _siblings_to_refresh(self):
        pairs = {(e.partner_id.id, e.unit_id.id) for e in self
                 if e.partner_id and e.unit_id}
        if not pairs:
            return self.browse()
        domain = []
        for index, (partner, unit) in enumerate(pairs):
            # Written with an explicit "&": two bare conditions after an "|"
            # would be read as the two alternatives of the or, not as a pair.
            leaf = ["&", ("partner_id", "=", partner), ("unit_id", "=", unit)]
            domain = leaf if not index else ["|"] + domain + leaf
        return self.search(domain) - self

    @api.model_create_multi
    def create(self, vals_list):
        entries = super().create(vals_list)
        entries._siblings_to_refresh()._compute_resit_outstanding()
        return entries

    def write(self, vals):
        result = super().write(vals)
        if {"result_id", "state", "sitting_id", "partner_id",
                "unit_id"} & set(vals):
            self._siblings_to_refresh()._compute_resit_outstanding()
        return result

    @api.depends("partner_name", "unit_id", "date_exam")
    def _compute_display_name(self):
        for entry in self:
            unit = entry.unit_id.code or ""
            entry.display_name = "%s - %s" % (
                entry.partner_name or _("Learner"), unit) if unit \
                else (entry.partner_name or "")

    @api.constrains("result_id", "partner_id")
    def _check_result_learner(self):
        """A result belongs to the learner whose entry it is attached to."""
        for entry in self:
            if entry.result_id and entry.result_id.partner_id \
                    != entry.partner_id:
                raise ValidationError(_(
                    "That result belongs to %(other)s, not to %(learner)s.",
                    other=entry.result_id.partner_id.display_name,
                    learner=entry.partner_id.display_name,
                ))

    # ------------------------------------------------------------------
    def action_enter(self):
        for entry in self:
            if not entry.candidate_number:
                entry.message_post(body=_(
                    "Entered with no candidate number. The result cannot be "
                    "matched back automatically until one is recorded."))
        self.write({"state": "entered"})

    def action_sat(self):
        self.write({"state": "sat"})

    def action_absent(self):
        self.write({"state": "absent"})

    def action_withdraw(self):
        self.write({"state": "withdrawn"})

    def action_draft(self):
        self.write({"state": "draft"})

    # ------------------------------------------------------------------
    def action_match_results(self):
        """Attach imported results to the entries that produced them.

        Matched on the learner and the unit code, within a window either
        side of the sitting - a resit or a late submission is dated a few
        weeks off the assessment. Never guesses between two candidates: if
        more than one row fits, it leaves the entry alone and says so,
        because a result attached to the wrong entry is worse than none.
        """
        results = self.env["dhb.nebosh.result"]
        matched = ambiguous = 0
        for entry in self.filtered(lambda e: not e.result_id):
            if not entry.partner_id or not entry.unit_id:
                continue
            domain = [
                ("partner_id", "=", entry.partner_id.id),
                ("unit_code", "=ilike", entry.unit_id.code or ""),
            ]
            if entry.date_exam:
                window = timedelta(days=MATCH_WINDOW_DAYS)
                domain += [
                    ("exam_date", ">=", entry.date_exam - window),
                    ("exam_date", "<=", entry.date_exam + window),
                ]
            candidates = results.search(domain)
            # A result already claimed by another entry is not available.
            candidates = candidates.filtered(
                lambda r: not self.search_count(
                    [("result_id", "=", r.id)]))
            if len(candidates) == 1:
                entry.result_id = candidates
                matched += 1
            elif len(candidates) > 1:
                ambiguous += 1
                entry.message_post(body=_(
                    "%s results fit this entry. Link the right one by hand.",
                    len(candidates)))
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "type": "success" if matched else "warning",
                "message": _(
                    "%(matched)s results attached. %(ambiguous)s entries had "
                    "more than one candidate and were left alone.",
                    matched=matched, ambiguous=ambiguous),
                "next": {"type": "ir.actions.act_window_close"},
            },
        }
