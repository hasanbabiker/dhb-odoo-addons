from odoo import models, fields, api

# Kept here rather than in the batch module's constants: an assessment type
# is a fact about exams, and nothing outside this app has an opinion on it.
ASSESSMENT_TYPES = [
    ("open_book", "Open book examination"),
    ("closed_book", "Closed book examination"),
    ("practical", "Practical assessment"),
    ("assignment", "Assignment"),
    ("discussion", "Professional discussion"),
    ("project", "Project"),
]


class DhbExamUnit(models.Model):
    """What is assessed.

    IG1 is a unit. The IGC is not - it is a course made of two units, and a
    learner holds it when both are passed. Keeping the two apart is what
    lets the system answer "who still owes us IG2" without anybody reading a
    spreadsheet.
    """

    _name = "dhb.exam.unit"
    _description = "Assessment unit"
    _order = "sequence, code"

    name = fields.Char(
        required=True,
        help="As the awarding body writes it. \"IG1: Management of health "
             "and safety\".")
    code = fields.Char(
        required=True, copy=False,
        help="Short and exact - IG1, IG2. It goes on the sitting name and "
             "on every entry.")
    _unique_code = models.Constraint(
        "unique(code)", "Another unit already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    course_ids = fields.Many2many(
        "dhb.course", "dhb_exam_unit_course_rel", "unit_id", "course_id",
        string="Part of",
        help="The courses a learner has to pass this unit for. A unit can "
             "belong to more than one.")

    assessment_type = fields.Selection(
        ASSESSMENT_TYPES, string="Assessed by", default="open_book",
        required=True)
    duration_hours = fields.Float(
        string="Time allowed (hours)",
        help="What the learner is told. Nothing is calculated from it.")
    submission_window_days = fields.Integer(
        string="Submission window (days)",
        help="For an open book examination or an assignment: how long the "
             "learner has from release to submission.")

    resit_allowed = fields.Boolean(
        string="May be re-sat", default=True,
        help="Untick for a unit the awarding body does not let a learner "
             "attempt again.")
    # Points at the timetable the centre already keeps. This module does not
    # own a sitting model and deliberately never will: there is one
    # published timetable and a second copy of it would disagree with the
    # first within a month.
    sitting_ids = fields.One2many(
        "dhb.nebosh.sitting", "unit_id", string="Sittings")
    sitting_count = fields.Integer(compute="_compute_sitting_count")

    note = fields.Text(string="Internal notes")

    @api.depends("sitting_ids")
    def _compute_sitting_count(self):
        for unit in self:
            unit.sitting_count = len(unit.sitting_ids)

    @api.depends("name", "code")
    def _compute_display_name(self):
        for unit in self:
            unit.display_name = "[%s] %s" % (unit.code, unit.name) \
                if unit.code else (unit.name or "")

    def action_open_sittings(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": self.display_name,
            "res_model": "dhb.nebosh.sitting",
            "view_mode": "list,form",
            "domain": [("unit_id", "=", self.id)],
            "context": {"default_unit_id": self.id},
        }
