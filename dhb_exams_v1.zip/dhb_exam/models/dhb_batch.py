from odoo import models, fields, api, _

from .exam_entry import FAILING, PASSING


class DhbBatch(models.Model):
    """What the batch still owes the awarding body, and what came back.

    Two numbers belong on a batch and nowhere else: how many of its learners
    are not entered for a unit they have to pass, and how many were referred
    and have not been re-entered. Both are quiet failures - nothing breaks, a
    deadline simply passes - so both are counted here and shown with the rest
    of what is outstanding on the batch.
    """

    _inherit = "dhb.batch"

    exam_entry_ids = fields.One2many(
        "dhb.exam.entry", "batch_id", string="Exam entries")
    exam_entry_count = fields.Integer(compute="_compute_exam_counts")
    exam_not_entered_count = fields.Integer(compute="_compute_exam_counts")
    exam_refer_open_count = fields.Integer(compute="_compute_exam_counts")
    exam_pass_count = fields.Integer(compute="_compute_exam_counts")
    exam_pass_rate = fields.Float(compute="_compute_exam_counts")

    def _exam_learners(self):
        """The learners a batch owes an entry for.

        Somebody who cancelled their place is not owed an exam, and somebody
        still unconfirmed has not committed to one. Registered and attended
        are the two that count.
        """
        self.ensure_one()
        return self.registration_ids.filtered(
            lambda line: line.state in ("open", "done")).mapped("partner_id")

    def _exam_required_units(self):
        self.ensure_one()
        if not self.course_id:
            return self.env["dhb.exam.unit"]
        return self.env["dhb.exam.unit"].search([
            ("course_ids", "in", self.course_id.id)])

    @api.depends("exam_entry_ids.state", "exam_entry_ids.outcome",
                 "exam_entry_ids.resit_outstanding", "registration_ids.state",
                 "course_id")
    def _compute_exam_counts(self):
        for batch in self:
            entries = batch.exam_entry_ids.filtered(
                lambda e: e.state != "withdrawn")
            batch.exam_entry_count = len(entries)
            batch.exam_refer_open_count = len(entries.filtered("resit_outstanding"))
            batch.exam_pass_count = len(
                entries.filtered(lambda e: e.outcome in PASSING))
            decided = batch.exam_pass_count + len(
                entries.filtered(lambda e: e.outcome in FAILING))
            batch.exam_pass_rate = (
                100.0 * batch.exam_pass_count / decided) if decided else 0.0

            # Not entered = every (learner, unit) pair the course requires
            # that has no entry against it. Counted as pairs rather than as
            # people: a learner entered for IG1 and missing IG2 is one thing
            # still to do, not none.
            if not batch.id:
                batch.exam_not_entered_count = 0
                continue
            units = batch._exam_required_units()
            learners = batch._exam_learners()
            if not units or not learners:
                batch.exam_not_entered_count = 0
                continue
            taken = {
                (entry.partner_id.id, entry.unit_id.id) for entry in entries}
            batch.exam_not_entered_count = sum(
                1 for learner in learners for unit in units
                if (learner.id, unit.id) not in taken)

    def _batch_blockers(self):
        items = super()._batch_blockers()
        # Only once the batch is under way. A cohort that has not started is
        # not late for an exam, and saying so on every planned batch would
        # teach people to ignore the line.
        if self.state in ("running", "exams") and self.exam_not_entered_count:
            items.append({
                "label": _("exam entries still to make"),
                "count": self.exam_not_entered_count,
            })
        if self.exam_refer_open_count:
            items.append({
                "label": _("referred with no resit entered"),
                "count": self.exam_refer_open_count,
            })
        return items

    # ------------------------------------------------------------------
    def action_open_exam_entries(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Exam entries for %s") % self.display_name,
            "res_model": "dhb.exam.entry",
            "view_mode": "list,form",
            "domain": [("batch_id", "=", self.id)],
            "context": {"default_batch_id": self.id},
        }

    def action_open_exam_referrals(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Referred on %s") % self.display_name,
            "res_model": "dhb.exam.entry",
            "view_mode": "list,form",
            "domain": [
                ("batch_id", "=", self.id), ("resit_outstanding", "=", True)],
        }

    def action_enter_for_exam(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Enter %s for an exam") % self.display_name,
            "res_model": "dhb.exam.entry.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_batch_id": self.id},
        }
