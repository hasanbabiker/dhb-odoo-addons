from odoo import models, fields, api, _


class DhbAttendanceLine(models.Model):
    """One learner, one lecture.

    This is the permanent record. Zoom deletes dashboard data after six
    months; NEBOSH may ask about a cohort that finished two years ago.
    """

    _name = "dhb.attendance.line"
    _description = "Lecture attendance line"
    _order = "event_id, lecture_number, zoom_name"

    zoom_session_id = fields.Many2one(
        "dhb.zoom.session", string="Session", ondelete="cascade", index=True
    )
    event_id = fields.Many2one("dhb.batch", string="Cohort", index=True)
    registration_id = fields.Many2one(
        "dhb.batch.line", string="Learner", index=True, ondelete="set null"
    )
    partner_id = fields.Many2one(
        "res.partner", string="Contact",
        related="registration_id.partner_id", store=True, readonly=True,
    )

    lecture_number = fields.Integer(string="Lecture no.", index=True)
    session_date = fields.Date(string="Date")

    # what Zoom told us
    zoom_name = fields.Char(string="Zoom display name")
    zoom_email = fields.Char(string="Zoom email", index=True)
    zoom_user_id = fields.Char(string="Zoom user ID")
    join_time = fields.Datetime(string="Joined (UTC)")
    leave_time = fields.Datetime(string="Left (UTC)")
    duration_minutes = fields.Float(string="Minutes", digits=(6, 1))
    rejoin_count = fields.Integer(
        string="Re-entries",
        help="How many times the learner dropped out and came back.",
    )
    device = fields.Char(string="Device")
    location = fields.Char(string="Location")

    camera_on = fields.Boolean(string="Camera on")
    camera_source = fields.Selection(
        [
            ("qos", "Inferred from Zoom QoS"),
            ("manual", "Set by hand"),
        ],
        default="qos",
        string="Camera evidence",
        help="Zoom has no API that reports camera state. The QoS value is an "
             "inference from outgoing video statistics and can be corrected.",
    )

    present = fields.Boolean(
        string="Counted present", compute="_compute_present", store=True, readonly=False,
        help="Computed from the attendance threshold on the cohort, and "
             "editable when a tutor knows better.",
    )

    source = fields.Selection(
        [
            ("zoom", "Zoom API"),
            ("partner_upload", "Uploaded by delivery partner"),
            ("manual", "Entered by hand"),
        ],
        default="zoom",
        required=True,
        string="Source",
        help="An auditor is entitled to know where each record came from.",
    )
    interaction_evidence = fields.Binary(string="Interaction evidence", attachment=True)
    interaction_filename = fields.Char(string="Evidence filename")
    note = fields.Text(string="Note")

    @api.depends("duration_minutes", "event_id.attendance_threshold_pct",
                 "zoom_session_id.duration_minutes")
    def _compute_present(self):
        for line in self:
            total = line.zoom_session_id.duration_minutes or 0
            threshold = line.event_id.attendance_threshold_pct or 0
            if not total or not threshold:
                line.present = bool(line.duration_minutes)
            else:
                line.present = line.duration_minutes >= (total * threshold / 100.0)

    def _match_registration(self):
        """Link the line to a registration, by email first and name second.

        Email is the reliable key. Name matching is a fallback and is
        deliberately strict, because a cohort can hold six learners called
        Ahmed and a wrong match is worse than no match: it puts one learner's
        attendance on another learner's audit file.
        """
        Registration = self.env["dhb.batch.line"]
        for line in self:
            if line.registration_id or not line.event_id:
                continue

            registration = False
            if line.zoom_email:
                registration = Registration.search([
                    ("event_id", "=", line.event_id.id),
                    ("email", "=ilike", line.zoom_email),
                ], limit=1)

            if not registration and line.zoom_name:
                candidates = Registration.search([
                    ("event_id", "=", line.event_id.id),
                    ("name", "=ilike", line.zoom_name.strip()),
                ])
                if len(candidates) == 1:
                    registration = candidates

            if registration:
                line.registration_id = registration.id

    def action_rematch(self):
        self.filtered(lambda l: not l.registration_id)._match_registration()
        return True

    def action_toggle_camera(self):
        for line in self:
            line.write({"camera_on": not line.camera_on, "camera_source": "manual"})
        return True
