from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbZoomCredentials(models.TransientModel):
    """Zoom credentials, on their own screen.

    Deliberately not an inherit of res.config.settings: that view's internal
    block structure changes between Odoo versions, and this module should not
    break every upgrade over a settings panel.
    """

    _name = "dhb.zoom.credentials"
    _description = "Zoom connection settings"

    account_id = fields.Char(string="Account ID", required=True)
    client_id = fields.Char(string="Client ID", required=True)
    client_secret = fields.Char(string="Client Secret", required=True)
    status = fields.Text(string="Last test result", readonly=True)

    @api.model
    def default_get(self, fields_list):
        values = super().default_get(fields_list)
        icp = self.env["ir.config_parameter"].sudo()
        values.update({
            "account_id": icp.get_param("dhb_zoom.account_id", ""),
            "client_id": icp.get_param("dhb_zoom.client_id", ""),
            "client_secret": icp.get_param("dhb_zoom.client_secret", ""),
        })
        return values

    def action_save(self):
        self.ensure_one()
        icp = self.env["ir.config_parameter"].sudo()
        icp.set_param("dhb_zoom.account_id", (self.account_id or "").strip())
        icp.set_param("dhb_zoom.client_id", (self.client_id or "").strip())
        icp.set_param("dhb_zoom.client_secret", (self.client_secret or "").strip())
        # A credential change invalidates any cached token.
        icp.set_param("dhb_zoom.access_token", "")
        icp.set_param("dhb_zoom.token_expiry", "")
        return {"type": "ir.actions.act_window_close"}

    def action_test(self):
        self.ensure_one()
        self.action_save()
        try:
            info = self.env["dhb.zoom.api"].test_connection()
        except UserError as exc:
            self.status = _("Failed: %s") % exc
            return self._reopen()

        self.status = _(
            "Connected as %(name)s (%(email)s). Account type %(type)s.",
            name=" ".join(filter(None, [info.get("first_name"), info.get("last_name")])) or "-",
            email=info.get("email") or "-",
            type=info.get("type") or "-",
        )
        return self._reopen()

    def _reopen(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }
