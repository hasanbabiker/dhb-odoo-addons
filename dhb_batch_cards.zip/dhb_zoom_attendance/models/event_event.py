from odoo import models, fields, api, _


class EventEvent(models.Model):
    """A cohort: one qualification, one language, one group, N lectures."""

    _inherit = "dhb.batch"

    qualification = fields.Selection(
        [
            ("igc", "NEBOSH IGC"),
            ("di1", "NEBOSH Diploma DI1"),
            ("di2", "NEBOSH Diploma DI2"),
            ("di3", "NEBOSH Diploma DI3"),
            ("emc", "NEBOSH Environmental Management"),
            ("fire", "NEBOSH Fire"),
            ("hse", "NEBOSH HSE Incident Investigation"),
            ("award", "NEBOSH Health and Safety at Work Award"),
            ("psm", "NEBOSH Process Safety Management"),
            ("iosh_ms", "IOSH Managing Safely"),
        ],
        string="Qualification",
        index=True,
    )
    delivery_language = fields.Selection(
        [
            ("en", "English"),
            ("ar", "Arabic"),
            ("ru", "Russian"),
            ("tr", "Turkish"),
            ("pt", "Portuguese (European)"),
            ("es", "Spanish (European)"),
            ("fr", "French"),
        ],
        string="Language of delivery",
    )
    # NEBOSH recognises exactly four study modes (C026a v1). Blended and
    # in-company are not among them: in-company is a *place*, and a course
    # held at a client site is still Full Time or Part Time depending on its
    # timetable. Offering modes the awarding body does not accept only
    # produces applications it will reject.
    delivery_mode = fields.Selection(
        [
            ("full_time", "Full Time — classroom, block week"),
            ("part_time", "Part Time — classroom, half days or evenings"),
            ("virtual", "Virtual Delivery — Zoom or Teams, scheduled"),
            ("elearning", "E-Learning — self-paced on an LMS"),
        ],
        string="Study mode",
        default="virtual",
        help="The four modes NEBOSH accepts. Open/Distance Learning was "
             "withdrawn and is no longer an option.",
    )
    in_company = fields.Boolean(
        string="Delivered at the client's site",
        help="A place, not a study mode. A course at a client site is still "
             "Full Time or Part Time.",
    )
    tutor_ratio = fields.Float(
        string="Learners per tutor", compute="_compute_tutor_ratio", store=True,
    )
    ratio_warning = fields.Char(compute="_compute_tutor_ratio", store=True)

    tutor_ids = fields.Many2many(
        "hr.employee", string="Tutors",
        help="A cohort can be shared between tutors. The DI1 register lists "
             "three.",
    )
    group_code = fields.Char(string="Group", help="Group 1, Group 2 ...")
    total_lectures = fields.Integer(string="Total lectures", default=0)
    max_absences = fields.Integer(
        string="Maximum absences", default=2,
        help="NEBOSH condition. Above this, exam registration is blocked "
             "unless a manager records an override with a reason.",
    )
    attendance_threshold_pct = fields.Integer(
        string="Presence threshold (%)", default=75,
        help="Share of the lecture a learner must be connected for before "
             "the line counts as present.",
    )
    exam_registration_deadline = fields.Date(string="Exam registration deadline")
    camera_required = fields.Boolean(
        string="Camera required", default=False,
        help="Stated as cohort policy rather than hard-coded, so an auditor "
             "sees a written rule and any exemption carries a reason.",
    )

    zoom_session_ids = fields.One2many(
        "dhb.zoom.session", "event_id", string="Zoom sessions"
    )
    zoom_session_count = fields.Integer(compute="_compute_zoom_counts")
    pulled_session_count = fields.Integer(compute="_compute_zoom_counts")

    @api.depends("zoom_session_ids.state")
    def _compute_zoom_counts(self):
        for event in self:
            sessions = event.zoom_session_ids
            event.zoom_session_count = len(sessions)
            event.pulled_session_count = len(sessions.filtered(lambda s: s.state == "pulled"))

    @api.depends("seats_taken", "tutor_ids", "delivery_mode")
    def _compute_tutor_ratio(self):
        """NEBOSH caps classroom and virtual delivery at 20 learners per tutor.

        Computed rather than left to memory: exceeding it is a finding, and it
        creeps up quietly as late registrations come in.
        """
        for event in self:
            learners = len(event.registration_ids.filtered(
                lambda r: r.state not in ("cancel",)
            ))
            tutors = len(event.tutor_ids) or 1
            ratio = learners / tutors
            event.tutor_ratio = ratio
            capped = event.delivery_mode in ("full_time", "part_time", "virtual")
            if capped and ratio > 20:
                event.ratio_warning = _(
                    "%(ratio).0f learners per tutor — NEBOSH caps this mode at 20."
                ) % {"ratio": ratio}
            else:
                event.ratio_warning = False

    def action_open_zoom_sessions(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Zoom sessions"),
            "res_model": "dhb.zoom.session",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }

    def action_open_attendance(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Attendance"),
            "res_model": "dhb.attendance.line",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }

    def action_pull_all_sessions(self):
        self.ensure_one()
        self.zoom_session_ids.filtered(
            lambda s: s.state != "pulled"
        ).action_pull_attendance()
        return True
