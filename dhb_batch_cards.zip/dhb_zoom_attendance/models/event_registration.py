from odoo import models, fields, api, _
from odoo.exceptions import UserError


class EventRegistration(models.Model):
    """A learner on a cohort, with the attendance gate NEBOSH asks for."""

    _inherit = "dhb.batch.line"

    attendance_line_ids = fields.One2many(
        "dhb.attendance.line", "registration_id", string="Attendance"
    )
    lectures_attended = fields.Integer(
        compute="_compute_attendance_figures", store=True
    )
    absence_count = fields.Integer(
        string="Absences", compute="_compute_attendance_figures", store=True
    )
    attendance_pct = fields.Float(
        string="Attendance %", compute="_compute_attendance_figures", store=True,
        digits=(5, 1),
    )
    camera_required = fields.Boolean(
        string="Camera required",
        related="event_id.camera_required", store=True, readonly=False,
    )
    camera_exemption_reason = fields.Text(
        string="Camera exemption reason",
        help="Required when the cohort policy asks for camera on and this "
             "learner is exempt. A written reason is what makes the exemption "
             "defensible.",
    )

    can_register_exam = fields.Boolean(
        string="Eligible for exam", compute="_compute_can_register_exam", store=True
    )
    exam_override = fields.Boolean(string="Attendance requirement overridden")
    exam_override_by = fields.Many2one("res.users", string="Overridden by", readonly=True)
    exam_override_date = fields.Datetime(string="Overridden on", readonly=True)
    exam_override_reason = fields.Text(string="Override reason")

    @api.depends(
        "attendance_line_ids.present",
        "event_id.total_lectures",
        "event_id.zoom_session_ids.state",
    )
    def _compute_attendance_figures(self):
        for registration in self:
            lines = registration.attendance_line_ids
            attended = len(lines.filtered("present"))
            # Only lectures that have actually been pulled can count as a
            # missed lecture. A lecture nobody has pulled yet is unknown, not
            # an absence, and marking it absent would block learners wrongly.
            held = len(registration.event_id.zoom_session_ids.filtered(
                lambda s: s.state == "pulled"
            ))
            registration.lectures_attended = attended
            registration.absence_count = max(held - attended, 0)
            registration.attendance_pct = (attended / held * 100.0) if held else 0.0

    @api.depends("absence_count", "event_id.max_absences", "exam_override")
    def _compute_can_register_exam(self):
        for registration in self:
            limit = registration.event_id.max_absences or 0
            within_limit = (not limit) or registration.absence_count <= limit
            registration.can_register_exam = within_limit or registration.exam_override

    @api.constrains("exam_override", "exam_override_reason")
    def _check_override_reason(self):
        for registration in self:
            if registration.exam_override and not (registration.exam_override_reason or "").strip():
                raise UserError(_(
                    "An override needs a written reason. An auditor accepts a "
                    "documented exception; a silent one is a finding."
                ))

    @api.constrains("camera_required", "camera_exemption_reason")
    def _check_camera_exemption(self):
        for registration in self:
            policy = registration.event_id.camera_required
            if policy and not registration.camera_required:
                if not (registration.camera_exemption_reason or "").strip():
                    raise UserError(_(
                        "This cohort's policy asks for cameras on. Exempting a "
                        "learner needs a recorded reason."
                    ))

    def write(self, values):
        if "exam_override" in values:
            if values.get("exam_override"):
                values.setdefault("exam_override_by", self.env.user.id)
                values.setdefault("exam_override_date", fields.Datetime.now())
            else:
                values.setdefault("exam_override_by", False)
                values.setdefault("exam_override_date", False)
        return super().write(values)

    def action_open_attendance(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Attendance"),
            "res_model": "dhb.attendance.line",
            "view_mode": "list,form",
            "domain": [("registration_id", "=", self.id)],
        }
