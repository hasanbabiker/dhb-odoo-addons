{
    "name": "DHB Course Evaluation Survey",
    "version": "19.0.1.0.0",
    "summary": "End-of-course evaluation, sent automatically after the last lecture",
    "description": """
DHB Course Evaluation Survey
============================

The seventeen questions DHB already uses, as a native Odoo survey, sent to
each learner within hours of the final lecture — the point at which the course
is freshest and the response rate highest.

Named, not anonymous. A named response can be followed up when a learner
raises something serious, and NEBOSH asks what was done about a complaint, not
merely whether one was received. The survey says plainly that the answers do
not affect the learner's result, because NEBOSH marks the assessment and the
centre does not.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["survey", "event", "dhb_zoom_attendance"],
    "data": [
        "data/survey_data.xml",
        "data/mail_template.xml",
        "data/ir_cron.xml",
        "views/event_views.xml",
    ],
    "installable": True,
    "application": False,
}
