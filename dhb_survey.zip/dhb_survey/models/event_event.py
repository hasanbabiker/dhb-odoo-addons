import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class EventEventSurvey(models.Model):
    """Sends the course evaluation once the last lecture has finished.

    Timing is the whole point. Sent hours after the final session the course is
    still fresh and the response rate is high; sent a week later it is an
    admin chore and the answers thin out. So the send is driven by the last
    Zoom session's end time rather than by someone remembering.
    """

    _inherit = "event.event"

    evaluation_survey_id = fields.Many2one(
        "survey.survey", string="Evaluation survey",
        default=lambda self: self.env.ref(
            "dhb_survey.survey_course_evaluation", raise_if_not_found=False
        ),
    )
    evaluation_send_after_hours = fields.Integer(
        string="Send this many hours after the last lecture", default=3,
        help="Counted from the end of the final Zoom session.",
    )
    evaluation_sent = fields.Boolean(string="Evaluation sent", readonly=True, copy=False)
    evaluation_sent_date = fields.Datetime(readonly=True, copy=False)
    evaluation_response_count = fields.Integer(compute="_compute_evaluation_stats")
    evaluation_response_rate = fields.Float(compute="_compute_evaluation_stats")

    def _compute_evaluation_stats(self):
        UserInput = self.env["survey.user_input"]
        for event in self:
            if not event.evaluation_survey_id:
                event.evaluation_response_count = 0
                event.evaluation_response_rate = 0
                continue
            done = UserInput.search_count([
                ("survey_id", "=", event.evaluation_survey_id.id),
                ("dhb_event_id", "=", event.id),
                ("state", "=", "done"),
            ])
            invited = len(event.registration_ids.filtered(
                lambda r: r.state not in ("cancel",)
            ))
            event.evaluation_response_count = done
            event.evaluation_response_rate = (done / invited * 100) if invited else 0

    # ------------------------------------------------------------------
    def _last_lecture_end(self):
        """When the final session actually finished."""
        self.ensure_one()
        sessions = self.zoom_session_ids.filtered("end_time")
        if sessions:
            return max(sessions.mapped("end_time"))
        return self.date_end

    def action_send_evaluation(self):
        for event in self:
            event._send_evaluation(force=True)
        return True

    def _send_evaluation(self, force=False):
        self.ensure_one()
        survey = self.evaluation_survey_id
        if not survey:
            raise UserError(_("No evaluation survey is set on this cohort."))
        if self.evaluation_sent and not force:
            return False

        learners = self.registration_ids.filtered(
            lambda r: r.state not in ("cancel",) and r.partner_id and r.partner_id.email
        )
        if not learners:
            raise UserError(_("No learners with an email address on this cohort."))

        template = self.env.ref(
            "dhb_survey.mail_template_course_evaluation", raise_if_not_found=False
        )
        UserInput = self.env["survey.user_input"]
        sent = 0

        for registration in learners:
            partner = registration.partner_id
            existing = UserInput.search([
                ("survey_id", "=", survey.id),
                ("partner_id", "=", partner.id),
                ("dhb_event_id", "=", self.id),
            ], limit=1)
            if existing and existing.state == "done":
                continue

            user_input = existing or UserInput.create({
                "survey_id": survey.id,
                "partner_id": partner.id,
                "email": partner.email,
                "dhb_event_id": self.id,
            })

            if template:
                template.with_context(
                    survey_url=user_input.get_start_url(),
                    event_name=self.name,
                ).send_mail(user_input.id, force_send=False)
            sent += 1

        self.write({
            "evaluation_sent": True,
            "evaluation_sent_date": fields.Datetime.now(),
        })
        self.message_post(body=_(
            "Course evaluation sent to %s learners. If mail is not configured "
            "yet, the individual links are on each response record and can be "
            "sent by WhatsApp."
        ) % sent)
        return True

    @api.model
    def _cron_send_evaluations(self):
        """Send for any cohort whose last lecture finished long enough ago."""
        now = fields.Datetime.now()
        candidates = self.search([
            ("evaluation_sent", "=", False),
            ("evaluation_survey_id", "!=", False),
        ])
        for event in candidates:
            end = event._last_lecture_end()
            if not end:
                continue
            hours = (now - end).total_seconds() / 3600
            if 0 <= hours < event.evaluation_send_after_hours:
                continue
            if hours < 0:
                continue
            try:
                event._send_evaluation()
            except UserError as exc:
                _logger.info("Evaluation not sent for %s: %s", event.name, exc)
        return True

    def action_open_evaluation_results(self):
        self.ensure_one()
        if not self.evaluation_survey_id:
            raise UserError(_("No evaluation survey is set on this cohort."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Evaluation responses"),
            "res_model": "survey.user_input",
            "view_mode": "list,form",
            "domain": [
                ("survey_id", "=", self.evaluation_survey_id.id),
                ("dhb_event_id", "=", self.id),
            ],
        }


class SurveyUserInputEvent(models.Model):
    """Ties a response to the cohort it came from.

    Without this the responses pile into one survey with no way to tell which
    cohort or tutor they refer to, which is exactly the question quality
    assurance asks.
    """

    _inherit = "survey.user_input"

    dhb_event_id = fields.Many2one("event.event", string="Cohort", index=True)
    dhb_tutor_ids = fields.Many2many(
        related="dhb_event_id.tutor_ids", string="Tutors", store=True,
    )
    dhb_qualification = fields.Selection(
        related="dhb_event_id.qualification", string="Qualification", store=True,
    )
