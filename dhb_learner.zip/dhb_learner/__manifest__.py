{
    "name": "DHB Learner Record",
    "version": "19.0.1.0.0",
    "summary": "NEBOSH and IOSH learner fields on the contact record",
    "description": """
DHB Learner Record
==================

Turns a contact into an accreditation file.

Every field here comes from the NEBOSH Learner Registration Form, including
three that are easy to get wrong:

* Legal name is separate from the display name, because the display name is
  edited freely and a mistake in it ends up printed on a certificate.
* The email must be personal, not a work address. The form says so explicitly,
  and corporate clients send the employee's company address by default.
* The NEBOSH marketing box is inverted: ticking it means the learner does NOT
  want contact. Coding it the usual way reverses the learner's wish.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Contacts",
    "license": "LGPL-3",
    "depends": ["contacts", "event"],
    "data": [
        "views/res_partner_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
}
