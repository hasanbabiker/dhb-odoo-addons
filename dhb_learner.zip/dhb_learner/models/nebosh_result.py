from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbNeboshResult(models.Model):
    """One unit result, as NEBOSH publishes it on a Unit Result Notification.

    The fields follow the URN's own columns rather than a tidier scheme,
    because the URN is the document an auditor will hold. Two of its columns
    are easy to overlook and both matter:

    * Learning Partner is recorded *per unit*. A learner can pass DI2 here and
      DI1 elsewhere, and the URN says so.
    * High valid mark is not the last attempt's mark. After a resit the two
      differ, and it is the high valid mark that counts toward the award.
    """

    _name = "dhb.nebosh.result"
    _description = "NEBOSH unit result"
    _order = "exam_date desc, unit_code"
    _rec_name = "display_name"

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True, ondelete="cascade", index=True
    )
    learner_number = fields.Char(
        string="Learner number", related="partner_id.nebosh_learner_number",
        store=True, readonly=True,
    )
    qualification = fields.Char(
        string="Qualification",
        help="As printed on the URN, e.g. NEBOSH Level 6 International Diploma "
             "for Occupational Health and Safety Management Professionals.",
    )

    unit_code = fields.Char(string="Unit", required=True, index=True)
    unit_description = fields.Char(string="Description")

    mark = fields.Integer(string="Mark")
    high_valid_mark = fields.Integer(
        string="High valid mark",
        help="The best valid mark for this unit. After a resit this differs "
             "from the mark above, and it is this one that counts.",
    )
    status = fields.Selection(
        [
            ("pass", "Pass"),
            ("refer", "Refer"),
            ("absent", "Absent"),
            ("void", "Void"),
            ("pending", "Pending"),
        ],
        string="Status",
        required=True,
        index=True,
        help="NEBOSH says Refer, not Fail — a refer is a resit, not the end "
             "of the qualification.",
    )
    unit_result = fields.Char(
        string="Unit result",
        help="The overall unit outcome as printed on the URN.",
    )

    exam_date = fields.Date(string="Exam date")
    results_expected = fields.Date(string="Results expected")
    issued_date = fields.Date(
        string="URN issued", help="The date printed at the top of the notification."
    )

    delivered_by_dhb = fields.Boolean(
        string="Studied with DHB", default=True,
        help="The URN names the Learning Partner per unit. A unit shown as "
             "'Other' was taken elsewhere and carries over as an exemption.",
    )
    learning_partner = fields.Char(
        string="Learning Partner on the URN", default="1708"
    )

    sitting_id = fields.Many2one(
        "dhb.nebosh.sitting", string="Sitting",
        help="Links the result to the published timetable, so the EAR "
             "deadline follows automatically.",
    )
    ear_deadline = fields.Date(
        related="sitting_id.ear_deadline", string="EAR closes", store=True,
    )
    days_to_ear = fields.Integer(compute="_compute_days_to_ear")
    ear_requested = fields.Boolean(string="EAR requested")
    ear_requested_date = fields.Date(string="EAR requested on")

    urn_file = fields.Binary(string="URN", attachment=True, copy=False)
    urn_filename = fields.Char(copy=False)

    needs_resit = fields.Boolean(compute="_compute_needs_resit", store=True)
    display_name = fields.Char(compute="_compute_display_name", store=True)

    _sql_constraints = [
        ("unique_unit_attempt", "unique(partner_id, unit_code, exam_date)",
         "That learner already has a result for that unit on that date."),
    ]

    @api.depends("partner_id.display_name", "unit_code", "status", "mark")
    def _compute_display_name(self):
        for result in self:
            result.display_name = "%s — %s %s (%s)" % (
                result.partner_id.display_name or "?",
                result.unit_code or "?",
                result.mark or "",
                dict(self._fields["status"].selection).get(result.status, "?"),
            )

    @api.depends("status")
    def _compute_needs_resit(self):
        for result in self:
            result.needs_resit = result.status in ("refer", "absent")

    def _compute_days_to_ear(self):
        today = fields.Date.today()
        for result in self:
            result.days_to_ear = (
                (result.ear_deadline - today).days if result.ear_deadline else 0
            )

    @api.onchange("unit_code", "exam_date")
    def _onchange_find_sitting(self):
        """Match the result to its published sitting by unit and exam date."""
        for result in self:
            if not (result.unit_code and result.exam_date):
                continue
            sitting = self.env["dhb.nebosh.sitting"].search([
                ("unit_code", "ilike", result.unit_code),
                ("assessment_date", "=", result.exam_date),
            ], limit=1)
            if not sitting:
                sitting = self.env["dhb.nebosh.sitting"].search([
                    ("unit_code", "ilike", result.unit_code),
                    ("assessment_date", "<=", result.exam_date),
                ], order="assessment_date desc", limit=1)
            result.sitting_id = sitting


class ResPartnerResults(models.Model):
    _inherit = "res.partner"

    nebosh_result_ids = fields.One2many(
        "dhb.nebosh.result", "partner_id", string="NEBOSH results"
    )
    nebosh_result_count = fields.Integer(compute="_compute_result_summary")
    units_passed = fields.Char(compute="_compute_result_summary", store=True)
    units_referred = fields.Char(compute="_compute_result_summary", store=True)
    has_open_ear_window = fields.Boolean(
        compute="_compute_result_summary", store=True,
        string="EAR window open",
    )

    @api.depends("nebosh_result_ids.status", "nebosh_result_ids.ear_deadline")
    def _compute_result_summary(self):
        today = fields.Date.today()
        for partner in self:
            results = partner.nebosh_result_ids
            partner.nebosh_result_count = len(results)
            partner.units_passed = ", ".join(
                results.filtered(lambda r: r.status == "pass").mapped("unit_code")
            )
            partner.units_referred = ", ".join(
                results.filtered(lambda r: r.status in ("refer", "absent")).mapped("unit_code")
            )
            partner.has_open_ear_window = any(
                r.ear_deadline and r.ear_deadline >= today and r.status == "refer"
                and not r.ear_requested
                for r in results
            )

    def action_open_results(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("NEBOSH results"),
            "res_model": "dhb.nebosh.result",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
            "context": {"default_partner_id": self.id},
        }
