import base64
import io
import logging
import os
import shutil
import subprocess
import tempfile

from odoo import models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

TEMPLATE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "static", "src", "doc", "NEBOSH_Learner_Record_Merge_Form_V4.docx",
)

# Row and column of every cell we write into, read off the official V4 form.
# Writing into the real document rather than redrawing it is the only way the
# output is genuinely identical: every border, font and logo stays untouched
# because nothing about the layout is recreated.
CELLS = {
    "forenames": (3, 2),
    "surname": (4, 2),
    "naming_format": (5, 2),
    "dob": (15, 2),
    "email": (17, 2),
    "mobile": (20, 3),
    "home": (20, 8),
    "work": (20, 14),
    "address1": (22, 2),
    "address2": (23, 2),
    "address3": (24, 2),
    "area": (25, 2),
    "country": (26, 2),
    "postcode": (27, 2),
    "other_id": (31, 6),
}

# Additional learner numbers: 1-4 down the left column, 5-8 down the right.
NUMBER_CELLS = [
    (9, 0), (10, 0), (11, 0), (12, 0),
    (9, 1), (10, 1), (11, 1), (12, 1),
]

PRIOR_CELLS = {
    "provider": (9, 12),
    "qualification": (10, 12),
    "units": (11, 12),
    "year": (12, 12),
}

TITLE_CELLS = {
    "Mr": (1, 2), "Mrs": (1, 4), "Miss": (1, 7),
    "Ms": (1, 10), "Other": (1, 13), "N/A": (1, 16),
}

ID_CELLS = {
    "Passport": (30, 0), "Drivers Licence": (30, 3),
    "PAN Card": (30, 6), "Aadhar Card": (30, 11), "Other": (30, 15),
}

TICK = "\u2612"   # ballot box with X


class ResPartnerMergeDoc(models.Model):
    _inherit = "res.partner"

    # ------------------------------------------------------------------
    def _merge_doc_values(self):
        """Everything that goes into the form, keyed by cell name."""
        self.ensure_one()

        def up(value):
            return (value or "").strip().upper()

        prior_provider = " / ".join(filter(None, [
            self.prior_provider_name, self.prior_provider_number
        ]))

        return {
            "forenames": up(self.legal_forenames),
            "surname": up(self.legal_surname),
            "naming_format": up(self.certificate_name_format or self.legal_name),
            "dob": self.date_of_birth.strftime("%d/%m/%Y") if self.date_of_birth else "",
            "email": up(self.email),
            "mobile": (self.mobile_phone or self.phone or "").strip(),
            "home": (self.home_phone or "").strip(),
            "work": (self.work_phone or "").strip(),
            "address1": up(self.street),
            "address2": up(self.street2),
            "address3": "",
            "area": up(self.city),
            "country": up(self.country_id.name),
            "postcode": up(self.zip) or "N/A",
            "other_id": up(self.id_document_other),
            "_prior": {
                "provider": prior_provider,
                "qualification": self.prior_qualification or "",
                "units": self.prior_units_passed or "",
                "year": self.prior_year_of_study or "",
            },
        }

    def _merge_build_docx(self):
        """Open the official template and type the learner's details into it."""
        self.ensure_one()
        try:
            from docx import Document
        except ImportError as exc:
            raise UserError(_(
                "The python-docx library is missing from the Odoo container.\n\n"
                "Install it with:\n"
                "docker exec -u root odoo pip install python-docx "
                "--break-system-packages\n\n"
                "Note that a container rebuild removes it again."
            )) from exc

        template = TEMPLATE_PATH
        if not os.path.exists(template):
            raise UserError(_(
                "The official merge form template is missing from the module."
            ))

        document = Document(template)
        table = document.tables[0]
        values = self._merge_doc_values()

        def write(row, col, text, bold=True):
            if not text:
                return
            cell = table.cell(row, col)
            # Keep the template's own run formatting: clear the text of the
            # first run and reuse it, rather than replacing the paragraph.
            paragraph = cell.paragraphs[0]
            if paragraph.runs:
                paragraph.runs[0].text = text
                paragraph.runs[0].bold = bold
                for extra in paragraph.runs[1:]:
                    extra.text = ""
            else:
                run = paragraph.add_run(text)
                run.bold = bold

        for key, (row, col) in CELLS.items():
            write(row, col, values.get(key, ""))

        for key, (row, col) in PRIOR_CELLS.items():
            write(row, col, values["_prior"].get(key, ""))

        for index, number in enumerate(self._merge_numbers_list()[:8]):
            row, col = NUMBER_CELLS[index]
            label = "%s. %s" % (index + 1 if index < 4 else index + 1, number)
            cell = table.cell(row, col)
            paragraph = cell.paragraphs[0]
            if paragraph.runs:
                paragraph.runs[0].text = label
                paragraph.runs[0].bold = True
                for extra in paragraph.runs[1:]:
                    extra.text = ""
            else:
                paragraph.add_run(label).bold = True

        # Tick boxes: replace the empty box glyph with a crossed one.
        chosen_title = self.learner_title if self.learner_title in TITLE_CELLS else "Other"
        self._merge_tick(table, TITLE_CELLS.get(chosen_title))
        self._merge_tick(table, ID_CELLS.get(self._merge_id_label()))

        buffer = io.BytesIO()
        document.save(buffer)
        return buffer.getvalue()

    def _merge_tick(self, table, position):
        if not position:
            return
        row, col = position
        cell = table.cell(row, col)
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                if "\u2610" in run.text:
                    run.text = run.text.replace("\u2610", TICK)
                    return
        # No empty box found in the template run: prefix the label instead.
        paragraph = cell.paragraphs[0]
        if paragraph.runs:
            paragraph.runs[0].text = TICK + " " + paragraph.runs[0].text

    # ------------------------------------------------------------------
    def _merge_docx_to_pdf(self, docx_bytes):
        """Convert with LibreOffice, which the container must provide."""
        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        if not soffice:
            raise UserError(_(
                "LibreOffice is not available in the Odoo container, so the "
                "filled form cannot be turned into a PDF.\n\n"
                "Install it with:\n"
                "docker exec -u root odoo apt-get install -y libreoffice-writer\n\n"
                "Note that a container rebuild removes it again. Meanwhile you "
                "can download the Word version and save it as PDF yourself."
            ))

        with tempfile.TemporaryDirectory() as workdir:
            source = os.path.join(workdir, "merge_form.docx")
            with open(source, "wb") as handle:
                handle.write(docx_bytes)
            try:
                subprocess.run(
                    [soffice, "--headless", "--norestore",
                     "--convert-to", "pdf", "--outdir", workdir, source],
                    check=True, capture_output=True, timeout=120,
                    env={**os.environ, "HOME": workdir},
                )
            except subprocess.TimeoutExpired as exc:
                raise UserError(_("LibreOffice timed out converting the form.")) from exc
            except subprocess.CalledProcessError as exc:
                _logger.error("soffice failed: %s", exc.stderr[:500])
                raise UserError(_(
                    "LibreOffice could not convert the form:\n%s"
                ) % (exc.stderr or b"")[:400].decode(errors="replace")) from exc

            produced = os.path.join(workdir, "merge_form.pdf")
            if not os.path.exists(produced):
                raise UserError(_("LibreOffice produced no PDF."))
            with open(produced, "rb") as handle:
                return handle.read()

    # ------------------------------------------------------------------
    def action_merge_form_docx(self):
        """Download the filled form as Word, for when LibreOffice is absent."""
        self.ensure_one()
        self._merge_check_ready()
        content = self._merge_build_docx()
        return self._merge_attach(content, "docx",
                                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document")

    def action_print_merge_form(self):
        """The official form, filled and converted, with the ID appended."""
        self.ensure_one()
        self._merge_check_ready()

        pdf_content = self._merge_docx_to_pdf(self._merge_build_docx())
        pdf_content = self._merge_append_id(pdf_content)
        return self._merge_attach(pdf_content, "pdf", "application/pdf")

    def _merge_check_ready(self):
        if not self.needs_record_merge:
            raise UserError(_(
                "This learner holds a single NEBOSH number, so there is "
                "nothing to merge. Record the additional numbers first."
            ))

    def _merge_append_id(self, pdf_content):
        """Put the identity document into the same file.

        NEBOSH receives one attachment rather than a form and a loose scan
        that can be separated in transit.
        """
        self.ensure_one()
        if not self.id_document_file:
            return pdf_content
        try:
            from odoo.tools.pdf import merge_pdf
            if self._merge_id_is_pdf():
                return merge_pdf([pdf_content, base64.b64decode(self.id_document_file)])
            return merge_pdf([pdf_content, self._merge_id_image_pdf()])
        except Exception:  # noqa: BLE001
            _logger.exception("Could not append the ID document for partner %s", self.id)
            self.message_post(body=_(
                "The merge form was produced, but the identity document could "
                "not be appended. Attach it by hand before sending to NEBOSH."
            ))
            return pdf_content

    def _merge_id_image_pdf(self):
        """Wrap the ID image in a one-page PDF so it can be merged."""
        self.ensure_one()
        html = self.env["ir.qweb"]._render(
            "dhb_learner.report_merge_id_page", {"partner": self}
        )
        return self.env["ir.actions.report"]._run_wkhtmltopdf([html])

    def _merge_attach(self, content, extension, mimetype):
        self.ensure_one()
        filename = "NEBOSH_Merge_Form_%s.%s" % (
            (self.legal_name or self.name or "learner").replace(" ", "_"), extension
        )
        attachment = self.env["ir.attachment"].create({
            "name": filename,
            "type": "binary",
            "datas": base64.b64encode(content),
            "res_model": "res.partner",
            "res_id": self.id,
            "mimetype": mimetype,
        })
        self.message_post(
            body=_("Merge form generated for submission to NEBOSH."),
            attachment_ids=[attachment.id],
        )
        return {
            "type": "ir.actions.act_url",
            "url": "/web/content/%s?download=true" % attachment.id,
            "target": "self",
        }
