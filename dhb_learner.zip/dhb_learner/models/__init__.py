from . import res_partner
from . import merge_form_doc
