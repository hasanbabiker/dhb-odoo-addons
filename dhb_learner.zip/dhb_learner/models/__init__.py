from . import nebosh_data
from . import res_partner
from . import merge_form_doc
from . import enrolment_form_pdf
