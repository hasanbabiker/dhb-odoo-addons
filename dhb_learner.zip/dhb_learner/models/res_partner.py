import base64
import logging
import re

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

# Free-mail domains are fine: NEBOSH asks for a personal address, and these
# are exactly that. What the form rules out is a work or company address.
PERSONAL_DOMAINS = {
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.co.uk", "ymail.com",
    "hotmail.com", "outlook.com", "live.com", "msn.com", "icloud.com",
    "me.com", "mac.com", "aol.com", "protonmail.com", "proton.me",
    "zoho.com", "mail.com", "gmx.com", "yandex.com", "hotmail.co.uk",
}

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ResPartner(models.Model):
    """A contact that can also be a NEBOSH or IOSH learner."""

    _inherit = "res.partner"

    is_learner = fields.Boolean(
        string="Is a learner", index=True,
        help="Shows the learner section and brings the contact into learner "
             "reports and evidence packs.",
    )

    # ------------------------------------------------------------------
    # identity as the awarding body wants it
    # ------------------------------------------------------------------
    # The eleven titles the NEBOSH import template accepts, verbatim.
    # Anything outside this list is rejected on upload.
    learner_title = fields.Selection(
        [
            ("Mr", "Mr"),
            ("Mrs", "Mrs"),
            ("Miss", "Miss"),
            ("Ms", "Ms"),
            ("Dr", "Dr"),
            ("Eur-Ing", "Eur-Ing"),
            ("Captain", "Captain"),
            ("Professor", "Professor"),
            ("Dept", "Dept"),
            ("Sir", "Sir"),
            ("Reverend", "Reverend"),
        ],
        string="Title",
        help="Collected on the NEBOSH form but never printed on the "
             "certificate. The stored value is exactly what the import "
             "template expects.",
    )
    # NEBOSH imports forenames and surname as separate columns, and the two
    # cannot be derived from one string: in "Ahmed Mohammed Musa Mohammed"
    # there is no rule that says which part is the family name. So they are
    # captured separately and the full name is assembled from them.
    legal_forenames = fields.Char(
        string="Forenames / given names",
        tracking=True,
        help="Exactly as on the identity document.",
    )
    legal_surname = fields.Char(
        string="Surname / family name",
        tracking=True,
        help="Exactly as on the identity document. This is what NEBOSH files "
             "the learner under.",
    )
    legal_name = fields.Char(
        string="Full legal name",
        compute="_compute_legal_name",
        store=True,
        readonly=True,
        help="Assembled from forenames and surname. This is the name printed "
             "on the certificate.",
    )
    legal_name_locked = fields.Boolean(
        string="Legal name locked", readonly=True, copy=False,
        help="Set once the learner has been registered with the awarding "
             "body. After that the name can only change through a formal "
             "amendment.",
    )
    legal_name_locked_by = fields.Many2one("res.users", readonly=True, copy=False)
    legal_name_locked_date = fields.Datetime(readonly=True, copy=False)

    nebosh_learner_number = fields.Char(
        string="NEBOSH learner number", index=True, copy=False,
        help="Follows the person across IGC, Diploma and any resit, so it "
             "belongs on the contact rather than on a single course.",
    )
    iosh_learner_number = fields.Char(string="IOSH learner number", copy=False)

    # A learner who studied the IGC with another provider and came here for
    # the Diploma often holds a second NEBOSH number, and their two records
    # sit apart until NEBOSH merges them. The merge form takes up to eight
    # extra numbers, so one field with a unique constraint is not enough.
    nebosh_numbers_additional = fields.Char(
        string="Other NEBOSH numbers",
        help="Any further numbers the learner holds, separated by commas. "
             "These are what a Learner Record Merge Form asks for. Ask the "
             "learner directly — they often do not volunteer an old number.",
    )
    needs_record_merge = fields.Boolean(
        compute="_compute_needs_record_merge", store=True,
        string="Record merge needed",
        help="Flagged when the learner holds more than one NEBOSH number.",
    )

    certificate_name_format = fields.Char(
        string="Name as it should appear on the certificate",
        help="The merge form asks for this separately from first name and "
             "surname, because the order and which parts appear is a "
             "decision, not something that can be derived. Long Arabic names "
             "are the common case.",
    )

    prior_provider_name = fields.Char(string="Previous learning partner")
    prior_provider_number = fields.Char(string="Previous LP number")
    prior_qualification = fields.Char(string="Qualification studied")
    prior_units_passed = fields.Char(string="Units passed")
    prior_year_of_study = fields.Char(string="Year of study")

    date_of_birth = fields.Date(string="Date of birth")
    age_years = fields.Integer(string="Age", compute="_compute_age_years")
    nationality_id = fields.Many2one("res.country", string="Nationality")
    # NEBOSH accepts Male, Female or Unspecified. Anything else fails the
    # upload, so the field cannot offer options the template will reject.
    gender = fields.Selection(
        [
            ("Male", "Male"),
            ("Female", "Female"),
            ("Unspecified", "Unspecified"),
        ],
        string="Gender",
    )

    # ------------------------------------------------------------------
    # consent, with the inverted box kept inverted
    # ------------------------------------------------------------------
    nebosh_consent = fields.Boolean(
        string="Consents to NEBOSH registration",
        help="The learner confirms their details may be used to register them "
             "for a NEBOSH qualification.",
    )
    nebosh_consent_date = fields.Datetime(string="Consent recorded", readonly=True)
    nebosh_marketing_opt_out = fields.Boolean(
        string="Opted OUT of NEBOSH marketing",
        help="The form asks the learner to TICK the box to refuse marketing. "
             "The field is named for what a tick means, so nobody later reads "
             "it as consent and reverses the learner's wish.",
    )

    # ------------------------------------------------------------------
    # identity document
    # ------------------------------------------------------------------
    id_document_type = fields.Selection(
        [
            ("passport", "Passport"),
            ("driving_licence", "Driving licence"),
            ("national_id", "National ID card"),
            ("birth_certificate", "Birth certificate"),
            ("other", "Other"),
        ],
        string="ID document type",
        help="The five options NEBOSH lists. A residence permit goes under "
             "Other, with the type written out.",
    )
    id_document_other = fields.Char(string="Other document type")
    id_document_number = fields.Char(string="ID number", copy=False)
    id_document_expiry = fields.Date(string="ID expiry")
    id_document_file = fields.Binary(string="ID document", attachment=True, copy=False)
    id_document_filename = fields.Char(string="ID filename", copy=False)
    id_expiry_state = fields.Selection(
        [
            ("none", "No expiry recorded"),
            ("valid", "Valid"),
            ("soon", "Expires within 90 days"),
            ("expired", "Expired"),
        ],
        compute="_compute_id_expiry_state",
        store=True,
        string="ID status",
    )

    id_verified = fields.Boolean(string="Identity verified", copy=False)
    id_verified_by = fields.Many2one("res.users", string="Verified by", readonly=True, copy=False)
    id_verified_date = fields.Date(string="Verified on", readonly=True, copy=False)

    # Odoo 19 merged mobile into phone, but the NEBOSH template keeps three
    # separate numbers, so they are captured explicitly.
    work_phone = fields.Char(string="Work phone")
    home_phone = fields.Char(string="Home phone")
    mobile_phone = fields.Char(string="Mobile phone")

    mail_address_type = fields.Selection(
        [("H", "Home"), ("W", "Work")],
        string="Correspondence address",
        default="H",
        help="Which address NEBOSH should write to. Exported as H or W.",
    )
    nebosh_nationality = fields.Char(
        string="NEBOSH nationality",
        help="Must match one of the 148 nationalities the import template "
             "accepts — Sudanese, Egyptian, British, and so on. The country "
             "field is separate and uses the country list.",
    )

    work_email_accepted = fields.Boolean(
        string="Work email accepted",
        help="Tick only when the learner has confirmed this really is their "
             "own address. Record why in the chatter.",
    )

    photo_verified = fields.Boolean(
        string="Photo verified", copy=False,
        help="The personal photograph is stored in the standard contact image "
             "field, not a separate one.",
    )

    # ------------------------------------------------------------------
    # completeness, so gaps are visible before an audit finds them
    # ------------------------------------------------------------------
    learner_file_complete = fields.Boolean(
        compute="_compute_learner_file", store=True, string="File complete"
    )
    learner_file_missing = fields.Char(
        compute="_compute_learner_file", store=True, string="Missing"
    )

    registration_ids = fields.One2many(
        "event.registration", "partner_id", string="Course registrations"
    )
    registration_count = fields.Integer(compute="_compute_registration_count")

    _sql_constraints = [
        (
            "unique_nebosh_number",
            "unique(nebosh_learner_number)",
            "That NEBOSH learner number is already on another contact. "
            "Duplicate learner records are the usual cause of a split "
            "attendance file.",
        ),
    ]

    # ------------------------------------------------------------------
    # computes
    # ------------------------------------------------------------------
    @api.depends("nebosh_learner_number", "nebosh_numbers_additional")
    def _compute_needs_record_merge(self):
        for partner in self:
            extras = [n.strip() for n in (partner.nebosh_numbers_additional or "").split(",")]
            extras = [n for n in extras if n]
            partner.needs_record_merge = bool(partner.nebosh_learner_number and extras)

    @api.depends("legal_forenames", "legal_surname")
    def _compute_legal_name(self):
        for partner in self:
            parts = [partner.legal_forenames, partner.legal_surname]
            partner.legal_name = " ".join(p.strip() for p in parts if p and p.strip())

    @api.depends("date_of_birth")
    def _compute_age_years(self):
        today = fields.Date.today()
        for partner in self:
            if partner.date_of_birth:
                born = partner.date_of_birth
                partner.age_years = today.year - born.year - (
                    (today.month, today.day) < (born.month, born.day)
                )
            else:
                partner.age_years = 0

    @api.depends("id_document_expiry")
    def _compute_id_expiry_state(self):
        today = fields.Date.today()
        for partner in self:
            expiry = partner.id_document_expiry
            if not expiry:
                partner.id_expiry_state = "none"
            elif expiry < today:
                partner.id_expiry_state = "expired"
            elif (expiry - today).days <= 90:
                partner.id_expiry_state = "soon"
            else:
                partner.id_expiry_state = "valid"

    @api.depends(
        "is_learner", "legal_forenames", "legal_surname", "date_of_birth", "email", "phone",
        "nationality_id", "id_document_type", "id_document_number",
        "id_document_file", "id_verified", "image_1920", "nebosh_consent",
    )
    def _compute_learner_file(self):
        for partner in self:
            if not partner.is_learner:
                partner.learner_file_complete = False
                partner.learner_file_missing = False
                continue

            missing = []
            if not partner.legal_forenames:
                missing.append(_("forenames"))
            if not partner.legal_surname:
                missing.append(_("surname"))
            if not partner.date_of_birth:
                missing.append(_("date of birth"))
            if not partner.email:
                missing.append(_("email"))
            if not partner.phone:
                missing.append(_("phone"))
            if not partner.nationality_id:
                missing.append(_("nationality"))
            if not partner.id_document_type:
                missing.append(_("ID type"))
            if not partner.id_document_number:
                missing.append(_("ID number"))
            if not partner.id_document_file:
                missing.append(_("ID scan"))
            if not partner.id_verified:
                missing.append(_("ID verification"))
            if not partner.image_1920:
                missing.append(_("photograph"))
            if not partner.nebosh_consent:
                missing.append(_("consent"))

            partner.learner_file_missing = ", ".join(missing)
            partner.learner_file_complete = not missing

    def _compute_registration_count(self):
        for partner in self:
            partner.registration_count = len(partner.registration_ids)

    # ------------------------------------------------------------------
    # constraints
    # ------------------------------------------------------------------
    @api.constrains("is_learner", "email", "work_email_accepted")
    def _check_personal_email(self):
        """NEBOSH asks for a personal address, not a work one.

        Enforced as a warning-shaped error rather than a silent acceptance,
        because a corporate address is the single most common reason a learner
        stops receiving awarding-body correspondence after leaving the job.
        """
        for partner in self:
            if not (partner.is_learner and partner.email):
                continue
            email = partner.email.strip().lower()
            if not EMAIL_RE.match(email):
                raise ValidationError(_("“%s” is not a valid email address.") % partner.email)
            domain = email.rsplit("@", 1)[-1]
            if domain in PERSONAL_DOMAINS:
                continue
            if partner.work_email_accepted or self.env.context.get("allow_work_email"):
                continue
            raise ValidationError(_(
                "The NEBOSH registration form asks for a personal email "
                "address, not a work one, and “%(domain)s” looks like a "
                "company domain.\n\n"
                "If this genuinely is the learner's own address, tick "
                "“Work email accepted” and record why.",
                domain=domain,
            ))

    @api.constrains("id_document_type", "id_document_other")
    def _check_other_document(self):
        for partner in self:
            if partner.id_document_type == "other" and not (partner.id_document_other or "").strip():
                raise ValidationError(_(
                    "When the document type is Other, write out what it "
                    "actually is. A residence permit recorded as “Other” with "
                    "no detail tells an auditor nothing."
                ))

    @api.constrains("date_of_birth")
    def _check_date_of_birth(self):
        today = fields.Date.today()
        for partner in self:
            dob = partner.date_of_birth
            if not dob:
                continue
            if dob >= today:
                raise ValidationError(_("The date of birth is in the future."))
            age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
            if age < 14:
                raise ValidationError(_(
                    "That date of birth makes the learner %s years old. "
                    "Check the year — this is almost always a typing slip, and "
                    "a wrong date of birth is rejected by the awarding body."
                ) % age)
            if age > 100:
                raise ValidationError(_(
                    "That date of birth makes the learner %s years old. "
                    "Check the year."
                ) % age)

    # ------------------------------------------------------------------
    # write guards
    # ------------------------------------------------------------------
    def write(self, values):
        if "legal_forenames" in values or "legal_surname" in values:
            locked = self.filtered("legal_name_locked")
            if locked and not self.env.context.get("allow_legal_name_change"):
                raise UserError(_(
                    "The legal name is locked for %(names)s because the learner "
                    "has been registered with the awarding body. Changing it "
                    "now would put a different name on the certificate than the "
                    "one registered.\n\n"
                    "Use Unlock legal name, which records who changed it and "
                    "why.",
                    names=", ".join(locked.mapped("display_name")),
                ))

        if values.get("nebosh_consent"):
            values.setdefault("nebosh_consent_date", fields.Datetime.now())
        elif "nebosh_consent" in values and not values["nebosh_consent"]:
            values.setdefault("nebosh_consent_date", False)

        if "id_verified" in values:
            if values["id_verified"]:
                values.setdefault("id_verified_by", self.env.user.id)
                values.setdefault("id_verified_date", fields.Date.today())
            else:
                values.setdefault("id_verified_by", False)
                values.setdefault("id_verified_date", False)

        return super().write(values)

    # ------------------------------------------------------------------
    # actions
    # ------------------------------------------------------------------
    def action_lock_legal_name(self):
        for partner in self:
            if not partner.legal_name:
                raise UserError(_("There is no legal name to lock."))
            partner.write({
                "legal_name_locked": True,
                "legal_name_locked_by": self.env.user.id,
                "legal_name_locked_date": fields.Datetime.now(),
            })
            partner.message_post(body=_(
                "Legal name locked as “%s” following registration with the "
                "awarding body."
            ) % partner.legal_name)
        return True

    def action_unlock_legal_name(self):
        for partner in self:
            partner.with_context(allow_legal_name_change=True).write({
                "legal_name_locked": False,
                "legal_name_locked_by": False,
                "legal_name_locked_date": False,
            })
            partner.message_post(body=_(
                "Legal name unlocked by %s. Record the reason and the "
                "awarding-body amendment reference in this thread."
            ) % self.env.user.name)
        return True

    def action_copy_name_to_legal(self):
        """Seed the legal name from the display name.

        The split is a guess — last word as surname — and is offered only as a
        starting point. An auditor sees the certificate name, so it must be
        checked against the ID document before the record is locked.
        """
        for partner in self.filtered(lambda p: not (p.legal_forenames or p.legal_surname)):
            parts = (partner.name or "").split()
            if not parts:
                continue
            if len(parts) == 1:
                partner.legal_surname = parts[0]
            else:
                partner.legal_forenames = " ".join(parts[:-1])
                partner.legal_surname = parts[-1]
        return True

    def action_certificate_name_from_legal(self):
        """Seed the certificate name from the legal name parts."""
        for partner in self.filtered(lambda p: not p.certificate_name_format):
            partner.certificate_name_format = partner.legal_name
        return True

    # ------------------------------------------------------------------
    # merge form helpers
    # ------------------------------------------------------------------
    def _merge_other_title(self):
        """Whatever goes in the form's 'if other' box for the title."""
        self.ensure_one()
        standard = ("Mr", "Mrs", "Miss", "Ms", "N/A")
        return self.learner_title if self.learner_title and self.learner_title not in standard else ""

    def _merge_prior_rows(self):
        """The four Previously Studied rows, in the form's own order."""
        self.ensure_one()
        partner_label = " / ".join(filter(None, [
            self.prior_provider_name, self.prior_provider_number
        ]))
        return [
            ("Learning Partner Name/Number:", partner_label),
            ("Qualification Name:", self.prior_qualification or ""),
            ("Passed Units:", self.prior_units_passed or ""),
            ("Year of Study:", self.prior_year_of_study or ""),
        ]

    def _merge_address_rows(self):
        """The six address rows, upper-cased as the form asks."""
        self.ensure_one()
        values = [
            ("Address Line 1:", self.street or ""),
            ("Address Line 2:", self.street2 or ""),
            ("Address Line 3:", ""),
            ("Area:", self.city or ""),
            ("Country:", self.country_id.name or ""),
            ("Postcode (UK):", self.zip or "N/A"),
        ]
        return [(label, value.upper() if value else "") for label, value in values]

    def _merge_numbers_list(self):
        """Every NEBOSH number except the primary one, in form order."""
        self.ensure_one()
        raw = (self.nebosh_numbers_additional or "").replace(";", ",")
        return [n.strip() for n in raw.split(",") if n.strip()]

    def _merge_id_is_pdf(self):
        self.ensure_one()
        name = (self.id_document_filename or "").lower()
        return name.endswith(".pdf")

    def _merge_id_label(self):
        """Map our document type onto the merge form's own list.

        NEBOSH uses a different set of options on this form than on the
        registration form — it adds the Indian PAN and Aadhar cards and drops
        national ID and birth certificate. Anything without a match on this
        particular form falls under Other, with the real type written out.
        """
        self.ensure_one()
        mapping = {
            "passport": "Passport",
            "driving_licence": "Drivers Licence",
        }
        return mapping.get(self.id_document_type, "Other")

    def action_print_merge_form(self):
        """Render the merge form and append the ID document when it is a PDF.

        An image ID is placed in the report itself by the template. A PDF one
        cannot be, so the two files are joined here — the point being that
        NEBOSH receives a single attachment rather than a form and a loose
        scan that can be separated in transit.
        """
        self.ensure_one()
        if not self.needs_record_merge:
            raise UserError(_(
                "This learner holds a single NEBOSH number, so there is "
                "nothing to merge. Record the additional numbers first."
            ))

        report = self.env.ref("dhb_learner.action_report_merge_form")
        pdf_content, _dummy = report._render_qweb_pdf(
            "dhb_learner.report_merge_form_document", res_ids=self.ids
        )

        if self.id_document_file and self._merge_id_is_pdf():
            try:
                from odoo.tools.pdf import merge_pdf
                pdf_content = merge_pdf([
                    pdf_content,
                    base64.b64decode(self.id_document_file),
                ])
            except Exception:  # noqa: BLE001
                _logger.exception(
                    "Could not append the ID document for partner %s; the form "
                    "is returned on its own.", self.id
                )
                self.message_post(body=_(
                    "The merge form was produced, but the identity document "
                    "could not be appended automatically. Attach it by hand "
                    "before sending to NEBOSH."
                ))

        filename = "NEBOSH_Merge_Form_%s.pdf" % (
            (self.legal_name or self.name or "learner").replace(" ", "_")
        )
        attachment = self.env["ir.attachment"].create({
            "name": filename,
            "type": "binary",
            "datas": base64.b64encode(pdf_content),
            "res_model": "res.partner",
            "res_id": self.id,
            "mimetype": "application/pdf",
        })
        self.message_post(
            body=_("Merge form generated for submission to NEBOSH."),
            attachment_ids=[attachment.id],
        )
        return {
            "type": "ir.actions.act_url",
            "url": "/web/content/%s?download=true" % attachment.id,
            "target": "self",
        }

    def action_open_registrations(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Registrations"),
            "res_model": "event.registration",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
        }
