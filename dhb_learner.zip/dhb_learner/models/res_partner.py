import logging
import re

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

# Free-mail domains are fine: NEBOSH asks for a personal address, and these
# are exactly that. What the form rules out is a work or company address.
PERSONAL_DOMAINS = {
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.co.uk", "ymail.com",
    "hotmail.com", "outlook.com", "live.com", "msn.com", "icloud.com",
    "me.com", "mac.com", "aol.com", "protonmail.com", "proton.me",
    "zoho.com", "mail.com", "gmx.com", "yandex.com", "hotmail.co.uk",
}

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ResPartner(models.Model):
    """A contact that can also be a NEBOSH or IOSH learner."""

    _inherit = "res.partner"

    is_learner = fields.Boolean(
        string="Is a learner", index=True,
        help="Shows the learner section and brings the contact into learner "
             "reports and evidence packs.",
    )

    # ------------------------------------------------------------------
    # identity as the awarding body wants it
    # ------------------------------------------------------------------
    learner_title = fields.Selection(
        [
            ("mr", "Mr"),
            ("mrs", "Mrs"),
            ("miss", "Miss"),
            ("ms", "Ms"),
            ("other", "Other"),
            ("na", "N/A"),
        ],
        string="Title",
        help="Collected on the NEBOSH form but never printed on the "
             "certificate.",
    )
    legal_name = fields.Char(
        string="Full legal name",
        tracking=True,
        help="Exactly as it appears on the identity document. This is the "
             "name NEBOSH prints on the certificate, so it is kept apart from "
             "the display name, which people edit freely.",
    )
    legal_name_locked = fields.Boolean(
        string="Legal name locked", readonly=True, copy=False,
        help="Set once the learner has been registered with the awarding "
             "body. After that the name can only change through a formal "
             "amendment.",
    )
    legal_name_locked_by = fields.Many2one("res.users", readonly=True, copy=False)
    legal_name_locked_date = fields.Datetime(readonly=True, copy=False)

    nebosh_learner_number = fields.Char(
        string="NEBOSH learner number", index=True, copy=False,
        help="Follows the person across IGC, Diploma and any resit, so it "
             "belongs on the contact rather than on a single course.",
    )
    iosh_learner_number = fields.Char(string="IOSH learner number", copy=False)

    date_of_birth = fields.Date(string="Date of birth")
    age_years = fields.Integer(string="Age", compute="_compute_age_years")
    nationality_id = fields.Many2one("res.country", string="Nationality")
    gender = fields.Selection(
        [
            ("male", "Male"),
            ("female", "Female"),
            ("other", "Other"),
            ("undisclosed", "Prefer not to say"),
        ],
        string="Gender",
    )

    # ------------------------------------------------------------------
    # consent, with the inverted box kept inverted
    # ------------------------------------------------------------------
    nebosh_consent = fields.Boolean(
        string="Consents to NEBOSH registration",
        help="The learner confirms their details may be used to register them "
             "for a NEBOSH qualification.",
    )
    nebosh_consent_date = fields.Datetime(string="Consent recorded", readonly=True)
    nebosh_marketing_opt_out = fields.Boolean(
        string="Opted OUT of NEBOSH marketing",
        help="The form asks the learner to TICK the box to refuse marketing. "
             "The field is named for what a tick means, so nobody later reads "
             "it as consent and reverses the learner's wish.",
    )

    # ------------------------------------------------------------------
    # identity document
    # ------------------------------------------------------------------
    id_document_type = fields.Selection(
        [
            ("passport", "Passport"),
            ("driving_licence", "Driving licence"),
            ("national_id", "National ID card"),
            ("birth_certificate", "Birth certificate"),
            ("other", "Other"),
        ],
        string="ID document type",
        help="The five options NEBOSH lists. A residence permit goes under "
             "Other, with the type written out.",
    )
    id_document_other = fields.Char(string="Other document type")
    id_document_number = fields.Char(string="ID number", copy=False)
    id_document_expiry = fields.Date(string="ID expiry")
    id_document_file = fields.Binary(string="ID document", attachment=True, copy=False)
    id_document_filename = fields.Char(string="ID filename", copy=False)
    id_expiry_state = fields.Selection(
        [
            ("none", "No expiry recorded"),
            ("valid", "Valid"),
            ("soon", "Expires within 90 days"),
            ("expired", "Expired"),
        ],
        compute="_compute_id_expiry_state",
        store=True,
        string="ID status",
    )

    id_verified = fields.Boolean(string="Identity verified", copy=False)
    id_verified_by = fields.Many2one("res.users", string="Verified by", readonly=True, copy=False)
    id_verified_date = fields.Date(string="Verified on", readonly=True, copy=False)

    work_email_accepted = fields.Boolean(
        string="Work email accepted",
        help="Tick only when the learner has confirmed this really is their "
             "own address. Record why in the chatter.",
    )

    photo_verified = fields.Boolean(
        string="Photo verified", copy=False,
        help="The personal photograph is stored in the standard contact image "
             "field, not a separate one.",
    )

    # ------------------------------------------------------------------
    # completeness, so gaps are visible before an audit finds them
    # ------------------------------------------------------------------
    learner_file_complete = fields.Boolean(
        compute="_compute_learner_file", store=True, string="File complete"
    )
    learner_file_missing = fields.Char(
        compute="_compute_learner_file", store=True, string="Missing"
    )

    registration_ids = fields.One2many(
        "event.registration", "partner_id", string="Course registrations"
    )
    registration_count = fields.Integer(compute="_compute_registration_count")

    _sql_constraints = [
        (
            "unique_nebosh_number",
            "unique(nebosh_learner_number)",
            "That NEBOSH learner number is already on another contact. "
            "Duplicate learner records are the usual cause of a split "
            "attendance file.",
        ),
    ]

    # ------------------------------------------------------------------
    # computes
    # ------------------------------------------------------------------
    @api.depends("date_of_birth")
    def _compute_age_years(self):
        today = fields.Date.today()
        for partner in self:
            if partner.date_of_birth:
                born = partner.date_of_birth
                partner.age_years = today.year - born.year - (
                    (today.month, today.day) < (born.month, born.day)
                )
            else:
                partner.age_years = 0

    @api.depends("id_document_expiry")
    def _compute_id_expiry_state(self):
        today = fields.Date.today()
        for partner in self:
            expiry = partner.id_document_expiry
            if not expiry:
                partner.id_expiry_state = "none"
            elif expiry < today:
                partner.id_expiry_state = "expired"
            elif (expiry - today).days <= 90:
                partner.id_expiry_state = "soon"
            else:
                partner.id_expiry_state = "valid"

    @api.depends(
        "is_learner", "legal_name", "date_of_birth", "email", "phone",
        "nationality_id", "id_document_type", "id_document_number",
        "id_document_file", "id_verified", "image_1920", "nebosh_consent",
    )
    def _compute_learner_file(self):
        for partner in self:
            if not partner.is_learner:
                partner.learner_file_complete = False
                partner.learner_file_missing = False
                continue

            missing = []
            if not partner.legal_name:
                missing.append(_("legal name"))
            if not partner.date_of_birth:
                missing.append(_("date of birth"))
            if not partner.email:
                missing.append(_("email"))
            if not partner.phone:
                missing.append(_("phone"))
            if not partner.nationality_id:
                missing.append(_("nationality"))
            if not partner.id_document_type:
                missing.append(_("ID type"))
            if not partner.id_document_number:
                missing.append(_("ID number"))
            if not partner.id_document_file:
                missing.append(_("ID scan"))
            if not partner.id_verified:
                missing.append(_("ID verification"))
            if not partner.image_1920:
                missing.append(_("photograph"))
            if not partner.nebosh_consent:
                missing.append(_("consent"))

            partner.learner_file_missing = ", ".join(missing)
            partner.learner_file_complete = not missing

    def _compute_registration_count(self):
        for partner in self:
            partner.registration_count = len(partner.registration_ids)

    # ------------------------------------------------------------------
    # constraints
    # ------------------------------------------------------------------
    @api.constrains("is_learner", "email", "work_email_accepted")
    def _check_personal_email(self):
        """NEBOSH asks for a personal address, not a work one.

        Enforced as a warning-shaped error rather than a silent acceptance,
        because a corporate address is the single most common reason a learner
        stops receiving awarding-body correspondence after leaving the job.
        """
        for partner in self:
            if not (partner.is_learner and partner.email):
                continue
            email = partner.email.strip().lower()
            if not EMAIL_RE.match(email):
                raise ValidationError(_("“%s” is not a valid email address.") % partner.email)
            domain = email.rsplit("@", 1)[-1]
            if domain in PERSONAL_DOMAINS:
                continue
            if partner.work_email_accepted or self.env.context.get("allow_work_email"):
                continue
            raise ValidationError(_(
                "The NEBOSH registration form asks for a personal email "
                "address, not a work one, and “%(domain)s” looks like a "
                "company domain.\n\n"
                "If this genuinely is the learner's own address, tick "
                "“Work email accepted” and record why.",
                domain=domain,
            ))

    @api.constrains("id_document_type", "id_document_other")
    def _check_other_document(self):
        for partner in self:
            if partner.id_document_type == "other" and not (partner.id_document_other or "").strip():
                raise ValidationError(_(
                    "When the document type is Other, write out what it "
                    "actually is. A residence permit recorded as “Other” with "
                    "no detail tells an auditor nothing."
                ))

    @api.constrains("date_of_birth")
    def _check_date_of_birth(self):
        today = fields.Date.today()
        for partner in self:
            dob = partner.date_of_birth
            if dob and dob >= today:
                raise ValidationError(_("The date of birth is in the future."))

    # ------------------------------------------------------------------
    # write guards
    # ------------------------------------------------------------------
    def write(self, values):
        if "legal_name" in values:
            locked = self.filtered("legal_name_locked")
            if locked and not self.env.context.get("allow_legal_name_change"):
                raise UserError(_(
                    "The legal name is locked for %(names)s because the learner "
                    "has been registered with the awarding body. Changing it "
                    "now would put a different name on the certificate than the "
                    "one registered.\n\n"
                    "Use Unlock legal name, which records who changed it and "
                    "why.",
                    names=", ".join(locked.mapped("display_name")),
                ))

        if values.get("nebosh_consent"):
            values.setdefault("nebosh_consent_date", fields.Datetime.now())
        elif "nebosh_consent" in values and not values["nebosh_consent"]:
            values.setdefault("nebosh_consent_date", False)

        if "id_verified" in values:
            if values["id_verified"]:
                values.setdefault("id_verified_by", self.env.user.id)
                values.setdefault("id_verified_date", fields.Date.today())
            else:
                values.setdefault("id_verified_by", False)
                values.setdefault("id_verified_date", False)

        return super().write(values)

    # ------------------------------------------------------------------
    # actions
    # ------------------------------------------------------------------
    def action_lock_legal_name(self):
        for partner in self:
            if not partner.legal_name:
                raise UserError(_("There is no legal name to lock."))
            partner.write({
                "legal_name_locked": True,
                "legal_name_locked_by": self.env.user.id,
                "legal_name_locked_date": fields.Datetime.now(),
            })
            partner.message_post(body=_(
                "Legal name locked as “%s” following registration with the "
                "awarding body."
            ) % partner.legal_name)
        return True

    def action_unlock_legal_name(self):
        for partner in self:
            partner.with_context(allow_legal_name_change=True).write({
                "legal_name_locked": False,
                "legal_name_locked_by": False,
                "legal_name_locked_date": False,
            })
            partner.message_post(body=_(
                "Legal name unlocked by %s. Record the reason and the "
                "awarding-body amendment reference in this thread."
            ) % self.env.user.name)
        return True

    def action_copy_name_to_legal(self):
        """Convenience for contacts created before this module existed."""
        for partner in self.filtered(lambda p: not p.legal_name):
            partner.legal_name = partner.name
        return True

    def action_open_registrations(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Registrations"),
            "res_model": "event.registration",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
        }
