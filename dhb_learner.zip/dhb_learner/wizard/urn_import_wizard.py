import base64
import io
import logging
import re

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

# A URN result line, e.g.
#   DI1  Know - workplace health and safety principles (International)
#        46  Refer  17/09/2025  10/02/2026  Other  46
# The Learning Partner column is either a four-digit LP number or the word
# "Other", so it is matched explicitly. A bare \S+ there swallows the two
# columns that follow it and the line fails to match at all.
UNIT_RE = re.compile(
    r"^(?P<unit>[A-Z]{2,4}\d{0,2})\s+"
    r"(?P<desc>.+?)\s+"
    r"(?P<mark>\d{1,3})\s+"
    r"(?P<status>Pass|Refer|Absent|Void|Pending)\s+"
    r"(?P<exam>\d{2}/\d{2}/\d{4})\s+"
    r"(?P<expected>\d{2}/\d{2}/\d{4})\s+"
    r"(?P<lp>Other|\d{3,5})"
    r"(?:\s+(?P<unit_result>Pass|Refer|Absent))?"
    r"(?:\s+(?P<high>\d{1,3}))?\s*$",
    re.M,
)

STATUS_MAP = {
    "Pass": "pass", "Refer": "refer", "Absent": "absent",
    "Void": "void", "Pending": "pending",
}


class DhbUrnImportWizard(models.TransientModel):
    """Read a Unit Result Notification and turn it into result rows.

    Typing results in by hand is where a mark or a date drifts, and a drifted
    mark is the thing an auditor spots. Reading the PDF keeps the record and
    the awarding body's own document in step, and the PDF is stored alongside.
    """

    _name = "dhb.urn.import.wizard"
    _description = "Import a NEBOSH URN"

    partner_id = fields.Many2one("res.partner", string="Learner")
    urn_file = fields.Binary(string="URN (PDF)", required=True)
    urn_filename = fields.Char()
    preview = fields.Text(string="What was read", readonly=True)
    state = fields.Selection(
        [("draft", "Draft"), ("read", "Read")], default="draft"
    )

    # ------------------------------------------------------------------
    def _extract_text(self):
        self.ensure_one()
        try:
            import pdfplumber
        except ImportError:
            pdfplumber = None

        raw = base64.b64decode(self.urn_file)

        if pdfplumber:
            with pdfplumber.open(io.BytesIO(raw)) as pdf:
                return "\n".join(p.extract_text() or "" for p in pdf.pages)

        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise UserError(_(
                "Neither pdfplumber nor pypdf is available in the Odoo "
                "container, so the URN cannot be read.\n\n"
                "Install one with:\n"
                "docker exec -u root odoo pip install pdfplumber "
                "--break-system-packages"
            )) from exc
        reader = PdfReader(io.BytesIO(raw))
        return "\n".join(page.extract_text() or "" for page in reader.pages)

    def _parse(self, text):
        """Pull the header and the unit lines out of the notification."""
        data = {"units": []}

        number = re.search(r"Learner number:\s*(\d+)", text)
        if number:
            data["learner_number"] = number.group(1)

        first = re.search(r"First name/s \(given name\):\s*(.+)", text)
        last = re.search(r"Surname \(family name\):\s*(.+)", text)
        if first:
            data["forenames"] = first.group(1).strip()
        if last:
            data["surname"] = last.group(1).strip()

        qualification = re.search(r"(NEBOSH Level \d[^\n]*)", text)
        if qualification:
            data["qualification"] = qualification.group(1).strip()

        issued = re.search(r"(\d{1,2}\s+\w+\s+20\d\d)", text)
        if issued:
            data["issued_raw"] = issued.group(1)

        for match in UNIT_RE.finditer(text):
            data["units"].append({
                "unit": match.group("unit"),
                "description": " ".join(match.group("desc").split()),
                "mark": int(match.group("mark")),
                "status": match.group("status"),
                "exam_date": match.group("exam"),
                "results_expected": match.group("expected"),
                "learning_partner": match.group("lp"),
                "unit_result": match.group("unit_result") or "",
                "high_valid_mark": int(match.group("high")) if match.group("high") else 0,
            })
        return data

    def _to_date(self, value):
        if not value:
            return False
        day, month, year = value.split("/")
        return fields.Date.to_date("%s-%s-%s" % (year, month, day))

    # ------------------------------------------------------------------
    def action_read(self):
        self.ensure_one()
        data = self._parse(self._extract_text())

        if not data["units"]:
            raise UserError(_(
                "No unit results were found in that file. It may not be a "
                "Unit Result Notification, or it may be a scan rather than a "
                "generated PDF."
            ))

        lines = [_("Learner number: %s") % data.get("learner_number", "?")]
        if data.get("forenames") or data.get("surname"):
            lines.append(_("Name: %s %s") % (
                data.get("forenames", ""), data.get("surname", "")))
        lines.append("")
        for unit in data["units"]:
            lines.append("%s  %s  %s  exam %s  LP %s%s" % (
                unit["unit"], unit["mark"], unit["status"],
                unit["exam_date"], unit["learning_partner"],
                _("  (high valid %s)") % unit["high_valid_mark"] if unit["high_valid_mark"] else "",
            ))

        # Warn rather than block: a mismatch is usually the wrong learner
        # selected, and that is worth a second look before importing.
        if self.partner_id and data.get("learner_number"):
            recorded = (self.partner_id.nebosh_learner_number or "").strip()
            if recorded and recorded != data["learner_number"]:
                lines.append("")
                lines.append(_(
                    "WARNING: this URN is for learner %(urn)s but %(name)s is "
                    "recorded as %(recorded)s. Check you have the right learner.",
                    urn=data["learner_number"], name=self.partner_id.display_name,
                    recorded=recorded,
                ))

        self.preview = "\n".join(lines)
        self.state = "read"
        return self._reopen()

    def action_import(self):
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_("Choose the learner first."))

        data = self._parse(self._extract_text())
        Result = self.env["dhb.nebosh.result"]
        created, skipped = 0, 0

        for unit in data["units"]:
            exam_date = self._to_date(unit["exam_date"])
            existing = Result.search([
                ("partner_id", "=", self.partner_id.id),
                ("unit_code", "=", unit["unit"]),
                ("exam_date", "=", exam_date),
            ], limit=1)
            if existing:
                skipped += 1
                continue

            partner_code = (unit["learning_partner"] or "").strip()
            result = Result.create({
                "partner_id": self.partner_id.id,
                "qualification": data.get("qualification"),
                "unit_code": unit["unit"],
                "unit_description": unit["description"],
                "mark": unit["mark"],
                "high_valid_mark": unit["high_valid_mark"] or unit["mark"],
                "status": STATUS_MAP.get(unit["status"], "pending"),
                "unit_result": unit["unit_result"],
                "exam_date": exam_date,
                "results_expected": self._to_date(unit["results_expected"]),
                "learning_partner": partner_code,
                "delivered_by_dhb": partner_code == "1708",
                "urn_file": self.urn_file,
                "urn_filename": self.urn_filename,
            })
            result._onchange_find_sitting()
            created += 1

        # Fill in the learner number from the URN when it is missing.
        if data.get("learner_number") and not self.partner_id.nebosh_learner_number:
            self.partner_id.nebosh_learner_number = data["learner_number"]

        self.partner_id.message_post(body=_(
            "URN imported: %(created)s results added, %(skipped)s already on file."
        ) % {"created": created, "skipped": skipped})

        return {
            "type": "ir.actions.act_window",
            "name": _("NEBOSH results"),
            "res_model": "dhb.nebosh.result",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.partner_id.id)],
        }

    def _reopen(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }
