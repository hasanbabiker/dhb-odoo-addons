"""Move the certificate movements into Shipping, then let the model go.

`dhb.certificate.movement` was this module's own little courier record. It
is replaced by `dhb.shipment`, which carries anything rather than only a
certificate - so the day the centre posts learner packs, nothing has to be
built twice.

There are no rows in it on this database today, and that is exactly why the
change is being made now rather than in a month. The migration is written
anyway: a table that is about to disappear is not the place to discover
that somebody created a test record on Friday.
"""

import logging

_logger = logging.getLogger(__name__)

# The old carrier keys, and which seeded carrier each becomes. "email" and
# "other" both go to hand-over rather than inventing a courier: neither was
# ever a parcel with a tracking number.
CARRIER_BY_KEY = {
    "dhl": "DHL",
    "aramex": "ARAMEX",
    "collected": "HAND",
    "email": "HAND",
    "other": "HAND",
}

STATE_BY_KEY = {
    "draft": "draft",
    "sent": "in_transit",
    "received": "delivered",
    "lost": "lost",
}


def migrate(cr, version):
    if not version:
        return

    cr.execute("""
        SELECT 1 FROM information_schema.tables
         WHERE table_name = 'dhb_certificate_movement'
    """)
    if not cr.fetchone():
        return

    cr.execute("""
        SELECT m.id, m.certificate_id, m.carrier, m.tracking_ref,
               m.date_sent, m.date_received, m.received_by, m.cost,
               m.currency_id, m.state, m.note,
               c.partner_id, c.name
          FROM dhb_certificate_movement m
          JOIN dhb_certificate c ON c.id = m.certificate_id
      ORDER BY m.id
    """)
    rows = cr.fetchall()
    if not rows:
        _logger.info("Certificates: no movements to carry over.")
        return

    # The carriers were seeded by dhb_shipping's own data file, which has
    # already loaded by the time a post-migration runs.
    cr.execute("SELECT code, id FROM dhb_shipping_carrier")
    carriers = dict(cr.fetchall())

    moved = 0
    for (_mid, certificate_id, carrier, tracking, sent, received,
         received_by, cost, currency, state, note, partner_id,
         reference) in rows:
        cr.execute("""
            INSERT INTO dhb_shipment
                (name, active, partner_id, res_model, res_id, origin,
                 contents, weight_kg, pieces, carrier_id, tracking_ref,
                 cost, currency_id, state, date_ready, date_shipped,
                 date_delivered, received_by, note,
                 create_uid, create_date, write_uid, write_date)
            VALUES (%s, TRUE, %s, 'dhb.certificate', %s, %s,
                    'Certificate', 0.5, 1, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s,
                    1, NOW() AT TIME ZONE 'UTC', 1, NOW() AT TIME ZONE 'UTC')
        """, (
            "SHP/MIGRATED/%s" % _mid,
            partner_id,
            certificate_id,
            reference,
            carriers.get(CARRIER_BY_KEY.get(carrier or "other", "HAND")),
            tracking,
            cost or 0.0,
            currency,
            STATE_BY_KEY.get(state or "draft", "draft"),
            sent,
            sent,
            received,
            received_by,
            note,
        ))
        moved += 1

    _logger.info("Certificates: %s movements carried over to Shipping.", moved)
