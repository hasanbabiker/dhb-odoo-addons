# -*- coding: utf-8 -*-

import logging
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from .zoom_api import ZoomAPI, ZoomError

_logger = logging.getLogger(__name__)

REFRESH_MARGIN = timedelta(minutes=5)


class ZoomAccount(models.Model):
    _name = "zoom.account"
    _description = "Zoom Connection"
    _inherit = ["mail.thread"]
    _order = "company_id, name"

    name = fields.Char(required=True, default="Zoom", tracking=True)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        "res.company", required=True, default=lambda self: self.env.company)
    user_id = fields.Many2one(
        "res.users", string="Owner",
        help="Leave empty for a company-wide connection. Set a user to make "
             "this connection personal to them.")

    auth_type = fields.Selection(
        [
            ("s2s", "Server-to-Server OAuth"),
            ("oauth", "User OAuth"),
        ],
        string="Authentication", default="s2s", required=True,
        help="Server-to-Server is one app for the whole Zoom account and needs "
             "no user interaction. User OAuth sends each person through the "
             "Zoom consent screen.")

    client_id = fields.Char(required=True, groups="base.group_system")
    client_secret = fields.Char(required=True, groups="base.group_system")
    account_id = fields.Char(
        "Zoom Account ID", groups="base.group_system",
        help="Server-to-Server apps only.")
    secret_token = fields.Char(
        "Webhook Secret Token", groups="base.group_system",
        help="From the Feature tab of your Zoom app. Used to validate the "
             "webhook endpoint and verify every incoming event.")

    access_token = fields.Char(readonly=True, copy=False, groups="base.group_system")
    refresh_token = fields.Char(readonly=True, copy=False, groups="base.group_system")
    token_expiry = fields.Datetime(readonly=True, copy=False)

    state = fields.Selection(
        [("draft", "Not connected"), ("connected", "Connected"),
         ("error", "Error")],
        default="draft", readonly=True, tracking=True)
    last_error = fields.Char(readonly=True)

    zoom_user_email = fields.Char("Zoom Account Email", readonly=True)
    zoom_user_id = fields.Char("Default Zoom Host ID", readonly=True)
    zoom_account_type = fields.Char("Plan", readonly=True)

    default_timezone = fields.Selection(
        lambda self: [(tz, tz) for tz in __import__("pytz").all_timezones],
        string="Default Timezone", default="Asia/Dubai")

    # -- default meeting settings --------------------------------------
    default_host_video = fields.Boolean("Host Video On", default=True)
    default_participant_video = fields.Boolean("Participant Video On")
    default_join_before_host = fields.Boolean("Join Before Host")
    default_mute_upon_entry = fields.Boolean("Mute on Entry", default=True)
    default_waiting_room = fields.Boolean("Waiting Room", default=True)
    default_auto_recording = fields.Selection(
        [("none", "No"), ("local", "Local"), ("cloud", "Cloud")],
        string="Auto Recording", default="none")

    _sql_constraints = [
        ("one_company_default",
         "unique(company_id, user_id)",
         "There is already a connection for this company and owner."),
    ]

    @api.constrains("auth_type", "account_id")
    def _check_account_id(self):
        for record in self:
            if record.auth_type == "s2s" and not record.sudo().account_id:
                raise ValidationError(_(
                    "Server-to-Server OAuth needs the Zoom Account ID."))

    # ==================================================================
    # selection of the right connection
    # ==================================================================
    @api.model
    def _for_user(self, user):
        """Personal connection if there is one, otherwise the company's."""
        domain_base = [("state", "=", "connected"),
                       ("company_id", "=", user.company_id.id)]
        personal = self.sudo().search(
            domain_base + [("user_id", "=", user.id)], limit=1)
        if personal:
            return personal
        return self.sudo().search(
            domain_base + [("user_id", "=", False)], limit=1)

    # ==================================================================
    # tokens
    # ==================================================================
    def _token(self):
        self.ensure_one()
        account = self.sudo()
        now = fields.Datetime.now()
        if account.access_token and account.token_expiry \
                and account.token_expiry - REFRESH_MARGIN > now:
            return account.access_token
        account._renew_token()
        return account.access_token

    def _renew_token(self):
        self.ensure_one()
        account = self.sudo()
        try:
            if account.auth_type == "s2s":
                body = ZoomAPI.token_server_to_server(
                    account.client_id, account.client_secret, account.account_id)
            else:
                if not account.refresh_token:
                    raise UserError(_(
                        "%s has never been connected. Use Connect to Zoom.")
                        % self.display_name)
                body = ZoomAPI.token_from_refresh(
                    account.client_id, account.client_secret, account.refresh_token)
        except ZoomError as err:
            account.write({
                "state": "error",
                "last_error": err.args[0] if err.args else str(err),
            })
            raise
        account._store_token(body)

    def _store_token(self, body):
        self.ensure_one()
        values = {
            "access_token": body.get("access_token"),
            "state": "connected",
            "last_error": False,
        }
        if body.get("refresh_token"):
            values["refresh_token"] = body["refresh_token"]
        if body.get("expires_in"):
            values["token_expiry"] = fields.Datetime.now() + timedelta(
                seconds=int(body["expires_in"]))
        self.sudo().write(values)

    # ==================================================================
    # actions
    # ==================================================================
    def action_test_connection(self):
        self.ensure_one()
        info = ZoomAPI.me(self._token())
        self.sudo().write({
            "zoom_user_email": info.get("email"),
            "zoom_user_id": info.get("id"),
            "zoom_account_type": {1: "Basic", 2: "Licensed", 3: "On-prem"}.get(
                info.get("type"), str(info.get("type") or "")),
            "state": "connected",
            "last_error": False,
        })
        self.message_post(body=_("Connected to Zoom as %s.") % info.get("email"))
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "type": "success",
                "title": _("Zoom"),
                "message": _("Connected as %s.") % info.get("email"),
                "sticky": False,
            },
        }

    def action_connect_oauth(self):
        """User-level OAuth: send the browser to Zoom's consent screen."""
        self.ensure_one()
        if self.auth_type != "oauth":
            raise UserError(_("This connection uses Server-to-Server OAuth; "
                              "just press Test Connection."))
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        if not base or base.startswith("http://localhost"):
            raise UserError(_(
                "Zoom needs a public HTTPS redirect URI. Set web.base.url to "
                "your real domain first."))
        return {
            "type": "ir.actions.act_url",
            "target": "self",
            "url": ZoomAPI.authorize_url(
                self.sudo().client_id,
                "%s/zoom/oauth/callback" % base,
                state=str(self.id)),
        }

    def action_disconnect(self):
        self.sudo().write({
            "access_token": False, "refresh_token": False,
            "token_expiry": False, "state": "draft",
        })
        return True

    # ==================================================================
    # host resolution
    # ==================================================================
    def zoom_host_for(self, user):
        """Which Zoom user should host a meeting created by this Odoo user.

        With Server-to-Server OAuth and the ``meeting:write:admin`` scope we can
        create a meeting under any licensed host in the account, matched by
        email. If there is no match we fall back to the app owner.
        """
        self.ensure_one()
        email = (user.email or "").strip()
        if email and self.auth_type == "s2s":
            try:
                info = ZoomAPI.get_user(self._token(), email)
                if info.get("id"):
                    return info["id"]
            except ZoomError:
                _logger.info("Zoom: no Zoom user for %s, falling back to the "
                             "app owner", email)
        return self.sudo().zoom_user_id or "me"

    # ==================================================================
    # crons
    # ==================================================================
    @api.model
    def _cron_refresh_tokens(self):
        deadline = fields.Datetime.now() + timedelta(minutes=30)
        for account in self.sudo().search([
                ("state", "=", "connected"), ("auth_type", "=", "oauth"),
                ("token_expiry", "<=", deadline)]):
            try:
                account._renew_token()
            except Exception as err:
                _logger.warning("Zoom: token refresh failed for %s (%s)",
                                account.display_name, err)
