# -*- coding: utf-8 -*-

from datetime import datetime

from odoo import api, fields, models


class ZoomParticipant(models.Model):
    _name = "zoom.participant"
    _description = "Zoom Meeting Participant"
    _order = "join_time, id"

    event_id = fields.Many2one(
        "calendar.event", string="Meeting", required=True,
        ondelete="cascade", index=True)
    company_id = fields.Many2one(
        "res.company", default=lambda self: self.env.company)

    participant_uuid = fields.Char("Zoom Participant ID", index=True)
    name = fields.Char("Name", required=True)
    email = fields.Char()
    partner_id = fields.Many2one("res.partner", string="Contact")
    user_id = fields.Many2one("res.users", string="Odoo User")

    join_time = fields.Datetime()
    leave_time = fields.Datetime()
    duration_minutes = fields.Float("Duration (min)")
    is_host = fields.Boolean()

    _sql_constraints = [
        ("participant_uniq", "unique(event_id, participant_uuid, join_time)",
         "This participant session is already recorded."),
    ]

    @api.model
    def _record_from_zoom(self, event, participants):
        """Replace the stored participant list with what Zoom reports."""
        Partner = self.env["res.partner"]
        Users = self.env["res.users"]
        event.participant_ids.unlink()
        rows = []
        for payload in participants:
            email = (payload.get("user_email") or "").strip().lower()
            partner = Partner.search(
                [("email", "=ilike", email)], limit=1) if email else Partner
            user = Users.search(
                [("login", "=ilike", email)], limit=1) if email else Users
            rows.append({
                "event_id": event.id,
                "participant_uuid": payload.get("id") or payload.get("user_id"),
                "name": payload.get("name") or email or "Guest",
                "email": email or False,
                "partner_id": partner.id or False,
                "user_id": user.id or False,
                "join_time": self._parse(payload.get("join_time")),
                "leave_time": self._parse(payload.get("leave_time")),
                "duration_minutes": round((payload.get("duration") or 0) / 60.0, 2),
            })
        if rows:
            self.create(rows)
        return len(rows)

    @staticmethod
    def _parse(value):
        if not value:
            return False
        try:
            return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            return False


class ZoomRecording(models.Model):
    _name = "zoom.recording"
    _description = "Zoom Cloud Recording"
    _order = "recording_start desc"

    event_id = fields.Many2one(
        "calendar.event", string="Meeting", required=True,
        ondelete="cascade", index=True)
    company_id = fields.Many2one(
        "res.company", default=lambda self: self.env.company)

    recording_id = fields.Char("Zoom Recording ID", index=True)
    name = fields.Char(required=True, default="Recording")
    file_type = fields.Char()
    recording_type = fields.Char(
        help="Zoom's own label, e.g. shared_screen_with_speaker_view, "
             "audio_transcript, chat_file.")
    file_size = fields.Float("Size (MB)")
    recording_start = fields.Datetime()
    recording_end = fields.Datetime()
    play_url = fields.Char("Play Link")
    download_url = fields.Char("Download Link")
    password = fields.Char("Passcode")

    _sql_constraints = [
        ("recording_uniq", "unique(event_id, recording_id)",
         "This recording file is already linked."),
    ]

    @api.model
    def _record_from_zoom(self, event, payload):
        files = payload.get("recording_files") or []
        existing = set(event.recording_ids.mapped("recording_id"))
        rows = []
        for item in files:
            identifier = item.get("id")
            if not identifier or identifier in existing:
                continue
            rows.append({
                "event_id": event.id,
                "recording_id": identifier,
                "name": "%s (%s)" % (item.get("recording_type") or "Recording",
                                     item.get("file_type") or ""),
                "file_type": item.get("file_type"),
                "recording_type": item.get("recording_type"),
                "file_size": round((item.get("file_size") or 0) / 1048576.0, 2),
                "recording_start": ZoomParticipant._parse(item.get("recording_start")),
                "recording_end": ZoomParticipant._parse(item.get("recording_end")),
                "play_url": item.get("play_url"),
                "download_url": item.get("download_url"),
                "password": payload.get("password") or payload.get("recording_play_passcode"),
            })
        if rows:
            self.create(rows)
        return len(rows)
