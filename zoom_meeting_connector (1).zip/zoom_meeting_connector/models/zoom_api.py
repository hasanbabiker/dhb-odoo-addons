# -*- coding: utf-8 -*-
"""HTTP layer for the Zoom API v2.

Two authentication styles are supported:

* **Server-to-Server OAuth** (``grant_type=account_credentials``) - one app for
  the whole Zoom account. This is the practical choice for a company that wants
  Odoo to schedule meetings on behalf of several hosts.
* **User-level OAuth** (``grant_type=authorization_code``) - each Odoo user
  connects their own Zoom account and meetings are created under it.

Both end up as a bearer token; everything below the token layer is identical.
"""

import base64
import logging
from urllib.parse import urlencode

import requests

from odoo import _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

API_BASE = "https://api.zoom.us/v2"
OAUTH_TOKEN_URL = "https://zoom.us/oauth/token"
OAUTH_AUTHORIZE_URL = "https://zoom.us/oauth/authorize"
JOIN_BASE = "https://zoom.us/j/"

TIMEOUT = 30

# Meeting types as Zoom defines them.
MEETING_TYPE_INSTANT = 1
MEETING_TYPE_SCHEDULED = 2
MEETING_TYPE_RECURRING_NO_FIXED = 3
MEETING_TYPE_RECURRING_FIXED = 8


class ZoomError(UserError):
    """Raised when Zoom answers with an error."""


class ZoomAPI:

    # ------------------------------------------------------------------
    # tokens
    # ------------------------------------------------------------------
    @staticmethod
    def _basic_auth(client_id, client_secret):
        raw = "%s:%s" % (client_id, client_secret)
        return "Basic %s" % base64.b64encode(raw.encode()).decode()

    @classmethod
    def token_server_to_server(cls, client_id, client_secret, account_id):
        return cls._token_call(
            client_id, client_secret,
            {"grant_type": "account_credentials", "account_id": account_id})

    @classmethod
    def token_from_code(cls, client_id, client_secret, code, redirect_uri):
        return cls._token_call(
            client_id, client_secret,
            {"grant_type": "authorization_code", "code": code,
             "redirect_uri": redirect_uri})

    @classmethod
    def token_from_refresh(cls, client_id, client_secret, refresh_token):
        return cls._token_call(
            client_id, client_secret,
            {"grant_type": "refresh_token", "refresh_token": refresh_token})

    @classmethod
    def _token_call(cls, client_id, client_secret, params):
        try:
            response = requests.post(
                OAUTH_TOKEN_URL, params=params,
                headers={
                    "Authorization": cls._basic_auth(client_id, client_secret),
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                timeout=TIMEOUT,
            )
            body = response.json()
        except requests.exceptions.RequestException as err:
            raise ZoomError(_("Could not reach Zoom: %s") % err)
        except ValueError:
            raise ZoomError(_("Zoom returned a token response that is not JSON."))
        if response.status_code >= 400 or body.get("error"):
            raise ZoomError(_(
                "Zoom refused the token request: %(error)s - %(reason)s",
                error=body.get("error") or response.status_code,
                reason=body.get("reason") or body.get("error_description") or ""))
        return body

    @staticmethod
    def authorize_url(client_id, redirect_uri, state):
        return "%s?%s" % (OAUTH_AUTHORIZE_URL, urlencode({
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "state": state,
        }))

    # ------------------------------------------------------------------
    # generic call
    # ------------------------------------------------------------------
    @classmethod
    def call(cls, access_token, path, method="GET", params=None, payload=None):
        url = "%s%s" % (API_BASE, path)
        headers = {
            "Authorization": "Bearer %s" % access_token,
            "Content-Type": "application/json",
        }
        try:
            response = requests.request(
                method, url, headers=headers, params=params, json=payload,
                timeout=TIMEOUT)
        except requests.exceptions.Timeout:
            raise ZoomError(_("Zoom did not answer within %s seconds.") % TIMEOUT)
        except requests.exceptions.RequestException as err:
            raise ZoomError(_("Could not reach Zoom: %s") % err)

        if response.status_code == 204 or not response.content:
            return {}
        try:
            body = response.json()
        except ValueError:
            raise ZoomError(_(
                "Zoom returned HTTP %(code)s with a non-JSON body for %(path)s.",
                code=response.status_code, path=path))
        if response.status_code >= 400:
            raise ZoomError(_(
                "Zoom API error on %(path)s (HTTP %(code)s): %(message)s",
                path=path, code=response.status_code,
                message=body.get("message") or body))
        return body

    # ------------------------------------------------------------------
    # meetings
    # ------------------------------------------------------------------
    @classmethod
    def create_meeting(cls, token, user_id, payload):
        return cls.call(token, "/users/%s/meetings" % user_id,
                        method="POST", payload=payload)

    @classmethod
    def update_meeting(cls, token, meeting_id, payload):
        return cls.call(token, "/meetings/%s" % meeting_id,
                        method="PATCH", payload=payload)

    @classmethod
    def get_meeting(cls, token, meeting_id):
        return cls.call(token, "/meetings/%s" % meeting_id)

    @classmethod
    def delete_meeting(cls, token, meeting_id, notify=True):
        return cls.call(token, "/meetings/%s" % meeting_id, method="DELETE",
                        params={"schedule_for_reminder": notify})

    @classmethod
    def list_meetings(cls, token, user_id, meeting_type="scheduled",
                      page_size=100, next_page_token=None):
        params = {"type": meeting_type, "page_size": page_size}
        if next_page_token:
            params["next_page_token"] = next_page_token
        return cls.call(token, "/users/%s/meetings" % user_id, params=params)

    # ------------------------------------------------------------------
    # after the meeting
    # ------------------------------------------------------------------
    @classmethod
    def past_meeting(cls, token, meeting_uuid):
        return cls.call(token, "/past_meetings/%s" % cls.encode_uuid(meeting_uuid))

    @classmethod
    def past_participants(cls, token, meeting_uuid, page_size=300):
        return cls.call(
            token, "/past_meetings/%s/participants" % cls.encode_uuid(meeting_uuid),
            params={"page_size": page_size})

    @classmethod
    def recordings(cls, token, meeting_id):
        return cls.call(token, "/meetings/%s/recordings" % meeting_id)

    @staticmethod
    def encode_uuid(uuid):
        """Zoom UUIDs that start with '/' or contain '//' must be double
        URL-encoded before they can be used in a path."""
        from urllib.parse import quote
        if uuid and (uuid.startswith("/") or "//" in uuid):
            return quote(quote(uuid, safe=""), safe="")
        return uuid

    # ------------------------------------------------------------------
    # users
    # ------------------------------------------------------------------
    @classmethod
    def me(cls, token):
        return cls.call(token, "/users/me")

    @classmethod
    def get_user(cls, token, identifier):
        return cls.call(token, "/users/%s" % identifier)
