# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    zoom_webhook_url = fields.Char(
        "Webhook URL", readonly=True, compute="_compute_zoom_urls",
        help="Paste this into the Event Subscription of your Zoom app.")
    zoom_redirect_uri = fields.Char(
        "OAuth Redirect URL", readonly=True, compute="_compute_zoom_urls")
    zoom_account_count = fields.Integer(compute="_compute_zoom_urls")

    @api.depends("company_id")
    def _compute_zoom_urls(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url") or ""
        count = self.env["zoom.account"].sudo().search_count([])
        for record in self:
            record.zoom_webhook_url = "%s/zoom/webhook" % base
            record.zoom_redirect_uri = "%s/zoom/oauth/callback" % base
            record.zoom_account_count = count

    def action_open_zoom_accounts(self):
        return self.env["ir.actions.act_window"]._for_xml_id(
            "zoom_meeting_connector.action_zoom_account")
