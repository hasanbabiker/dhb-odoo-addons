# -*- coding: utf-8 -*-

import logging
import re
from datetime import datetime, timedelta

import pytz

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .zoom_api import (
    JOIN_BASE, MEETING_TYPE_INSTANT, MEETING_TYPE_RECURRING_NO_FIXED,
    MEETING_TYPE_SCHEDULED, ZoomAPI, ZoomError,
)

_logger = logging.getLogger(__name__)


class CalendarEvent(models.Model):
    _inherit = "calendar.event"

    is_zoom_meeting = fields.Boolean(
        "Zoom Meeting", copy=False,
        help="Tick to create this meeting in Zoom when the event is saved.")
    zoom_account_id = fields.Many2one(
        "zoom.account", string="Zoom Connection", copy=False,
        domain="[('state', '=', 'connected')]")
    zoom_meeting_id = fields.Char("Zoom Meeting ID", readonly=True,
                                  copy=False, index=True)
    zoom_meeting_uuid = fields.Char("Zoom Meeting UUID", readonly=True, copy=False)
    zoom_join_url = fields.Char("Join Link", readonly=True, copy=False)
    zoom_start_url = fields.Char("Host Start Link", readonly=True, copy=False,
                                 groups="base.group_user")
    zoom_password = fields.Char("Passcode", copy=False)
    zoom_host_email = fields.Char("Host", readonly=True, copy=False)

    zoom_meeting_type = fields.Selection(
        [
            ("scheduled", "Scheduled"),
            ("instant", "Instant"),
            ("recurring", "Recurring, no fixed time"),
        ],
        string="Meeting Type", default="scheduled")
    zoom_agenda = fields.Text("Agenda")

    zoom_host_video = fields.Boolean("Host Video On", default=True)
    zoom_participant_video = fields.Boolean("Participant Video On")
    zoom_join_before_host = fields.Boolean("Join Before Host")
    zoom_mute_upon_entry = fields.Boolean("Mute on Entry", default=True)
    zoom_waiting_room = fields.Boolean("Waiting Room", default=True)
    zoom_auto_recording = fields.Selection(
        [("none", "No"), ("local", "Local"), ("cloud", "Cloud")],
        string="Auto Recording", default="none")

    zoom_state = fields.Selection(
        [
            ("none", "Not created"),
            ("created", "Scheduled"),
            ("started", "In progress"),
            ("ended", "Ended"),
            ("cancelled", "Cancelled in Zoom"),
            ("error", "Error"),
        ],
        string="Zoom Status", default="none", readonly=True, copy=False)
    zoom_error = fields.Char(readonly=True, copy=False)
    zoom_actual_start = fields.Datetime("Actual Start", readonly=True, copy=False)
    zoom_actual_duration = fields.Integer("Actual Duration (min)", readonly=True,
                                          copy=False)
    zoom_total_participants = fields.Integer("Participants", readonly=True,
                                             copy=False)

    participant_ids = fields.One2many(
        "zoom.participant", "event_id", string="Attendance", readonly=True)
    recording_ids = fields.One2many(
        "zoom.recording", "event_id", string="Recordings", readonly=True)
    recording_count = fields.Integer(compute="_compute_recording_count")

    @api.depends("recording_ids")
    def _compute_recording_count(self):
        for event in self:
            event.recording_count = len(event.recording_ids)

    # ==================================================================
    # onchange
    # ==================================================================
    @api.onchange("is_zoom_meeting")
    def _onchange_is_zoom_meeting(self):
        if not self.is_zoom_meeting:
            return
        account = self.env["zoom.account"]._for_user(self.env.user)
        if not account:
            return {"warning": {
                "title": _("No Zoom connection"),
                "message": _("No connected Zoom account was found for your "
                             "company. Ask an administrator to set one up "
                             "under Settings > Zoom."),
            }}
        self.zoom_account_id = account
        self.zoom_host_video = account.default_host_video
        self.zoom_participant_video = account.default_participant_video
        self.zoom_join_before_host = account.default_join_before_host
        self.zoom_mute_upon_entry = account.default_mute_upon_entry
        self.zoom_waiting_room = account.default_waiting_room
        self.zoom_auto_recording = account.default_auto_recording

    # ==================================================================
    # ORM hooks
    # ==================================================================
    @api.model_create_multi
    def create(self, vals_list):
        events = super().create(vals_list)
        if self.env.context.get("from_zoom_webhook"):
            return events
        for event in events:
            if event.is_zoom_meeting and not event.zoom_meeting_id:
                event._zoom_create()
        return events

    # Fields that must be pushed to Zoom when they change.
    ZOOM_SYNCED_FIELDS = {
        "name", "start", "stop", "duration", "allday", "zoom_agenda",
        "zoom_password", "zoom_meeting_type", "zoom_host_video",
        "zoom_participant_video", "zoom_join_before_host",
        "zoom_mute_upon_entry", "zoom_waiting_room", "zoom_auto_recording",
    }

    def write(self, values):
        result = super().write(values)
        if self.env.context.get("from_zoom_webhook"):
            return result
        for event in self:
            if values.get("is_zoom_meeting") and not event.zoom_meeting_id:
                event._zoom_create()
            elif event.zoom_meeting_id and (
                    set(values) & self.ZOOM_SYNCED_FIELDS):
                event._zoom_update()
        return result

    def unlink(self):
        if not self.env.context.get("from_zoom_webhook"):
            for event in self:
                if event.zoom_meeting_id and event.zoom_state in (
                        "created", "started"):
                    try:
                        event._zoom_delete()
                    except (ZoomError, UserError) as err:
                        # Deleting in Odoo must not be blocked by a Zoom outage.
                        _logger.warning(
                            "Zoom: could not delete meeting %s (%s)",
                            event.zoom_meeting_id, err)
        return super().unlink()

    # ==================================================================
    # payload
    # ==================================================================
    def _zoom_timezone(self):
        self.ensure_one()
        return (self.zoom_account_id.default_timezone
                or self.env.user.tz
                or self.env.company.partner_id.tz
                or "UTC")

    def _zoom_start_time(self):
        """Zoom wants an ISO string; sending it in UTC with the Z suffix and a
        separate timezone field is the least ambiguous combination."""
        self.ensure_one()
        if not self.start:
            return None
        return pytz.utc.localize(self.start).strftime("%Y-%m-%dT%H:%M:%SZ")

    def _zoom_duration_minutes(self):
        self.ensure_one()
        if self.allday:
            return 480
        if self.duration:
            return max(1, int(round(self.duration * 60)))
        if self.start and self.stop:
            return max(1, int((self.stop - self.start).total_seconds() // 60))
        return 60

    def _zoom_type(self):
        self.ensure_one()
        return {
            "instant": MEETING_TYPE_INSTANT,
            "scheduled": MEETING_TYPE_SCHEDULED,
            "recurring": MEETING_TYPE_RECURRING_NO_FIXED,
        }.get(self.zoom_meeting_type or "scheduled", MEETING_TYPE_SCHEDULED)

    def _zoom_payload(self):
        self.ensure_one()
        payload = {
            "topic": (self.name or _("Meeting"))[:200],
            "type": self._zoom_type(),
            "agenda": (self.zoom_agenda or self._plain_description())[:2000],
            "timezone": self._zoom_timezone(),
            "settings": {
                "host_video": self.zoom_host_video,
                "participant_video": self.zoom_participant_video,
                "join_before_host": self.zoom_join_before_host,
                "mute_upon_entry": self.zoom_mute_upon_entry,
                "waiting_room": self.zoom_waiting_room,
                "auto_recording": self.zoom_auto_recording or "none",
                "approval_type": 2,  # no registration required
            },
        }
        if payload["type"] in (MEETING_TYPE_SCHEDULED,):
            payload["start_time"] = self._zoom_start_time()
            payload["duration"] = self._zoom_duration_minutes()
        if self.zoom_password:
            payload["password"] = self.zoom_password[:10]
        return payload

    def _plain_description(self):
        """Zoom's agenda field is plain text; strip the HTML Odoo stores."""
        self.ensure_one()
        return re.sub(r"<[^>]+>", " ", str(self.description or "")).strip()

    # ==================================================================
    # Zoom operations
    # ==================================================================
    def _zoom_account(self):
        self.ensure_one()
        account = self.zoom_account_id or self.env["zoom.account"]._for_user(
            self.user_id or self.env.user)
        if not account:
            raise UserError(_(
                "No connected Zoom account is available for this meeting."))
        return account

    def _zoom_create(self):
        self.ensure_one()
        account = self._zoom_account()
        host = account.zoom_host_for(self.user_id or self.env.user)
        try:
            body = ZoomAPI.create_meeting(
                account._token(), host, self._zoom_payload())
        except (ZoomError, UserError) as err:
            message = err.args[0] if err.args else str(err)
            self.sudo().write({"zoom_state": "error", "zoom_error": message})
            self.message_post(body=_("Zoom refused to create the meeting: %s")
                              % message)
            return False
        self._apply_zoom_body(body, account)
        self.message_post(body=_(
            "Zoom meeting created.<br/>ID: <b>%(id)s</b><br/>"
            "<a href='%(url)s' target='_blank'>Join link</a>",
            id=body.get("id"), url=body.get("join_url") or ""))
        return True

    def _apply_zoom_body(self, body, account=None):
        self.ensure_one()
        values = {
            "zoom_meeting_id": str(body.get("id") or ""),
            "zoom_meeting_uuid": body.get("uuid"),
            "zoom_join_url": body.get("join_url"),
            "zoom_start_url": body.get("start_url"),
            "zoom_password": body.get("password") or self.zoom_password,
            "zoom_host_email": body.get("host_email"),
            "zoom_state": "created",
            "zoom_error": False,
            "is_zoom_meeting": True,
        }
        if account:
            values["zoom_account_id"] = account.id
        # Make the calendar's Join button open Zoom. These two fields moved
        # around between Odoo versions, so check before writing them.
        if body.get("join_url") and "videocall_location" in self._fields:
            values["videocall_location"] = body["join_url"]
            source = self._fields.get("videocall_source")
            if source and "custom" in dict(
                    source.get_description(self.env).get("selection") or []):
                values["videocall_source"] = "custom"
        self.with_context(from_zoom_webhook=True).sudo().write(values)

    def _zoom_update(self):
        self.ensure_one()
        account = self._zoom_account()
        try:
            ZoomAPI.update_meeting(
                account._token(), self.zoom_meeting_id, self._zoom_payload())
        except (ZoomError, UserError) as err:
            message = err.args[0] if err.args else str(err)
            self.sudo().write({"zoom_error": message})
            self.message_post(body=_("Zoom update failed: %s") % message)
            return False
        self.sudo().write({"zoom_error": False})
        return True

    def _zoom_delete(self):
        self.ensure_one()
        account = self._zoom_account()
        ZoomAPI.delete_meeting(account._token(), self.zoom_meeting_id)
        self.with_context(from_zoom_webhook=True).sudo().write({
            "zoom_state": "cancelled",
        })
        return True

    # ==================================================================
    # buttons
    # ==================================================================
    def action_zoom_create(self):
        for event in self:
            if event.zoom_meeting_id:
                raise UserError(_("%s already has a Zoom meeting.") % event.name)
            event.is_zoom_meeting = True
            event._zoom_create()
        return True

    def action_zoom_refresh(self):
        """Pull the meeting back from Zoom, in case it was edited there."""
        for event in self:
            if not event.zoom_meeting_id:
                continue
            account = event._zoom_account()
            try:
                body = ZoomAPI.get_meeting(account._token(), event.zoom_meeting_id)
            except ZoomError as err:
                event.sudo().write({
                    "zoom_state": "cancelled",
                    "zoom_error": err.args[0] if err.args else str(err),
                })
                continue
            event._apply_zoom_body(body, account)
            event._zoom_apply_remote_schedule(body)
        return True

    def _zoom_apply_remote_schedule(self, body):
        """Bring topic and timing from Zoom back into the Odoo event."""
        self.ensure_one()
        values = {}
        if body.get("topic") and body["topic"] != self.name:
            values["name"] = body["topic"]
        start_raw = body.get("start_time")
        if start_raw:
            try:
                start = datetime.strptime(start_raw, "%Y-%m-%dT%H:%M:%SZ")
            except ValueError:
                start = None
            if start and start != self.start:
                minutes = int(body.get("duration") or self._zoom_duration_minutes())
                values["start"] = start
                values["stop"] = start + timedelta(minutes=minutes)
                values["duration"] = minutes / 60.0
        if values:
            self.with_context(from_zoom_webhook=True).sudo().write(values)

    def action_zoom_join(self):
        self.ensure_one()
        if not self.zoom_join_url:
            raise UserError(_("This meeting has no Zoom link yet."))
        return {"type": "ir.actions.act_url", "target": "new",
                "url": self.zoom_join_url}

    def action_zoom_start(self):
        self.ensure_one()
        if not self.zoom_start_url:
            raise UserError(_("Only the host has a start link for this meeting."))
        return {"type": "ir.actions.act_url", "target": "new",
                "url": self.zoom_start_url}

    def action_view_recordings(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Recordings"),
            "res_model": "zoom.recording",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
        }

    # ==================================================================
    # post-meeting
    # ==================================================================
    def action_zoom_fetch_report(self):
        for event in self:
            event._zoom_pull_report()
        return True

    def _zoom_pull_report(self):
        """Actual duration, attendance and recordings, once the meeting ended."""
        self.ensure_one()
        if not (self.zoom_meeting_uuid or self.zoom_meeting_id):
            return False
        account = self._zoom_account()
        token = account._token()
        reference = self.zoom_meeting_uuid or self.zoom_meeting_id

        summary_lines = []
        try:
            past = ZoomAPI.past_meeting(token, reference)
            start = past.get("start_time")
            self.with_context(from_zoom_webhook=True).sudo().write({
                "zoom_actual_start": self.env["zoom.participant"]._parse(start),
                "zoom_actual_duration": past.get("duration") or 0,
                "zoom_total_participants": past.get("participants_count") or 0,
                "zoom_state": "ended",
            })
            summary_lines.append(_("Duration: %s minutes") % (past.get("duration") or 0))
        except ZoomError as err:
            _logger.info("Zoom: past meeting not available yet for %s (%s)",
                         reference, err)

        try:
            data = ZoomAPI.past_participants(token, reference)
            count = self.env["zoom.participant"]._record_from_zoom(
                self, data.get("participants") or [])
            summary_lines.append(_("Attendance: %s participants") % count)
        except ZoomError as err:
            _logger.info("Zoom: participants not available for %s (%s)",
                         reference, err)

        if self.zoom_auto_recording and self.zoom_auto_recording == "cloud":
            try:
                data = ZoomAPI.recordings(token, self.zoom_meeting_id)
                added = self.env["zoom.recording"]._record_from_zoom(self, data)
                if added:
                    summary_lines.append(_("%s recording files linked.") % added)
            except ZoomError as err:
                _logger.info("Zoom: recordings not available for %s (%s)",
                             self.zoom_meeting_id, err)

        if summary_lines:
            self.message_post(body=_("Zoom meeting summary:<br/>%s")
                              % "<br/>".join(summary_lines))
        return True

    @api.model
    def _cron_pull_zoom_reports(self):
        """Catch meetings whose webhook never arrived."""
        now = fields.Datetime.now()
        events = self.search([
            ("zoom_meeting_id", "!=", False),
            ("zoom_state", "in", ("created", "started")),
            ("stop", "<", now - timedelta(minutes=15)),
            ("stop", ">", now - timedelta(days=7)),
        ], limit=50)
        for event in events:
            try:
                event._zoom_pull_report()
            except Exception as err:
                _logger.warning("Zoom: report pull failed for %s (%s)",
                                event.name, err)
