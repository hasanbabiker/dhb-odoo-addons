# Zoom Meeting Connector — وحدة أوديو 19

جدولة اجتماعات Zoom من تقويم أوديو مباشرة، مع مزامنة في الاتجاهين عبر webhooks.

## المميزات

| | |
|---|---|
| إنشاء الاجتماع | فعّل خانة *Zoom Meeting* في حدث التقويم واحفظ — يُنشأ الاجتماع في Zoom |
| التعديل والحذف | أي تغيير في الوقت أو الموضوع أو الإعدادات يُرسل إلى Zoom تلقائيًا |
| الاتجاه المعاكس | webhook يعيد إلى أوديو ما عُدّل أو أُلغي أو أُنشئ داخل Zoom |
| أنواع الاجتماعات | Scheduled · Instant · Recurring بلا وقت ثابت |
| الخيارات | كلمة مرور، غرفة انتظار، كاميرا المضيف والمشاركين، الدخول قبل المضيف، كتم عند الدخول، تسجيل تلقائي |
| بعد الاجتماع | المدة الفعلية، قائمة الحضور مع أوقات الدخول والخروج، وروابط التسجيل السحابي، وملخّص في المحادثة |
| زر الانضمام | رابط Zoom يُكتب في `videocall_location` فيعمل زر Join في التقويم |

## الهيكل

```
zoom_meeting_connector/
├── models/
│   ├── zoom_api.py           عميل Zoom API v2 بنوعي المصادقة
│   ├── zoom_account.py       الاتصال، التوكنات، تحديد المضيف
│   ├── calendar_event.py     امتداد calendar.event وكل منطق المزامنة
│   └── zoom_participant.py   الحضور والتسجيلات
├── controllers/main.py       webhook + callback الخاص بـ OAuth
```

## إعداد تطبيق Zoom

على [marketplace.zoom.us](https://marketplace.zoom.us) → Develop → Build App.

### الخيار الموصى به: Server-to-Server OAuth

اختر نوع **Server-to-Server OAuth**. لا يحتاج أي تفاعل من المستخدم،
وتستطيع من خلاله جدولة اجتماعات باسم أي مضيف مرخّص في حسابك.

الصلاحيات المطلوبة (Scopes):

```
meeting:write:admin      إنشاء وتعديل وحذف الاجتماعات
meeting:read:admin       قراءة تفاصيل الاجتماع
user:read:admin          مطابقة مستخدم أوديو بمضيف Zoom عبر البريد
report:read:admin        تقرير ما بعد الاجتماع والحضور
recording:read:admin     روابط التسجيل السحابي
```

انسخ **Account ID** و **Client ID** و **Client Secret** إلى
*Zoom → Configuration → Zoom Connections* في أوديو، ثم اضغط **Test Connection**.

### الخيار الثاني: User OAuth

لو أردت أن يربط كل مستخدم حساب Zoom الخاص به، أنشئ تطبيق **General**
وأضف الـ Redirect URL المعروض في إعدادات أوديو
(`https://your-domain.com/zoom/oauth/callback`)، ثم اضغط **Connect to Zoom**
من بطاقة الاتصال.

### الـ Webhook

في تبويب **Feature → Event Subscription**:

- العنوان: `https://your-domain.com/zoom/webhook`
- انسخ **Secret Token** إلى حقل *Webhook Secret Token* في أوديو **قبل** الضغط
  على Validate، لأن Zoom يتحقق من العنوان بتوقيع HMAC والوحدة تردّ عليه.
- الأحداث: `meeting.created` · `meeting.updated` · `meeting.deleted` ·
  `meeting.started` · `meeting.ended` · `recording.completed`

## متطلبات

- `web.base.url` مضبوط على النطاق الحقيقي بـ HTTPS.
- أن يمرّر البروكسي ترويسات `x-zm-signature` و`x-zm-request-timestamp`.
- المضيف يجب أن يكون **Licensed** في Zoom؛ الحسابات المجانية محدودة بأربعين دقيقة
  ولا تدعم التسجيل السحابي.

## حدود معروفة — اقرأها قبل الإنتاج

**التكرار (Recurrence) غير مربوط بالكامل.** أوديو يمثّل التكرار بطريقته الخاصة
(`recurrency`, `rrule`)، وZoom بطريقة مختلفة (`type=8` مع كائن `recurrence`).
الوحدة تدعم `Recurring بلا وقت ثابت` (`type=3`) وهو رابط واحد يصلح لكل
المرّات، وهذا يغطي معظم حالات التدريب. تحويل قاعدة التكرار الأوديوية إلى
كائن Zoom كاملًا قطعة إضافية أستطيع بناءها إن احتجتها.

**تقرير ما بعد الاجتماع لا يكون جاهزًا لحظة انتهائه.** لهذا لا تُستدعى واجهة
التقارير عند وصول `meeting.ended`، بل يتولّاها كرون كل نصف ساعة. تستطيع
استعجاله بزر **Fetch Report**.

**الحذف من أوديو لا يُوقفه انقطاع Zoom.** إن فشل حذف الاجتماع في Zoom يُسجَّل
تحذير ويكمل الحذف في أوديو، حتى لا يعلق المستخدم. راجع السجل في هذه الحالة.

**مطابقة المضيف تتم بالبريد الإلكتروني.** إن لم يوجد مضيف في Zoom ببريد
مستخدم أوديو، يُنشأ الاجتماع باسم مالك التطبيق. تأكّد من تطابق العناوين.

## الرخصة

LGPL-3 — الكود مكتوب من الصفر، ولا يحتوي على شيء منقول من الوحدات التجارية
المنشورة على متجر أوديو.
