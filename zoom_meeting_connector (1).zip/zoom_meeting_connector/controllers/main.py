# -*- coding: utf-8 -*-

import hashlib
import hmac
import json
import logging

from odoo import _, http
from odoo.http import request

from ..models.zoom_api import ZoomAPI, ZoomError

_logger = logging.getLogger(__name__)

JSON_HEADERS = [("Content-Type", "application/json; charset=utf-8")]


class ZoomController(http.Controller):

    # ==================================================================
    # OAuth callback (user-level connections)
    # ==================================================================
    @http.route("/zoom/oauth/callback", type="http", auth="user",
                methods=["GET"], csrf=False)
    def zoom_oauth_callback(self, **kwargs):
        if kwargs.get("error"):
            return self._page(_("Zoom refused the connection"),
                              kwargs.get("error_description")
                              or kwargs["error"], success=False)
        code = kwargs.get("code")
        account = request.env["zoom.account"].sudo().browse(
            int(kwargs.get("state") or 0)).exists()
        if not code or not account:
            return self._page(_("Connection failed"),
                              _("Zoom sent an incomplete response."),
                              success=False)

        base = request.env["ir.config_parameter"].sudo().get_param("web.base.url")
        try:
            body = ZoomAPI.token_from_code(
                account.client_id, account.client_secret, code,
                "%s/zoom/oauth/callback" % base)
            account._store_token(body)
            account.action_test_connection()
        except ZoomError as err:
            return self._page(_("Connection failed"),
                              err.args[0] if err.args else str(err),
                              success=False)

        action = request.env.ref("zoom_meeting_connector.action_zoom_account",
                                 raise_if_not_found=False)
        url = "/odoo/action-%s/%s" % (action.id, account.id) if action else "/odoo"
        return request.redirect(url)

    def _page(self, title, message, success=True):
        return request.render("zoom_meeting_connector.zoom_result", {
            "title": title, "message": message, "success": success,
        })

    # ==================================================================
    # Webhooks
    # ==================================================================
    @http.route("/zoom/webhook", type="http", auth="public",
                methods=["POST"], csrf=False, save_session=False)
    def zoom_webhook(self, **kwargs):
        raw = request.httprequest.get_data()
        try:
            payload = json.loads(raw or b"{}")
        except ValueError:
            return request.make_response("bad payload", status=400)

        event = payload.get("event")
        account = self._match_account(payload)

        # Zoom validates the endpoint by asking us to sign a token.
        if event == "endpoint.url_validation":
            return self._url_validation(payload, account)

        if not self._verify_signature(raw, account):
            _logger.warning("Zoom: webhook rejected, bad signature (event %s)", event)
            return request.make_response("invalid signature", status=401)

        try:
            self._handle(event, payload.get("payload") or {}, account)
        except Exception:
            _logger.exception("Zoom: webhook handling failed for %s", event)
        return request.make_response(
            json.dumps({"status": "ok"}), headers=JSON_HEADERS)

    # ------------------------------------------------------------------
    def _match_account(self, payload):
        """Find the connection this event belongs to, by Zoom account id."""
        Account = request.env["zoom.account"].sudo()
        account_id = (payload.get("payload") or {}).get("account_id")
        if account_id:
            match = Account.search([("account_id", "=", account_id)], limit=1)
            if match:
                return match
        # A single-connection database is the common case.
        return Account.search([("state", "=", "connected")], limit=1)

    def _url_validation(self, payload, account):
        secret = account.secret_token if account else None
        plain = (payload.get("payload") or {}).get("plainToken") or ""
        if not secret:
            _logger.warning("Zoom: URL validation asked for but no webhook "
                            "secret token is configured")
            return request.make_response("no secret configured", status=400)
        encrypted = hmac.new(secret.encode(), plain.encode(),
                             hashlib.sha256).hexdigest()
        return request.make_response(
            json.dumps({"plainToken": plain, "encryptedToken": encrypted}),
            headers=JSON_HEADERS)

    def _verify_signature(self, raw, account):
        secret = account.secret_token if account else None
        if not secret:
            _logger.info("Zoom: webhook accepted without signature check "
                         "(no secret token configured)")
            return True
        timestamp = request.httprequest.headers.get("x-zm-request-timestamp")
        signature = request.httprequest.headers.get("x-zm-signature")
        if not (timestamp and signature):
            return False
        message = "v0:%s:%s" % (timestamp, raw.decode())
        expected = "v0=%s" % hmac.new(
            secret.encode(), message.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)

    # ------------------------------------------------------------------
    def _handle(self, event, payload, account):
        obj = payload.get("object") or {}
        meeting_id = str(obj.get("id") or "")
        env = request.env(su=True)
        Event = env["calendar.event"]
        record = Event.search([("zoom_meeting_id", "=", meeting_id)], limit=1) \
            if meeting_id else Event

        if event == "meeting.created" and not record:
            self._create_from_zoom(env, obj, account)
            return
        if not record:
            _logger.info("Zoom: event %s for unknown meeting %s", event, meeting_id)
            return

        writer = record.with_context(from_zoom_webhook=True)

        if event == "meeting.updated":
            # Zoom sends old_object / object; take the new values.
            new_values = payload.get("object") or {}
            record.action_zoom_refresh()
            if new_values.get("topic"):
                writer.write({"name": new_values["topic"]})
        elif event == "meeting.deleted":
            writer.write({"zoom_state": "cancelled"})
            record.message_post(body=_("This meeting was deleted in Zoom."))
        elif event == "meeting.started":
            writer.write({
                "zoom_state": "started",
                "zoom_meeting_uuid": obj.get("uuid") or record.zoom_meeting_uuid,
            })
        elif event == "meeting.ended":
            writer.write({
                "zoom_state": "ended",
                "zoom_meeting_uuid": obj.get("uuid") or record.zoom_meeting_uuid,
            })
            # The report is not ready the instant the meeting ends, so let the
            # cron pick it up rather than calling Zoom straight away.
        elif event == "recording.completed":
            env["zoom.recording"]._record_from_zoom(
                record, obj.get("recording_files") and obj or {})
            record.message_post(body=_("Zoom cloud recording is ready."))
        else:
            _logger.debug("Zoom: unhandled event %s", event)

    def _create_from_zoom(self, env, obj, account):
        """A meeting scheduled directly in the Zoom client shows up in Odoo."""
        from datetime import datetime, timedelta
        start_raw = obj.get("start_time")
        try:
            start = datetime.strptime(start_raw, "%Y-%m-%dT%H:%M:%SZ") \
                if start_raw else False
        except ValueError:
            start = False
        if not start:
            return
        minutes = int(obj.get("duration") or 60)
        host_email = (obj.get("host_email") or "").strip().lower()
        user = env["res.users"].search(
            [("login", "=ilike", host_email)], limit=1) if host_email else None
        env["calendar.event"].with_context(from_zoom_webhook=True).create({
            "name": obj.get("topic") or _("Zoom meeting"),
            "start": start,
            "stop": start + timedelta(minutes=minutes),
            "duration": minutes / 60.0,
            "user_id": user.id if user else env.ref("base.user_admin").id,
            "is_zoom_meeting": True,
            "zoom_account_id": account.id if account else False,
            "zoom_meeting_id": str(obj.get("id") or ""),
            "zoom_meeting_uuid": obj.get("uuid"),
            "zoom_join_url": obj.get("join_url"),
            "zoom_host_email": obj.get("host_email"),
            "zoom_state": "created",
        })
