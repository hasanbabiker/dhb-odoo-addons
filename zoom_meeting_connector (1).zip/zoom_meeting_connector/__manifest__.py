# -*- coding: utf-8 -*-
{
    "name": "Zoom Meeting Connector",
    "version": "19.0.1.0.0",
    "category": "Productivity/Calendar",
    "summary": "Create, update and delete Zoom meetings from the Odoo calendar, "
               "with two-way sync through Zoom webhooks.",
    "description": """
Zoom Meeting Connector
======================

Schedule Zoom meetings straight from an Odoo calendar event. Changes flow both
ways: editing or cancelling in Odoo updates Zoom, and Zoom webhooks bring
changes made in the Zoom client back into Odoo.

* Server-to-Server OAuth (company-wide) or user-level OAuth.
* Meeting types: instant, scheduled, and recurring without a fixed time.
* Per-meeting options: password, waiting room, host and participant video,
  join before host, mute on entry, automatic recording.
* Webhook endpoint with Zoom's CRC validation and signature verification.
* After a meeting ends, Odoo pulls the real duration, the participant list and
  any cloud recording links, and posts a summary in the chatter.
* The calendar's Join button opens the Zoom link directly.
""",
    "author": "",
    "website": "",
    "license": "LGPL-3",
    "depends": ["base", "calendar", "mail"],
    "external_dependencies": {"python": ["requests"]},
    "data": [
        "security/zoom_security.xml",
        "security/ir.model.access.csv",
        "data/ir_cron.xml",
        "views/zoom_participant_views.xml",
        "views/zoom_recording_views.xml",
        "views/zoom_account_views.xml",
        "views/calendar_event_views.xml",
        "views/res_config_settings_views.xml",
        "views/zoom_menus.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
