{
    "name": "DHB Training Schedule",
    "version": "19.0.1.1.1",
    "summary": "The course notification NEBOSH asks for, built from the "
               "batches instead of typed every month",
    "description": """
DHB Training Schedule
=====================

NEBOSH requires a Learning Partner to notify every course before it runs, on
a form with eleven fixed columns. This produces that form from the batches
the centre is already running - as a spreadsheet, because that is what their
process expects, and as a PDF, because that is what people read.

The column that gets a schedule rejected
----------------------------------------
Two of the eleven columns are the UK start and finish times, and their
heading changes between BST and GMT. The Gulf never moves its clocks; the UK
moves twice a year, on the last Sunday in March and the last Sunday in
October. A class at 7:00 PM Dubai is 4:00 PM BST in July and 3:00 PM GMT in
December, and a schedule carried over from last term is wrong by an hour for
half the year - which is discovered by a learner sitting in an empty
meeting.

So the two UK columns are never typed. They are computed through pytz, from
the batch's own time zone to Europe/London, on the batch's own start date.
Where a file spans a clock change, the heading says ``GMT/BST`` rather than
mislabelling half its rows.

What it adds
------------
Five fields, on the batch: the local class start and finish, and the joining
details - platform, link, meeting ID, passcode. Course-level defaults for
the first three, so a coordinator opening November's batch does not have to
remember what time the course runs.

And the batch says, with everything else that is outstanding on it, when it
is not yet ready to be notified.

The joining details are not typed
---------------------------------
An eleven-digit meeting number and a signed ``?pwd=`` token are exactly the
two values a person mistypes, and the mistake is invisible until a class -
or a NEBOSH visitor - is looking at a link that will not open. So the batch
has two buttons: **Create the Zoom meeting**, which asks Zoom for a new one
and writes down what it answers, and **Find it in Zoom**, which attaches a
meeting that already exists by matching its topic. Neither guesses: if two
meetings match, it names them both and attaches nothing.

Creating needs the scope ``meeting:write:admin`` on the same
Server-to-Server OAuth app whose keys are already in Settings. Without it
Zoom refuses, and the message says which scope to add and that the app has
to be re-activated afterwards.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Education",
    "license": "LGPL-3",
    "depends": [
        "base", "dhb_batch",
        # For the Zoom client. This module teaches it to POST - everything
        # the attendance module needs is a GET - rather than building a
        # second set of credentials handling beside it.
        "dhb_zoom_attendance",
    ],
    "data": [
        "report/schedule_report.xml",
        "views/batch_views.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
