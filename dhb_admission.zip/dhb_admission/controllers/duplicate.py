import logging

from odoo.http import request
from odoo.addons.dhb_registration.controllers.main import DhbRegistrationController

_logger = logging.getLogger(__name__)


class RegistrationDuplicateAware(DhbRegistrationController):
    """Match the learner on more than their email before making a new one.

    The form already reuses a learner whose email matches. That covers the
    person who types the same address twice and misses the far more common
    one who used a work address in March and a personal one in September.

    Only identifiers that belong to one human being are used here — an
    identity document number, a NEBOSH learner number. A shared phone is a
    family and a shared name is a coincidence; those are shown to staff on
    the application screen and never acted on by a controller with nobody
    watching.
    """

    def _save_partner(self, invite, post, id_file, photo_file):
        if not invite.partner_id:
            partner = self._match_existing_learner(post)
            if partner:
                # Set it before the original runs, so its own lookup finds
                # the learner already attached and updates them rather than
                # creating a second record.
                invite.sudo().partner_id = partner
                invite.sudo().message_post(body=(
                    "Matched to the existing learner %s on a strong "
                    "identifier, so no second record was created."
                ) % partner.display_name)
        return super()._save_partner(invite, post, id_file, photo_file)

    @staticmethod
    def _match_existing_learner(post):
        Partner = request.env["res.partner"].sudo()
        matches = Partner._learner_matches(
            email=post.get("email"),
            id_number=post.get("id_document_number"),
            nebosh_number=post.get("nebosh_learner_number"),
        )
        strong = [partner for partner, _reason, is_strong in matches
                  if is_strong]
        if len(strong) == 1:
            return strong[0]
        if len(strong) > 1:
            # Two existing learners share an identifier. Joining the form to
            # either would be a guess, and a wrong guess writes one person's
            # documents onto another. Leave it for a human.
            _logger.warning(
                "Registration form matched %s existing learners on strong "
                "identifiers; left for staff to resolve.", len(strong))
        return False
