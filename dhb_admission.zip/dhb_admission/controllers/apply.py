import logging
import re

from odoo import http, fields, _
from odoo.http import request

_logger = logging.getLogger(__name__)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class AdmissionApplyController(http.Controller):
    """The page an applicant reaches from a published admission register.

    A wide-open form that writes straight into the database is the thing this
    centre cannot have: NEBOSH asks who applied, when, and from where, and a
    form with no identity behind it cannot answer that. So this page does not
    submit an application. It asks for a name and an email, issues that person
    their own single-use registration link, and sends them to it.

    The result is the same to look at as an open application form, and the
    same underneath as an invitation: one tokened record per named applicant,
    with a timestamp and an IP address on it.
    """

    # ------------------------------------------------------------------
    def _get_register(self, token):
        if not token:
            return False
        return request.env["dhb.admission.register"].sudo().search(
            [("token", "=", token)], limit=1)

    def _render_closed(self, register, message):
        return request.render("dhb_admission.apply_closed", {
            "register": register,
            "message": message,
        })

    # ------------------------------------------------------------------
    @http.route(["/dhb/apply/<string:token>"], type="http", auth="public",
                website=True, sitemap=False)
    def apply_form(self, token, **kwargs):
        register = self._get_register(token)
        if not register:
            return request.render("dhb_admission.apply_closed", {
                "register": False,
                "message": _(
                    "This application link is not valid. Please ask DHB "
                    "Training and Consulting for the current one."
                ),
            })

        closed = register._why_closed()
        if closed:
            return self._render_closed(register, closed)

        return request.render("dhb_admission.apply_form", {
            "register": register,
            "event": register.event_id,
            "error": kwargs.get("error"),
            "values": {
                "name": kwargs.get("name", ""),
                "email": kwargs.get("email", ""),
            },
        })

    # ------------------------------------------------------------------
    @http.route(["/dhb/apply/<string:token>/start"], type="http", auth="public",
                website=True, methods=["POST"], csrf=True, sitemap=False)
    def apply_start(self, token, **post):
        register = self._get_register(token)
        if not register:
            return self._render_closed(False, _(
                "This application link is not valid."))

        closed = register._why_closed()
        if closed:
            return self._render_closed(register, closed)

        name = (post.get("name") or "").strip()
        email = (post.get("email") or "").strip().lower()

        error = False
        if len(name) < 3:
            error = _("Please write your full name as it appears on your passport.")
        elif not EMAIL_RE.match(email):
            error = _("That email address does not look right. Please check it.")

        if error:
            return request.render("dhb_admission.apply_form", {
                "register": register,
                "event": register.event_id,
                "error": error,
                "values": {"name": name, "email": email},
            })

        Invite = request.env["dhb.registration.invite"].sudo()

        # Someone who half-filled the form yesterday and came back today
        # should land on the same application, not start a second one.
        invite = Invite.search([
            ("register_id", "=", register.id),
            ("email", "=ilike", email),
            ("state", "in", ("draft", "sent", "opened")),
        ], limit=1)

        if not invite:
            values = register._defaults_for_application()
            values.update({
                "email": email,
                "learner_name": name,
                "state": "opened",
                "opened_on": fields.Datetime.now(),
            })
            invite = Invite.create(values)
            invite.message_post(body=_(
                "Applied through the public page of register %(register)s "
                "from %(ip)s."
            ) % {
                "register": register.name,
                "ip": request.httprequest.remote_addr or _("an unknown address"),
            })

        return request.redirect("/learner/register/%s" % invite.token)
