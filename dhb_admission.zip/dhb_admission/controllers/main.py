import base64
import logging

from odoo import http, fields, _
from odoo.http import request

_logger = logging.getLogger(__name__)

MAX_BYTES = 10 * 1024 * 1024
ALLOWED = {
    "application/pdf": ".pdf",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/heic": ".heic",
    "image/webp": ".webp",
}


class PaymentProofController(http.Controller):
    """The learner's page for sending a receipt back.

    It uses the same invitation token as the registration form, so the learner
    has one link rather than two. The page stays usable after the form has
    been submitted, because payment comes after registration, and it is closed
    only when the invitation itself is cancelled or expired.
    """

    def _get_invite(self, token):
        if not token:
            return False
        return request.env["dhb.registration.invite"].sudo().search(
            [("token", "=", token)], limit=1)

    def _render_closed(self, message):
        return request.render(
            "dhb_admission.payment_link_closed", {"message": message})

    @http.route(["/dhb/payment/<string:token>"], type="http", auth="public",
                website=True, sitemap=False)
    def payment_form(self, token, **kwargs):
        invite = self._get_invite(token)
        if not invite:
            return self._render_closed(_(
                "This link is not valid. Ask the training centre for a new one."
            ))
        if invite.state in ("cancelled", "expired"):
            return self._render_closed(_(
                "This link is no longer active. Ask the training centre for a "
                "new one."
            ))
        return request.render("dhb_admission.payment_upload_form", {
            "invite": invite,
            "error": kwargs.get("error"),
        })

    @http.route(["/dhb/payment/<string:token>/submit"], type="http",
                auth="public", website=True, methods=["POST"], csrf=True,
                sitemap=False)
    def payment_submit(self, token, **post):
        invite = self._get_invite(token)
        if not invite or invite.state in ("cancelled", "expired"):
            return self._render_closed(_("This link is no longer active."))

        upload = request.httprequest.files.get("receipt")
        error = self._check_upload(upload)
        if error:
            return request.render("dhb_admission.payment_upload_form", {
                "invite": invite,
                "error": error,
            })

        content = upload.read()
        amount = 0.0
        raw_amount = (post.get("amount") or "").strip().replace(",", "")
        if raw_amount:
            try:
                amount = float(raw_amount)
            except ValueError:
                amount = 0.0

        paid_on = False
        raw_date = (post.get("paid_on") or "").strip()
        if raw_date:
            try:
                paid_on = fields.Date.to_date(raw_date)
            except (ValueError, TypeError):
                paid_on = False

        kind = post.get("kind")
        if kind not in ("deposit", "balance", "full", "other"):
            kind = "deposit"

        request.env["dhb.payment.proof"].sudo().create({
            "application_id": invite.id,
            "kind": kind,
            "amount": amount,
            "paid_on": paid_on,
            "reference": (post.get("reference") or "").strip()[:64],
            "file": base64.b64encode(content),
            "filename": upload.filename[:128],
            "uploaded_on": fields.Datetime.now(),
            "uploaded_ip": request.httprequest.remote_addr,
            "uploaded_by_learner": True,
        })
        invite.sudo().message_post(body=_(
            "The learner uploaded a proof of payment."))

        return request.render("dhb_admission.payment_upload_thanks", {
            "invite": invite,
        })

    @staticmethod
    def _check_upload(upload):
        """Refuse what cannot be read, and say why in the learner's terms."""
        if not upload or not upload.filename:
            return _("Choose the receipt file first.")
        mimetype = (upload.mimetype or "").lower()
        if mimetype not in ALLOWED:
            return _(
                "Send the receipt as a PDF or a photo (JPG, PNG or HEIC). "
                "Other file types cannot be opened here."
            )
        upload.seek(0, 2)
        size = upload.tell()
        upload.seek(0)
        if size == 0:
            return _("That file is empty.")
        if size > MAX_BYTES:
            return _(
                "That file is larger than %s MB. A photo of the screen is "
                "usually enough."
            ) % (MAX_BYTES // (1024 * 1024))
        return False
