import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"


class DhbAdmissionBlocklist(models.Model):
    """People the centre will not take, and why.

    Separate from NEBOSH's own sanctions, which live on the contact and are
    the awarding body's decision. This is DHB's: someone who charged back,
    who was abusive to a tutor, who was caught passing off another person's
    work before NEBOSH ever heard of it.

    An entry matches on more than the contact record, because the whole point
    is catching somebody who comes back. A person barred in March returns in
    September with a new email and a fresh contact, and a flag on the old
    record catches nothing. So an entry can hold an email, a NEBOSH learner
    number, an identity document number and a phone, and an application is
    checked against all of them.
    """

    _name = "dhb.admission.blocklist"
    _description = "Admission blocklist"
    _order = "create_date desc"
    _inherit = ["mail.thread"]
    _rec_name = "name"

    name = fields.Char(
        string="Name", required=True, tracking=True,
        help="The person as the centre knows them. Spelling varies; the "
             "identifiers below are what actually match.",
    )
    partner_id = fields.Many2one(
        "res.partner", string="Contact", tracking=True,
        help="Their contact record, if there is one.",
    )

    # --- what an application is matched against -------------------------
    email = fields.Char(string="Email", tracking=True)
    nebosh_learner_number = fields.Char(string="NEBOSH learner number", tracking=True)
    id_document_number = fields.Char(string="Identity document number", tracking=True)
    phone = fields.Char(string="Phone", tracking=True)

    severity = fields.Selection(
        [
            ("warn", "Warn only"),
            ("block", "Block — a manager may override"),
        ],
        string="Effect", default="block", required=True, tracking=True,
    )
    reason = fields.Text(
        string="Why", required=True,
        help="Read out loud when somebody overrides this, and read by whoever "
             "asks in two years why this person was turned away.",
    )
    expiry_date = fields.Date(
        string="Until",
        help="Empty means indefinitely. A bar with no end date should be a "
             "decision somebody took, not one nobody revisited.",
    )

    state = fields.Selection(
        [("active", "In force"), ("lifted", "Lifted")],
        default="active", required=True, tracking=True, index=True,
    )
    lifted_reason = fields.Text(string="Why it was lifted")
    lifted_by = fields.Many2one("res.users", readonly=True)
    lifted_on = fields.Datetime(readonly=True)

    active = fields.Boolean(default=True)
    is_in_force = fields.Boolean(
        string="In force now", compute="_compute_in_force", store=True)

    # ------------------------------------------------------------------
    @api.depends("state", "expiry_date")
    def _compute_in_force(self):
        today = fields.Date.today()
        for entry in self:
            entry.is_in_force = bool(
                entry.state == "active"
                and (not entry.expiry_date or entry.expiry_date >= today)
            )

    @api.constrains("email", "nebosh_learner_number", "id_document_number",
                    "phone", "partner_id")
    def _check_something_to_match(self):
        for entry in self:
            if not any([entry.partner_id, entry.email,
                        entry.nebosh_learner_number,
                        entry.id_document_number, entry.phone]):
                raise UserError(_(
                    "An entry with nothing to match on catches nobody. Give "
                    "at least a contact, an email, a NEBOSH number, an "
                    "identity document number or a phone."
                ))

    # ------------------------------------------------------------------
    def action_lift(self):
        if not self.env.user.has_group(MANAGER_GROUP):
            raise UserError(_(
                "Only a DHB Attendance Manager can lift a bar."))
        for entry in self:
            if not (entry.lifted_reason or "").strip():
                raise UserError(_(
                    "Write why the bar is being lifted. It is the same "
                    "question as why it was put on."))
            entry.write({
                "state": "lifted",
                "lifted_by": self.env.user.id,
                "lifted_on": fields.Datetime.now(),
            })
            entry.message_post(body=_("Lifted: %s") % entry.lifted_reason)
        return True

    def action_reinstate(self):
        self.write({"state": "active", "lifted_reason": False,
                    "lifted_by": False, "lifted_on": False})
        return True

    # ------------------------------------------------------------------
    @api.model
    def matches_for(self, partner=None, email=None, learner_number=None,
                    id_number=None, phone=None):
        """Every entry in force that matches any identifier given.

        Blank identifiers never match: an entry with no phone must not catch
        every applicant who also has no phone.
        """
        clauses = []
        if partner:
            clauses.append([("partner_id", "=", partner.id)])
            if partner.email:
                clauses.append([("email", "=ilike", partner.email.strip())])
            if partner.nebosh_learner_number:
                clauses.append([
                    ("nebosh_learner_number", "=ilike",
                     partner.nebosh_learner_number.strip())])
            if getattr(partner, "id_document_number", False):
                clauses.append([
                    ("id_document_number", "=ilike",
                     partner.id_document_number.strip())])
        for value, field in (
            (email, "email"),
            (learner_number, "nebosh_learner_number"),
            (id_number, "id_document_number"),
            (phone, "phone"),
        ):
            if value and str(value).strip():
                clauses.append([(field, "=ilike", str(value).strip())])

        if not clauses:
            return self.browse()

        # Written against the columns rather than against is_in_force: a
        # stored compute on a date does not recompute because the date
        # passed, so an entry that expired last night would still read as
        # in force until something wrote to it.
        today = fields.Date.today()
        domain = [
            "&", ("state", "=", "active"),
            "|", ("expiry_date", "=", False), ("expiry_date", ">=", today),
        ]
        combined = clauses[0]
        for clause in clauses[1:]:
            combined = ["|"] + combined + clause
        return self.search(domain + combined)

    def write(self, values):
        result = super().write(values)
        self._refresh_open_applications()
        return result

    @api.model_create_multi
    def create(self, vals_list):
        entries = super().create(vals_list)
        entries._refresh_open_applications()
        return entries

    @api.model
    def _cron_expire(self):
        """Keep the displayed flag honest once a bar's end date passes.

        The matching itself does not rely on this — it reads the dates — but
        a list showing "in force" against an entry that ended in June is the
        kind of thing that makes people stop trusting the screen.
        """
        stale = self.search([("is_in_force", "=", True),
                             ("expiry_date", "<", fields.Date.today())])
        if stale:
            stale._compute_in_force()
            stale.flush_recordset(["is_in_force"])
            stale._refresh_open_applications()
        return True

    def _refresh_open_applications(self):
        """Keep the flag on open applications true after a change here."""
        Invite = self.env["dhb.registration.invite"]
        try:
            open_applications = Invite.search([
                ("state", "in", ("draft", "sent", "opened", "submitted",
                                 "review", "accepted")),
            ])
            open_applications._compute_blocklist()
            # Called directly rather than left to the recompute queue: the
            # dependency is on the applicant's own fields, so nothing here
            # marks them dirty, and without the flush the new bar would sit
            # in cache and never reach the column the list reads.
            open_applications.flush_recordset([
                "blocklist_ids", "blocklist_hit", "blocklist_blocks",
                "blocklist_reason",
            ])
        except Exception:  # noqa: BLE001
            _logger.exception("Could not refresh blocklist flags")
        return True
