import logging

from odoo import models, _

_logger = logging.getLogger(__name__)


class RegistrationInviteLearner(models.Model):
    """Enrolment is what makes someone a learner in the Learners app.

    The registration form already ticks "Is a learner" the moment it is
    submitted, which was fine when a submitted form was the end of the story.
    Now that there is a decision in between, that tick arrives too early: an
    applicant the centre went on to refuse still sits in the Learners list,
    and the list stops meaning "people we teach".

    So this does two things. It guarantees the tick on enrolment — including
    for learners who arrived by some other route and never had it — and it
    takes the tick back from an applicant who was refused and who turns out
    to have no history with the centre at all.
    """

    _inherit = "dhb.registration.invite"

    # ------------------------------------------------------------------
    def _has_history_with_centre(self, partner):
        """Anything that makes this person a learner regardless of this form.

        Deliberately generous. Removing someone from the Learners app is the
        kind of tidy-up that quietly loses a record, so it only happens when
        every one of these is empty.
        """
        if not partner:
            return False

        confirmed = self.env["event.registration"].search_count([
            ("partner_id", "=", partner.id),
            ("state", "in", ("open", "done")),
        ])
        if confirmed:
            return True

        if self.env["dhb.nebosh.result"].search_count([
                ("partner_id", "=", partner.id)]):
            return True

        other = self.search_count([
            ("partner_id", "=", partner.id),
            ("id", "!=", self.id),
            ("state", "in", ("accepted", "enrolled", "withdrawn")),
        ])
        if other:
            return True

        if partner.moodle_user_id:
            return True

        return False

    # ------------------------------------------------------------------
    def action_enrol(self):
        result = super().action_enrol()
        for application in self:
            partner = application.partner_id
            if application.state == "enrolled" and partner and not partner.is_learner:
                partner.is_learner = True
                application.message_post(body=_(
                    "%s now appears in the Learners app."
                ) % partner.display_name)
        return result

    def action_reject(self):
        result = super().action_reject()
        for application in self:
            partner = application.partner_id
            if not partner or not partner.is_learner:
                continue
            if application._has_history_with_centre(partner):
                continue
            partner.is_learner = False
            application.message_post(body=_(
                "%s was taken out of the Learners app: this application was "
                "refused and the contact has no confirmed place, no result "
                "and no platform account. The contact itself is untouched."
            ) % partner.display_name)
        return result
