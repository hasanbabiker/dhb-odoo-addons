from markupsafe import Markup

from odoo import models, fields, _

# done / attention / waiting. Bootstrap classes only, so the bar takes the
# colours of whatever theme the centre is running rather than fighting it.
STYLES = {
    "done": ("text-bg-success", "✓"),
    "warn": ("text-bg-warning", "!"),
    "wait": ("text-bg-light border", "·"),
}


class ResPartnerJourney(models.Model):
    """Where this learner has got to, on one line.

    A learner's position is spread over seven screens: the application, the
    place on the cohort, the platform account, the attendance register, the
    interview record, the result and the certificate. Answering "where is
    this person?" meant opening all seven and holding the answer in your head.

    This reads all of them and prints one row per cohort. It writes nothing
    and decides nothing — it is a window, so it can never be the reason a
    record is wrong.
    """

    _inherit = "res.partner"

    dhb_journey_html = fields.Html(
        string="Journey", compute="_compute_dhb_journey",
        sanitize=False, readonly=True,
    )

    # ------------------------------------------------------------------
    def _journey_chip(self, state, label, detail=None):
        """Only the CSS class is trusted markup; everything else is escaped.

        The detail comes from a rejection reason or a platform error message,
        which is text somebody typed. Interpolating that into an attribute
        without escaping is how a stray quote breaks the page.
        """
        css, mark = STYLES.get(state, STYLES["wait"])
        if detail:
            return Markup(
                '<span class="badge %s me-1 mb-1" title="%s">%s %s</span>'
            ) % (Markup(css), detail, mark, label)
        return Markup(
            '<span class="badge %s me-1 mb-1">%s %s</span>'
        ) % (Markup(css), mark, label)

    # ------------------------------------------------------------------
    def _journey_stages(self, registration):
        """The eight stages for one place on one cohort."""
        self.ensure_one()
        event = registration.event_id
        Invite = self.env["dhb.registration.invite"]

        application = Invite.search([
            ("partner_id", "=", self._origin.id),
            ("event_id", "=", event.id),
        ], order="create_date desc", limit=1)

        stages = []

        # 1. Applied
        if application:
            stages.append(("done", _("Applied"), application.name))
        else:
            stages.append((
                "wait", _("Applied"),
                _("Added to the cohort without going through admissions")))

        # 2. Accepted
        if application.state == "enrolled":
            stages.append(("done", _("Enrolled"), None))
        elif application.state == "accepted":
            stages.append(("warn", _("Accepted"), _("Place held, not confirmed")))
        elif application.state in ("rejected", "withdrawn"):
            stages.append((
                "warn",
                _("Rejected") if application.state == "rejected" else _("Withdrew"),
                application.rejection_reason or application.withdrawal_reason))
        elif registration.state in ("open", "done"):
            stages.append(("done", _("Enrolled"), _("Confirmed on the cohort")))
        else:
            stages.append(("wait", _("Enrolled"), None))

        # 3. Paid
        invoices = application.invoice_id | application.balance_invoice_id
        posted = invoices.filtered(lambda i: i.state == "posted")
        if not invoices:
            stages.append(("wait", _("Paid"), _("Nothing invoiced yet")))
        elif posted and all(
                i.payment_state in ("paid", "in_payment", "reversed")
                for i in posted):
            stages.append(("done", _("Paid"), None))
        else:
            outstanding = sum(i.amount_residual for i in posted)
            stages.append((
                "warn", _("Paid"),
                _("%s still outstanding") % outstanding if outstanding
                else _("Invoice not posted yet")))

        # 4. Platform
        if self.moodle_state == "active":
            stages.append(("done", _("Platform"), self.moodle_username or None))
        elif self.moodle_state == "held":
            stages.append(("warn", _("Platform"), _("Account created, suspended")))
        elif self.moodle_state == "error":
            stages.append(("warn", _("Platform"), self.moodle_message or None))
        else:
            stages.append(("wait", _("Platform"), _("No account")))

        # 5. Attendance
        pct = registration.attendance_pct or 0.0
        if not registration.attendance_line_ids:
            stages.append(("wait", _("Attendance"), _("No lectures recorded yet")))
        elif registration.can_register_exam:
            stages.append(("done", _("Attendance %.0f%%") % pct, None))
        else:
            stages.append((
                "warn", _("Attendance %.0f%%") % pct,
                _("Below the requirement to sit the exam")))

        # 6. Interview — the module may not be installed.
        if "dhb.interview" in self.env:
            interviews = self.env["dhb.interview"].search([
                ("registration_id", "=", registration.id)])
            if not interviews:
                stages.append(("wait", _("Interview"), None))
            elif all(i.is_complete for i in interviews):
                stages.append(("done", _("Interview"), None))
            else:
                stages.append((
                    "warn", _("Interview"),
                    _("Recorded but not complete")))

        # 7. Result
        results = self.env["dhb.nebosh.result"].search([
            ("partner_id", "=", self._origin.id),
        ])
        if event.qualification:
            key = event.qualification.replace("_", "").lower()
            narrowed = results.filtered(
                lambda r: key in (r.qualification or "").replace(
                    " ", "").replace("_", "").lower()
                or key in (r.unit_code or "").lower())
            results = narrowed or results
        if not results:
            stages.append(("wait", _("Result"), None))
        elif any(r.status == "refer" for r in results):
            stages.append((
                "warn", _("Result"),
                _("%s unit(s) referred") % len(
                    results.filtered(lambda r: r.status == "refer"))))
        elif all(r.status == "pass" for r in results):
            stages.append(("done", _("Result"), _("Passed")))
        else:
            stages.append(("warn", _("Result"), _("Not all units are through")))

        # 8. Certificate
        if self.certificate_sent_to_learner or self.certificate_tracking:
            stages.append(("done", _("Certificate"), _("Sent to the learner")))
        elif self.certificate_received or self.certificate_number:
            stages.append((
                "warn", _("Certificate"), _("Received, not sent on")))
        else:
            stages.append(("wait", _("Certificate"), None))

        return stages

    # ------------------------------------------------------------------
    def _compute_dhb_journey(self):
        Registration = self.env["event.registration"]
        for partner in self:
            # A form being filled in has a NewId, which no search accepts.
            origin = partner._origin
            if not partner.is_learner or not origin.id:
                partner.dhb_journey_html = False
                continue

            registrations = Registration.search([
                ("partner_id", "=", origin.id),
                ("state", "!=", "cancel"),
            ], order="create_date desc")

            if not registrations:
                partner.dhb_journey_html = Markup(
                    '<div class="text-muted">This learner is not on a cohort '
                    'yet.</div>')
                continue

            blocks = []
            for registration in registrations:
                chips = Markup("").join(
                    partner._journey_chip(state, label, detail)
                    for state, label, detail in partner._journey_stages(registration)
                )
                blocks.append(Markup(
                    '<div class="mb-2">'
                    '<div class="fw-bold small text-muted">%s</div>'
                    '<div>%s</div>'
                    '</div>'
                ) % (registration.event_id.display_name or "", chips))

            partner.dhb_journey_html = Markup("").join(blocks)
