import base64
import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

REPORT = "dhb_admission.report_registration_record"


class ReportRegistrationRecord(models.AbstractModel):
    """Feeds the registration record its policy acceptances."""

    _name = "report.dhb_admission.report_registration_record"
    _description = "Registration record"

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env["dhb.registration.invite"].browse(docids)
        Acceptance = self.env["dhb.policy.acceptance"].sudo()
        acceptances = {}
        for doc in docs:
            acceptances[doc.id] = Acceptance.search(
                [("partner_id", "=", doc.partner_id.id)], order="accepted_on"
            ) if doc.partner_id else Acceptance.browse()
        return {
            "doc_ids": docids,
            "doc_model": "dhb.registration.invite",
            "docs": docs,
            "acceptances": acceptances,
        }


class RegistrationInviteConfirmation(models.Model):
    """Send the learner their own paperwork the moment it exists.

    A learner who has filled in a form, accepted the policies and been
    invoiced currently receives nothing. They have no copy of what they
    agreed to and no invoice to take to whoever is paying, so they ask, and
    somebody digs it out by hand.

    This sends both as attachments: the registration record, which reproduces
    their submitted details and every policy text they accepted with its
    timestamp, and the invoice itself.
    """

    _inherit = "dhb.registration.invite"

    confirmation_state = fields.Selection(
        [
            ("none", "Not sent"),
            ("queued", "Queued"),
            ("sent", "Sent"),
            ("failed", "Failed"),
        ],
        string="Confirmation pack", default="none", copy=False, index=True,
        tracking=True,
    )
    confirmation_sent_on = fields.Datetime(
        string="Confirmation sent", readonly=True, copy=False)
    confirmation_message = fields.Char(readonly=True, copy=False)

    # ------------------------------------------------------------------
    def _confirmation_attachments(self):
        """The registration record, the invoices, and the signed declaration.

        Each is attempted on its own: a missing PDF engine should cost one
        attachment, not the whole email.
        """
        self.ensure_one()
        Attachment = self.env["ir.attachment"]
        attachments = Attachment.browse()
        Report = self.env["ir.actions.report"]

        # 1. the registration record
        try:
            pdf, _dummy = Report._render_qweb_pdf(REPORT, self.ids)
            attachments |= Attachment.create({
                "name": "Registration - %s.pdf" % (
                    self.partner_id.display_name or self.name),
                "type": "binary",
                "datas": base64.b64encode(pdf),
                "res_model": self._name,
                "res_id": self.id,
                "mimetype": "application/pdf",
            })
        except Exception as exc:  # noqa: BLE001
            _logger.exception(
                "Could not render the registration record for %s", self.id)
            self.message_post(body=_(
                "The registration record could not be produced, so it is not "
                "attached: %s") % exc)

        # 2. the invoices
        invoice_report = self.env.ref(
            "account.account_invoices", raise_if_not_found=False)
        for invoice in (self.invoice_id | self.balance_invoice_id):
            if invoice.state == "cancel" or not invoice_report:
                continue
            try:
                pdf, _dummy = Report._render_qweb_pdf(
                    invoice_report.report_name, invoice.ids)
                attachments |= Attachment.create({
                    "name": "%s.pdf" % (invoice.name or "Invoice"),
                    "type": "binary",
                    "datas": base64.b64encode(pdf),
                    "res_model": "account.move",
                    "res_id": invoice.id,
                    "mimetype": "application/pdf",
                })
            except Exception as exc:  # noqa: BLE001
                _logger.exception(
                    "Could not render invoice %s", invoice.id)
                self.message_post(body=_(
                    "Invoice %(name)s could not be attached: %(error)s"
                ) % {"name": invoice.name, "error": exc})

        # 3. the signed declaration, if one was uploaded
        if self.declaration_file:
            attachments |= Attachment.create({
                "name": self.declaration_filename or "Signed declaration",
                "type": "binary",
                "datas": self.declaration_file,
                "res_model": self._name,
                "res_id": self.id,
            })

        return attachments

    # ------------------------------------------------------------------
    def action_send_confirmation(self):
        """Email the learner their registration record and their invoice."""
        template = self.env.ref(
            "dhb_admission.mail_template_admission_confirmation",
            raise_if_not_found=False)
        if not template:
            raise UserError(_("The confirmation email template is missing."))

        mail_configured = bool(
            self.env["ir.mail_server"].sudo().search_count([]))

        for application in self:
            recipient = (application.partner_id.email
                         or application.email or "").strip()
            if not recipient:
                raise UserError(_(
                    "There is no email address to send to. Add one to the "
                    "learner's contact first."
                ))

            attachments = application._confirmation_attachments()
            try:
                template.send_mail(
                    application.id,
                    force_send=False,
                    email_values={
                        "email_to": recipient,
                        "attachment_ids": [(6, 0, attachments.ids)],
                    },
                )
            except Exception as exc:  # noqa: BLE001
                _logger.exception(
                    "Confirmation email failed for application %s",
                    application.id)
                application.write({
                    "confirmation_state": "failed",
                    "confirmation_message": str(exc)[:250],
                })
                application.message_post(body=_(
                    "The confirmation email could not be queued: %s") % exc)
                continue

            application.write({
                "confirmation_state": "sent" if mail_configured else "queued",
                "confirmation_sent_on": fields.Datetime.now(),
                "confirmation_message": False if mail_configured else _(
                    "Queued: no outgoing mail server is configured yet."),
            })

            if mail_configured:
                application.message_post(body=_(
                    "Registration record and invoice sent to %s with "
                    "%s attachment(s)."
                ) % (recipient, len(attachments)))
            else:
                # Said plainly rather than shown as success: DHB's mail
                # server has been pending for weeks, and a green tick that
                # means "sitting in a queue" is worse than no tick.
                application.message_post(body=_(
                    "The email is prepared and waiting in Odoo's outgoing "
                    "queue, but no outgoing mail server is configured, so "
                    "nothing has left the building. It will go out by itself "
                    "once one is set up. Until then, download the attachments "
                    "from this record and send them by WhatsApp."
                ))
        return True

    def action_send_confirmation_batch(self):
        return self._run_batch("action_send_confirmation", _("sent their pack"))

    # ------------------------------------------------------------------
    def action_create_invoice(self):
        """Raising the invoice is the moment the learner's pack is complete."""
        result = super().action_create_invoice()
        auto = self.env["ir.config_parameter"].sudo().get_param(
            "dhb_admission.auto_send_confirmation", "1") == "1"
        if not auto:
            return result
        for application in self:
            ready = (
                application.state in (
                    "submitted", "review", "accepted", "enrolled")
                and application.invoice_id
                and application.confirmation_state in ("none", "failed")
            )
            if ready:
                try:
                    application.action_send_confirmation()
                except Exception:  # noqa: BLE001
                    # Never let the email cost the invoice that triggered it.
                    _logger.exception(
                        "Automatic confirmation failed for %s", application.id)
        return result
