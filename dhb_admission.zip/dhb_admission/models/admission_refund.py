from odoo import models, fields, api, _
from odoo.exceptions import UserError

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"


class DhbAdmissionRefund(models.Model):
    """A learner who paid and then left, and what goes back to them.

    DHB's policy has two tiers and one hard line:

    * Registered with DHB only - the fee comes back less a fixed
      administrative percentage.
    * Entered with NEBOSH - nothing comes back. The centre has already paid
      the awarding body for that learner's registration and assessment, and
      that money does not return.

    The second tier is written as a red warning with a manager override rather
    than a wall. A sitting cancelled by NEBOSH, or a learner who dies, are
    cases where the centre will choose to refund anyway, and a system that
    makes that impossible only pushes the refund outside the system where
    nobody can audit it. The override costs a manager and a written reason.
    """

    _name = "dhb.admission.refund"
    _description = "Admission refund"
    _order = "create_date desc"
    _inherit = ["mail.thread"]

    name = fields.Char(string="Reference", readonly=True, copy=False, default="/")

    application_id = fields.Many2one(
        "dhb.registration.invite", string="Application", required=True,
        ondelete="cascade", index=True, tracking=True,
    )
    partner_id = fields.Many2one(
        related="application_id.partner_id", string="Learner",
        store=True, readonly=True)
    event_id = fields.Many2one(
        related="application_id.event_id", string="Cohort",
        store=True, readonly=True)
    currency_id = fields.Many2one(
        related="application_id.currency_id", string="Currency", readonly=True)

    # --- the facts the policy turns on ----------------------------------
    nebosh_entered = fields.Boolean(
        related="application_id.nebosh_entry_done",
        string="Entered with NEBOSH", store=True, readonly=True,
    )
    nebosh_entry_date = fields.Date(
        related="application_id.nebosh_entry_date", readonly=True)
    course_started = fields.Boolean(compute="_compute_course_started")

    amount_paid = fields.Monetary(
        string="Paid so far", currency_field="currency_id",
        compute="_compute_amounts", store=True,
        help="What the learner has actually settled, not what was invoiced.",
    )
    admin_fee_percent = fields.Float(
        string="Administrative deduction (%)",
        default=lambda self: self._default_admin_fee(),
    )
    admin_fee_amount = fields.Monetary(
        string="Deduction", currency_field="currency_id",
        compute="_compute_amounts", store=True)
    amount_suggested = fields.Monetary(
        string="Policy says", currency_field="currency_id",
        compute="_compute_amounts", store=True,
        help="What DHB's written policy gives back in this case.",
    )
    amount_refunded = fields.Monetary(
        string="Refund", currency_field="currency_id", tracking=True,
        help="What actually goes back. It starts at the policy figure.",
    )
    is_override = fields.Boolean(
        string="Differs from policy", compute="_compute_is_override")
    override_reason = fields.Text(
        string="Why it differs from policy",
        help="Required whenever the refund is not the policy figure. This is "
             "the line an auditor reads.",
    )

    reason = fields.Text(string="Why the learner is leaving", required=True)

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("approved", "Approved"),
            ("done", "Refunded"),
            ("cancel", "Cancelled"),
        ],
        default="draft", required=True, tracking=True, index=True,
    )
    approved_by = fields.Many2one("res.users", string="Approved by", readonly=True)
    approved_on = fields.Datetime(string="Approved on", readonly=True)

    credit_note_id = fields.Many2one(
        "account.move", string="Credit note", readonly=True, copy=False)
    credit_note_state = fields.Selection(
        related="credit_note_id.state", string="Credit note status", readonly=True)

    # ------------------------------------------------------------------
    @api.model
    def _default_admin_fee(self):
        value = self.env["ir.config_parameter"].sudo().get_param(
            "dhb_admission.refund_admin_fee_percent", "0")
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    @api.model_create_multi
    def create(self, vals_list):
        for values in vals_list:
            if values.get("name", "/") == "/":
                application = self.env["dhb.registration.invite"].browse(
                    values.get("application_id"))
                existing = self.search_count([
                    ("application_id", "=", application.id)])
                values["name"] = "%s/REF%s" % (
                    application.name or "REF", existing + 1)
        records = super().create(vals_list)
        for record in records:
            if not record.amount_refunded:
                record.amount_refunded = record.amount_suggested
        return records

    # ------------------------------------------------------------------
    # what the money actually is
    # ------------------------------------------------------------------
    @api.depends("application_id.invoice_id.amount_total",
                 "application_id.invoice_id.amount_residual",
                 "application_id.invoice_id.state",
                 "application_id.balance_invoice_id.amount_total",
                 "application_id.balance_invoice_id.amount_residual",
                 "application_id.balance_invoice_id.state",
                 "nebosh_entered", "admin_fee_percent")
    def _compute_amounts(self):
        for refund in self:
            application = refund.application_id
            paid = 0.0
            invoices = application.invoice_id | application.balance_invoice_id
            for invoice in invoices:
                if invoice.state == "posted":
                    # settled = total less what is still owed
                    paid += (invoice.amount_total or 0.0) - (
                        invoice.amount_residual or 0.0)
            refund.amount_paid = max(paid, 0.0)

            if refund.nebosh_entered:
                # The awarding body has been paid for this learner. Nothing
                # the centre can recover, so nothing the policy gives back.
                refund.admin_fee_amount = refund.amount_paid
                refund.amount_suggested = 0.0
            else:
                deduction = refund.amount_paid * (
                    (refund.admin_fee_percent or 0.0) / 100.0)
                refund.admin_fee_amount = deduction
                refund.amount_suggested = max(refund.amount_paid - deduction, 0.0)

    @api.depends("amount_refunded", "amount_suggested")
    def _compute_is_override(self):
        for refund in self:
            refund.is_override = self.env.company.currency_id.compare_amounts(
                refund.amount_refunded or 0.0,
                refund.amount_suggested or 0.0,
            ) != 0

    def _compute_course_started(self):
        now = fields.Datetime.now()
        for refund in self:
            begin = refund.event_id.date_begin
            refund.course_started = bool(begin and begin <= now)

    # ------------------------------------------------------------------
    # the pipeline
    # ------------------------------------------------------------------
    def _check_before_approval(self):
        self.ensure_one()
        if self.amount_refunded < 0:
            raise UserError(_("A refund cannot be negative."))
        if self.amount_refunded > self.amount_paid:
            raise UserError(_(
                "You are refunding %(refund)s but the learner has only paid "
                "%(paid)s. If money is owed for another reason, raise it "
                "separately so the two are not confused."
            ) % {
                "refund": self.amount_refunded,
                "paid": self.amount_paid,
            })
        if self.is_override and not (self.override_reason or "").strip():
            raise UserError(_(
                "This refund is not the policy figure. Write why before "
                "approving it — that sentence is what defends the decision "
                "later."
            ))
        if self.nebosh_entered and self.amount_refunded > 0:
            if not self.env.user.has_group(MANAGER_GROUP):
                raise UserError(_(
                    "This learner was entered with NEBOSH, and DHB's policy "
                    "refunds nothing after that point. Only a DHB Attendance "
                    "Manager can override it."
                ))

    def action_approve(self):
        if not self.env.user.has_group(MANAGER_GROUP):
            raise UserError(_(
                "Only a DHB Attendance Manager can approve a refund."))
        for refund in self:
            if refund.state != "draft":
                raise UserError(_("Only a draft refund can be approved."))
            refund._check_before_approval()
            refund.write({
                "state": "approved",
                "approved_by": self.env.user.id,
                "approved_on": fields.Datetime.now(),
            })
            refund.message_post(body=_(
                "Refund of %(amount)s approved. Policy figure was %(policy)s."
            ) % {
                "amount": refund.amount_refunded,
                "policy": refund.amount_suggested,
            })
        return True

    def action_create_credit_note(self):
        """A draft credit note. Posting it is accounting's decision, not this
        screen's — the same rule the payment receipts follow."""
        for refund in self:
            if refund.state != "approved":
                raise UserError(_(
                    "Approve the refund before raising the credit note."))
            if refund.credit_note_id:
                raise UserError(_("This refund already has a credit note."))
            if refund.amount_refunded <= 0:
                raise UserError(_(
                    "Nothing is being refunded, so there is no credit note to "
                    "raise. Mark it refunded instead."))

            product_id = refund.application_id._fee_product_id()
            credit_note = self.env["account.move"].create({
                "move_type": "out_refund",
                "partner_id": refund.partner_id.id,
                "currency_id": refund.currency_id.id,
                "invoice_origin": refund.name,
                "ref": _("Refund — %s") % (refund.event_id.name or ""),
                "invoice_line_ids": [(0, 0, {
                    "product_id": product_id,
                    "name": _("Refund of course fee — %(event)s (%(learner)s)") % {
                        "event": refund.event_id.name,
                        "learner": refund.partner_id.name,
                    },
                    "quantity": 1,
                    "price_unit": refund.amount_refunded,
                })],
            })
            refund.credit_note_id = credit_note.id
            refund.message_post(body=_(
                "Draft credit note %s raised.") % credit_note.name)
        return True

    def action_mark_refunded(self):
        for refund in self:
            if refund.state != "approved":
                raise UserError(_(
                    "Approve the refund before marking it paid back."))
            refund.state = "done"
            refund.message_post(body=_("Marked as refunded."))
        return True

    def action_cancel(self):
        for refund in self:
            if refund.state == "done":
                raise UserError(_(
                    "This refund has already been paid back. Cancelling it "
                    "here would hide that. Raise the correction in accounting "
                    "instead."))
            refund.state = "cancel"
        return True

    def action_reset(self):
        self.write({"state": "draft", "approved_by": False, "approved_on": False})
        return True

    def action_open_credit_note(self):
        self.ensure_one()
        if not self.credit_note_id:
            raise UserError(_("No credit note has been raised yet."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "account.move",
            "res_id": self.credit_note_id.id,
            "view_mode": "form",
        }
