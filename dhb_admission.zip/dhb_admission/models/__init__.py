from . import admission_register
from . import payment_proof
from . import registration_invite
from . import res_config_settings
