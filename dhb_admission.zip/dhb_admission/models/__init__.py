from . import admission_register
from . import admission_refund
from . import payment_proof
from . import registration_invite
from . import res_config_settings
from . import lms_release
from . import learner_promotion
