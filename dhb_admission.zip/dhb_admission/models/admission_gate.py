from odoo import models, fields, api, _
from odoo.exceptions import UserError

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"


class RegistrationInviteGate(models.Model):
    """Two reasons not to take somebody, checked before anyone says yes.

    The first is NEBOSH's and was already on the contact, computed and stored
    by dhb_learner: under investigation (C018 clause 9.1.3 does not permit
    sitting other assessments while one is open) or debarred from entry. It
    was simply never read here — until now the centre could accept a learner
    NEBOSH had barred, and nothing on the screen would have said so.

    The second is DHB's own blocklist.

    Both are a wall with a door: a manager may pass, and only with a written
    reason. A hard block with no way through is how a centre ends up doing
    the thing outside the system, where nobody can audit it; no block at all
    is how it happens by accident.
    """

    _inherit = "dhb.registration.invite"

    # --- NEBOSH's own, already computed on the contact ------------------
    nebosh_blocked = fields.Boolean(
        related="partner_id.registration_blocked",
        string="Blocked by NEBOSH", store=True, readonly=True,
    )
    nebosh_block_reason = fields.Char(
        related="partner_id.registration_block_reason",
        string="NEBOSH says", store=True, readonly=True,
    )

    # --- DHB's own ------------------------------------------------------
    blocklist_ids = fields.Many2many(
        "dhb.admission.blocklist", string="Blocklist entries",
        compute="_compute_blocklist", store=True,
    )
    blocklist_hit = fields.Boolean(
        string="On the blocklist", compute="_compute_blocklist", store=True,
        index=True,
    )
    blocklist_blocks = fields.Boolean(
        string="Blocklist bars this applicant", compute="_compute_blocklist",
        store=True,
    )
    blocklist_reason = fields.Char(
        string="Blocklist says", compute="_compute_blocklist", store=True)

    admission_barred = fields.Boolean(
        string="Barred", compute="_compute_barred", store=True, index=True,
        help="Either NEBOSH or DHB's own blocklist bars this applicant.",
    )
    bar_override_reason = fields.Text(
        string="Why the bar was overridden",
        help="Required to accept somebody who is barred. A manager only.",
    )
    bar_overridden_by = fields.Many2one("res.users", readonly=True)
    bar_overridden_on = fields.Datetime(readonly=True)

    # ------------------------------------------------------------------
    @api.depends("partner_id", "email",
                 "partner_id.email", "partner_id.nebosh_learner_number",
                 "partner_id.id_document_number", "partner_id.phone")
    def _compute_blocklist(self):
        Blocklist = self.env["dhb.admission.blocklist"]
        for application in self:
            entries = Blocklist.matches_for(
                partner=application.partner_id or None,
                email=application.email,
            )
            application.blocklist_ids = [(6, 0, entries.ids)]
            application.blocklist_hit = bool(entries)
            blocking = entries.filtered(lambda e: e.severity == "block")
            application.blocklist_blocks = bool(blocking)
            application.blocklist_reason = (
                blocking[:1].reason or entries[:1].reason or False
            ) if entries else False

    @api.depends("nebosh_blocked", "blocklist_blocks")
    def _compute_barred(self):
        for application in self:
            application.admission_barred = bool(
                application.nebosh_blocked or application.blocklist_blocks)

    # ------------------------------------------------------------------
    def _bar_reasons(self):
        self.ensure_one()
        reasons = []
        if self.nebosh_blocked:
            reasons.append(_("NEBOSH: %s") % (
                self.nebosh_block_reason or _("registration blocked")))
        if self.blocklist_blocks:
            reasons.append(_("DHB blocklist: %s") % (
                self.blocklist_reason or _("no reason recorded")))
        return reasons

    def _check_not_barred(self):
        """Refuse to accept a barred applicant without a manager's reason."""
        self.ensure_one()
        reasons = self._bar_reasons()
        if not reasons:
            return True

        written = (self.bar_override_reason or "").strip()
        if not written:
            raise UserError(
                _("This applicant is barred:\n\n%s\n\n"
                  "To accept them anyway, write why in \"Why the bar was "
                  "overridden\" on the Decision tab. A manager must do it.")
                % "\n".join("• %s" % line for line in reasons)
            )
        if not self.env.user.has_group(MANAGER_GROUP):
            raise UserError(
                _("This applicant is barred:\n\n%s\n\n"
                  "Only a DHB Attendance Manager can accept them.")
                % "\n".join("• %s" % line for line in reasons)
            )
        return True

    # ------------------------------------------------------------------
    def action_start_review(self):
        """The bar is said at review, not sprung at acceptance."""
        result = super().action_start_review()
        for application in self:
            reasons = application._bar_reasons()
            if reasons:
                application.message_post(body=_(
                    "<strong>This applicant is barred.</strong><br/>%s"
                ) % "<br/>".join(reasons))
        return result

    def action_accept(self):
        for application in self:
            application._check_not_barred()
            if application._bar_reasons():
                application.write({
                    "bar_overridden_by": self.env.user.id,
                    "bar_overridden_on": fields.Datetime.now(),
                })
                application.message_post(body=_(
                    "<strong>Accepted despite a bar.</strong><br/>%(bars)s"
                    "<br/><em>%(why)s</em>"
                ) % {
                    "bars": "<br/>".join(application._bar_reasons()),
                    "why": application.bar_override_reason,
                })
        return super().action_accept()

    def action_view_blocklist(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Blocklist entries"),
            "res_model": "dhb.admission.blocklist",
            "view_mode": "list,form",
            "domain": [("id", "in", self.blocklist_ids.ids)],
        }

    def action_add_to_blocklist(self):
        """Bar this applicant, pre-filled from what the application knows."""
        self.ensure_one()
        partner = self.partner_id
        return {
            "type": "ir.actions.act_window",
            "name": _("Add to the blocklist"),
            "res_model": "dhb.admission.blocklist",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_partner_id": partner.id or False,
                "default_name": (
                    partner.display_name or self.learner_name or self.email),
                "default_email": partner.email or self.email,
                "default_nebosh_learner_number":
                    partner.nebosh_learner_number or False,
                "default_id_document_number":
                    getattr(partner, "id_document_number", False) or False,
                "default_phone": partner.phone or False,
            },
        }
