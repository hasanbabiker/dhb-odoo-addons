import logging

from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)


class AdmissionRegisterResponsible(models.Model):
    """Somebody owns each intake, and that is who the work goes to."""

    _inherit = "dhb.admission.register"

    user_id = fields.Many2one(
        "res.users", string="Responsible",
        default=lambda self: self.env.user, tracking=True,
        help="Who gets the to-do when an application on this intake needs "
             "attention.",
    )


class RegistrationInviteActivity(models.Model):
    """Put the work in somebody's list instead of waiting to be found.

    DHB's outgoing mail server has been down for weeks, so a learner can send
    their form at eight in the morning and nobody knows until somebody happens
    to open the screen. Odoo's activities need no mail server at all: they
    appear in the user's own clock icon and in their to-do list, on the record
    itself, with a due date.
    """

    _name = "dhb.registration.invite"
    _inherit = ["dhb.registration.invite", "mail.activity.mixin"]

    # ------------------------------------------------------------------
    def _activity_owner(self):
        """Who should act. The intake's owner, then whoever set it up."""
        self.ensure_one()
        if self.register_id and self.register_id.user_id:
            return self.register_id.user_id
        if self.lead_id and getattr(self.lead_id, "user_id", False):
            return self.lead_id.user_id
        return self.create_uid or self.env.user

    def _schedule_admission_activity(self, summary, note=False, days=0):
        """One open to-do per application, not one per event.

        A second reminder on a record that already has one is noise, and noise
        is how people learn to ignore the clock icon.
        """
        self.ensure_one()
        todo = self.env.ref("mail.mail_activity_data_todo",
                            raise_if_not_found=False)
        existing = self.activity_ids.filtered(
            lambda a: a.summary == summary and not a.date_done)
        if existing:
            return existing

        try:
            return self.activity_schedule(
                act_type_xmlid="mail.mail_activity_data_todo" if todo else False,
                date_deadline=fields.Date.add(fields.Date.today(), days=days),
                summary=summary,
                note=note or "",
                user_id=self._activity_owner().id,
            )
        except Exception as exc:  # noqa: BLE001
            # A missing activity must never cost the write that triggered it.
            _logger.warning(
                "Could not schedule activity on application %s: %s",
                self.id, exc)
            return False

    # ------------------------------------------------------------------
    def write(self, values):
        result = super().write(values)
        if values.get("state") == "submitted":
            for application in self:
                application._schedule_admission_activity(
                    _("Review this application"),
                    _("%s has completed the registration form. Check the "
                      "documents and decide.") % (
                        application.partner_id.display_name
                        or application.learner_name or ""),
                    days=1,
                )
        return result

    @api.model_create_multi
    def create(self, vals_list):
        applications = super().create(vals_list)
        for application in applications:
            if application.state == "submitted":
                application._schedule_admission_activity(
                    _("Review this application"), days=1)
        return applications


class PaymentProofActivity(models.Model):
    """A receipt somebody sent is money waiting to be recognised."""

    _name = "dhb.payment.proof"
    _inherit = ["dhb.payment.proof", "mail.activity.mixin"]

    @api.model_create_multi
    def create(self, vals_list):
        proofs = super().create(vals_list)
        for proof in proofs:
            application = proof.application_id
            if not application:
                continue
            try:
                application._schedule_admission_activity(
                    _("Check the payment receipt"),
                    _("%s has sent a receipt through their own link.") % (
                        application.partner_id.display_name
                        or application.learner_name or ""),
                    days=1,
                )
            except Exception:  # noqa: BLE001
                _logger.warning(
                    "Could not schedule a receipt activity for proof %s",
                    proof.id)
        return proofs


class AdmissionRefundActivity(models.Model):
    """A refund waiting for approval is somebody's money, held."""

    _name = "dhb.admission.refund"
    _inherit = ["dhb.admission.refund", "mail.activity.mixin"]

    @api.model_create_multi
    def create(self, vals_list):
        refunds = super().create(vals_list)
        manager_group = self.env.ref(
            "dhb_zoom_attendance.group_dhb_attendance_manager",
            raise_if_not_found=False)
        approver = self.env.user
        if manager_group and not self.env.user.has_group(
                "dhb_zoom_attendance.group_dhb_attendance_manager"):
            approver = manager_group.users[:1] or self.env.user

        for refund in refunds:
            try:
                refund.activity_schedule(
                    act_type_xmlid="mail.mail_activity_data_todo",
                    date_deadline=fields.Date.today(),
                    summary=_("Approve this refund"),
                    note=_("%(learner)s withdrew from %(event)s.") % {
                        "learner": refund.partner_id.display_name or "",
                        "event": refund.event_id.name or "",
                    },
                    user_id=approver.id,
                )
            except Exception:  # noqa: BLE001
                _logger.warning(
                    "Could not schedule a refund activity for %s", refund.id)
        return refunds
