import logging

from odoo import models, fields, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class RegistrationInviteLMS(models.Model):
    """Release the learner's platform account when they are enrolled.

    The account already exists: dhb_moodle creates it the moment the form is
    submitted and immediately suspends it, so a half-finished applicant cannot
    log in and start the course. What was missing was the other half — nobody
    ever lifted the hold, so every account sat suspended and staff released
    them by hand on the platform.

    Enrolment is the right moment for it, and the only one: it is the single
    point where the centre has said yes, the place is confirmed on the cohort,
    and whatever the office wanted settled has been settled.
    """

    _inherit = "dhb.registration.invite"

    lms_state = fields.Selection(
        [
            ("none", "Not released"),
            ("released", "Released"),
            ("failed", "Release failed"),
        ],
        string="Platform access", default="none", copy=False, index=True,
        tracking=True,
    )
    lms_message = fields.Char(string="Last platform message", copy=False,
                              readonly=True)

    # ------------------------------------------------------------------
    def _lms_course_ids(self):
        """Every platform course this cohort maps to.

        Prefers the explicit course map when dhb_enrolment is installed,
        because a cohort can sit in more than one course there. Falls back to
        the single ID on the cohort, then to the configured default.
        """
        self.ensure_one()
        course_ids = []

        if "dhb.moodle.course.map" in self.env:
            maps = self.env["dhb.moodle.course.map"].search([
                ("event_id", "=", self.event_id.id),
            ])
            course_ids = [m.moodle_course_id for m in maps if m.moodle_course_id]

        if not course_ids and self.event_id.moodle_course_id:
            course_ids = [self.event_id.moodle_course_id]

        if not course_ids:
            default = self.env["ir.config_parameter"].sudo().get_param(
                "dhb_moodle.default_course_id")
            if default:
                try:
                    course_ids = [int(default)]
                except (TypeError, ValueError):
                    course_ids = []

        return course_ids

    # ------------------------------------------------------------------
    def _release_lms_access(self, raise_on_error=False):
        """Create the account if missing, enrol on the course, lift the hold."""
        self.ensure_one()
        partner = self.partner_id
        if not partner:
            message = _("There is no learner on this application yet.")
            if raise_on_error:
                raise UserError(message)
            return False

        api_client = self.env["dhb.moodle.api"]
        course_ids = self._lms_course_ids()

        try:
            # 1. The account. Normally it is already there, held.
            if not partner.moodle_user_id:
                partner._create_moodle_account(
                    course_id=course_ids[0] if course_ids else None)
            if not partner.moodle_user_id:
                raise UserError(_(
                    "The platform account could not be created. Open the "
                    "learner's contact — the reason is on the LMS account "
                    "field there."
                ))

            # 2. The course. Enrolling twice is harmless on the platform;
            #    not enrolling at all leaves a learner with a login and
            #    nothing to open.
            for course_id in course_ids:
                api_client.enrol_user(
                    partner.moodle_user_id, int(course_id), suspend=False)

            # 3. The hold comes off last, so a learner never gets a working
            #    login before the course is on their platform home page.
            if partner.moodle_state != "active":
                partner.action_activate_moodle_account()

            self.write({
                "lms_state": "released",
                "lms_message": _("Released on %s course(s).") % len(course_ids),
            })
            self.message_post(body=_(
                "Platform access released for %(user)s on %(count)s course(s)."
            ) % {"user": partner.moodle_username or partner.name,
                 "count": len(course_ids)})
            if not course_ids:
                self.message_post(body=_(
                    "No platform course is mapped to %s, so the learner can "
                    "log in but has nothing to open. Set the course on the "
                    "cohort."
                ) % self.event_id.name)
            return True

        except Exception as exc:  # noqa: BLE001
            # A platform outage must never undo an enrolment that the centre
            # has decided on. The place stays confirmed; the access is flagged
            # for retry.
            _logger.exception(
                "Platform release failed for application %s", self.id)
            self.write({
                "lms_state": "failed",
                "lms_message": str(exc)[:250],
            })
            self.message_post(body=_(
                "Enrolment stands, but platform access could not be released: "
                "%s\n\nUse 'Retry platform access' once the platform is "
                "reachable."
            ) % exc)
            if raise_on_error:
                raise
            return False

    # ------------------------------------------------------------------
    def _hold_lms_access(self):
        """Accepted: the account exists, and it is suspended.

        Acceptance is a yes, not a start. The learner should have an account
        waiting — so the username can be handed over and nothing is built on
        the day the course opens — but not a working login, because they have
        not paid and the course has not begun.
        """
        self.ensure_one()
        partner = self.partner_id
        if not partner:
            return False

        try:
            if not partner.moodle_user_id:
                # _create_moodle_account suspends on creation, per the
                # platform policy configured in the LMS settings.
                partner._create_moodle_account()
            if partner.moodle_user_id and partner.moodle_state == "active":
                partner.action_hold_moodle_account()
            self.write({
                "lms_state": "none",
                "lms_message": _("Account created and held on acceptance."),
            })
            self.message_post(body=_(
                "Platform account %s is ready and suspended. It is released "
                "when the application is enrolled."
            ) % (partner.moodle_username or partner.name))
            return True
        except Exception as exc:  # noqa: BLE001
            _logger.exception(
                "Platform account preparation failed for application %s", self.id)
            self.write({"lms_state": "failed", "lms_message": str(exc)[:250]})
            self.message_post(body=_(
                "The applicant was accepted, but their platform account could "
                "not be prepared: %s\n\nUse 'Retry platform access' once the "
                "platform is reachable."
            ) % exc)
            return False

    def action_accept(self):
        result = super().action_accept()
        auto = self.env["ir.config_parameter"].sudo().get_param(
            "dhb_admission.auto_create_lms", "1") == "1"
        if auto:
            for application in self:
                if application.state == "accepted":
                    application._hold_lms_access()
        return result

    def action_enrol(self):
        result = super().action_enrol()
        auto = self.env["ir.config_parameter"].sudo().get_param(
            "dhb_admission.auto_release_lms", "1") == "1"
        if auto:
            for application in self:
                if application.state == "enrolled" and application.lms_state != "released":
                    application._release_lms_access()
        return result

    def action_release_lms(self):
        """The manual button, and the retry after an outage."""
        for application in self:
            application._release_lms_access(raise_on_error=len(self) == 1)
        return True

    def action_withdraw(self):
        """Put the platform account back on hold when the learner leaves."""
        result = super().action_withdraw()
        for application in self:
            partner = application.partner_id
            if not partner or not partner.moodle_user_id:
                continue
            if partner.moodle_state != "active":
                continue
            try:
                partner.action_hold_moodle_account()
                application.lms_state = "none"
            except Exception as exc:  # noqa: BLE001
                _logger.exception(
                    "Could not hold the platform account for %s", application.id)
                application.message_post(body=_(
                    "The learner withdrew but their platform account could "
                    "NOT be suspended, so they can still log in. Suspend it by "
                    "hand.\n\n%s"
                ) % exc)
        return result
