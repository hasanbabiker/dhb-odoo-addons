import secrets

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"

# The states an application can be in before anyone has decided anything.
# Kept in one place because three different counters ask the same question.
UNDECIDED = ("draft", "sent", "opened", "submitted", "review")


class DhbAdmissionRegister(models.Model):
    """An intake window: one cohort, open for applications between two dates.

    Until now an application existed only because someone issued an invitation,
    which answered "who did we invite" but not "what are we recruiting for".
    A register is that second record. It gives the centre a place to say the
    January IGC intake takes thirty learners, opens on the first and closes on
    the twenty-eighth, and it gives everyone a screen where the answer to
    "how is recruitment going" is three numbers rather than a search.

    The register does not replace the invitation. Every application still ends
    up as a tokened invitation tied to one named person, because that is what
    the awarding body asks to see. The register is what those invitations
    belong to.
    """

    _name = "dhb.admission.register"
    _description = "Admission register"
    _order = "start_date desc, id desc"
    _inherit = ["mail.thread"]

    name = fields.Char(string="Register", required=True, tracking=True)
    active = fields.Boolean(default=True)
    priority = fields.Selection(
        [("0", "Normal"), ("1", "Starred")], default="0",
        string="Starred",
        help="The intakes the office is working on this month, pinned to the "
             "front of the list.",
    )
    color = fields.Integer(string="Colour")

    event_id = fields.Many2one(
        "event.event", string="Cohort", required=True, tracking=True,
        help="The course and intake this register admits learners onto. "
             "Accepting an application confirms their place on this cohort.",
    )
    qualification = fields.Selection(
        related="event_id.qualification", string="Qualification",
        store=True, index=True, readonly=True,
    )
    delivery_language = fields.Selection(
        related="event_id.delivery_language", string="Language", readonly=True)
    course_date_begin = fields.Datetime(
        related="event_id.date_begin", string="Course starts", readonly=True)

    start_date = fields.Date(
        string="Applications open", required=True, tracking=True,
        default=fields.Date.context_today,
    )
    end_date = fields.Date(
        string="Applications close", required=True, tracking=True,
        default=lambda self: fields.Date.add(fields.Date.today(), days=30),
    )

    min_count = fields.Integer(
        string="Minimum learners", default=0,
        help="Below this the intake does not pay for itself. It is a warning "
             "on the register, not a rule that stops anything.",
    )
    max_count = fields.Integer(
        string="Maximum learners", default=0,
        help="The public application page stops accepting once this many "
             "places are taken. Zero means no limit.",
    )

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("published", "Published"),
            ("closed", "Closed"),
            ("done", "Done"),
            ("cancel", "Cancelled"),
        ],
        string="Status", default="draft", required=True, tracking=True, index=True,
    )

    # --- the fee the applications inherit -------------------------------
    currency_id = fields.Many2one(
        "res.currency", string="Currency",
        default=lambda self: self.env.company.currency_id,
    )
    course_fee = fields.Monetary(
        string="Course fee", currency_field="currency_id",
        help="Copied onto every application made through this register, so "
             "nobody has to remember the price of each intake.",
    )
    fee_plan = fields.Selection(
        [
            ("full", "One invoice for the whole fee"),
            ("deposit", "Deposit first, balance later"),
        ],
        string="How the fee is billed", default="full", required=True,
    )
    deposit_amount = fields.Monetary(
        string="Deposit", currency_field="currency_id")

    # --- the public page ------------------------------------------------
    token = fields.Char(string="Token", readonly=True, copy=False, index=True)
    apply_url = fields.Char(
        string="Application page", compute="_compute_apply_url")

    # --- what is on the register ----------------------------------------
    application_ids = fields.One2many(
        "dhb.registration.invite", "register_id", string="Applications")
    application_count = fields.Integer(
        string="Applications", compute="_compute_counts")
    count_draft = fields.Integer(string="Draft", compute="_compute_counts")
    count_confirm = fields.Integer(string="Confirmed", compute="_compute_counts")
    count_enroll = fields.Integer(string="Enrolled", compute="_compute_counts")
    count_rejected = fields.Integer(string="Rejected", compute="_compute_counts")
    seats_left = fields.Integer(string="Places left", compute="_compute_counts")

    is_open = fields.Boolean(string="Open now", compute="_compute_is_open")

    _unique_name_event = models.Constraint(
        "unique(name, event_id)",
        "There is already a register with this name on this cohort.",
    )

    # ------------------------------------------------------------------
    # housekeeping
    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        for values in vals_list:
            if not values.get("token"):
                values["token"] = secrets.token_urlsafe(24)
        return super().create(vals_list)

    @api.constrains("start_date", "end_date")
    def _check_dates(self):
        for register in self:
            if register.end_date < register.start_date:
                raise ValidationError(_(
                    "Applications cannot close before they open."))

    @api.onchange("event_id")
    def _onchange_event_id(self):
        """Name the register after the cohort, which is what people call it."""
        if self.event_id and not self.name:
            self.name = self.event_id.name

    def _compute_apply_url(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url", "")
        for register in self:
            register.apply_url = (
                "%s/dhb/apply/%s" % (base, register.token)
                if register.token else False
            )

    @api.depends("application_ids.state", "max_count")
    def _compute_counts(self):
        for register in self:
            applications = register.application_ids
            register.application_count = len(applications)
            register.count_draft = len(
                applications.filtered(lambda a: a.state in UNDECIDED))
            register.count_confirm = len(
                applications.filtered(lambda a: a.state == "accepted"))
            register.count_enroll = len(
                applications.filtered(lambda a: a.state == "enrolled"))
            register.count_rejected = len(
                applications.filtered(lambda a: a.state == "rejected"))
            taken = register.count_confirm + register.count_enroll
            register.seats_left = (
                max(register.max_count - taken, 0) if register.max_count else 0)

    @api.depends("state", "start_date", "end_date", "max_count",
                 "application_ids.state")
    def _compute_is_open(self):
        today = fields.Date.today()
        for register in self:
            full = bool(register.max_count) and register.seats_left <= 0
            register.is_open = bool(
                register.state == "published"
                and register.start_date <= today <= register.end_date
                and not full
            )

    # ------------------------------------------------------------------
    # the pipeline
    # ------------------------------------------------------------------
    def action_publish(self):
        for register in self:
            if not register.event_id:
                raise UserError(_("Pick the cohort before publishing."))
            register.state = "published"
            register.message_post(body=_(
                "Published. Applications open %(from)s to %(to)s."
            ) % {"from": register.start_date, "to": register.end_date})
        return True

    def action_close(self):
        """Stop taking applications; the ones already in still get decided."""
        self.write({"state": "closed"})
        return True

    def action_done(self):
        for register in self:
            if register.count_draft or register.count_confirm:
                raise UserError(_(
                    "%(n)s application(s) on this register have not been "
                    "enrolled or rejected yet. Finish them before marking the "
                    "register done, or the numbers stop meaning anything."
                ) % {"n": register.count_draft + register.count_confirm})
            register.state = "done"
        return True

    def action_cancel(self):
        if not self.env.user.has_group(MANAGER_GROUP):
            raise UserError(_(
                "Only a DHB Attendance Manager can cancel a register."))
        self.write({"state": "cancel"})
        return True

    def action_draft(self):
        self.write({"state": "draft"})
        return True

    # ------------------------------------------------------------------
    # the buttons on the card
    # ------------------------------------------------------------------
    def _action_applications(self, name, domain):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": name,
            "res_model": "dhb.registration.invite",
            "view_mode": "kanban,list,form",
            "domain": [("register_id", "=", self.id)] + domain,
            "context": {
                "default_register_id": self.id,
                "default_event_id": self.event_id.id,
                "search_default_group_state": 1,
            },
        }

    def action_view_applications(self):
        return self._action_applications(_("Applications"), [])

    def action_view_draft(self):
        return self._action_applications(
            _("Not decided yet"), [("state", "in", list(UNDECIDED))])

    def action_view_confirm(self):
        return self._action_applications(
            _("Confirmed"), [("state", "=", "accepted")])

    def action_view_enroll(self):
        return self._action_applications(
            _("Enrolled"), [("state", "=", "enrolled")])

    def action_open_apply_page(self):
        """The Template link: the page an applicant actually sees."""
        self.ensure_one()
        if not self.token:
            raise UserError(_("This register has no application page yet."))
        return {
            "type": "ir.actions.act_url",
            "url": "/dhb/apply/%s" % self.token,
            "target": "new",
        }

    def action_new_invitation(self):
        """Invite one named person onto this register.

        The route the centre uses for a learner it already knows: no public
        page, no self-service, just a link addressed to a person.
        """
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("New invitation"),
            "res_model": "dhb.registration.invite",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_register_id": self.id,
                "default_event_id": self.event_id.id,
                "default_course_fee": self.course_fee,
                "default_fee_plan": self.fee_plan,
                "default_deposit_amount": self.deposit_amount,
            },
        }

    def action_attach_existing(self):
        """Pull in applications made on this cohort before the register existed.

        Without this, a centre that has been running on invitations sees an
        empty register and assumes the module is broken.
        """
        Invite = self.env["dhb.registration.invite"]
        for register in self:
            orphans = Invite.search([
                ("event_id", "=", register.event_id.id),
                ("register_id", "=", False),
            ])
            orphans.write({"register_id": register.id})
            register.message_post(body=_(
                "%(n)s existing application(s) on %(event)s attached to this "
                "register."
            ) % {"n": len(orphans), "event": register.event_id.name})
        return True

    # ------------------------------------------------------------------
    # used by the public page
    # ------------------------------------------------------------------
    def _why_closed(self):
        """A sentence for the applicant, or False when the register is open."""
        self.ensure_one()
        today = fields.Date.today()
        if self.state == "draft":
            return _("This intake has not opened for applications yet.")
        if self.state in ("closed", "done"):
            return _("Applications for this intake have closed.")
        if self.state == "cancel":
            return _("This intake is no longer running.")
        if self.start_date > today:
            return _("Applications for this intake open on %s.") % self.start_date
        if self.end_date < today:
            return _("Applications for this intake closed on %s.") % self.end_date
        if self.max_count and self.seats_left <= 0:
            return _("This intake is full.")
        return False

    def _defaults_for_application(self):
        self.ensure_one()
        return {
            "register_id": self.id,
            "event_id": self.event_id.id,
            "course_fee": self.course_fee,
            "fee_plan": self.fee_plan,
            "deposit_amount": self.deposit_amount,
            "currency_id": self.currency_id.id,
        }
