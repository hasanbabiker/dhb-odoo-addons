from odoo import models, fields, api, _

# Most urgent first. The compute walks this order and stops at the first
# thing that is true, because an application always has exactly one next
# thing to do — a list of five is what the office already has and cannot act
# on.
NEXT_ACTION = [
    ("none", "Nothing"),
    ("barred", "Barred — decide"),
    ("lms_retry", "Retry platform access"),
    ("check_receipt", "Check the payment receipt"),
    ("send_link", "Send the registration link"),
    ("chase_form", "Chase the form"),
    ("review", "Review it"),
    ("chase_documents", "Chase the learner's documents"),
    ("sign_declaration", "Get the declaration signed"),
    ("invoice", "Raise the invoice"),
    ("invoice_balance", "Raise the balance invoice"),
    ("await_payment", "Waiting for payment"),
    ("decide", "Accept or reject"),
    ("enrol", "Ready to enrol"),
    ("nebosh_entry", "Tick the NEBOSH entry"),
]


class RegistrationInviteNextAction(models.Model):
    """One column that says what to do, so nobody has to open twenty records.

    The information was always there — spread over a status, a checklist, an
    invoice and a receipt. Reading it meant opening each application and
    working it out. This works it out once, stores it, and puts it in the
    list, where it can also be filtered and grouped: "show me everyone
    waiting on payment" stops being a memory exercise.
    """

    _inherit = "dhb.registration.invite"

    next_action = fields.Selection(
        NEXT_ACTION, string="Next step", compute="_compute_next_action",
        store=True, index=True, readonly=True,
    )

    # ------------------------------------------------------------------
    def _missing_learner_documents(self):
        """What the awarding body would notice was absent."""
        self.ensure_one()
        partner = self.partner_id
        if not partner:
            return True
        return not (partner.legal_name and partner.date_of_birth
                    and partner.id_document_file)

    def _invoice_unpaid(self):
        self.ensure_one()
        invoices = self.invoice_id | self.balance_invoice_id
        live = invoices.filtered(lambda i: i.state == "posted")
        if not live:
            return False
        return any(i.payment_state not in ("paid", "in_payment", "reversed")
                   for i in live)

    # ------------------------------------------------------------------
    @api.depends(
        "state", "declaration_state", "course_fee", "fee_plan",
        "invoice_id", "invoice_id.state", "invoice_id.payment_state",
        "balance_invoice_id", "balance_invoice_id.state",
        "balance_invoice_id.payment_state",
        "payment_proof_ids.state",
        "lms_state", "nebosh_entry_done", "admission_barred",
        "partner_id", "partner_id.legal_name", "partner_id.date_of_birth",
        "partner_id.id_document_file",
        "event_id.nebosh_sitting_id.registration_closing",
    )
    def _compute_next_action(self):
        # Deliberately not depending on write_date: storing this field
        # updates write_date, which would trigger the compute again. "Nothing
        # has moved for two weeks" is a search filter on write_date instead,
        # where it costs nothing and cannot loop.
        today = fields.Date.today()
        for application in self:
            application.next_action = application._next_action_value(today)

    def _next_action_value(self, today):
        self.ensure_one()
        state = self.state

        if state in ("rejected", "withdrawn", "cancelled", "expired"):
            return "none"

        # A bar outranks everything. Chasing documents from somebody NEBOSH
        # has debarred wastes their time and yours.
        if self.admission_barred and state not in ("enrolled",):
            return "barred"

        # Two things jump the queue wherever the application has got to: a
        # broken platform release, and money somebody has sent us.
        if self.lms_state == "failed":
            return "lms_retry"
        if any(p.state == "pending" for p in self.payment_proof_ids):
            return "check_receipt"

        if state == "draft":
            return "send_link"
        if state in ("sent", "opened"):
            return "chase_form"
        if state == "submitted":
            return "review"

        if state == "review":
            if self._missing_learner_documents():
                return "chase_documents"
            if self.declaration_state != "signed":
                return "sign_declaration"
            if self.course_fee and not self.invoice_id:
                return "invoice"
            return "decide"

        if state == "accepted":
            if self.course_fee and not self.invoice_id:
                return "invoice"
            if self._invoice_unpaid():
                return "await_payment"
            if self.declaration_state != "signed":
                return "sign_declaration"
            return "enrol"

        if state == "enrolled":
            if self.fee_plan == "deposit" and not self.balance_invoice_id \
                    and self.balance_amount > 0:
                return "invoice_balance"
            if self._invoice_unpaid():
                return "await_payment"
            sitting = self.event_id.nebosh_sitting_id
            closing = sitting.registration_closing if sitting else False
            if not self.nebosh_entry_done and closing and closing <= today:
                return "nebosh_entry"
            return "none"

        return "none"

    # ------------------------------------------------------------------
    # batch decisions
    # ------------------------------------------------------------------
    def _run_batch(self, method, label):
        """Run a decision over a selection without one failure stopping it.

        Twenty learners accepted one at a time is a hundred clicks, and the
        reason nobody did it in the system. Running them together only helps
        if a single incomplete record does not abort the other nineteen, so
        each is tried on its own and the result is reported.
        """
        done, skipped = 0, []
        for application in self:
            try:
                with self.env.cr.savepoint():
                    getattr(application, method)()
                done += 1
            except Exception as exc:  # noqa: BLE001
                skipped.append("%s — %s" % (
                    application.partner_id.display_name
                    or application.learner_name or application.name,
                    str(exc).strip().split("\n")[0],
                ))

        if not skipped:
            message = _("%(count)s application(s) %(label)s.") % {
                "count": done, "label": label}
        else:
            message = _(
                "%(done)s %(label)s. %(failed)s could not be:\n\n%(list)s"
            ) % {
                "done": done, "label": label, "failed": len(skipped),
                "list": "\n".join("• %s" % line for line in skipped),
            }

        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Done") if not skipped else _("Partly done"),
                "message": message,
                "type": "success" if not skipped else "warning",
                "sticky": bool(skipped),
                "next": {"type": "ir.actions.act_window_close"},
            },
        }

    def action_accept_batch(self):
        return self._run_batch("action_accept", _("accepted"))

    def action_enrol_batch(self):
        return self._run_batch("action_enrol", _("enrolled"))

    def action_start_review_batch(self):
        return self._run_batch("action_start_review", _("moved to review"))

    def action_accept_and_enrol(self):
        """One press when nothing is outstanding."""
        self.action_accept()
        return self.action_enrol()
