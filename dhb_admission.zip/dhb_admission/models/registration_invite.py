from odoo import models, fields, api, _
from odoo.exceptions import UserError

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"


class RegistrationInvite(models.Model):
    """The application, from submitted form to confirmed place.

    The invitation already carries the cohort, the learner and the submission.
    Turning it into an application is a matter of adding the decision and what
    hangs off it - the fee and the declaration - rather than a second record
    that would have to be kept in step with this one.
    """

    _inherit = "dhb.registration.invite"

    # The new states are placed after "submitted" rather than appended, so the
    # kanban columns read in the order the work actually happens.
    state = fields.Selection(
        selection_add=[
            ("submitted",),
            ("review", "Under review"),
            ("accepted", "Accepted"),
            ("enrolled", "Enrolled"),
            ("rejected", "Rejected"),
        ],
        ondelete={
            "review": "set default",
            "accepted": "set default",
            "enrolled": "set default",
            "rejected": "set default",
        },
    )

    # --- what intake this application belongs to ------------------------
    register_id = fields.Many2one(
        "dhb.admission.register", string="Admission register",
        ondelete="set null", index=True, tracking=True,
        help="The intake this application was made against. Applications "
             "created before the register existed can be attached to it from "
             "the register itself.",
    )

    # --- the decision ---------------------------------------------------
    reviewed_by = fields.Many2one("res.users", string="Reviewed by", readonly=True)
    reviewed_on = fields.Datetime(string="Reviewed on", readonly=True)
    review_note = fields.Text(string="Review notes")
    rejection_reason = fields.Text(
        string="Reason for rejection",
        help="Kept because months later someone asks why this applicant was "
             "turned away, and memory is not an answer an auditor accepts.",
    )

    # --- the declaration ------------------------------------------------
    declaration_sent_on = fields.Datetime(string="Declaration sent", readonly=True)
    declaration_signed_on = fields.Datetime(string="Declaration signed")
    declaration_file = fields.Binary(
        string="Signed declaration", attachment=True, copy=False)
    declaration_filename = fields.Char(copy=False)
    declaration_state = fields.Selection(
        [
            ("none", "Not sent"),
            ("sent", "Waiting for signature"),
            ("signed", "Signed"),
        ],
        string="Declaration", compute="_compute_declaration_state", store=True,
    )

    # --- the fee --------------------------------------------------------
    currency_id = fields.Many2one(
        "res.currency", string="Currency",
        default=lambda self: self.env.company.currency_id,
    )
    course_fee = fields.Monetary(string="Course fee", currency_field="currency_id")

    fee_plan = fields.Selection(
        [
            ("full", "One invoice for the whole fee"),
            ("deposit", "Deposit first, balance later"),
        ],
        string="How the fee is billed", default="full", required=True,
        help="A deposit holds the place while the learner arranges the rest. "
             "Each part is its own invoice, so each can be paid and chased "
             "separately.",
    )
    deposit_amount = fields.Monetary(
        string="Deposit", currency_field="currency_id",
        help="What the learner pays to hold the place.",
    )
    balance_amount = fields.Monetary(
        string="Balance", currency_field="currency_id",
        compute="_compute_fee_amounts", store=True,
    )

    invoice_id = fields.Many2one(
        "account.move", string="Deposit invoice", readonly=True, copy=False,
        help="With a single invoice for the whole fee, this is that invoice.",
    )
    balance_invoice_id = fields.Many2one(
        "account.move", string="Balance invoice", readonly=True, copy=False)
    invoice_state = fields.Selection(
        related="invoice_id.state", string="Invoice status", readonly=True)
    invoice_payment_state = fields.Selection(
        related="invoice_id.payment_state", string="Payment", readonly=True)

    amount_invoiced = fields.Monetary(
        string="Invoiced", currency_field="currency_id",
        compute="_compute_fee_amounts", store=True,
    )
    amount_outstanding = fields.Monetary(
        string="Not yet invoiced", currency_field="currency_id",
        compute="_compute_fee_amounts", store=True,
    )

    # --- what the learner sends back ------------------------------------
    payment_proof_ids = fields.One2many(
        "dhb.payment.proof", "application_id", string="Payment proofs")
    payment_proof_count = fields.Integer(compute="_compute_payment_proofs")
    payment_proof_pending = fields.Integer(compute="_compute_payment_proofs")
    payment_upload_url = fields.Char(
        string="Upload link for the learner", compute="_compute_payment_upload_url")

    # --- what the applicant still owes us -------------------------------
    missing_items = fields.Text(compute="_compute_missing_items")
    policy_acceptance_count = fields.Integer(compute="_compute_policy_count")

    # ------------------------------------------------------------------
    # computes
    # ------------------------------------------------------------------
    @api.depends("declaration_sent_on", "declaration_signed_on", "declaration_file")
    def _compute_declaration_state(self):
        for application in self:
            if application.declaration_signed_on or application.declaration_file:
                application.declaration_state = "signed"
            elif application.declaration_sent_on:
                application.declaration_state = "sent"
            else:
                application.declaration_state = "none"

    @api.depends("course_fee", "deposit_amount", "fee_plan",
                 "invoice_id.amount_total", "invoice_id.state",
                 "balance_invoice_id.amount_total", "balance_invoice_id.state")
    def _compute_fee_amounts(self):
        for application in self:
            fee = application.course_fee or 0.0
            deposit = application.deposit_amount or 0.0
            if application.fee_plan != "deposit":
                deposit = 0.0
            application.balance_amount = max(fee - deposit, 0.0)

            invoiced = 0.0
            for invoice in (application.invoice_id | application.balance_invoice_id):
                if invoice.state != "cancel":
                    invoiced += invoice.amount_total
            application.amount_invoiced = invoiced
            application.amount_outstanding = max(fee - invoiced, 0.0)

    @api.depends("payment_proof_ids.state")
    def _compute_payment_proofs(self):
        for application in self:
            proofs = application.payment_proof_ids
            application.payment_proof_count = len(proofs)
            application.payment_proof_pending = len(
                proofs.filtered(lambda p: p.state == "pending"))

    def _compute_payment_upload_url(self):
        """The learner's own page for sending a receipt back.

        It reuses the invitation token rather than issuing a second secret:
        the learner already has that link, and one link per learner is one
        thing to explain rather than two.
        """
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        for application in self:
            application.payment_upload_url = (
                "%s/dhb/payment/%s" % (base, application.token)
                if application.token else False
            )

    def _compute_policy_count(self):
        Acceptance = self.env["dhb.policy.acceptance"]
        for application in self:
            application.policy_acceptance_count = Acceptance.search_count([
                ("partner_id", "=", application.partner_id.id),
            ]) if application.partner_id else 0

    @api.depends(
        "partner_id.nebosh_learner_number", "partner_id.date_of_birth",
        "partner_id.id_document_file", "partner_id.legal_name",
        "declaration_state", "invoice_id.payment_state",
    )
    def _compute_missing_items(self):
        """What would stop this application being accepted.

        Listed rather than enforced: a learner number can legitimately be
        pending at NEBOSH while the place is confirmed, and a hard block would
        push the centre into accepting people outside the system instead.
        """
        for application in self:
            partner = application.partner_id
            missing = []
            if not partner:
                missing.append(_("The form has not been submitted yet"))
            else:
                if not partner.legal_name:
                    missing.append(_("Full legal name"))
                if not partner.date_of_birth:
                    missing.append(_("Date of birth"))
                if not partner.nebosh_learner_number:
                    missing.append(_("NEBOSH learner number"))
                if not partner.id_document_file:
                    missing.append(_("Identity document"))
                if not application.policy_acceptance_count:
                    missing.append(_("Policy acceptance"))
            if application.declaration_state != "signed":
                missing.append(_("Signed learner declaration"))
            if application.course_fee and not application.invoice_id:
                missing.append(_("Invoice for the course fee"))
            application.missing_items = "\n".join("- %s" % m for m in missing)

    # ------------------------------------------------------------------
    # the pipeline
    # ------------------------------------------------------------------
    def action_start_review(self):
        for application in self:
            if application.state != "submitted":
                raise UserError(_(
                    "Only a submitted application can go under review."))
            application.write({
                "state": "review",
                "reviewed_by": self.env.user.id,
                "reviewed_on": fields.Datetime.now(),
            })
        return True

    def action_accept(self):
        """Offer the place: reserve it on the cohort, but do not confirm yet.

        Accepting and enrolling used to be one button, which made the middle
        of the pipeline invisible: an applicant the centre had said yes to but
        who had not paid looked exactly like a learner sitting in the room.
        They are now two steps, and the register counts them separately.
        """
        for application in self:
            if application.state == "enrolled":
                continue
            if not application.partner_id:
                raise UserError(_(
                    "There is no learner on this application yet. It can only "
                    "be accepted once the form has been submitted."
                ))
            registration = application._ensure_registration()
            application.write({
                "state": "accepted",
                "registration_id": registration.id,
                "reviewed_by": application.reviewed_by.id or self.env.user.id,
                "reviewed_on": application.reviewed_on or fields.Datetime.now(),
                "rejection_reason": False,
            })
            application.message_post(body=_(
                "Accepted. A place is held on %s, not yet confirmed."
            ) % application.event_id.name)
        return True

    def action_enrol(self):
        """Confirm the place on the cohort. This is the learner's start."""
        for application in self:
            if application.state == "enrolled":
                continue
            if application.state not in ("accepted", "review"):
                raise UserError(_(
                    "Accept the application before enrolling it."))
            if not application.partner_id:
                raise UserError(_(
                    "There is no learner on this application yet."))
            registration = application._ensure_registration()
            if registration.state == "draft":
                registration.action_confirm()
            application.write({
                "state": "enrolled",
                "registration_id": registration.id,
                "reviewed_by": application.reviewed_by.id or self.env.user.id,
                "reviewed_on": application.reviewed_on or fields.Datetime.now(),
            })
            application.message_post(body=_(
                "Enrolled and confirmed on %s.") % application.event_id.name)
        return True

    def action_reject(self):
        """Turn the applicant away, with the reason on the record."""
        for application in self:
            if not (application.rejection_reason or "").strip():
                raise UserError(_(
                    "Write the reason for rejection first. An application "
                    "refused without a recorded reason cannot be defended."
                ))
            if application.registration_id and application.registration_id.state != "cancel":
                application.registration_id.action_cancel()
            application.write({
                "state": "rejected",
                "reviewed_by": self.env.user.id,
                "reviewed_on": fields.Datetime.now(),
            })
            application.message_post(body=_(
                "Rejected: %s") % application.rejection_reason)
        return True

    def action_reopen(self):
        """Put a rejected application back under review."""
        if not self.env.user.has_group(MANAGER_GROUP):
            raise UserError(_(
                "Only a DHB Attendance Manager can reopen a rejected "
                "application."
            ))
        for application in self:
            application.write({"state": "review"})
        return True

    def _ensure_registration(self):
        """The learner's place on the cohort, created only if it is missing."""
        self.ensure_one()
        Registration = self.env["event.registration"]
        if self.registration_id:
            return self.registration_id
        existing = Registration.search([
            ("event_id", "=", self.event_id.id),
            ("partner_id", "=", self.partner_id.id),
        ], limit=1)
        if existing:
            return existing
        return Registration.create({
            "event_id": self.event_id.id,
            "partner_id": self.partner_id.id,
            "email": self.partner_id.email or self.email,
            "name": self.partner_id.legal_name or self.partner_id.name,
        })

    # ------------------------------------------------------------------
    # the declaration
    # ------------------------------------------------------------------
    def action_mark_declaration_sent(self):
        for application in self:
            application.declaration_sent_on = fields.Datetime.now()
        return True

    def action_mark_declaration_signed(self):
        for application in self:
            if not application.declaration_file:
                raise UserError(_(
                    "Attach the signed declaration before marking it signed. "
                    "The file is the evidence; the tick is only a label."
                ))
            application.declaration_signed_on = fields.Datetime.now()
        return True

    # ------------------------------------------------------------------
    # the fee
    # ------------------------------------------------------------------
    def _fee_product_id(self):
        product_id = self.env["ir.config_parameter"].sudo().get_param(
            "dhb_admission.fee_product_id")
        if not product_id:
            raise UserError(_(
                "No training product is configured, so an invoice line would "
                "have no account to post to.\n\nSet one under Settings > DHB "
                "Admissions > Course fee product."
            ))
        return int(product_id)

    def _create_fee_invoice(self, amount, label):
        """One draft customer invoice for part or all of the fee."""
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_("There is no learner to invoice yet."))
        if amount <= 0:
            raise UserError(_("There is nothing left to invoice."))

        invoice = self.env["account.move"].create({
            "move_type": "out_invoice",
            "partner_id": self.partner_id.id,
            "currency_id": self.currency_id.id,
            "invoice_origin": self.name,
            "invoice_line_ids": [(0, 0, {
                "product_id": self._fee_product_id(),
                "name": "%s - %s (%s)" % (
                    self.event_id.name, self.partner_id.name, label),
                "quantity": 1,
                "price_unit": amount,
            })],
        })
        self.message_post(body=_(
            "Draft invoice %(number)s created for the %(label)s."
        ) % {"number": invoice.name, "label": label})
        return invoice

    def action_create_invoice(self):
        """The whole fee, or the deposit when the fee is split."""
        for application in self:
            if application.invoice_id:
                raise UserError(_(
                    "This application already has its first invoice."))
            if not application.course_fee:
                raise UserError(_(
                    "Set the course fee on the application first."))

            if application.fee_plan == "deposit":
                if not application.deposit_amount:
                    raise UserError(_(
                        "Set how much the deposit is before invoicing it."))
                if application.deposit_amount > application.course_fee:
                    raise UserError(_(
                        "The deposit is larger than the course fee."))
                invoice = application._create_fee_invoice(
                    application.deposit_amount, _("deposit"))
            else:
                invoice = application._create_fee_invoice(
                    application.course_fee, _("course fee"))
            application.invoice_id = invoice.id
        return True

    def action_create_balance_invoice(self):
        """The rest of the fee, once the deposit has been invoiced."""
        for application in self:
            if application.fee_plan != "deposit":
                raise UserError(_(
                    "This application is billed as one invoice, so there is "
                    "no balance to raise separately."))
            if not application.invoice_id:
                raise UserError(_("Invoice the deposit first."))
            if application.balance_invoice_id:
                raise UserError(_(
                    "The balance has already been invoiced."))
            invoice = application._create_fee_invoice(
                application.balance_amount, _("balance"))
            application.balance_invoice_id = invoice.id
        return True

    def action_open_balance_invoice(self):
        self.ensure_one()
        if not self.balance_invoice_id:
            raise UserError(_("No balance invoice has been created yet."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "account.move",
            "res_id": self.balance_invoice_id.id,
            "view_mode": "form",
        }

    def action_open_payment_proofs(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Payment proofs"),
            "res_model": "dhb.payment.proof",
            "view_mode": "list,form",
            "domain": [("application_id", "=", self.id)],
            "context": {"default_application_id": self.id},
        }

    def action_open_invoice(self):
        self.ensure_one()
        if not self.invoice_id:
            raise UserError(_("No invoice has been created yet."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "account.move",
            "res_id": self.invoice_id.id,
            "view_mode": "form",
        }

    def action_open_learner(self):
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_("The form has not been submitted yet."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "res.partner",
            "res_id": self.partner_id.id,
            "view_mode": "form",
        }
