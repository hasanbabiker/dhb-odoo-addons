import logging

from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)


class RegistrationInviteReminder(models.Model):
    """Chase the learner who opened the form and never finished it.

    This is the biggest silent leak in the pipeline: somebody asks, gets a
    link, opens it, gets interrupted, and is never heard from again. Nobody
    notices because nothing in the system changes — the record simply sits
    there looking the same as it did on day one.

    A reminder every two days, three times, then a human. Not forever: an
    unlimited sequence is what gets a training centre marked as spam, and a
    learner who has ignored three emails needs a phone call, not a fourth.
    """

    _inherit = "dhb.registration.invite"

    reminder_count = fields.Integer(
        string="Reminders sent", default=0, copy=False, readonly=True)
    last_reminder_on = fields.Datetime(
        string="Last reminder", copy=False, readonly=True)
    reminder_opt_out = fields.Boolean(
        string="Stop reminding this learner", copy=False, tracking=True,
        help="Tick when the learner asks to be left alone, or when somebody "
             "is handling them personally.",
    )
    reminder_exhausted = fields.Boolean(
        string="Reminders finished", copy=False, readonly=True,
        help="Every reminder has been sent and the form is still not in. "
             "This one needs a person.",
    )

    # ------------------------------------------------------------------
    @api.model
    def _reminder_settings(self):
        icp = self.env["ir.config_parameter"].sudo()
        def _int(key, fallback):
            try:
                return int(icp.get_param(key, fallback))
            except (TypeError, ValueError):
                return fallback
        return {
            "active": icp.get_param("dhb_admission.reminder_active", "1") == "1",
            "days": max(_int("dhb_admission.reminder_interval_days", 2), 1),
            "maximum": max(_int("dhb_admission.reminder_max", 3), 0),
        }

    def _reminder_due(self, days):
        """Two days since we last spoke, whichever way we last spoke."""
        self.ensure_one()
        last = (self.last_reminder_on or self.opened_on or self.create_date)
        if not last:
            return True
        return last <= fields.Datetime.subtract(
            fields.Datetime.now(), days=days)

    # ------------------------------------------------------------------
    def action_send_reminder(self):
        """Send one reminder now, by hand or from the cron."""
        template = self.env.ref(
            "dhb_admission.mail_template_registration_reminder",
            raise_if_not_found=False)
        if not template:
            return False

        for application in self:
            recipient = (application.partner_id.email
                         or application.email or "").strip()
            if not recipient:
                continue
            try:
                template.send_mail(
                    application.id, force_send=False,
                    email_values={"email_to": recipient},
                )
            except Exception as exc:  # noqa: BLE001
                _logger.exception(
                    "Reminder failed for application %s", application.id)
                application.message_post(body=_(
                    "The reminder could not be queued: %s") % exc)
                continue

            application.write({
                "reminder_count": application.reminder_count + 1,
                "last_reminder_on": fields.Datetime.now(),
            })
            application.message_post(body=_(
                "Reminder %(n)s sent to %(email)s."
            ) % {"n": application.reminder_count, "email": recipient})
        return True

    def action_reset_reminders(self):
        """Start the sequence again — after a phone call, usually."""
        self.write({
            "reminder_count": 0,
            "last_reminder_on": False,
            "reminder_exhausted": False,
        })
        return True

    # ------------------------------------------------------------------
    @api.model
    def _cron_chase_incomplete(self):
        """Every learner who has a link and has not sent the form back."""
        settings = self._reminder_settings()
        if not settings["active"]:
            return True

        stalled = self.search([
            ("state", "in", ("sent", "opened")),
            ("reminder_opt_out", "=", False),
        ])
        if not stalled:
            return True

        mail_configured = bool(
            self.env["ir.mail_server"].sudo().search_count([]))

        for application in stalled:
            if not application._is_usable():
                continue
            if not application._reminder_due(settings["days"]):
                continue

            # With no outgoing mail server the sequence is not started at all.
            # Burning three reminders into a queue means the learner receives
            # all three in the same minute on the day SMTP is fixed, which is
            # worse than none. A person is asked to call instead.
            if not mail_configured:
                application._schedule_admission_activity(
                    _("Chase this learner — no mail server"),
                    _("They opened their registration link and have not sent "
                      "the form back. Automatic reminders cannot go out "
                      "because no outgoing mail server is configured, so this "
                      "one needs a message by hand."),
                )
                continue

            if settings["maximum"] and \
                    application.reminder_count >= settings["maximum"]:
                if not application.reminder_exhausted:
                    application.reminder_exhausted = True
                    application._schedule_admission_activity(
                        _("Call this learner"),
                        _("%(n)s reminders have gone out and the form is "
                          "still not in. A fourth email will not work.") % {
                            "n": application.reminder_count},
                    )
                continue

            application.action_send_reminder()

        return True
