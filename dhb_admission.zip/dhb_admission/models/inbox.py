from odoo import models, fields, api, _

UNDECIDED = ("draft", "sent", "opened", "submitted", "review")


class DhbAdmissionInbox(models.TransientModel):
    """Everything waiting on somebody, counted on one screen.

    Six things need attention on an ordinary morning and each one lives in a
    different list, so the only reliable way to find them all was to remember
    that they exist. This counts them and opens each one.

    It is transient on purpose: it stores nothing, it is rebuilt every time it
    is opened, and it can therefore never disagree with the records it counts.
    """

    _name = "dhb.admission.inbox"
    _description = "What needs attention today"
    _rec_name = "title"

    # Without this the breadcrumb reads "dhb.admission.inbox,NewId_0x7f..",
    # which is the record's technical identity showing through a screen that
    # is not really a record at all.
    #
    # A plain string, not _(): a default is evaluated while Odoo is still
    # initialising the column, and _() reaches for the user's language, which
    # means a database read during schema setup. It worked, but it put this
    # lambda in the middle of an unrelated warning's traceback — a trap for
    # whoever reads that log next.
    title = fields.Char(default="What needs attention", readonly=True)

    count_review = fields.Integer(
        string="Applications to review", compute="_compute_counts")
    count_ready = fields.Integer(
        string="Ready to enrol", compute="_compute_counts")
    count_money = fields.Integer(
        string="Money outstanding", compute="_compute_counts")
    count_receipts = fields.Integer(
        string="Receipts to check", compute="_compute_counts")
    count_refunds = fields.Integer(
        string="Refunds to approve", compute="_compute_counts")
    count_nebosh = fields.Integer(
        string="NEBOSH entries to tick", compute="_compute_counts")
    count_lms = fields.Integer(
        string="Platform access failed", compute="_compute_counts")
    count_low = fields.Integer(
        string="Intakes below their minimum", compute="_compute_counts")
    count_stale = fields.Integer(
        string="Untouched for two weeks", compute="_compute_counts")

    total = fields.Integer(string="Things waiting", compute="_compute_counts")

    # ------------------------------------------------------------------
    def _compute_counts(self):
        Invite = self.env["dhb.registration.invite"]
        Proof = self.env["dhb.payment.proof"]
        Refund = self.env["dhb.admission.refund"]
        Register = self.env["dhb.admission.register"]
        for inbox in self:
            inbox.count_review = Invite.search_count([
                ("next_action", "in", ("review", "decide"))])
            inbox.count_ready = Invite.search_count([
                ("next_action", "=", "enrol")])
            inbox.count_money = Invite.search_count([
                ("next_action", "in", ("invoice", "invoice_balance"))])
            inbox.count_receipts = Proof.search_count([
                ("state", "=", "pending")])
            inbox.count_refunds = Refund.search_count([
                ("state", "=", "draft")])
            inbox.count_nebosh = Invite.search_count([
                ("next_action", "=", "nebosh_entry")])
            inbox.count_lms = Invite.search_count([
                ("next_action", "=", "lms_retry")])
            # A domain cannot compare two columns, so the shortlist is
            # fetched and the comparison done here.
            published = Register.search([
                ("state", "=", "published"),
                ("min_count", ">", 0),
            ])
            inbox.count_low = len(published.filtered(
                lambda r: r.seats_taken < r.min_count))
            inbox.count_stale = Invite.search_count([
                ("write_date", "<", fields.Datetime.to_string(
                    fields.Datetime.subtract(fields.Datetime.now(), days=14))),
                ("next_action", "not in", ("none",)),
            ])
            # Every counter, not a chosen few: a page that says "nothing is
            # waiting" above a card showing three is worse than no page.
            inbox.total = (
                inbox.count_review + inbox.count_ready + inbox.count_money
                + inbox.count_receipts + inbox.count_refunds
                + inbox.count_nebosh + inbox.count_lms + inbox.count_low
                + inbox.count_stale
            )

    # ------------------------------------------------------------------
    def _open_applications(self, name, domain):
        return {
            "type": "ir.actions.act_window",
            "name": name,
            "res_model": "dhb.registration.invite",
            "view_mode": "list,form",
            "domain": domain,
            "views": [
                (self.env.ref("dhb_admission.view_admission_worklist").id, "list"),
                (False, "form"),
            ],
        }

    def action_review(self):
        return self._open_applications(
            _("To review"), [("next_action", "in", ("review", "decide"))])

    def action_ready(self):
        return self._open_applications(
            _("Ready to enrol"), [("next_action", "=", "enrol")])

    def action_money(self):
        return self._open_applications(
            _("Invoice to raise"),
            [("next_action", "in", ("invoice", "invoice_balance"))])

    def action_nebosh(self):
        return self._open_applications(
            _("NEBOSH entry to tick"), [("next_action", "=", "nebosh_entry")])

    def action_lms(self):
        return self._open_applications(
            _("Platform access failed"), [("next_action", "=", "lms_retry")])

    def action_stale(self):
        return self._open_applications(
            _("Untouched for two weeks"), [
                ("write_date", "<", fields.Datetime.to_string(
                    fields.Datetime.subtract(fields.Datetime.now(), days=14))),
                ("next_action", "not in", ("none",)),
            ])

    def action_receipts(self):
        return {
            "type": "ir.actions.act_window",
            "name": _("Receipts to check"),
            "res_model": "dhb.payment.proof",
            "view_mode": "list,form",
            "domain": [("state", "=", "pending")],
        }

    def action_refunds(self):
        return {
            "type": "ir.actions.act_window",
            "name": _("Refunds to approve"),
            "res_model": "dhb.admission.refund",
            "view_mode": "list,form",
            "domain": [("state", "=", "draft")],
        }

    def action_registers(self):
        return {
            "type": "ir.actions.act_window",
            "name": _("Published intakes"),
            "res_model": "dhb.admission.register",
            "view_mode": "kanban,list,form",
            "domain": [("state", "=", "published")],
        }

    # ------------------------------------------------------------------
    @api.model
    def action_open_inbox(self):
        """The menu opens a fresh, empty transient every time."""
        return {
            "type": "ir.actions.act_window",
            "name": _("What needs attention"),
            "res_model": "dhb.admission.inbox",
            "view_mode": "form",
            "target": "current",
            "res_id": self.create({}).id,
        }
