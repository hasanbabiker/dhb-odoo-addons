from odoo import models, fields


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    dhb_admission_fee_product_id = fields.Many2one(
        "product.product",
        string="Course fee product",
        config_parameter="dhb_admission.fee_product_id",
        help="The product an admission invoice line is raised against. It "
             "decides the income account, so without it the invoice has "
             "nowhere to post.",
    )
    dhb_admission_default_fee = fields.Float(
        string="Default course fee",
        config_parameter="dhb_admission.default_fee",
        help="Filled into a new application. It can be changed per learner, "
             "which is what a discount or a company rate is.",
    )
    dhb_admission_refund_admin_fee_percent = fields.Float(
        string="Administrative deduction on refunds (%)",
        config_parameter="dhb_admission.refund_admin_fee_percent",
        help="Kept off a learner who withdraws before being entered with "
             "NEBOSH. Once they have been entered, policy refunds nothing and "
             "this percentage no longer applies.",
    )
    dhb_admission_auto_create_lms = fields.Boolean(
        string="Create the platform account when an applicant is accepted",
        config_parameter="dhb_admission.auto_create_lms",
        default=True,
        help="The account is created suspended: the username exists and can "
             "be handed over, but the learner cannot log in yet.",
    )
    dhb_admission_auto_release_lms = fields.Boolean(
        string="Release platform access when an application is enrolled",
        config_parameter="dhb_admission.auto_release_lms",
        default=True,
        help="Enrols the learner on the cohort's platform course and lifts "
             "the suspension. A platform outage never blocks the enrolment "
             "itself; the release is flagged for retry.",
    )
    dhb_admission_live_max_learners = fields.Integer(
        string="Maximum learners per tutor on a taught course",
        config_parameter="dhb_admission.live_max_learners",
        default=20,
        help="NEBOSH C026a v1 sets 1:20 for Full Time, Part Time and Virtual "
             "Delivery. It is per tutor, so a class with two tutors can take "
             "twice as many. E-Learning has no ratio.",
    )
    dhb_admission_auto_send_confirmation = fields.Boolean(
        string="Email the learner their record and invoice automatically",
        config_parameter="dhb_admission.auto_send_confirmation",
        default=True,
        help="Sent when the invoice is raised. With no outgoing mail server "
             "configured the email waits in Odoo's queue and the application "
             "says so rather than claiming it was sent.",
    )
    dhb_admission_reminder_active = fields.Boolean(
        string="Remind learners who have not finished registering",
        config_parameter="dhb_admission.reminder_active",
        default=True,
    )
    dhb_admission_reminder_interval_days = fields.Integer(
        string="Days between reminders",
        config_parameter="dhb_admission.reminder_interval_days",
        default=2,
    )
    dhb_admission_reminder_max = fields.Integer(
        string="How many reminders before a person calls",
        config_parameter="dhb_admission.reminder_max",
        default=3,
        help="After this many, the reminders stop and a to-do is raised "
             "instead. A learner who has ignored three emails needs a phone "
             "call, not a fourth.",
    )
    dhb_admission_course_change_fee = fields.Float(
        string="Transfer fee when a learner changes course",
        config_parameter="dhb_admission.course_change_fee",
        help="What DHB charges for moving somebody between cohorts. Any fee "
             "NEBOSH charges for a transfer is separate and is added on the "
             "request itself.",
    )
