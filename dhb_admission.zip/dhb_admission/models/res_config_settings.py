from odoo import models, fields


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    dhb_admission_fee_product_id = fields.Many2one(
        "product.product",
        string="Course fee product",
        config_parameter="dhb_admission.fee_product_id",
        help="The product an admission invoice line is raised against. It "
             "decides the income account, so without it the invoice has "
             "nowhere to post.",
    )
    dhb_admission_default_fee = fields.Float(
        string="Default course fee",
        config_parameter="dhb_admission.default_fee",
        help="Filled into a new application. It can be changed per learner, "
             "which is what a discount or a company rate is.",
    )
