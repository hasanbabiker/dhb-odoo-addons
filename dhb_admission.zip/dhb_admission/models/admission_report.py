from odoo import models, fields, api, _
from odoo.exceptions import UserError


class AdmissionSummaryWizard(models.TransientModel):
    """The one report the centre hands to somebody else.

    The interactive screens answer "how many of these are there"; a printed
    page has to answer "how did the term go", which is a different question.
    So this is a funnel — enquiry to learner — with the losses shown, not a
    count of rows.
    """

    _name = "dhb.admission.summary.wizard"
    _description = "Admissions report"

    date_from = fields.Date(
        string="From", required=True,
        default=lambda self: fields.Date.today().replace(day=1),
    )
    date_to = fields.Date(
        string="To", required=True, default=fields.Date.context_today)

    event_ids = fields.Many2many(
        "event.event", string="Cohorts",
        help="Leave empty for every cohort in the period.",
    )
    register_ids = fields.Many2many(
        "dhb.admission.register", string="Intakes",
        help="Leave empty for every intake.",
    )

    @api.constrains("date_from", "date_to")
    def _check_dates(self):
        for wizard in self:
            if wizard.date_to < wizard.date_from:
                raise UserError(_("The end date is before the start date."))

    def action_print(self):
        self.ensure_one()
        return self.env.ref(
            "dhb_admission.action_report_admission_summary"
        ).report_action(self)


class ReportAdmissionSummary(models.AbstractModel):
    _name = "report.dhb_admission.report_admission_summary"
    _description = "Admissions report values"

    # ------------------------------------------------------------------
    def _applications(self, wizard):
        """Applications raised inside the period.

        Dated on creation, not on the state they reached: an application
        raised in March and enrolled in April belongs to March's intake
        effort, and counting it in April would make March look barren and
        April miraculous.
        """
        domain = [
            ("create_date", ">=", fields.Datetime.to_datetime(wizard.date_from)),
            ("create_date", "<=", fields.Datetime.to_datetime(
                fields.Date.add(wizard.date_to, days=1))),
        ]
        if wizard.event_ids:
            domain.append(("event_id", "in", wizard.event_ids.ids))
        if wizard.register_ids:
            domain.append(("register_id", "in", wizard.register_ids.ids))
        return self.env["dhb.registration.invite"].search(domain)

    def _enquiry_count(self, wizard):
        """Enquiries in the period, when the CRM bridge is installed.

        Returns None rather than zero when there is no CRM, because "none
        recorded" and "we do not record them" are different facts and a
        report that shows 0 invites the wrong conclusion.
        """
        if "crm.lead" not in self.env:
            return None
        domain = [
            ("type", "=", "opportunity"),
            ("create_date", ">=", fields.Datetime.to_datetime(wizard.date_from)),
            ("create_date", "<=", fields.Datetime.to_datetime(
                fields.Date.add(wizard.date_to, days=1))),
        ]
        return self.env["crm.lead"].search_count(domain)

    @staticmethod
    def _percent(part, whole):
        return round(100.0 * part / whole, 1) if whole else 0.0

    @staticmethod
    def _average_days(pairs):
        spans = [
            (later - earlier).total_seconds() / 86400.0
            for earlier, later in pairs if earlier and later
        ]
        return round(sum(spans) / len(spans), 1) if spans else None

    # ------------------------------------------------------------------
    def _get_report_values(self, docids, data=None):
        wizards = self.env["dhb.admission.summary.wizard"].browse(docids)
        wizard = wizards[:1]
        if not wizard:
            raise UserError(_("Nothing to report on."))

        applications = self._applications(wizard)

        def count(*states):
            return len(applications.filtered(lambda a: a.state in states))

        raised = len(applications)
        submitted = count("submitted", "review", "accepted", "enrolled",
                          "rejected", "withdrawn")
        accepted = count("accepted", "enrolled", "withdrawn")
        enrolled = count("enrolled", "withdrawn")
        rejected = count("rejected")
        withdrawn = count("withdrawn")
        still_open = len(applications.filtered(
            lambda a: a.state in ("draft", "sent", "opened", "submitted",
                                  "review", "accepted")))

        # Per cohort, so a bad month can be traced to the intake that caused
        # it rather than being read as a general slump.
        by_cohort = []
        for event in applications.mapped("event_id").sorted("name"):
            rows = applications.filtered(lambda a: a.event_id == event)
            by_cohort.append({
                "name": event.name,
                "raised": len(rows),
                "enrolled": len(rows.filtered(
                    lambda a: a.state in ("enrolled", "withdrawn"))),
                "rejected": len(rows.filtered(lambda a: a.state == "rejected")),
                "withdrawn": len(rows.filtered(lambda a: a.state == "withdrawn")),
                "open": len(rows.filtered(
                    lambda a: a.state in ("draft", "sent", "opened",
                                          "submitted", "review", "accepted"))),
            })

        # Why the ones that did not make it did not make it. Written down
        # because "we lost half of them" is not an answer anybody can act on.
        rejections = [
            {
                "name": a.partner_id.display_name or a.learner_name or a.email,
                "reason": (a.rejection_reason or "").strip() or _("not recorded"),
            }
            for a in applications.filtered(lambda a: a.state == "rejected")
        ]
        withdrawals = [
            {
                "name": a.partner_id.display_name or a.learner_name or a.email,
                "reason": (a.withdrawal_reason or "").strip() or _("not recorded"),
            }
            for a in applications.filtered(lambda a: a.state == "withdrawn")
        ]

        # Where they came from. Only when the CRM bridge is installed, which
        # is what carries the source from the enquiry onto the application.
        by_source = []
        if "lead_source_id" in applications._fields:
            buckets = {}
            for application in applications:
                source = application.lead_source_id
                key = source.name if source else _("Not recorded")
                bucket = buckets.setdefault(key, {"name": key, "raised": 0,
                                                  "enrolled": 0})
                bucket["raised"] += 1
                if application.state in ("enrolled", "withdrawn"):
                    bucket["enrolled"] += 1
            for bucket in buckets.values():
                bucket["rate"] = self._percent(bucket["enrolled"],
                                               bucket["raised"])
            by_source = sorted(buckets.values(),
                               key=lambda b: -b["raised"])

        company = self.env.company
        settled = sum(applications.mapped("amount_settled"))
        refunded = sum(applications.mapped("amount_refunded_total"))

        enquiries = self._enquiry_count(wizard)

        return {
            "doc_ids": docids,
            "doc_model": "dhb.admission.summary.wizard",
            "docs": wizards,
            "wizard": wizard,
            "company": company,
            "currency": company.currency_id,
            "printed_on": fields.Datetime.now(),
            "enquiries": enquiries,
            "funnel": [
                {"label": _("Applications raised"), "value": raised,
                 "of_raised": 100.0 if raised else 0.0},
                {"label": _("Form submitted"), "value": submitted,
                 "of_raised": self._percent(submitted, raised)},
                {"label": _("Accepted"), "value": accepted,
                 "of_raised": self._percent(accepted, raised)},
                {"label": _("Enrolled"), "value": enrolled,
                 "of_raised": self._percent(enrolled, raised)},
            ],
            "raised": raised,
            "enrolled": enrolled,
            "rejected": rejected,
            "withdrawn": withdrawn,
            "still_open": still_open,
            "conversion": self._percent(enrolled, raised),
            "enquiry_conversion": (
                self._percent(enrolled, enquiries) if enquiries else None),
            "days_to_submit": self._average_days([
                (a.create_date, a.submitted_on) for a in applications]),
            "days_to_enrol": self._average_days([
                (a.create_date, a.enrolled_on) for a in applications]),
            "by_cohort": by_cohort,
            "by_source": by_source,
            "rejections": rejections,
            "withdrawals": withdrawals,
            "settled": settled,
            "refunded": refunded,
        }
