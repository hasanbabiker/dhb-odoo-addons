from odoo import models, fields, api, _


class PartnerMatching(models.Model):
    """Finding the person you already have.

    A learner who did IOSH with the centre in March and comes back for
    NEBOSH in September is the same human being. Whether the system knows
    that depends today on whether they happen to type the same email
    address, which is a coin toss: people use a work address once and a
    personal one the next time.

    When it guesses wrong the damage is quiet. Two contacts, two DHB
    numbers, a history split in half, and every count in every report
    wrong by one — with nothing anywhere saying so.
    """

    _inherit = "res.partner"

    @api.model
    def _learner_matches(self, email=None, phone=None, id_number=None,
                         nebosh_number=None, name=None, exclude_id=None):
        """Existing learners who may be this person, strongest first.

        Returns a list of (partner, reason, strong) so the caller can decide.
        `strong` marks an identifier that belongs to one human being and
        nobody else; the rest are worth showing a person and never worth
        acting on by themselves.
        """
        matches, seen = [], set()

        def _add(partners, reason, strong):
            for partner in partners:
                if partner.id in seen or partner.id == exclude_id:
                    continue
                seen.add(partner.id)
                matches.append((partner, reason, strong))

        base = [("is_learner", "=", True)]
        if exclude_id:
            base.append(("id", "!=", exclude_id))

        def _clean(value):
            return (value or "").strip()

        if _clean(nebosh_number):
            _add(self.search(base + [
                ("nebosh_learner_number", "=ilike", _clean(nebosh_number))
            ], limit=5), _("the same NEBOSH learner number"), True)

        if _clean(id_number):
            _add(self.search(base + [
                ("id_document_number", "=ilike", _clean(id_number))
            ], limit=5), _("the same identity document number"), True)

        if _clean(email):
            _add(self.search(base + [
                ("email", "=ilike", _clean(email))
            ], limit=5), _("the same email address"), True)

        # Weaker from here. A shared phone is a family, and a shared name is
        # a coincidence — both are worth a second look and neither is proof.
        if _clean(phone):
            digits = "".join(c for c in _clean(phone) if c.isdigit())[-9:]
            if len(digits) >= 7:
                _add(self.search(base + [
                    ("phone", "ilike", digits)
                ], limit=5), _("a phone number ending %s") % digits[-4:], False)

        if _clean(name) and len(_clean(name)) > 5:
            _add(self.search(base + [
                ("name", "ilike", _clean(name))
            ], limit=5), _("a very similar name"), False)

        return matches


class InviteDuplicateCheck(models.Model):
    """The warning, shown where the application is being made."""

    _inherit = "dhb.registration.invite"

    duplicate_partner_ids = fields.Many2many(
        "res.partner", string="Might already be on file",
        compute="_compute_duplicates",
    )
    duplicate_warning = fields.Text(
        string="Possible duplicate", compute="_compute_duplicates")

    @api.depends("email", "learner_name", "partner_id")
    def _compute_duplicates(self):
        Partner = self.env["res.partner"]
        for application in self:
            if application.partner_id:
                # Already attached to somebody: there is nothing to warn about.
                application.duplicate_partner_ids = [(5, 0, 0)]
                application.duplicate_warning = False
                continue

            matches = Partner._learner_matches(
                email=application.email,
                name=application.learner_name,
                exclude_id=application.partner_id.id or None,
            )
            application.duplicate_partner_ids = [
                (6, 0, [m[0].id for m in matches])]
            if not matches:
                application.duplicate_warning = False
                continue

            lines = []
            for partner, reason, strong in matches[:5]:
                history = partner._dhb_history_line()
                lines.append("• %s — %s%s" % (
                    partner.display_name, reason,
                    (" · %s" % history) if history else ""))
            application.duplicate_warning = "\n".join(lines)

    def action_open_duplicates(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Might already be on file"),
            "res_model": "res.partner",
            "view_mode": "list,form",
            "domain": [("id", "in", self.duplicate_partner_ids.ids)],
        }

    def action_use_duplicate(self):
        """Attach the one we found, rather than making a second person."""
        self.ensure_one()
        matches = self.duplicate_partner_ids
        if len(matches) != 1:
            return self.action_open_duplicates()
        self.partner_id = matches
        self.message_post(body=_(
            "Attached to the existing learner %s rather than creating a "
            "second record."
        ) % matches.display_name)
        return True


class PartnerHistoryLine(models.Model):
    _inherit = "res.partner"

    def _dhb_history_line(self):
        """One short line of what this person already did with the centre.

        Shown beside a possible duplicate so whoever is looking can decide
        from the screen instead of opening three tabs.
        """
        self.ensure_one()
        bits = []
        if self.dhb_learner_number:
            bits.append(self.dhb_learner_number)
        registrations = self.env["event.registration"].sudo().search([
            ("partner_id", "=", self.id),
            ("state", "!=", "cancel"),
        ], order="create_date desc", limit=1)
        if registrations:
            bits.append(_("last on %s") % registrations.event_id.name)
        results = self.env["dhb.nebosh.result"].sudo().search_count([
            ("partner_id", "=", self.id)])
        if results:
            bits.append(_("%s NEBOSH result(s)") % results)
        return " · ".join(bits)
