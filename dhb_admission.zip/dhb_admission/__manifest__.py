{
    "name": "DHB Admissions",
    "version": "19.0.1.17.0",
    "summary": "Review, accept or reject an applicant, invoice the course fee, "
               "and confirm the place on the cohort",
    "description": """
DHB Admissions
==============

The registration form already collects the learner's details and creates their
place on the cohort. What it does not do is let anyone decide. A submitted
form went straight to a confirmed registration, so an incomplete application,
an unpaid fee and a learner who never signed the declaration all looked
exactly like an accepted learner.

This adds the decision, without touching the form:

* Admission registers: one card per intake, showing how many applications are
  undecided, confirmed and enrolled, with the dates applications are accepted
  between and the number of places. A published register has an application
  page of its own, and whoever applies through it still receives a single-use
  link tied to their name, so the audit trail the awarding body asks for
  survives an open front door.

* A pipeline the applications sit in - Submitted, Under review, Accepted,
  Enrolled, Rejected - as a kanban anyone can read at a glance.
* Accepting confirms the place on the cohort. Rejecting cancels it and keeps
  the written reason, because "why was this person turned away" is a question
  that gets asked months later.
* The course fee becomes a draft customer invoice with one button, and the
  application shows whether it was paid.
* The learner declaration is tracked as sent and signed, with the signed file
  kept on the application. The e-signature bridge is a separate module, so
  this one installs whether or not Sign is on the database.

Nothing here replaces dhb_registration; it extends it.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["dhb_registration", "dhb_learner", "dhb_moodle", "event", "account", "website", "base_setup"],
    "data": [
        "security/ir.model.access.csv",
        "data/mail_template.xml",
        "data/reminder_data.xml",
        "data/course_change_data.xml",
        "data/learner_number_data.xml",
        "data/blocklist_data.xml",
        "report/registration_record.xml",
        "report/admission_summary.xml",
        "views/payment_proof_views.xml",
        "views/invite_views.xml",
        "views/register_views.xml",
        "views/refund_views.xml",
        "views/blocklist_views.xml",
        "views/course_change_views.xml",
        "views/reporting_views.xml",
        "views/admission_report_views.xml",
        "views/apply_templates.xml",
        "views/payment_templates.xml",
        "views/res_config_settings_views.xml",
        "views/workflow_views.xml",
        "views/inbox_views.xml",
        "views/learner_number_views.xml",
        "views/journey_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
