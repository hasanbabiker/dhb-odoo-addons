{
    "name": "DHB Tutors",
    "version": "19.0.1.0.1",
    "summary": "The people who teach: what they are approved to deliver, and "
               "the paperwork that proves it",
    "description": """
DHB Tutors
==========

An accredited centre is judged on its tutors before it is judged on anything
else. A NEBOSH or IOSH visit asks three questions about every person who
stood in front of a batch:

* What are they qualified to hold? - the certificates, and whether any of
  them has expired.
* What are they approved to deliver? - not "a tutor", but this course, in
  this language, in this role.
* How do you know they are still any good? - the observation records and the
  CPD log.

This answers all three from one screen, and answers them before the visit
rather than during it.

Where tutors live
-----------------
On the employee record, inside the Employees app. A tutor is a member of
staff, and a second home for the same person is two records that drift apart
and two places to look for a phone number.

Odoo's employee model is normally readable only by an HR officer. This
module opens **read** access to every internal user, and nothing more,
because a batch coordinator has to see who is teaching on Tuesday. Nothing
private is exposed by that: in Odoo's own source every private field carries
its own guard::

    private_email = fields.Char(string="Private Email", groups="hr.group_hr_user")
    visa_no       = fields.Char('Visa No',             groups="hr.group_hr_user")
    id_card       = fields.Binary(string="ID Card Copy", groups="hr.group_hr_user")

and a guard on the field definition is enforced on read, export and API -
not only in the form. Editing tutor information is reserved to the *Tutor
manager* group.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Human Resources",
    "license": "LGPL-3",
    "depends": [
        "base", "mail", "hr", "dhb_batch",
        # For dhb.batch.tutor_ids, which this module uses rather than
        # redeclares - see the note in models/dhb_batch.py.
        "dhb_zoom_attendance",
    ],
    "data": [
        "security/tutor_groups.xml",
        "security/ir.model.access.csv",
        "data/tutor_language_data.xml",
        "data/tutor_cron.xml",
        "views/tutor_views.xml",
        "views/tutor_qualification_views.xml",
        "views/tutor_cpd_views.xml",
        "views/tutor_observation_views.xml",
        "views/tutor_language_views.xml",
        "views/batch_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
