"""Certificates: the award, and the journey of the paper that proves it.

Three awarding bodies, three different flows, and the differences are not
cosmetic - they decide who pays, when the centre may order, and what the
office is waiting for:

  NEBOSH  The certificate is inside the course fee. On a pass NEBOSH prints
          it and ships it to the centre by DHL without being asked. The
          centre then tells the learner and usually sends it on by Aramex.
          Nothing is ordered and nothing is charged.

  IOSH    The electronic certificate is inside the course fee. A paper copy
          is issued only if the learner asks, and then the learner pays for
          the issue and the shipping - IOSH to the centre, centre to the
          learner.

  DHB     Our own. We produce it ourselves, so there is nothing to wait for,
          nothing to order and nothing to pay. It carries a verification
          code instead, because a certificate nobody can check is a
          certificate an employer cannot trust.

One record per award. The parcel that carries it is not here at all: it
lives in the Shipping app, which knows about recipients and couriers and
nothing about certificates. A certificate that is re-sent is one
certificate and two shipments, and neither of them erases the other.
"""

import secrets

from datetime import timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


# How long a certificate may sit at the centre before somebody is told to
# chase the learner. Certificates are not ours to store; an uncollected one
# is a learner who has not been reached, not a filing problem.
UNCOLLECTED_DAYS = 30

# A parcel that has been in the courier's hands longer than this has almost
# certainly gone wrong. Aramex inside the Gulf is two to four days.
IN_TRANSIT_DAYS = 14

# A paper copy asked for, invoiced, and then forgotten by everybody.
UNPAID_DAYS = 7


class DhbCertificate(models.Model):
    _name = "dhb.certificate"
    _description = "Certificate"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_awarded desc, id desc"
    _rec_name = "name"

    name = fields.Char(
        string="Reference", required=True, copy=False, readonly=True,
        default=lambda self: _("New"),
        help="Ours, not the awarding body's. It identifies this record even "
             "before the awarding body has issued a number of its own.",
    )
    active = fields.Boolean(default=True)

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True, index=True,
        tracking=True, ondelete="restrict",
    )
    event_id = fields.Many2one(
        "dhb.batch", string="Batch", index=True, tracking=True,
        ondelete="restrict",
        help="The cohort the learner sat with. It is what makes a parcel of "
             "forty certificates sortable.",
    )
    course_id = fields.Many2one(
        "dhb.course", string="Course", index=True, tracking=True)
    qualification_id = fields.Many2one(
        "dhb.qualification", string="Qualification", index=True,
        tracking=True,
        help="What was awarded. The certificate says this, not the course - "
             "the same qualification delivered in two languages produces one "
             "certificate, not two different ones.")

    # Stored rather than related, and for the same reason the course carries
    # its own copy: the body decides the whole flow below, and a related
    # field recomputed at the wrong moment would move a certificate from one
    # flow to another silently.
    awarding_body = fields.Selection(
        [
            ("nebosh", "NEBOSH"),
            ("iosh", "IOSH"),
            ("dhb", "DHB - our own"),
            ("other", "Other"),
        ],
        string="Awarded by", required=True, default="nebosh", index=True,
        tracking=True,
    )

    issue_type = fields.Selection(
        [
            ("electronic", "Electronic"),
            ("paper", "Paper"),
        ],
        string="Issued as", required=True, default="paper", tracking=True,
        help="What the learner is actually getting. NEBOSH issues paper and "
             "IOSH issues electronic; a paper IOSH copy is asked for with "
             "the button and is charged for.",
    )

    certificate_number = fields.Char(
        string="Certificate number", copy=False, tracking=True,
        help="The number printed by the awarding body. Blank until it "
             "arrives - it is not ours to invent.",
    )
    date_awarded = fields.Date(
        string="Awarded on", tracking=True,
        default=fields.Date.context_today,
        help="The date the qualification was achieved, which is the date "
             "printed on the certificate - not the date it reached us.",
    )
    date_at_centre = fields.Date(
        string="Arrived at the centre", readonly=True, copy=False,
        tracking=True)
    date_delivered = fields.Date(
        string="Reached the learner", readonly=True, copy=False,
        tracking=True)

    # A tick, not a button - and the difference is honesty.
    #
    # There was a button here called "Send electronically", and it sent
    # nothing: it changed a state and wrote a note saying the certificate
    # had been sent. The sending happens on another platform entirely, with
    # no connection to this one. A control that claims to do something it
    # does not do is worse than no control, because the record then says
    # the learner was sent their certificate on the authority of a click.
    #
    # So this records what a person did elsewhere. The date is stamped by
    # the system because a date typed from memory is a date that drifts.
    sent_electronically = fields.Boolean(
        string="Sent to the learner electronically", tracking=True,
        copy=False,
        help="Tick this once you have actually sent it, from wherever you "
             "send it. Nothing is sent from here.",
    )
    date_sent_electronic = fields.Date(
        string="Sent electronically on", readonly=True, copy=False,
        tracking=True)

    # ------------------------------------------------------------------
    # One state field, and it tracks the paper rather than the award. The
    # award itself is a fact with a date on it; what an office actually
    # needs to know every morning is where the paper has got to.
    #
    # Different bodies join this line at different points, which is why it
    # is written as one sequence rather than three: NEBOSH starts at
    # "waiting" and jumps to "at the centre" when the DHL parcel lands; IOSH
    # goes straight to "sent electronically" and only enters the middle of
    # the line if a paper copy is asked for; ours is produced here and
    # emailed.
    #
    # The labels are short on purpose. "Learner told it is ready" and "On its
    # way to the learner" are sentences, and a sentence does not fit in a
    # kanban column head or a badge - it is cut off, and a label a person
    # cannot finish reading is not a label. The stored keys are unchanged, so
    # nothing that reads them has to be touched.
    state = fields.Selection(
        [
            ("pending", "Waiting for certificate"),
            ("electronic", "Electronic issued"),
            ("requested", "Paper copy requested"),
            ("ordered", "Ordered from awarding body"),
            ("at_centre", "Received at centre"),
            ("notified", "Ready for collection"),
            ("in_transit", "Dispatched"),
            ("delivered", "Delivered"),
            ("lost", "Lost"),
            ("cancelled", "Cancelled"),
        ],
        default="pending", required=True, index=True, tracking=True,
    )

    # ------------------------------------------------------------------
    # The one line that turns a board of statuses into something a person
    # can act on. A status says where a certificate is; this says whether
    # anybody needs to do anything about it, and what.
    #
    # `action_level` is stored so it can be a filter and a facet on the left
    # of the screen - a warning nobody can search for is a warning nobody
    # finds. That storage has a cost, and it is worth naming: part of what
    # decides the level is how many days have passed, and a stored field
    # does not recompute because the clock moved. The nightly cron therefore
    # recomputes the open ones; without that, a shipment that goes late on a
    # Tuesday would still read green on Wednesday.
    action_level = fields.Selection(
        [
            ("ok", "Nothing to do"),
            ("warn", "Needs attention"),
            ("stop", "Something is wrong"),
        ],
        string="Action required", compute="_compute_action", store=True,
        index=True, default="ok",
    )
    action_required = fields.Char(
        string="What needs doing", compute="_compute_action", store=True)

    # What the card shows without opening the record: the last journey this
    # certificate made. Read from Shipping rather than copied onto the
    # certificate, so a second parcel cannot silently erase the first.
    # Filled by _compute_shipments below, in one search, rather than by
    # three related paths through a non-stored computed many2one.
    last_shipment_id = fields.Many2one(
        "dhb.shipment", compute="_compute_shipments",
        string="Last shipment")
    last_carrier = fields.Char(
        string="Sent by", compute="_compute_shipments")
    last_tracking = fields.Char(
        string="Tracking", compute="_compute_shipments")

    # Read softly rather than by depending on the admissions module for one
    # field. The number lives on res.partner in dhb_admission; this module
    # has no business requiring the whole of admissions to print it, and it
    # must not break if that module is ever uninstalled.
    learner_number = fields.Char(
        string="Learner no.", compute="_compute_learner_number")

    # ------------------------------------------------------------------
    # The money, and only for the case that has any: a paper copy asked for
    # from IOSH. Everything else is inside the course fee and must show
    # nothing at all here, or somebody will eventually invoice a learner for
    # a NEBOSH certificate they have already paid for.
    fee_issue = fields.Monetary(
        string="Issue fee", tracking=True,
        help="What the awarding body charges to issue the paper copy.")
    fee_shipping = fields.Monetary(
        string="Shipping fee", tracking=True,
        help="Awarding body to the centre, and the centre to the learner.")
    fee_total = fields.Monetary(
        string="Total charged", compute="_compute_fee_total", store=True)
    currency_id = fields.Many2one(
        "res.currency", default=lambda self: self.env.company.currency_id,
        required=True)
    invoice_id = fields.Many2one(
        "account.move", string="Invoice", copy=False, readonly=True,
        tracking=True)
    invoice_state = fields.Selection(
        related="invoice_id.payment_state", string="Payment", readonly=True)

    # ------------------------------------------------------------------
    # Ours only. A DHB certificate has no awarding body behind it to
    # confirm it, so it carries its own check: a code on the page and a
    # public page that confirms it. Without one, our certificate is a PDF
    # anybody can edit in a browser.
    verification_code = fields.Char(
        string="Verification code", copy=False, readonly=True, index=True)
    verification_url = fields.Char(
        compute="_compute_verification_url", string="Verification link")

    # Found rather than related. A One2many would need dhb.shipment to
    # carry a certificate_id, and the moment it does, Shipping knows what a
    # certificate is - which is the one thing this split exists to prevent.
    shipment_ids = fields.Many2many(
        "dhb.shipment", string="Shipments", compute="_compute_shipments")
    shipment_count = fields.Integer(compute="_compute_shipments")

    # What the reminders read, and what the list colours itself by.
    days_waiting = fields.Integer(
        compute="_compute_days_waiting", string="Days in this state")

    # A photograph or scan of the certificate itself.
    #
    # Worth more than it looks: it is the evidence that the certificate
    # existed and what was on it, on the day a learner says theirs never
    # arrived, or an employer asks the centre to confirm a number years
    # after the paper left the building.
    scan = fields.Image(
        string="Scan of the certificate",
        max_width=2400, max_height=2400,
        help="A photograph or scan of the certificate as received, before "
             "it is sent on.")
    has_scan = fields.Boolean(compute="_compute_has_scan", store=True)

    note = fields.Text(string="Internal notes")

    _unique_reference = models.Constraint(
        "unique(name)", "That certificate reference is already used.")

    # ==================================================================
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "dhb.certificate") or _("New")
        certificates = super().create(vals_list)
        for certificate, vals in zip(certificates, vals_list):
            certificate._sync_from_course(skip=set(vals))
        return certificates

    def write(self, vals):
        # Captured before super(), because afterwards every record already
        # carries the new value and the ones that were already ticked
        # cannot be told from the ones that just were.
        newly = self.env["dhb.certificate"]
        if vals.get("sent_electronically"):
            newly = self.filtered(lambda c: not c.sent_electronically)
        untick = "sent_electronically" in vals \
            and not vals["sent_electronically"]

        result = super().write(vals)

        if "course_id" in vals:
            self._sync_from_course(skip=set(vals) - {"course_id"})

        if newly:
            today = fields.Date.context_today(self)
            for certificate in newly:
                values = {"date_sent_electronic": today}
                # An electronic certificate that has reached the learner
                # has reached them: there is no parcel still to follow.
                if certificate.state in ("pending", "electronic"):
                    values["state"] = "electronic"
                    values["date_delivered"] = today
                super(DhbCertificate, certificate).write(values)
                certificate.message_post(body=_(
                    "Recorded as sent to the learner electronically."))

        if untick:
            for certificate in self.filtered(
                    lambda c: c.state == "electronic"):
                super(DhbCertificate, certificate).write({
                    "state": "pending",
                    "date_delivered": False,
                    "date_sent_electronic": False,
                })
        return result

    def _sync_from_course(self, skip=()):
        """Fill the qualification and the awarding body from the course.

        `skip` is what the caller set explicitly in this same create or
        write, and it wins. Without it the sync is not a default at all: it
        is an overwrite that silently discards what a person asked for, and
        the chatter records the discarded value as though they had typed it.

        Testing "is it empty?" instead would not work here either, because
        awarding_body is required with a default - it is never empty, so the
        sync would never fire and an IOSH course would produce a NEBOSH
        certificate.
        """
        for certificate in self:
            course = certificate.course_id
            if not course:
                continue
            if course.qualification_id and "qualification_id" not in skip:
                certificate.qualification_id = course.qualification_id
            if course.awarding_body and "awarding_body" not in skip:
                certificate.awarding_body = course.awarding_body

    @api.onchange("event_id")
    def _onchange_event_id(self):
        if self.event_id and self.event_id.course_id:
            self.course_id = self.event_id.course_id

    @api.onchange("course_id")
    def _onchange_course_id(self):
        self._sync_from_course()
        # IOSH is electronic unless somebody asks otherwise; the other two
        # are paper. Set rather than suggested, because the default that is
        # wrong three times out of four is the one that gets clicked past.
        if self.awarding_body == "iosh":
            self.issue_type = "electronic"
        elif self.awarding_body in ("nebosh", "dhb"):
            self.issue_type = "paper" if self.awarding_body == "nebosh" \
                else "electronic"

    # ==================================================================
    @api.depends("fee_issue", "fee_shipping")
    def _compute_fee_total(self):
        for certificate in self:
            certificate.fee_total = (certificate.fee_issue or 0.0) + \
                (certificate.fee_shipping or 0.0)

    @api.depends("verification_code")
    def _compute_verification_url(self):
        base = self.env["ir.config_parameter"].sudo().get_param(
            "web.base.url") or ""
        for certificate in self:
            certificate.verification_url = (
                "%s/certificate/%s" % (base, certificate.verification_code)
                if certificate.verification_code else False)

    @api.depends("state", "date_at_centre", "write_date")
    def _compute_days_waiting(self):
        today = fields.Date.context_today(self)
        for certificate in self:
            start = None
            if certificate.state == "at_centre":
                start = certificate.date_at_centre
            elif certificate.write_date:
                start = fields.Date.to_date(certificate.write_date)
            certificate.days_waiting = (today - start).days if start else 0

    # No group_expand on `state`, deliberately. Forcing every one of the ten
    # states to appear draws a board ten columns wide, eight of them empty,
    # with the right-hand ones off the edge of the screen - on the day the
    # app is installed and there is nothing in it at all. The board grows a
    # column when something reaches that state, which is also the only time
    # the column says anything.

    @api.depends("partner_id", "qualification_id")
    def _compute_display_name(self):
        for certificate in self:
            who = certificate.partner_id.display_name or _("Unnamed")
            what = certificate.qualification_id.code or ""
            certificate.display_name = "%s - %s" % (who, what) if what else who

    # ==================================================================
    # The buttons, in the order the office presses them.
    # ==================================================================
    def action_request_paper(self):
        """A learner has asked for the paper copy IOSH does not include.

        This is the only flow in the module that charges anybody, so it is
        also the only one that raises an invoice. The invoice is left in
        draft: an amount that is going to be asked of a learner should be
        looked at by a person before it is sent.
        """
        for certificate in self:
            if certificate.awarding_body == "nebosh":
                raise UserError(_(
                    "The NEBOSH certificate is inside the course fee and "
                    "arrives on paper without being asked for. There is "
                    "nothing to request and nothing to charge."))
            if certificate.state in ("in_transit", "delivered"):
                raise UserError(_(
                    "%s has already gone to the learner.")
                    % certificate.display_name)
            if not certificate.fee_total:
                raise UserError(_(
                    "Fill in the issue fee and the shipping fee first. A "
                    "paper copy that is requested with no amount on it is a "
                    "cost the centre absorbs without noticing."))
            certificate.issue_type = "paper"
            certificate.state = "requested"
            certificate._create_fee_invoice()

    def _create_fee_invoice(self):
        """A draft invoice for the issue and the shipping.

        Each line carries a product, and that is not decoration. An invoice
        line with no product has no account to post to: Odoo's
        _compute_account_id resolves nothing and the save fails with "Field
        'Account' is required on invoice lines". The admissions module in
        this same database already hit that and refuses to invoice without a
        product configured. Rather than ask for configuration that would be
        forgotten, this module ships its own two service products.
        """
        self.ensure_one()
        if self.invoice_id:
            return self.invoice_id
        lines = []
        if self.fee_issue:
            lines.append((0, 0, {
                "product_id": self.env.ref(
                    "dhb_certificate.product_certificate_issue").id,
                "name": _("Paper certificate - issue fee (%s)")
                        % (self.qualification_id.code or self.awarding_body),
                "quantity": 1,
                "price_unit": self.fee_issue,
            }))
        if self.fee_shipping:
            lines.append((0, 0, {
                "product_id": self.env.ref(
                    "dhb_certificate.product_certificate_shipping").id,
                "name": _("Paper certificate - shipping"),
                "quantity": 1,
                "price_unit": self.fee_shipping,
            }))
        invoice = self.env["account.move"].create({
            "move_type": "out_invoice",
            "partner_id": self.partner_id.id,
            "currency_id": self.currency_id.id,
            "invoice_origin": self.name,
            "invoice_line_ids": lines,
        })
        self.invoice_id = invoice
        self.message_post(body=_(
            "Draft invoice %s raised for the paper copy.") % invoice.name)
        return invoice

    def action_order_from_body(self):
        """Ask the awarding body for the paper copy - once it is paid for.

        The refusal is the point of the button. A centre that orders before
        the learner pays is a centre that pays for certificates learners
        change their mind about, and it finds out months later.
        """
        for certificate in self:
            if certificate.state != "requested":
                raise UserError(_(
                    "%s has not been requested as a paper copy.")
                    % certificate.display_name)
            invoice = certificate.invoice_id
            if not invoice:
                raise UserError(_(
                    "There is no invoice against %s.")
                    % certificate.display_name)
            if invoice.state == "draft":
                raise UserError(_(
                    "The invoice for %s is still a draft. Confirm and send "
                    "it first.") % certificate.display_name)
            if invoice.payment_state not in ("paid", "in_payment"):
                raise UserError(_(
                    "%(name)s has not been paid for yet (%(state)s). The "
                    "copy is ordered once the learner has paid - otherwise "
                    "the centre carries the cost of a copy nobody collects.",
                    name=certificate.display_name,
                    state=invoice.payment_state or _("not paid"),
                ))
            certificate.state = "ordered"

    def action_mark_at_centre(self):
        """The parcel has landed - DHL from NEBOSH, or the IOSH copy."""
        for certificate in self:
            if certificate.state in ("delivered", "cancelled"):
                raise UserError(_(
                    "%s is already finished with.") % certificate.display_name)
            certificate.write({
                "state": "at_centre",
                "date_at_centre": fields.Date.context_today(certificate),
            })

    def action_notify_learner(self):
        """Tell the learner the certificate is here and ask how they want it."""
        for certificate in self:
            if certificate.state != "at_centre":
                raise UserError(_(
                    "%s is not at the centre, so there is nothing to tell "
                    "the learner yet.") % certificate.display_name)
            certificate.state = "notified"
            certificate.message_post(body=_(
                "Learner told the certificate is ready for collection or "
                "shipping."))

    def action_create_shipment(self):
        """Hand the parcel over to Shipping, and stop knowing about it.

        Everything the courier needs is already here, so nothing is typed a
        second time. What this does NOT do is choose a carrier or book
        anything: that is Shipping's business and the office's decision.
        """
        self.ensure_one()
        if self.issue_type != "paper":
            raise UserError(_(
                "%s is an electronic certificate. There is nothing to post.")
                % self.display_name)
        shipment = self.env["dhb.shipment"].create({
            "partner_id": self.partner_id.id,
            "res_model": self._name,
            "res_id": self.id,
            "origin": self.name,
            "contents": _("Certificate - %s") % (
                self.qualification_id.code or _("training")),
        })
        self.message_post(body=_(
            "Shipment %s raised.") % shipment.name)
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.shipment",
            "res_id": shipment.id,
            "view_mode": "form",
        }

    def action_open_shipments(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Shipments for %s") % self.display_name,
            "res_model": "dhb.shipment",
            "view_mode": "list,form",
            "domain": [("id", "in", self.shipment_ids.ids)],
        }

    def action_mark_delivered(self):
        for certificate in self:
            certificate.write({
                "state": "delivered",
                "date_delivered": fields.Date.context_today(certificate),
            })

    def action_mark_lost(self):
        self.write({"state": "lost"})

    def action_cancel(self):
        self.write({"state": "cancelled"})

    def action_back_to_pending(self):
        self.write({"state": "pending"})

    # ------------------------------------------------------------------
    def action_issue_dhb(self):
        """Produce our own certificate: give it a code, then print it.

        The code is issued here rather than on creation on purpose. A code
        that exists before the certificate has been issued is a code that
        can be verified before the learner has earned anything.
        """
        for certificate in self:
            if certificate.awarding_body != "dhb":
                raise UserError(_(
                    "Only our own certificates are produced here. %s is "
                    "awarded by somebody else, and printing our own version "
                    "of it would be a forgery.") % certificate.display_name)
            if not certificate.verification_code:
                certificate.verification_code = \
                    certificate._new_verification_code()
            # Deliberately NOT marked as delivered here. Producing the PDF
            # is not the same act as putting it in front of the learner,
            # and the second one happens somewhere this system cannot see.
            # The tick above records that.
        return self.env.ref(
            "dhb_certificate.action_report_certificate").report_action(self)

    @api.depends("scan")
    def _compute_has_scan(self):
        """Stored, so the list can show a column and the search a filter.

        The image itself must never be put in either: a list of forty rows
        would fetch forty full-size scans to draw forty ticks.
        """
        for certificate in self:
            certificate.has_scan = bool(certificate.scan)

    def _compute_shipments(self):
        """Whatever Shipping has raised against this certificate.

        Not cached and not stored: a shipment is created in another app and
        a stored mirror of it here would be a second copy of the one fact
        that matters - where the paper is.
        """
        shipments = self.env["dhb.shipment"]
        for certificate in self:
            found = shipments.search([
                ("res_model", "=", "dhb.certificate"),
                ("res_id", "=", certificate.id or 0),
            ], order="date_ready desc, id desc") if certificate.id \
                else shipments
            certificate.shipment_ids = found
            certificate.shipment_count = len(found)
            last = found[:1]
            certificate.last_shipment_id = last
            certificate.last_carrier = last.carrier_id.name if last else False
            certificate.last_tracking = last.tracking_ref if last else False

    def _compute_learner_number(self):
        """The DHB learner number, read without depending on admissions.

        No @api.depends, deliberately. The field it would have to name lives
        on res.partner in dhb_admission - a module this one does not require
        and which may not be installed - and a dependency on a field that
        does not exist breaks the registry at load. Recomputing on every
        read is correct and costs nothing: it is one attribute off a record
        already in memory.
        """
        for certificate in self:
            partner = certificate.partner_id
            certificate.learner_number = partner.dhb_learner_number \
                if partner and "dhb_learner_number" in partner._fields \
                else False

    @api.depends("state", "date_at_centre", "invoice_id.payment_state",
                 "certificate_number", "issue_type", "awarding_body",
                 "sent_electronically", "verification_code",
                 "partner_id.street", "partner_id.city", "partner_id.email",
                 "shipment_ids")
    def _compute_action(self):
        """One sentence per certificate, or nothing at all.

        Ordered worst first and stopping at the first hit, because a line
        that tries to say three things says none of them. The office needs
        the next thing to do, not an inventory of everything imperfect.
        """
        today = fields.Date.context_today(self)
        for certificate in self:
            level, message = certificate._action_for(today)
            certificate.action_level = level
            certificate.action_required = message

    def _action_for(self, today):
        self.ensure_one()

        if self.state == "lost":
            return "stop", _("Lost. Open a claim with the courier or ask "
                             "the awarding body for a replacement.")

        # A parcel that is late is late whatever else is true of it.
        sent = [
            shipment for shipment in self.shipment_ids
            if shipment.date_shipped and shipment.state not in (
                "delivered", "returned", "cancelled")
        ]
        if self.state == "in_transit" and sent:
            days = (today - max(s.date_shipped for s in sent)).days
            if days >= IN_TRANSIT_DAYS:
                return "stop", _("Shipment is %s days old and not recorded "
                                 "as delivered. Check the tracking number.") \
                                 % days

        if self.state in ("at_centre", "notified") and self.date_at_centre:
            days = (today - self.date_at_centre).days
            if days >= UNCOLLECTED_DAYS:
                return "stop", _("Sitting at the centre for %s days. The "
                                 "learner has not collected it.") % days

        if self.state == "requested" and self.invoice_id and \
                self.invoice_id.payment_state not in ("paid", "in_payment"):
            return "warn", _("Paper copy requested and not paid for. Nothing "
                             "has been ordered from the awarding body.")

        if self.state == "requested" and not self.invoice_id:
            return "warn", _("Requested as a paper copy with no invoice "
                             "raised against it.")

        # Only asked at the point it matters: the certificate is here and
        # about to be sent. Asking earlier would light up every record in
        # the system on the day it is installed.
        if self.state in ("at_centre", "notified") and \
                self.issue_type == "paper" and \
                not (self.partner_id.street and self.partner_id.city):
            return "warn", _("No delivery address on the learner. It cannot "
                             "be couriered until there is one.")

        if self.awarding_body == "dhb" and self.verification_code \
                and not self.sent_electronically:
            return "warn", _("Produced, but not yet recorded as sent to the "
                             "learner. Tick it once you have sent it.")

        if self.state == "electronic" and not self.partner_id.email:
            return "warn", _("No email address on the learner, so the "
                             "electronic certificate has nowhere to go.")

        if self.state in ("at_centre", "notified", "in_transit", "delivered") \
                and self.awarding_body != "dhb" and not self.certificate_number:
            return "warn", _("The awarding body's certificate number has not "
                             "been recorded.")

        return "ok", False

    def _new_verification_code(self):
        """A code that cannot be guessed from the one before it.

        The reference (CERT/2026/0007) is ours and is sequential by design -
        0008 follows it, and that is useful. A verification code must be the
        opposite: anybody who can guess one can enumerate every certificate
        the centre has ever issued, read each learner's name and what they
        were awarded, and do it from a public page with no login. So this
        does not come from a sequence. It comes from the system's
        cryptographic random source, and it is checked for a collision
        rather than assumed to be unique.
        """
        self.ensure_one()
        year = (self.date_awarded or fields.Date.context_today(self)).year
        for _attempt in range(10):
            code = "DHB-%s-%s" % (year, secrets.token_hex(5).upper())
            if not self.sudo().search_count([("verification_code", "=", code)]):
                return code
        raise UserError(_(
            "Could not produce a unique verification code. Try again."))

    # ==================================================================
    @api.model
    def _cron_certificate_reminders(self):
        """Three things that go quiet and cost money or goodwill."""
        today = fields.Date.context_today(self)

        uncollected = self.search([
            ("state", "in", ("at_centre", "notified")),
            ("date_at_centre", "<=", today - timedelta(days=UNCOLLECTED_DAYS)),
        ])
        for certificate in uncollected:
            certificate._raise_reminder(_(
                "This certificate has been at the centre since %(date)s - "
                "%(days)s days. The learner has not collected it and has not "
                "asked for it to be sent.",
                date=certificate.date_at_centre,
                days=(today - certificate.date_at_centre).days,
            ))

        stuck = self.search([("state", "=", "in_transit")])
        for certificate in stuck:
            # The empty dates are dropped rather than trusted. date_sent is
            # editable and not required, so one shipment with it cleared
            # puts False into this list - and max() on a list of dates and a
            # False raises, which would abort the whole nightly run and
            # silently stop the other two chases below as well.
            sent = [
                date for date in certificate.shipment_ids.filtered(
                    lambda s: s.state not in (
                        "delivered", "returned", "cancelled")
                ).mapped("date_shipped") if date
            ]
            if sent and (today - max(sent)).days >= IN_TRANSIT_DAYS:
                certificate._raise_reminder(_(
                    "Sent %(days)s days ago and not recorded as delivered. "
                    "Check the tracking number before the courier's claim "
                    "window closes.",
                    days=(today - max(sent)).days,
                ))

        unpaid = self.search([
            ("state", "=", "requested"),
            ("invoice_id", "!=", False),
            ("write_date", "<=", today - timedelta(days=UNPAID_DAYS)),
        ])
        for certificate in unpaid:
            if certificate.invoice_id.payment_state in ("paid", "in_payment"):
                continue
            certificate._raise_reminder(_(
                "A paper copy was requested and the invoice is still "
                "unpaid. Nothing has been ordered from the awarding body."))

        # Last, and the order is not a matter of taste.
        #
        # action_level is stored, and part of what decides it is how many
        # days have passed - nothing in Odoo recomputes a stored field
        # because the clock moved, so it has to be refreshed here. But
        # assigning to a stored computed field outside a compute context
        # issues a real write, and every write stamps write_date. The
        # "unpaid" search above filters on write_date, so running this
        # first would touch every open certificate and guarantee that
        # reminder could never fire again - silently, forever. It also
        # resets days_waiting, which reads write_date as its clock.
        open_ones = self.search([
            ("state", "not in", ("delivered", "cancelled")),
        ])
        if open_ones:
            open_ones._compute_action()

    def _raise_reminder(self, body):
        """One open activity per certificate, never a second.

        A cron that files a new activity every night turns a reminder into
        wallpaper, and the day it matters nobody is reading it.
        """
        self.ensure_one()
        existing = self.env["mail.activity"].search_count([
            ("res_model", "=", self._name),
            ("res_id", "=", self.id),
            ("activity_type_id", "=", self.env.ref("mail.mail_activity_data_todo").id),
        ])
        if existing:
            return
        user = self.env.user
        if self.event_id and self.event_id.user_id:
            user = self.event_id.user_id
        self.activity_schedule(
            "mail.mail_activity_data_todo",
            summary=_("Certificate: %s") % self.partner_id.display_name,
            note=body,
            user_id=user.id,
        )
