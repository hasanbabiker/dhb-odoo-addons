# Moodle Connector — وحدة أوديو 19

مزامنة في الاتجاهين بين أوديو ومنصة Moodle: المتدربون، الدورات، التسجيل،
الدرجات، ونسبة الإنجاز.

## ما تفعله

**من أوديو إلى Moodle**

| | |
|---|---|
| إنشاء حساب متدرب | زر في بطاقة جهة الاتصال، وبيانات الدخول تظهر مرة واحدة في المحادثة |
| التسجيل في دورة | معالج يختار عدة متدربين ويسجّلهم دفعة واحدة، وينشئ الحسابات الناقصة |
| إلغاء التسجيل | زر في سطر التسجيل |
| إنشاء وتعديل دورة | تُنشأ في Moodle، وأي تعديل لاحق على الاسم أو التواريخ يُدفع تلقائيًا |

**من Moodle إلى أوديو**

| | |
|---|---|
| كتالوج الدورات | مع التصنيفات والتواريخ وحالة الظهور |
| المسجّلون | مع الدور وآخر دخول |
| الدرجات | الدرجة الإجمالية للدورة من `gradereport_user_get_grade_items` |
| نسبة الإنجاز | من `core_completion_get_course_completion_status` |
| مطابقة المتدربين | ربط مستخدم Moodle بجهة اتصال أوديو عبر البريد الإلكتروني |

## الإعداد على جانب Moodle

هذه الخطوات تسبق أي شيء في أوديو.

**١) تفعيل خدمات الويب**

*Site administration → General → Advanced features* وفعّل **Enable web services**.

*Site administration → Server → Web services → Manage protocols* وفعّل **REST protocol**.

**٢) إنشاء خدمة خارجية**

*Web services → External services → Add*، سمّها `Odoo`، وفعّل **Enabled**
و**Authorised users only**.

ثم اضغط **Functions** وأضف هذه الدوال:

```
core_webservice_get_site_info
core_course_get_courses
core_course_get_categories
core_course_create_courses
core_course_update_courses
core_user_create_users
core_user_get_users
core_user_get_users_by_field
core_user_update_users
enrol_manual_enrol_users
enrol_manual_unenrol_users
core_enrol_get_enrolled_users
gradereport_user_get_grade_items
core_completion_get_course_completion_status
```

**٣) إنشاء التوكن**

*Web services → Manage tokens → Add*، اختر مستخدمًا إداريًا وخدمة `Odoo`.
انسخ التوكن.

**٤) صلاحيات المستخدم صاحب التوكن**

يحتاج هذه القدرات (capabilities) على الأقل:

```
moodle/user:create        moodle/course:create
moodle/user:update        moodle/course:update
moodle/user:viewalldetails
enrol/manual:enrol        enrol/manual:unenrol
moodle/course:viewparticipants
moodle/grade:viewall
```

الأسهل أن يكون حسابًا بدور Manager على مستوى النظام.

## الإعداد في أوديو

**Moodle → Configuration → Moodle Sites → New**

- Site URL: `https://elearning.dhbtraining.com`
- Web Service Token: التوكن الذي أنشأته
- Student Role ID: `5` (الدور الافتراضي للطالب في Moodle)
- Default Category ID: تصنيف الدورات الافتراضي

اضغط **Test Connection**. إن نجح ستظهر لك نسخة Moodle واسم الموقع. وإن كانت
هناك دوال ناقصة فستُسرد لك في المحادثة بالاسم، فتضيفها في Moodle.

ثم **Sync Everything** لسحب الكتالوج والمسجّلين.

## نقاط تحتاج انتباهك

**لا توجد webhooks في Moodle الأساسي.** الاتجاه من Moodle إلى أوديو يعمل
بالاستطلاع الدوري (كرون كل ساعتين افتراضيًا)، لا لحظيًا. لو احتجت فورية،
فذلك يتطلب إضافة طرف ثالث على Moodle أو استدعاء المزامنة يدويًا.

**كلمات المرور تُعرض مرة واحدة.** عند إنشاء حساب متدرب تظهر بيانات الدخول في
محادثة جهة الاتصال ولا تُخزَّن في أي حقل. انسخها فورًا وسلّمها للمتدرب.

**المطابقة بالبريد الإلكتروني.** إن اختلف بريد المتدرب بين النظامين فلن
يُربط سجل التسجيل بجهة اتصال أوديو. استخدم فلتر «No Odoo contact» في شاشة
التسجيلات لاكتشاف هذه الحالات.

**`shortname` يجب أن يكون فريدًا** على مستوى موقع Moodle كله. إن رفض Moodle
إنشاء دورة فهذا أول ما تتحقق منه.

**نسبة الإنجاز تحتاج تفعيل تتبّع الإنجاز** في إعدادات الدورة داخل Moodle.
إن كان معطّلًا فستظهر النسبة صفرًا دون أن يكون ذلك خطأ.

## الخطوة التالية المقترحة

ربط المبيعات: عند تأكيد أمر بيع لدورة، يُنشأ حساب المتدرب ويُسجَّل تلقائيًا.
هذه وحدة جسر صغيرة فوق هذه، تعتمد على `sale` وتضيف حقل «دورة Moodle» على
المنتج.

## الرخصة

LGPL-3 — الكود مكتوب من الصفر.
