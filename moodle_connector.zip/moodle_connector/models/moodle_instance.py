# -*- coding: utf-8 -*-

import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .moodle_api import MoodleAPI, MoodleError, REQUIRED_FUNCTIONS

_logger = logging.getLogger(__name__)


class MoodleInstance(models.Model):
    _name = "moodle.instance"
    _description = "Moodle Site"
    _inherit = ["mail.thread"]
    _order = "name"

    name = fields.Char(required=True, default="Moodle", tracking=True)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        "res.company", required=True, default=lambda self: self.env.company)

    url = fields.Char(
        "Site URL", required=True, tracking=True,
        help="Root of the Moodle site, e.g. https://elearning.example.com")
    token = fields.Char(
        "Web Service Token", required=True, groups="base.group_system",
        help="Moodle: Site administration, Server, Web services, Manage tokens.")
    verify_ssl = fields.Boolean(
        "Verify SSL", default=True,
        help="Untick only for a test server with a self-signed certificate.")

    student_role_id = fields.Integer(
        "Student Role ID", default=5,
        help="Moodle role id used when enrolling. 5 is the stock student role.")
    default_category_id = fields.Integer(
        "Default Category ID", default=1,
        help="Moodle course category used when Odoo creates a course.")

    state = fields.Selection(
        [("draft", "Not connected"), ("connected", "Connected"),
         ("error", "Error")],
        default="draft", readonly=True, tracking=True)
    last_error = fields.Char(readonly=True)

    site_name = fields.Char(readonly=True)
    moodle_release = fields.Char("Moodle Version", readonly=True)
    connected_as = fields.Char("Token Belongs To", readonly=True)
    last_sync = fields.Datetime(readonly=True)

    course_ids = fields.One2many("moodle.course", "instance_id", string="Courses")
    course_count = fields.Integer(compute="_compute_counts")
    enrolment_count = fields.Integer(compute="_compute_counts")

    _sql_constraints = [
        ("url_company_uniq", "unique(url, company_id)",
         "This Moodle site is already configured for this company."),
    ]

    @api.depends("course_ids")
    def _compute_counts(self):
        Enrolment = self.env["moodle.enrolment"]
        for instance in self:
            instance.course_count = len(instance.course_ids)
            instance.enrolment_count = Enrolment.search_count(
                [("course_id.instance_id", "=", instance.id)])

    # ==================================================================
    # plumbing
    # ==================================================================
    def _call(self, function, params=None):
        self.ensure_one()
        site = self.sudo()
        return MoodleAPI.call(site.url, site.token, function, params,
                              verify_ssl=site.verify_ssl)

    def _args(self):
        """(url, token, verify) triple for the API helpers."""
        self.ensure_one()
        site = self.sudo()
        return site.url, site.token, site.verify_ssl

    @api.model
    def _default_instance(self):
        return self.sudo().search([
            ("state", "=", "connected"),
            ("company_id", "=", self.env.company.id),
        ], limit=1)

    # ==================================================================
    # actions
    # ==================================================================
    def action_test_connection(self):
        self.ensure_one()
        url, token, verify = self._args()
        try:
            info = MoodleAPI.site_info(url, token, verify_ssl=verify)
        except MoodleError as err:
            message = err.args[0] if err.args else str(err)
            self.sudo().write({"state": "error", "last_error": message})
            raise

        available = set(info.get("functions") and
                        [f.get("name") for f in info["functions"]] or [])
        missing = [f for f in REQUIRED_FUNCTIONS if available and f not in available]

        self.sudo().write({
            "site_name": info.get("sitename"),
            "moodle_release": info.get("release"),
            "connected_as": info.get("fullname"),
            "state": "connected",
            "last_error": False,
        })
        self.message_post(body=_(
            "Connected to %(site)s (%(release)s) as %(user)s.",
            site=info.get("sitename"), release=info.get("release"),
            user=info.get("fullname")))

        if missing:
            # Not fatal: the token works, but some features will fail later.
            self.message_post(body=_(
                "These web service functions are not enabled on the token, so "
                "the matching features will fail:<br/>%s") % "<br/>".join(missing))
            return {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "type": "warning",
                    "title": _("Connected, with gaps"),
                    "message": _("%s function(s) are missing. See the chatter.")
                               % len(missing),
                    "sticky": True,
                },
            }
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "type": "success",
                "title": _("Moodle"),
                "message": _("Connected to %s.") % info.get("sitename"),
                "sticky": False,
            },
        }

    def action_sync_courses(self):
        for instance in self:
            instance.env["moodle.course"]._pull_from_moodle(instance)
            instance.sudo().last_sync = fields.Datetime.now()
        return True

    def action_sync_everything(self):
        for instance in self:
            instance.action_sync_courses()
            instance.course_ids.action_sync_enrolments()
        return True

    def action_open_courses(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Courses"),
            "res_model": "moodle.course",
            "view_mode": "list,form",
            "domain": [("instance_id", "=", self.id)],
            "context": {"default_instance_id": self.id},
        }

    def action_open_enrolments(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Enrolments"),
            "res_model": "moodle.enrolment",
            "view_mode": "list,form",
            "domain": [("course_id.instance_id", "=", self.id)],
        }

    # ==================================================================
    # cron
    # ==================================================================
    @api.model
    def _cron_sync(self):
        """Moodle core has no outbound webhooks, so we poll."""
        for instance in self.sudo().search([("state", "=", "connected")]):
            try:
                instance.action_sync_everything()
            except Exception as err:  # one bad site must not stop the others
                _logger.warning("Moodle: sync failed for %s (%s)",
                                instance.display_name, err)
                instance.write({"state": "error", "last_error": str(err)[:500]})
