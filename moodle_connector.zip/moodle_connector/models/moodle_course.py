# -*- coding: utf-8 -*-

import logging
from datetime import datetime

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .moodle_api import MoodleAPI, MoodleError

_logger = logging.getLogger(__name__)


class MoodleCourse(models.Model):
    _name = "moodle.course"
    _description = "Moodle Course"
    _inherit = ["mail.thread"]
    _order = "start_date desc, name"

    name = fields.Char("Full Name", required=True, tracking=True)
    short_name = fields.Char("Short Name", required=True, tracking=True,
                             help="Must be unique across the Moodle site.")
    instance_id = fields.Many2one(
        "moodle.instance", string="Moodle Site", required=True,
        ondelete="cascade", index=True,
        default=lambda self: self.env["moodle.instance"]._default_instance())
    company_id = fields.Many2one(related="instance_id.company_id", store=True)

    moodle_id = fields.Integer("Moodle Course ID", readonly=True, index=True)
    category_id_moodle = fields.Integer("Moodle Category ID", default=1)
    category_name = fields.Char("Category", readonly=True)
    summary = fields.Html("Summary")
    start_date = fields.Date(tracking=True)
    end_date = fields.Date(tracking=True)
    visible = fields.Boolean(default=True)
    course_url = fields.Char("Course Link", compute="_compute_course_url")

    state = fields.Selection(
        [("draft", "Not in Moodle"), ("synced", "Synced")],
        default="draft", readonly=True, tracking=True)

    enrolment_ids = fields.One2many(
        "moodle.enrolment", "course_id", string="Enrolments")
    enrolment_count = fields.Integer(compute="_compute_stats")
    completed_count = fields.Integer(compute="_compute_stats")
    average_grade = fields.Float(compute="_compute_stats", digits=(16, 2))
    enrolments_synced = fields.Datetime(readonly=True)

    _sql_constraints = [
        ("moodle_id_uniq", "unique(instance_id, moodle_id)",
         "This course is already linked."),
    ]

    @api.depends("instance_id.url", "moodle_id")
    def _compute_course_url(self):
        for course in self:
            base = (course.instance_id.url or "").rstrip("/")
            course.course_url = (
                "%s/course/view.php?id=%s" % (base, course.moodle_id)
                if base and course.moodle_id else False)

    @api.depends("enrolment_ids.completion_percent", "enrolment_ids.grade")
    def _compute_stats(self):
        for course in self:
            enrolments = course.enrolment_ids
            course.enrolment_count = len(enrolments)
            course.completed_count = len(
                enrolments.filtered(lambda e: e.completion_percent >= 100))
            graded = enrolments.filtered(lambda e: e.grade)
            course.average_grade = (
                sum(graded.mapped("grade")) / len(graded)) if graded else 0.0

    # ==================================================================
    # Moodle -> Odoo
    # ==================================================================
    @api.model
    def _pull_from_moodle(self, instance):
        url, token, verify = instance._args()
        courses = MoodleAPI.get_courses(url, token, verify_ssl=verify)
        categories = {
            c.get("id"): c.get("name")
            for c in MoodleAPI.get_categories(url, token, verify_ssl=verify)
        }

        existing = {
            course.moodle_id: course
            for course in self.search([("instance_id", "=", instance.id)])
        }
        created = 0
        for payload in courses:
            moodle_id = payload.get("id")
            # Course id 1 is the Moodle front page, never a real course.
            if not moodle_id or moodle_id == 1:
                continue
            values = {
                "instance_id": instance.id,
                "moodle_id": moodle_id,
                "name": payload.get("fullname") or _("Untitled"),
                "short_name": payload.get("shortname") or str(moodle_id),
                "category_id_moodle": payload.get("categoryid") or 1,
                "category_name": categories.get(payload.get("categoryid")),
                "summary": payload.get("summary") or False,
                "start_date": self._epoch_to_date(payload.get("startdate")),
                "end_date": self._epoch_to_date(payload.get("enddate")),
                "visible": bool(payload.get("visible", 1)),
                "state": "synced",
            }
            course = existing.get(moodle_id)
            if course:
                course.with_context(from_moodle=True).write(values)
            else:
                self.with_context(from_moodle=True).create(values)
                created += 1
        _logger.info("Moodle: pulled %s courses from %s (%s new)",
                     len(courses), instance.display_name, created)
        return created

    @staticmethod
    def _epoch_to_date(value):
        if not value:
            return False
        try:
            return datetime.utcfromtimestamp(int(value)).date()
        except (ValueError, OSError):
            return False

    @staticmethod
    def _date_to_epoch(value):
        if not value:
            return 0
        return int(datetime.combine(value, datetime.min.time()).timestamp())

    # ==================================================================
    # Odoo -> Moodle
    # ==================================================================
    def _moodle_payload(self):
        self.ensure_one()
        values = {
            "fullname": self.name,
            "shortname": self.short_name,
            "categoryid": self.category_id_moodle
                          or self.instance_id.default_category_id or 1,
            "visible": 1 if self.visible else 0,
        }
        if self.summary:
            import re
            values["summary"] = re.sub(r"<[^>]+>", " ", self.summary).strip()
        if self.start_date:
            values["startdate"] = self._date_to_epoch(self.start_date)
        if self.end_date:
            values["enddate"] = self._date_to_epoch(self.end_date)
        return values

    def action_push_to_moodle(self):
        for course in self:
            url, token, verify = course.instance_id._args()
            payload = course._moodle_payload()
            if course.moodle_id:
                payload["id"] = course.moodle_id
                MoodleAPI.update_course(url, token, payload, verify_ssl=verify)
                course.message_post(body=_("Course updated in Moodle."))
            else:
                result = MoodleAPI.create_course(url, token, payload,
                                                 verify_ssl=verify)
                course.with_context(from_moodle=True).write({
                    "moodle_id": result.get("id"),
                    "state": "synced",
                })
                course.message_post(body=_(
                    "Course created in Moodle with id %s.") % result.get("id"))
        return True

    def write(self, values):
        result = super().write(values)
        if self.env.context.get("from_moodle"):
            return result
        pushed = {"name", "short_name", "summary", "start_date", "end_date",
                  "visible", "category_id_moodle"}
        if set(values) & pushed:
            for course in self.filtered("moodle_id"):
                try:
                    course.action_push_to_moodle()
                except (MoodleError, UserError) as err:
                    course.message_post(body=_(
                        "Could not push the change to Moodle: %s")
                        % (err.args[0] if err.args else err))
        return result

    # ==================================================================
    # enrolments
    # ==================================================================
    def action_sync_enrolments(self):
        Enrolment = self.env["moodle.enrolment"]
        for course in self.filtered("moodle_id"):
            try:
                Enrolment._pull_for_course(course)
                course.enrolments_synced = fields.Datetime.now()
            except MoodleError as err:
                _logger.warning("Moodle: enrolment sync failed for %s (%s)",
                                course.display_name, err)
        return True

    def action_open_moodle(self):
        self.ensure_one()
        if not self.course_url:
            raise UserError(_("This course has no Moodle id yet."))
        return {"type": "ir.actions.act_url", "target": "new",
                "url": self.course_url}

    def action_enrol_wizard(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Enrol learners"),
            "res_model": "moodle.enrol.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_course_id": self.id},
        }
