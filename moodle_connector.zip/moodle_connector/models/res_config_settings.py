# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    moodle_site_count = fields.Integer(compute="_compute_moodle_info")
    moodle_connected_site = fields.Char(compute="_compute_moodle_info")

    @api.depends("company_id")
    def _compute_moodle_info(self):
        Instance = self.env["moodle.instance"].sudo()
        connected = Instance.search([("state", "=", "connected")], limit=1)
        count = Instance.search_count([])
        for record in self:
            record.moodle_site_count = count
            record.moodle_connected_site = connected.site_name or connected.url or ""

    def action_open_moodle_sites(self):
        return self.env["ir.actions.act_window"]._for_xml_id(
            "moodle_connector.action_moodle_instance")
