# -*- coding: utf-8 -*-

import logging
import re
import secrets
import unicodedata

from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .moodle_api import MoodleAPI, MoodleError

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = "res.partner"

    moodle_user_id = fields.Integer("Moodle User ID", readonly=True, copy=False,
                                    index=True)
    moodle_username = fields.Char("Moodle Username", readonly=True, copy=False)
    moodle_enrolment_ids = fields.One2many(
        "moodle.enrolment", "partner_id", string="Moodle Enrolments")
    moodle_enrolment_count = fields.Integer(compute="_compute_moodle_counts")

    @api.depends("moodle_enrolment_ids")
    def _compute_moodle_counts(self):
        for partner in self:
            partner.moodle_enrolment_count = len(
                partner.moodle_enrolment_ids.filtered(
                    lambda e: e.state == "active"))

    # ==================================================================
    @staticmethod
    def _slug(value):
        """Moodle usernames: lowercase, no spaces, limited punctuation."""
        text = unicodedata.normalize("NFKD", value or "")
        text = text.encode("ascii", "ignore").decode()
        text = re.sub(r"[^a-zA-Z0-9._-]+", ".", text).strip(".").lower()
        return text[:80] or "learner"

    def _ensure_moodle_user(self, instance):
        """Return the Moodle user id, creating the account if needed."""
        self.ensure_one()
        if self.moodle_user_id:
            return self.moodle_user_id
        if not self.email:
            raise UserError(_(
                "%s has no email address, so no Moodle account can be created.")
                % self.display_name)

        url, token, verify = instance._args()
        email = self.email.strip().lower()

        # Someone may already exist in Moodle with this address.
        existing = MoodleAPI.get_user_by_email(url, token, email,
                                               verify_ssl=verify)
        if existing and existing.get("id"):
            self.sudo().write({
                "moodle_user_id": existing["id"],
                "moodle_username": existing.get("username"),
            })
            self.message_post(body=_(
                "Linked to the existing Moodle account %s.")
                % existing.get("username"))
            self._pull_moodle_avatar(instance, existing)
            return existing["id"]

        parts = (self.name or "").split()
        first = parts[0] if parts else (self.name or "Learner")
        last = " ".join(parts[1:]) or first
        username = self._slug(email.split("@")[0])
        password = self._generate_password()

        try:
            created = MoodleAPI.create_user(url, token, {
                "username": username,
                "password": password,
                "firstname": first[:100],
                "lastname": last[:100],
                "email": email,
                "auth": "manual",
                "lang": "en",
            }, verify_ssl=verify)
        except MoodleError as err:
            self.message_post(body=_("Moodle account creation failed: %s")
                              % (err.args[0] if err.args else err))
            return False

        self.sudo().write({
            "moodle_user_id": created.get("id"),
            "moodle_username": created.get("username") or username,
        })
        self._push_avatar_to_moodle(instance)
        # The password is posted once, in the chatter, so whoever created the
        # account can pass it on. It is never stored in a field.
        # Markup keeps the tags as real HTML; _() alone would escape them and
        # the learner would see literal <br/> in the chatter.
        self.message_post(body=Markup(
            "<p><b>%s</b></p>"
            "<ul><li>%s: <b>%s</b></li>"
            "<li>%s: <b>%s</b></li>"
            "<li>%s: <a href='%s' target='_blank'>%s</a></li></ul>"
            "<p><i>%s</i></p>"
        ) % (
            _("Moodle account created"),
            _("Username"), created.get("username") or username,
            _("Password"), password,
            _("Site"), url, url,
            _("Hand these over now - the password is not stored."),
        ))
        return created.get("id")

    @staticmethod
    def _generate_password():
        """Moodle's default policy: 8+ chars, upper, lower, digit, symbol."""
        alphabet = "abcdefghijkmnopqrstuvwxyz"
        upper = "ABCDEFGHJKLMNPQRSTUVWXYZ"
        digits = "23456789"
        symbols = "!@#$%*"
        pieces = [
            secrets.choice(upper), secrets.choice(digits),
            secrets.choice(symbols),
        ] + [secrets.choice(alphabet) for _ in range(7)]
        secrets.SystemRandom().shuffle(pieces)
        return "".join(pieces)

    # ==================================================================
    def action_create_moodle_user(self):
        instance = self.env["moodle.instance"]._default_instance()
        if not instance:
            raise UserError(_(
                "No connected Moodle site was found. Set one up under "
                "Moodle > Configuration > Moodle Sites."))
        for partner in self:
            partner._ensure_moodle_user(instance)
        return True

    # ------------------------------------------------------------------
    # Profile pictures, both directions
    # ------------------------------------------------------------------
    def _pull_moodle_avatar(self, instance, moodle_user=None, force=False):
        """Copy the Moodle profile picture onto the Odoo contact.

        Skipped when the contact already has an image, unless forced, so a
        photo chosen in Odoo is never silently replaced by a sync.
        """
        self.ensure_one()
        if self.image_1920 and not force:
            return False
        url, token, verify = instance._args()

        if moodle_user is None:
            if not self.moodle_user_id:
                return False
            moodle_user = MoodleAPI.get_user_by_email(
                url, token, (self.email or "").strip().lower(),
                verify_ssl=verify) or {}

        picture = moodle_user.get("profileimageurl")
        if not MoodleAPI.is_real_avatar(picture):
            # Moodle's grey placeholder: not worth storing 200 copies of.
            return False

        image = MoodleAPI.download_avatar(picture, token=token,
                                          verify_ssl=verify)
        if not image:
            return False
        self.sudo().write({"image_1920": image})
        return True

    def _push_avatar_to_moodle(self, instance):
        """Send the Odoo contact photo to Moodle as the profile picture."""
        self.ensure_one()
        if not self.image_1920 or not self.moodle_user_id:
            return False
        url, token, verify = instance._args()
        filename = "%s.png" % (self.moodle_username or self.id)
        try:
            item_id = MoodleAPI.upload_file(url, token, filename,
                                            self.image_1920,
                                            verify_ssl=verify)
            if not item_id:
                return False
            MoodleAPI.set_user_picture(url, token, self.moodle_user_id,
                                       item_id, verify_ssl=verify)
        except MoodleError as err:
            # Not worth failing account creation over a picture.
            self.message_post(body=_("Could not send the profile picture to "
                                     "Moodle: %s")
                              % (err.args[0] if err.args else err))
            return False
        self.message_post(body=_("Profile picture sent to Moodle."))
        return True

    def _connected_instance(self):
        instance = self.env["moodle.instance"].search(
            [("state", "=", "connected")], limit=1)
        if not instance:
            raise UserError(_("No connected Moodle site."))
        return instance

    def action_push_avatar_to_moodle(self):
        instance = self._connected_instance()
        done = sum(1 for p in self if p._push_avatar_to_moodle(instance))
        return self._avatar_notification(
            _("%s picture(s) sent to Moodle.") % done)

    def action_pull_avatar_from_moodle(self):
        instance = self._connected_instance()
        done = sum(1 for p in self.filtered("moodle_user_id")
                   if p._pull_moodle_avatar(instance, force=True))
        return self._avatar_notification(
            _("%s picture(s) copied from Moodle.") % done)

    def _avatar_notification(self, message):
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {"type": "success", "title": _("Profile pictures"),
                       "message": message, "sticky": False},
        }

    def action_open_moodle_enrolments(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Moodle Enrolments"),
            "res_model": "moodle.enrolment",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
        }
