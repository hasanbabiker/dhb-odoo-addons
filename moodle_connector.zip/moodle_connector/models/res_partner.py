# -*- coding: utf-8 -*-

import logging
import re
import secrets
import unicodedata

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .moodle_api import MoodleAPI, MoodleError

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = "res.partner"

    moodle_user_id = fields.Integer("Moodle User ID", readonly=True, copy=False,
                                    index=True)
    moodle_username = fields.Char("Moodle Username", readonly=True, copy=False)
    moodle_enrolment_ids = fields.One2many(
        "moodle.enrolment", "partner_id", string="Moodle Enrolments")
    moodle_enrolment_count = fields.Integer(compute="_compute_moodle_counts")

    @api.depends("moodle_enrolment_ids")
    def _compute_moodle_counts(self):
        for partner in self:
            partner.moodle_enrolment_count = len(
                partner.moodle_enrolment_ids.filtered(
                    lambda e: e.state == "active"))

    # ==================================================================
    @staticmethod
    def _slug(value):
        """Moodle usernames: lowercase, no spaces, limited punctuation."""
        text = unicodedata.normalize("NFKD", value or "")
        text = text.encode("ascii", "ignore").decode()
        text = re.sub(r"[^a-zA-Z0-9._-]+", ".", text).strip(".").lower()
        return text[:80] or "learner"

    def _ensure_moodle_user(self, instance):
        """Return the Moodle user id, creating the account if needed."""
        self.ensure_one()
        if self.moodle_user_id:
            return self.moodle_user_id
        if not self.email:
            raise UserError(_(
                "%s has no email address, so no Moodle account can be created.")
                % self.display_name)

        url, token, verify = instance._args()
        email = self.email.strip().lower()

        # Someone may already exist in Moodle with this address.
        existing = MoodleAPI.get_user_by_email(url, token, email,
                                               verify_ssl=verify)
        if existing and existing.get("id"):
            self.sudo().write({
                "moodle_user_id": existing["id"],
                "moodle_username": existing.get("username"),
            })
            self.message_post(body=_(
                "Linked to the existing Moodle account %s.")
                % existing.get("username"))
            return existing["id"]

        parts = (self.name or "").split()
        first = parts[0] if parts else (self.name or "Learner")
        last = " ".join(parts[1:]) or first
        username = self._slug(email.split("@")[0])
        password = self._generate_password()

        try:
            created = MoodleAPI.create_user(url, token, {
                "username": username,
                "password": password,
                "firstname": first[:100],
                "lastname": last[:100],
                "email": email,
                "auth": "manual",
                "lang": "en",
            }, verify_ssl=verify)
        except MoodleError as err:
            self.message_post(body=_("Moodle account creation failed: %s")
                              % (err.args[0] if err.args else err))
            return False

        self.sudo().write({
            "moodle_user_id": created.get("id"),
            "moodle_username": created.get("username") or username,
        })
        # The password is posted once, in the chatter, so whoever created the
        # account can pass it on. It is never stored in a field.
        self.message_post(body=_(
            "Moodle account created.<br/>Username: <b>%(user)s</b>"
            "<br/>Password: <b>%(pwd)s</b>"
            "<br/>Site: %(url)s"
            "<br/><i>Hand these over now - the password is not stored.</i>",
            user=created.get("username") or username, pwd=password, url=url))
        return created.get("id")

    @staticmethod
    def _generate_password():
        """Moodle's default policy: 8+ chars, upper, lower, digit, symbol."""
        alphabet = "abcdefghijkmnopqrstuvwxyz"
        upper = "ABCDEFGHJKLMNPQRSTUVWXYZ"
        digits = "23456789"
        symbols = "!@#$%*"
        pieces = [
            secrets.choice(upper), secrets.choice(digits),
            secrets.choice(symbols),
        ] + [secrets.choice(alphabet) for _ in range(7)]
        secrets.SystemRandom().shuffle(pieces)
        return "".join(pieces)

    # ==================================================================
    def action_create_moodle_user(self):
        instance = self.env["moodle.instance"]._default_instance()
        if not instance:
            raise UserError(_(
                "No connected Moodle site was found. Set one up under "
                "Moodle > Configuration > Moodle Sites."))
        for partner in self:
            partner._ensure_moodle_user(instance)
        return True

    def action_open_moodle_enrolments(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Moodle Enrolments"),
            "res_model": "moodle.enrolment",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
        }
