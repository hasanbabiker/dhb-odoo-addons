# -*- coding: utf-8 -*-
"""Client for Moodle's REST web services.

Every call goes to ``/webservice/rest/server.php`` with the token in the query
string and ``moodlewsrestformat=json``. Moodle answers HTTP 200 even for
failures, putting the problem in an ``exception`` key, so the status code alone
tells you nothing - the body has to be inspected.
"""

import logging

import requests

from odoo import _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

TIMEOUT = 60
REST_PATH = "/webservice/rest/server.php"

# Web service functions this module needs. Every one of them has to be added to
# the external service in Moodle, otherwise the token is refused per-function.
REQUIRED_FUNCTIONS = [
    "core_webservice_get_site_info",
    "core_course_get_courses",
    "core_course_get_categories",
    "core_course_create_courses",
    "core_course_update_courses",
    "core_user_create_users",
    "core_user_get_users",
    "core_user_get_users_by_field",
    "core_user_update_users",
    "enrol_manual_enrol_users",
    "enrol_manual_unenrol_users",
    "core_enrol_get_enrolled_users",
    "gradereport_user_get_grade_items",
    "core_completion_get_course_completion_status",
]


class MoodleError(UserError):
    """Raised when Moodle answers with an exception payload."""


class MoodleAPI:

    @staticmethod
    def _flatten(data, prefix=""):
        """Moodle expects PHP-style bracket notation, not JSON bodies.

        {"users": [{"id": 3}]} becomes {"users[0][id]": 3}
        """
        out = {}
        if isinstance(data, dict):
            for key, value in data.items():
                name = "%s[%s]" % (prefix, key) if prefix else str(key)
                out.update(MoodleAPI._flatten(value, name))
        elif isinstance(data, (list, tuple)):
            for index, value in enumerate(data):
                out.update(MoodleAPI._flatten(value, "%s[%s]" % (prefix, index)))
        elif isinstance(data, bool):
            out[prefix] = 1 if data else 0
        elif data is not None:
            out[prefix] = data
        return out

    @classmethod
    def call(cls, base_url, token, function, params=None, verify_ssl=True):
        url = "%s%s" % (base_url.rstrip("/"), REST_PATH)
        payload = {
            "wstoken": token,
            "wsfunction": function,
            "moodlewsrestformat": "json",
        }
        payload.update(cls._flatten(params or {}))

        try:
            response = requests.post(url, data=payload, timeout=TIMEOUT,
                                     verify=verify_ssl)
        except requests.exceptions.Timeout:
            raise MoodleError(_("Moodle did not answer within %s seconds.") % TIMEOUT)
        except requests.exceptions.SSLError:
            raise MoodleError(_(
                "The SSL certificate of %s could not be verified. If this is a "
                "test server with a self-signed certificate, untick 'Verify "
                "SSL' on the connection.") % base_url)
        except requests.exceptions.RequestException as err:
            raise MoodleError(_("Could not reach Moodle: %s") % err)

        if response.status_code >= 400:
            raise MoodleError(_(
                "Moodle returned HTTP %(code)s for %(fn)s.",
                code=response.status_code, fn=function))
        try:
            body = response.json()
        except ValueError:
            snippet = (response.text or "")[:200]
            raise MoodleError(_(
                "Moodle returned a non-JSON reply for %(fn)s. This usually "
                "means web services are off or the URL is wrong.\n%(snippet)s",
                fn=function, snippet=snippet))

        # Moodle reports failures inside a 200 response.
        if isinstance(body, dict) and body.get("exception"):
            code = body.get("errorcode", "")
            message = body.get("message", "")
            if code == "invalidtoken":
                raise MoodleError(_(
                    "Moodle rejected the token. Check that it belongs to an "
                    "active external service and has not expired."))
            if code == "accessexception":
                raise MoodleError(_(
                    "The token is valid but %(fn)s is not allowed. Add that "
                    "function to the external service in Moodle.", fn=function))
            raise MoodleError(_(
                "Moodle error on %(fn)s: %(code)s - %(message)s",
                fn=function, code=code, message=message))
        return body

    # ------------------------------------------------------------------
    # site
    # ------------------------------------------------------------------
    @classmethod
    def site_info(cls, base_url, token, verify_ssl=True):
        return cls.call(base_url, token, "core_webservice_get_site_info",
                        verify_ssl=verify_ssl)

    # ------------------------------------------------------------------
    # courses
    # ------------------------------------------------------------------
    @classmethod
    def get_courses(cls, base_url, token, verify_ssl=True):
        return cls.call(base_url, token, "core_course_get_courses",
                        verify_ssl=verify_ssl) or []

    @classmethod
    def get_categories(cls, base_url, token, verify_ssl=True):
        return cls.call(base_url, token, "core_course_get_categories",
                        verify_ssl=verify_ssl) or []

    @classmethod
    def create_course(cls, base_url, token, values, verify_ssl=True):
        result = cls.call(base_url, token, "core_course_create_courses",
                          {"courses": [values]}, verify_ssl=verify_ssl)
        return (result or [{}])[0]

    @classmethod
    def update_course(cls, base_url, token, values, verify_ssl=True):
        return cls.call(base_url, token, "core_course_update_courses",
                        {"courses": [values]}, verify_ssl=verify_ssl)

    # ------------------------------------------------------------------
    # users
    # ------------------------------------------------------------------
    @classmethod
    def create_user(cls, base_url, token, values, verify_ssl=True):
        result = cls.call(base_url, token, "core_user_create_users",
                          {"users": [values]}, verify_ssl=verify_ssl)
        return (result or [{}])[0]

    @classmethod
    def update_user(cls, base_url, token, values, verify_ssl=True):
        return cls.call(base_url, token, "core_user_update_users",
                        {"users": [values]}, verify_ssl=verify_ssl)

    @classmethod
    def get_user_by_email(cls, base_url, token, email, verify_ssl=True):
        result = cls.call(
            base_url, token, "core_user_get_users_by_field",
            {"field": "email", "values": [email]}, verify_ssl=verify_ssl)
        return (result or [None])[0]

    # ------------------------------------------------------------------
    # enrolment
    # ------------------------------------------------------------------
    @classmethod
    def enrol(cls, base_url, token, user_id, course_id, role_id=5,
              verify_ssl=True):
        """role_id 5 is the stock 'student' role on a default Moodle."""
        return cls.call(
            base_url, token, "enrol_manual_enrol_users",
            {"enrolments": [{
                "roleid": role_id,
                "userid": user_id,
                "courseid": course_id,
            }]}, verify_ssl=verify_ssl)

    @classmethod
    def unenrol(cls, base_url, token, user_id, course_id, verify_ssl=True):
        return cls.call(
            base_url, token, "enrol_manual_unenrol_users",
            {"enrolments": [{"userid": user_id, "courseid": course_id}]},
            verify_ssl=verify_ssl)

    @classmethod
    def enrolled_users(cls, base_url, token, course_id, verify_ssl=True):
        return cls.call(base_url, token, "core_enrol_get_enrolled_users",
                        {"courseid": course_id}, verify_ssl=verify_ssl) or []

    # ------------------------------------------------------------------
    # results
    # ------------------------------------------------------------------
    @classmethod
    def grades(cls, base_url, token, course_id, user_id=None, verify_ssl=True):
        params = {"courseid": course_id}
        if user_id:
            params["userid"] = user_id
        body = cls.call(base_url, token, "gradereport_user_get_grade_items",
                        params, verify_ssl=verify_ssl) or {}
        return body.get("usergrades") or []

    @classmethod
    def completion(cls, base_url, token, course_id, user_id, verify_ssl=True):
        body = cls.call(
            base_url, token, "core_completion_get_course_completion_status",
            {"courseid": course_id, "userid": user_id}, verify_ssl=verify_ssl)
        return (body or {}).get("completionstatus") or {}
