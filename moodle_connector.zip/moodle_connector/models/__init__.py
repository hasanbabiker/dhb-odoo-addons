# -*- coding: utf-8 -*-
from . import moodle_api
from . import moodle_instance
from . import moodle_course
from . import moodle_enrolment
from . import res_partner
from . import res_config_settings
