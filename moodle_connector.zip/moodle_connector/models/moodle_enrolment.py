# -*- coding: utf-8 -*-

import logging
from datetime import datetime

from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .moodle_api import MoodleAPI, MoodleError

_logger = logging.getLogger(__name__)


class MoodleEnrolment(models.Model):
    _name = "moodle.enrolment"
    _description = "Moodle Enrolment"
    _order = "course_id, partner_name"
    _rec_name = "partner_name"

    course_id = fields.Many2one(
        "moodle.course", string="Course", required=True,
        ondelete="cascade", index=True)
    instance_id = fields.Many2one(
        related="course_id.instance_id", store=True, index=True)
    company_id = fields.Many2one(related="course_id.company_id", store=True)

    partner_id = fields.Many2one("res.partner", string="Contact", index=True)
    partner_name = fields.Char("Learner", required=True)
    email = fields.Char()
    moodle_user_id = fields.Integer("Moodle User ID", index=True)
    role = fields.Char(default="Student")

    enrolled_on = fields.Datetime(readonly=True)
    last_access = fields.Datetime("Last Access", readonly=True)
    grade = fields.Float(digits=(16, 2), readonly=True)
    grade_max = fields.Float("Out Of", digits=(16, 2), readonly=True)
    completion_percent = fields.Float("Completion %", digits=(16, 1), readonly=True)
    completed = fields.Boolean(compute="_compute_completed", store=True)

    state = fields.Selection(
        [("active", "Enrolled"), ("removed", "Unenrolled")],
        default="active", readonly=True)

    _sql_constraints = [
        ("enrolment_uniq", "unique(course_id, moodle_user_id)",
         "This learner is already enrolled on that course."),
    ]

    @api.depends("completion_percent")
    def _compute_completed(self):
        for record in self:
            record.completed = record.completion_percent >= 100

    # ==================================================================
    # Moodle -> Odoo
    # ==================================================================
    @api.model
    def _pull_for_course(self, course):
        url, token, verify = course.instance_id._args()
        users = MoodleAPI.enrolled_users(url, token, course.moodle_id,
                                         verify_ssl=verify)

        # Grades come back for the whole course in one call, so fetch once.
        grades_by_user = {}
        try:
            for entry in MoodleAPI.grades(url, token, course.moodle_id,
                                          verify_ssl=verify):
                total = next(
                    (item for item in entry.get("gradeitems") or []
                     if item.get("itemtype") == "course"), None)
                if total:
                    grades_by_user[entry.get("userid")] = (
                        total.get("graderaw") or 0.0,
                        total.get("grademax") or 0.0,
                    )
        except MoodleError as err:
            _logger.info("Moodle: grades unavailable for %s (%s)",
                         course.display_name, err)

        Partner = self.env["res.partner"]
        existing = {e.moodle_user_id: e for e in course.enrolment_ids}
        seen = set()

        for user in users:
            moodle_user_id = user.get("id")
            if not moodle_user_id:
                continue
            seen.add(moodle_user_id)
            email = (user.get("email") or "").strip().lower()
            partner = Partner.search(
                [("email", "=ilike", email)], limit=1) if email else Partner
            grade, grade_max = grades_by_user.get(moodle_user_id, (0.0, 0.0))

            values = {
                "course_id": course.id,
                "moodle_user_id": moodle_user_id,
                "partner_id": partner.id or False,
                "partner_name": user.get("fullname") or email or _("Learner"),
                "email": email or False,
                "role": ", ".join(
                    r.get("shortname", "") for r in user.get("roles") or []
                ) or "student",
                "last_access": self._epoch_to_datetime(user.get("lastaccess")),
                "grade": grade,
                "grade_max": grade_max,
                "state": "active",
            }
            values["completion_percent"] = self._completion_percent(
                course, moodle_user_id)

            record = existing.get(moodle_user_id)
            if record:
                record.write(values)
            else:
                values["enrolled_on"] = fields.Datetime.now()
                self.create(values)

        # Anyone who disappeared from Moodle was unenrolled there.
        gone = course.enrolment_ids.filtered(
            lambda e: e.moodle_user_id not in seen and e.state == "active")
        gone.write({"state": "removed"})
        return len(users)

    @api.model
    def _completion_percent(self, course, moodle_user_id):
        url, token, verify = course.instance_id._args()
        try:
            status = MoodleAPI.completion(url, token, course.moodle_id,
                                          moodle_user_id, verify_ssl=verify)
        except MoodleError:
            # Completion tracking is off on many courses; not an error.
            return 0.0
        if status.get("completed"):
            return 100.0
        criteria = status.get("completions") or []
        if not criteria:
            return 0.0
        done = len([c for c in criteria if c.get("complete")])
        return round(done / len(criteria) * 100.0, 1)

    @staticmethod
    def _epoch_to_datetime(value):
        if not value:
            return False
        try:
            return datetime.utcfromtimestamp(int(value))
        except (ValueError, OSError):
            return False

    # ==================================================================
    # Odoo -> Moodle
    # ==================================================================
    def action_unenrol(self):
        for record in self:
            url, token, verify = record.course_id.instance_id._args()
            MoodleAPI.unenrol(url, token, record.moodle_user_id,
                              record.course_id.moodle_id, verify_ssl=verify)
            record.state = "removed"
            record.course_id.message_post(body=_(
                "%s was unenrolled from Moodle.") % record.partner_name)
        return True

    def action_reenrol(self):
        for record in self:
            course = record.course_id
            url, token, verify = course.instance_id._args()
            MoodleAPI.enrol(url, token, record.moodle_user_id,
                            course.moodle_id,
                            role_id=course.instance_id.student_role_id,
                            verify_ssl=verify)
            record.state = "active"
        return True

    def action_open_partner(self):
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_(
                "%s is not matched to an Odoo contact. Matching is by email "
                "address, so check the address on both sides.")
                % self.partner_name)
        return {
            "type": "ir.actions.act_window",
            "res_model": "res.partner",
            "res_id": self.partner_id.id,
            "view_mode": "form",
        }


class MoodleEnrolWizard(models.TransientModel):
    _name = "moodle.enrol.wizard"
    _description = "Enrol Learners on a Moodle Course"

    course_id = fields.Many2one("moodle.course", required=True)
    partner_ids = fields.Many2many(
        "res.partner", string="Learners", required=True,
        domain=[("email", "!=", False)])
    create_accounts = fields.Boolean(
        "Create missing Moodle accounts", default=True,
        help="Contacts without a Moodle account get one created, and the "
             "credentials are logged on their contact form.")

    def action_enrol(self):
        self.ensure_one()
        course = self.course_id
        instance = course.instance_id
        if not course.moodle_id:
            raise UserError(_("Push this course to Moodle first."))

        url, token, verify = instance._args()
        enrolled, skipped = [], []
        for partner in self.partner_ids:
            moodle_user_id = partner.moodle_user_id
            if not moodle_user_id:
                if not self.create_accounts:
                    skipped.append(partner.display_name)
                    continue
                moodle_user_id = partner._ensure_moodle_user(instance)
                if not moodle_user_id:
                    skipped.append(partner.display_name)
                    continue
            try:
                MoodleAPI.enrol(url, token, moodle_user_id, course.moodle_id,
                                role_id=instance.student_role_id,
                                verify_ssl=verify)
                enrolled.append(partner.display_name)
            except MoodleError as err:
                skipped.append("%s (%s)" % (
                    partner.display_name, err.args[0] if err.args else err))

        course.action_sync_enrolments()
        body = Markup("<p>%s: %s</p>") % (
            _("Enrolled"), ", ".join(enrolled) or _("none"))
        if skipped:
            body += Markup("<p>%s: %s</p>") % (_("Skipped"), ", ".join(skipped))
        course.message_post(body=body)
        return {"type": "ir.actions.act_window_close"}
