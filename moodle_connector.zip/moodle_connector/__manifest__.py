# -*- coding: utf-8 -*-
{
    "name": "Moodle Connector",
    "version": "19.0.1.1.1",
    "category": "Services/Training",
    "summary": "Two-way sync between Odoo and Moodle: learners, courses, "
               "enrolments, grades and completion.",
    "description": """
Moodle Connector for Odoo
=========================

Connects Odoo to a Moodle site through Moodle's REST web services.

Odoo -> Moodle
    * Create a Moodle account for a contact, with credentials to hand over.
    * Enrol and unenrol learners on a course.
    * Create and update courses.

Moodle -> Odoo
    * Pull the course catalogue with categories, dates and visibility.
    * Pull enrolled users, their last access, grade and completion percentage.
    * Match Moodle users back to Odoo contacts by email.

Moodle has no outbound webhooks in core, so the Moodle-to-Odoo direction runs
on a scheduled job rather than in real time. The interval is configurable.
""",
    "author": "",
    "website": "",
    "license": "LGPL-3",
    "depends": ["base", "mail", "contacts"],
    "external_dependencies": {"python": ["requests"]},
    "data": [
        "security/moodle_security.xml",
        "security/ir.model.access.csv",
        "data/ir_cron.xml",
        "views/moodle_enrolment_views.xml",
        "views/moodle_course_views.xml",
        "views/moodle_instance_views.xml",
        "views/res_partner_views.xml",
        "data/avatar_actions.xml",
        "views/res_config_settings_views.xml",
        "views/moodle_menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
