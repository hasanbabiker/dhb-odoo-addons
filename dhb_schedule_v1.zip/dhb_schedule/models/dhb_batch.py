import base64
import io

from odoo import models, fields, api, _
from odoo.exceptions import UserError

from .schedule_time import (
    format_local, format_meeting_id, to_uk,
)

# NEBOSH's own eleven columns, in NEBOSH's own order. The double space in
# "Meeting  Passcode" is in their file and is reproduced deliberately: a
# Learning Partner's submission should differ from the form they sent in no
# respect at all, including the ones that look like typing mistakes.
HEADERS = [
    "Dates (start - finish)",
    "Qualification & Language",
    "Start Time (including time zone)",
    "UK Start Time ({dst})",
    "Finish Time (including time zone)",
    "UK Finish Time ({dst})",
    "Tutor Name(s)",
    "Mode of Study & Platform",
    "Link",
    "Meeting ID",
    "Meeting  Passcode",
]

COL_WIDTHS = [20, 30, 18, 15, 18, 15, 25, 18, 22, 32, 21.83]


class DhbBatch(models.Model):
    """The batch as one row of the schedule NEBOSH is sent every month.

    A row of that form is a *delivery*, not a course: IGC Arabic in October
    and IGC Arabic in November are two rows and one course. So the row is
    built here, on the batch, and the file is several batches printed
    together.
    """

    _inherit = "dhb.batch"

    # ------------------------------------------------------------------
    # The class timetable. Held as a time of day rather than a datetime,
    # because it is the same every teaching day and a datetime would have to
    # be repeated per lecture to say one thing.
    session_start = fields.Float(
        string="Class starts", help="Local time, in the batch's own time "
                                    "zone. 19.0 is 7:00 PM.")
    session_end = fields.Float(string="Class ends")

    platform = fields.Char(
        string="Platform", default="Zoom",
        help="Zoom, Teams, or the venue and city for a classroom course.")
    join_url = fields.Char(
        string="Join link",
        help="The recurring meeting's link, as Zoom gives it - including "
             "the ?pwd= part. Never typed by hand.")
    meeting_id = fields.Char(string="Meeting ID")
    meeting_passcode = fields.Char(
        string="Passcode",
        help="The numeric code learners type. It is not the ?pwd= value in "
             "the link, which is an encrypted token.")

    # Computed for the screen; the report builds its own from the same
    # helpers so a printed file never depends on what a form happened to
    # have cached.
    uk_session_start = fields.Char(
        string="UK start", compute="_compute_uk_times")
    uk_session_end = fields.Char(
        string="UK finish", compute="_compute_uk_times")
    uk_dst_label = fields.Char(compute="_compute_uk_times")
    schedule_ready = fields.Boolean(compute="_compute_schedule_ready")
    schedule_missing = fields.Char(compute="_compute_schedule_ready")

    @api.depends("session_start", "session_end", "date_begin", "date_tz")
    def _compute_uk_times(self):
        for batch in self:
            if not batch.date_begin:
                batch.uk_session_start = False
                batch.uk_session_end = False
                batch.uk_dst_label = False
                continue
            on_date = fields.Datetime.context_timestamp(
                batch, batch.date_begin).date()
            start, label = to_uk(
                batch.session_start, batch.date_tz, on_date)
            end, _label = to_uk(batch.session_end, batch.date_tz, on_date)
            batch.uk_session_start = start
            batch.uk_session_end = end
            batch.uk_dst_label = label

    def _schedule_missing(self):
        """What the NEBOSH row still has no value for.

        Written as names, like everything else in this system, because
        "incomplete" tells nobody which cell to go and fill in.
        """
        self.ensure_one()
        missing = []
        if not self.session_start and not self.session_end:
            missing.append(_("Class times"))
        # Asked for only where a tutor field exists at all. This module does
        # not depend on the Tutors app, and a schedule built without it
        # falls back to the coordinator's name rather than pretending a
        # field is empty that was never there.
        tutor_fields = [name for name in ("tutor_id", "tutor_ids")
                        if name in self._fields]
        if tutor_fields and not any(self[name] for name in tutor_fields):
            missing.append(_("Tutor"))
        if self.delivery_mode != "elearning":
            if not self.join_url:
                missing.append(_("Join link"))
            if not self.meeting_id:
                missing.append(_("Meeting ID"))
            if not self.meeting_passcode:
                missing.append(_("Passcode"))
        return missing

    @api.depends("session_start", "session_end", "join_url", "meeting_id",
                 "meeting_passcode", "delivery_mode")
    def _compute_schedule_ready(self):
        for batch in self:
            missing = batch._schedule_missing()
            batch.schedule_ready = not missing
            batch.schedule_missing = ", ".join(missing) or False

    def _batch_blockers(self):
        """A batch NEBOSH has not been told about is a batch at risk.

        Only once it is open or running - a cohort still being planned has
        nothing to notify yet.
        """
        items = super()._batch_blockers()
        if self.state in ("open", "running"):
            missing = self._schedule_missing()
            if missing:
                items.append({
                    "label": _("missing for the NEBOSH schedule (%s)")
                    % ", ".join(missing),
                    "count": len(missing),
                })
        return items

    # ------------------------------------------------------------------
    def _tutor_names(self):
        """Whoever this module can see. The Tutors app supplies the field;
        without it the coordinator's name is the honest answer."""
        self.ensure_one()
        if "tutor_ids" in self._fields and self.tutor_ids:
            return ", ".join(self.tutor_ids.mapped("name"))
        if "tutor_id" in self._fields and self.tutor_id:
            return self.tutor_id.name
        return self.user_id.name or _("TBC")

    def _schedule_row(self):
        """One row of the NEBOSH form, as a list of eleven strings."""
        self.ensure_one()
        begin = fields.Datetime.context_timestamp(self, self.date_begin) \
            if self.date_begin else False
        end = fields.Datetime.context_timestamp(self, self.date_end) \
            if self.date_end else False
        if not begin:
            raise UserError(_(
                "%s has no start date, so it cannot go on a schedule.")
                % self.display_name)
        # NEBOSH accepts TBC for a finish date that is not yet fixed, and
        # prefers it to a date invented to fill the cell.
        dates = "%s - %s" % (
            begin.strftime("%d %B %Y"),
            end.strftime("%d %B %Y") if end else "TBC")

        course = self.course_id
        qualification = course.name if course else (self.name or "")
        language = dict(self._fields["delivery_language"].selection).get(
            self.delivery_language, "")
        qual_cell = "%s\n%s" % (qualification, language) if language \
            else qualification

        mode = dict(self._fields["delivery_mode"].selection).get(
            self.delivery_mode, "")
        # The form wants the short word, not our explanatory label.
        mode = mode.split(" (")[0]
        mode_cell = "%s\n%s" % (mode, self.platform) if self.platform \
            else mode

        on_date = begin.date()
        uk_start, label = to_uk(self.session_start, self.date_tz, on_date)
        uk_end, _l = to_uk(self.session_end, self.date_tz, on_date)

        return [
            dates,
            qual_cell,
            format_local(self.session_start, self.date_tz),
            uk_start,
            format_local(self.session_end, self.date_tz),
            uk_end,
            self._tutor_names(),
            mode_cell,
            self.join_url or "",
            format_meeting_id(self.meeting_id),
            self.meeting_passcode or "",
        ], label

    def _schedule_rows(self):
        rows, labels = [], set()
        for batch in self.sorted("date_begin"):
            row, label = batch._schedule_row()
            rows.append(row)
            labels.add(label)
        # A file that straddles a clock change cannot label its UK columns
        # with one of them without mislabelling half the rows.
        return rows, (labels.pop() if len(labels) == 1 else "GMT/BST")

    # ------------------------------------------------------------------
    def action_export_schedule_xlsx(self):
        """Build NEBOSH's own workbook and hand it back as a download."""
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

        if not self:
            raise UserError(_("Pick the batches to put on the schedule."))
        rows, dst = self._schedule_rows()

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Schedule"

        header_font = Font(name="Arial", size=11, bold=True)
        body_font = Font(name="Arial", size=11)
        fill = PatternFill("solid", fgColor="D9D9D9")
        centre = Alignment(
            horizontal="center", vertical="center", wrap_text=True)
        thin = Side(style="thin")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)

        sheet.append([h.format(dst=dst) for h in HEADERS])
        for cell in sheet[1]:
            cell.font = header_font
            cell.fill = fill
            cell.alignment = centre
            cell.border = border
        sheet.row_dimensions[1].height = 45

        for index, row in enumerate(rows, start=2):
            sheet.append(row)
            for cell in sheet[index]:
                cell.font = body_font
                cell.alignment = centre
                cell.border = border
            sheet.row_dimensions[index].height = 55

        for column, width in enumerate(COL_WIDTHS, start=1):
            sheet.column_dimensions[
                sheet.cell(row=1, column=column).column_letter].width = width
        sheet.freeze_panes = "A2"

        stream = io.BytesIO()
        workbook.save(stream)

        first = self.sorted("date_begin")[0]
        when = fields.Datetime.context_timestamp(first, first.date_begin)
        name = "DHB_NEBOSH_Training_Schedule_%s.xlsx" % when.strftime("%b_%Y")
        attachment = self.env["ir.attachment"].create({
            "name": name,
            "type": "binary",
            "datas": base64.b64encode(stream.getvalue()),
            "mimetype": "application/vnd.openxmlformats-officedocument."
                        "spreadsheetml.sheet",
        })
        return {
            "type": "ir.actions.act_url",
            "url": "/web/content/%s?download=true" % attachment.id,
            "target": "self",
        }

    @api.model
    def _schedule_headers(self, dst):
        return [h.format(dst=dst) for h in HEADERS]


class DhbBatchCourseDefaults(models.Model):
    """Carry the course's usual times onto a new batch.

    Written as an extension of the existing hook rather than a new onchange,
    which is what lets six modules each add their own fields to one press of
    "Create the batch" without any of them knowing the others exist.
    """

    _inherit = "dhb.batch"

    def _apply_course_defaults(self):
        super()._apply_course_defaults()
        for batch in self:
            course = batch.course_id
            if not course:
                continue
            if course.session_start and not batch.session_start:
                batch.session_start = course.session_start
            if course.session_end and not batch.session_end:
                batch.session_end = course.session_end
            if course.platform and not batch.platform:
                batch.platform = course.platform
