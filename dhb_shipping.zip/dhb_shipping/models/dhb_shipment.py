"""A parcel leaving the centre, whatever is in it.

This module deliberately does not know what a certificate is. A shipment
carries a recipient, an address, a weight, a carrier and a tracking number,
and it points back at whatever caused it through a model name and an id -
so the day the centre posts learner packs, printed materials or ID cards,
nothing here has to be touched.

The direction of the dependency is the point. Certificates knows that it
ships things; Shipping does not know what a certificate is.
"""

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbShipment(models.Model):
    _name = "dhb.shipment"
    _description = "Shipment"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_ready desc, id desc"

    name = fields.Char(
        string="Reference", required=True, copy=False, readonly=True,
        default=lambda self: _("New"))
    active = fields.Boolean(default=True)

    # ------------------------------------------------------------------
    # Who it goes to. The address is read from the contact rather than
    # copied onto the shipment: a second copy of an address is a second
    # address to keep in step, and the one that gets updated is never the
    # one the courier was given.
    partner_id = fields.Many2one(
        "res.partner", string="Recipient", required=True, index=True,
        tracking=True, ondelete="restrict")
    destination = fields.Char(
        compute="_compute_destination", string="Going to", store=True)
    # Stored, and that is not an optimisation.
    #
    # "Address incomplete" has to be a filter and a facet - a warning
    # nobody can search for is a warning nobody finds. A domain against a
    # non-stored computed field is not a slow query; Odoo refuses to load
    # the view at all, which fails the install.
    #
    # Storage is safe here because nothing in the computation is
    # time-based: it reads four fields on the contact and nothing else, so
    # it recomputes exactly when one of them changes and is never stale.
    address_ready = fields.Boolean(
        compute="_compute_address_ready", store=True)
    address_missing = fields.Char(
        compute="_compute_address_ready", store=True)

    # What caused it, without knowing what that is.
    res_model = fields.Char(string="Related model", index=True, readonly=True)
    res_id = fields.Integer(string="Related id", index=True, readonly=True)
    origin = fields.Char(
        string="Related to", readonly=True,
        help="What this parcel was raised for, in words.")

    contents = fields.Char(
        string="Contents", default="Documents", required=True,
        help="What the courier is told is in the envelope.")
    weight_kg = fields.Float(string="Weight (kg)", default=0.5)
    pieces = fields.Integer(string="Pieces", default=1)

    # ------------------------------------------------------------------
    carrier_id = fields.Many2one(
        "dhb.shipping.carrier", string="Carrier", tracking=True,
        ondelete="restrict")
    integration = fields.Selection(
        related="carrier_id.integration", readonly=True)
    service = fields.Char(string="Service")
    tracking_ref = fields.Char(string="Tracking number", tracking=True,
                               copy=False, index="trigram")
    tracking_url = fields.Char(compute="_compute_tracking_url")
    label_url = fields.Char(string="Label", readonly=True, copy=False)

    cost = fields.Monetary(string="Shipping cost", tracking=True)
    currency_id = fields.Many2one(
        "res.currency", required=True,
        default=lambda self: self.env.company.currency_id)

    # ------------------------------------------------------------------
    # The seven states a parcel really passes through, plus the four ways
    # it fails. They are not decoration: each one is a different thing for
    # the office to do, and collapsing them is how "it was posted weeks
    # ago" becomes an answer nobody can check.
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("ready", "Ready to ship"),
            ("scheduled", "Pickup scheduled"),
            ("picked_up", "Picked up"),
            ("in_transit", "In transit"),
            ("out_for_delivery", "Out for delivery"),
            ("delivered", "Delivered"),
            ("failed", "Delivery failed"),
            ("returned", "Returned"),
            ("lost", "Lost"),
            ("cancelled", "Cancelled"),
        ],
        default="draft", required=True, index=True, tracking=True,
        group_expand="_group_expand_state",
    )

    date_ready = fields.Date(
        string="Ready on", default=fields.Date.context_today, tracking=True)
    date_shipped = fields.Date(string="Shipped on", readonly=True,
                               copy=False, tracking=True)
    date_delivered = fields.Date(string="Delivered on", readonly=True,
                                 copy=False, tracking=True)
    received_by = fields.Char(
        string="Received by",
        help="Who signed for it, when that is not the recipient.")

    last_status = fields.Char(string="Last carrier update", readonly=True,
                              copy=False)
    last_polled = fields.Datetime(string="Last checked", readonly=True,
                                  copy=False)
    days_out = fields.Integer(compute="_compute_days_out", string="Days out")

    note = fields.Text(string="Internal notes")

    _unique_reference = models.Constraint(
        "unique(name)", "That shipment reference is already used.")

    # ==================================================================
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "dhb.shipment") or _("New")
        return super().create(vals_list)

    @api.model
    def _group_expand_state(self, states, domain):
        # Only the live part of the pipeline is forced open. Delivered and
        # the four failures appear when something is in them - a board that
        # always shows eleven columns is a board nobody can read.
        return ["draft", "ready", "scheduled", "picked_up", "in_transit",
                "out_for_delivery"]

    @api.depends("partner_id.city", "partner_id.country_id")
    def _compute_destination(self):
        for shipment in self:
            partner = shipment.partner_id
            parts = [partner.city, partner.country_id.name]
            shipment.destination = ", ".join(p for p in parts if p) or False

    # No partner_id.mobile here. Odoo 18 folded res.partner.mobile into
    # phone, and naming a field that no longer exists does not degrade - it
    # refuses to build the registry, which fails the install.
    @api.depends("partner_id.street", "partner_id.city",
                 "partner_id.country_id", "partner_id.phone")
    def _compute_address_ready(self):
        """Checked here, before the courier refuses it.

        Every carrier rejects an incomplete address, and every one of them
        does it with a numeric code that arrives after the booking call.
        Saying "no city on Ahmed Ali" before the call is the difference
        between a fix and an investigation.
        """
        for shipment in self:
            partner = shipment.partner_id
            missing = []
            if not partner.street:
                missing.append(_("street"))
            if not partner.city:
                missing.append(_("city"))
            if not partner.country_id:
                missing.append(_("country"))
            if not partner.phone:
                missing.append(_("phone number"))
            shipment.address_missing = ", ".join(missing) or False
            shipment.address_ready = not missing

    @api.depends("carrier_id", "tracking_ref")
    def _compute_tracking_url(self):
        for shipment in self:
            shipment.tracking_url = shipment.carrier_id.build_tracking_url(
                shipment.tracking_ref) if shipment.carrier_id else False

    @api.depends("state", "date_shipped")
    def _compute_days_out(self):
        today = fields.Date.context_today(self)
        for shipment in self:
            shipment.days_out = (today - shipment.date_shipped).days \
                if shipment.date_shipped and shipment.state not in (
                    "delivered", "returned", "cancelled") else 0

    @api.depends("name", "partner_id")
    def _compute_display_name(self):
        for shipment in self:
            shipment.display_name = "%s - %s" % (
                shipment.name, shipment.partner_id.display_name or "")

    # ==================================================================
    def action_open_related(self):
        """Back to whatever caused this parcel, without knowing what it is."""
        self.ensure_one()
        if not self.res_model or not self.res_id:
            raise UserError(_("This shipment is not linked to anything."))
        return {
            "type": "ir.actions.act_window",
            "res_model": self.res_model,
            "res_id": self.res_id,
            "view_mode": "form",
        }

    def _require_address(self):
        for shipment in self:
            if not shipment.address_ready:
                raise UserError(_(
                    "%(name)s has no %(missing)s on their contact record, "
                    "and no carrier will accept a shipment without it.",
                    name=shipment.partner_id.display_name,
                    missing=shipment.address_missing))

    def action_ready(self):
        self._require_address()
        for shipment in self:
            if not shipment.carrier_id:
                raise UserError(_("Choose a carrier first."))
        self.write({"state": "ready"})

    def action_schedule_pickup(self):
        self.write({"state": "scheduled"})

    def action_picked_up(self):
        for shipment in self:
            shipment.write({
                "state": "picked_up",
                "date_shipped": shipment.date_shipped or
                                fields.Date.context_today(shipment),
            })

    def action_in_transit(self):
        self.write({"state": "in_transit"})

    def action_out_for_delivery(self):
        self.write({"state": "out_for_delivery"})

    def action_delivered(self):
        for shipment in self:
            shipment.write({
                "state": "delivered",
                "date_delivered": shipment.date_delivered or
                                  fields.Date.context_today(shipment),
            })

    def action_failed(self):
        self.write({"state": "failed"})

    def action_returned(self):
        self.write({"state": "returned"})

    def action_lost(self):
        self.write({"state": "lost"})

    def action_cancel(self):
        for shipment in self:
            if shipment.tracking_ref:
                raise UserError(_(
                    "%s already has a tracking number, so the carrier has "
                    "it. Cancel it with the carrier first, then mark this "
                    "returned or lost - cancelling here would leave a real "
                    "parcel with no record.") % shipment.name)
        self.write({"state": "cancelled"})

    def action_back_to_draft(self):
        self.write({"state": "draft"})

    # ==================================================================
    # The carrier-specific part, and the only place it exists.
    def action_book(self):
        """Ask the carrier for an airway bill, if it is one we can ask."""
        self.ensure_one()
        if self.tracking_ref:
            raise UserError(_(
                "%(name)s already has tracking number %(ref)s. Booking again "
                "would put a second courier on the same envelope.",
                name=self.name, ref=self.tracking_ref))
        self._require_address()
        if self.integration == "aramex":
            self.env["dhb.aramex.api"].book(self)
        else:
            raise UserError(_(
                "%s is a manual carrier, so there is nothing to book from "
                "here. Enter the tracking number the courier gives you.")
                % self.carrier_id.display_name)

    def action_track(self):
        """Ask the carrier where it is."""
        tracked = self.filtered(
            lambda s: s.tracking_ref and s.integration == "aramex")
        if not tracked:
            raise UserError(_(
                "Nothing here can be tracked automatically. A manual "
                "carrier's tracking link is on the shipment."))
        self.env["dhb.aramex.api"].track(tracked)

    @api.model
    def _cron_track(self):
        """Follow the parcels that are still out."""
        out = self.search([
            ("state", "in", ("picked_up", "in_transit", "out_for_delivery",
                             "ready", "scheduled")),
            ("tracking_ref", "!=", False),
            ("carrier_id.integration", "=", "aramex"),
        ])
        for index in range(0, len(out), 30):
            self.env["dhb.aramex.api"].track(
                out[index:index + 30], raise_on_error=False)
