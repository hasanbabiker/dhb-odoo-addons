import logging

from odoo import models, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

MODE_PARAM = "dhb_mail_guard.mode"
ADDRESS_PARAM = "dhb_mail_guard.test_address"


class IrMailServer(models.Model):
    """Redirect every outgoing message while the system is under test.

    This is the only override in the module, and it is on purpose. Odoo has
    several ways to send a message - the queue and its cron, send_mail with
    force_send, a template sent straight from a button, a notification to a
    document's followers - but all of them end at ir.mail_server.send_email.
    Guarding anything higher up would leave a path open, and the path left
    open is the one that reaches a learner.
    """

    _inherit = "ir.mail_server"

    @api.model
    def _dhb_guard_settings(self):
        params = self.env["ir.config_parameter"].sudo()
        mode = (params.get_param(MODE_PARAM) or "redirect").strip().lower()
        address = (params.get_param(ADDRESS_PARAM) or "").strip()
        return mode, address

    def send_email(self, message, *args, **kwargs):
        mode, address = self._dhb_guard_settings()
        if mode == "live":
            return super().send_email(message, *args, **kwargs)

        original = ", ".join(
            part for part in (
                message.get("To"), message.get("Cc"), message.get("Bcc"),
            ) if part
        )

        if not address:
            # Refusing loudly is the right failure. Falling back to sending
            # the message as addressed would defeat the whole module at the
            # exact moment it is needed.
            raise UserError(_(
                "Mail is in test mode but no test address is set, so this "
                "message has not been sent.\n\n"
                "Set dhb_mail_guard.test_address under Settings > Technical "
                "> System Parameters, or set dhb_mail_guard.mode to \"live\" "
                "when the system is ready to write to learners."
            ))

        for header in ("To", "Cc", "Bcc"):
            if header in message:
                del message[header]
        message["To"] = address

        message["X-DHB-Mail-Guard"] = "redirected"
        message["X-DHB-Original-Recipients"] = original or "(none)"

        subject = message.get("Subject") or ""
        if "Subject" in message:
            del message["Subject"]
        message["Subject"] = "[TEST -> %s] %s" % (original or "?", subject)

        _logger.info(
            "dhb_mail_guard: redirected a message to %s (would have gone to "
            "%s)", address, original or "(none)",
        )
        return super().send_email(message, *args, **kwargs)
