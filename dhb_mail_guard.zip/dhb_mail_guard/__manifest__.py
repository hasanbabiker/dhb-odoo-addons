{
    "name": "DHB Mail Guard",
    "version": "19.0.1.1.0",
    "summary": "While the system is being tested, every outgoing email goes "
               "to one address you choose - never to a learner or a tutor",
    "description": """
DHB Mail Guard
==============

A training database is full of real people. Real learners, real tutors, real
email addresses. Testing the system means pressing the buttons that send
them mail - and on 18 September 2026 that is exactly what happened: a queue
of messages that had been stuck for months went out to tutors the moment the
mail server started working.

Turning mail off stops that, but then the mail cannot be tested at all. So
this does something better: it lets every message be built, queued and sent
exactly as it will be in production, and then, at the last possible moment
before it leaves the server, it redirects it to one address.

The single override is on ir.mail_server.send_email - the one place every
outgoing message in Odoo passes through, whatever module created it, whether
it went through the queue or was forced out immediately. There is no second
path to miss.

Each redirected message carries what it would have done:

* the subject is prefixed with the real recipients, so the inbox reads like
  a log of who would have been written to;
* a header X-DHB-Original-Recipients keeps the full list;
* the server log records every redirect.

Two system parameters control it, under Settings > Technical > System
Parameters:

* dhb_mail_guard.mode - "redirect" (default) or "live"
* dhb_mail_guard.test_address - where test mail goes

It ships in redirect mode. Going live is a deliberate act: someone has to
change that parameter to "live". A system that is safe by default and
dangerous only on purpose is the right way round.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Technical",
    "license": "LGPL-3",
    "depends": ["mail"],
    "data": [
        "data/mail_guard_data.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
