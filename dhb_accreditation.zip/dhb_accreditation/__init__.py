# -*- coding: utf-8 -*-
import logging

from . import models

_logger = logging.getLogger(__name__)

EVIDENCE_LIST = """
    <list decoration-danger="days_overdue &gt; 0"
          decoration-success="state == 'approved'"
          decoration-muted="state == 'na'">
        <field name="requirement_id"/>
        <field name="level"/>
        <field name="date_due"/>
        <field name="days_overdue"/>
        <field name="state" widget="badge"/>
    </list>
"""

ENROLLMENT_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_evidence">
      <group>
        <group>
          <field name="evidence_total_count"/>
          <field name="evidence_missing_count"/>
        </group>
        <group>
          <field name="evidence_complete_rate"/>
        </group>
      </group>
      <button name="action_generate_evidence" type="object"
              string="Refresh Evidence List" class="btn-secondary"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST

BATCH_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_batch_evidence">
      <group>
        <group string="Tutors">
          <field name="tutor_employee_id"/>
          <field name="co_tutor_employee_id"/>
          <field name="ratio_compliant"/>
        </group>
        <group string="NEBOSH Sitting">
          <field name="sitting_id"/>
          <field name="exam_window_start" readonly="1"/>
          <field name="exam_window_end" readonly="1"/>
          <field name="evidence_missing_count"/>
        </group>
      </group>
      <button name="action_generate_evidence" type="object"
              string="Refresh Evidence List" class="btn-secondary"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST


STUDENT_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_student_evidence">
      <group>
        <group>
          <field name="partner_id"/>
          <field name="evidence_total_count"/>
        </group>
        <group>
          <field name="evidence_missing_count"/>
          <field name="evidence_complete_rate"/>
        </group>
      </group>
      <button name="action_create_contact" type="object"
              string="Create Contact" class="btn-secondary"
              invisible="partner_id"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST

PARTNER_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Learner File" name="dhb_learner_file">
      <field name="dhb_student_ids" readonly="1">
        <list>
          <field name="name"/>
          <field name="kyc_status"/>
          <field name="enrollment_count"/>
          <field name="evidence_missing_count"/>
          <field name="evidence_complete_rate"/>
        </list>
      </field>
      <button name="action_view_learner_file" type="object"
              string="Open learner file" class="btn-secondary"/>
    </page>
  </xpath>
</data>
"""


KYC_HEADER = """<?xml version="1.0"?>
<data>
  <xpath expr="//field[@name='kyc_status']" position="attributes">
    <attribute name="clickable">1</attribute>
  </xpath>
</data>
"""

KYC_BUTTONS = """<?xml version="1.0"?>
<data>
  <xpath expr="//field[@name='kyc_status']" position="before">
    <button name="action_kyc_passed" type="object"
            string="ID checked - pass" class="btn-primary"
            invisible="kyc_status == 'passed'"/>
    <button name="action_kyc_review" type="object"
            string="Send to review" class="btn-secondary"
            invisible="kyc_status in ['review','passed']"/>
    <button name="action_kyc_failed" type="object"
            string="ID check failed" class="btn-secondary"
            invisible="kyc_status in ['failed','not_started']"/>
    <button name="action_kyc_reset" type="object"
            string="Reset ID check" class="btn-secondary"
            invisible="kyc_status == 'not_started'"/>
  </xpath>
</data>
"""


KYC_DOCS = """<?xml version="1.0"?>
<data>
  <xpath expr="//field[@name='kyc_doc_expiry']" position="after">
    <field name="id_document_count"/>
    <field name="id_document_ids" nolabel="1" colspan="2"
           context="{'default_student_id': id}">
      <list editable="bottom">
        <field name="doc_type"/>
        <field name="doc_number"/>
        <field name="issuing_country_id"/>
        <field name="date_expiry"/>
        <field name="attachment" filename="attachment_filename"
               widget="binary"/>
        <field name="attachment_filename" column_invisible="1"/>
        <field name="date_checked"/>
        <field name="checked_by_id" optional="hide"/>
      </list>
    </field>
  </xpath>
</data>
"""


PHOTO_FORM = """<?xml version="1.0"?>
<data>
  <xpath expr="//sheet" position="inside">
    <field name="image_1920" widget="image" class="oe_avatar"
           options="{'preview_image': 'image_128'}"/>
  </xpath>
</data>
"""

PHOTO_LIST = """<?xml version="1.0"?>
<data>
  <xpath expr="//list/field[1]" position="before">
    <field name="image_128" widget="image" width="40"
           options="{'zoom': true, 'zoom_delay': 800}"/>
  </xpath>
</data>
"""


def _graft_photo(env):
    """Put the learner photograph top-right of the form and in the list.

    oe_avatar floats the image to the top-right of the sheet, which is where
    Odoo puts a person's picture everywhere else - so it reads as native
    rather than as a bolted-on field.
    """
    View = env["ir.ui.view"]
    for view_type, arch, xmlid in (
            ("form", PHOTO_FORM, "view_dhb_student_photo_form"),
            ("list", PHOTO_LIST, "view_dhb_student_photo_list")):
        base = View.search([
            ("model", "=", "dhb.student"),
            ("type", "=", view_type),
            ("mode", "=", "primary"),
        ], order="priority, id", limit=1)
        if not base:
            continue
        if view_type == "form" and "<sheet" not in (base.arch_db or ""):
            continue
        if env.ref("dhb_accreditation.%s" % xmlid,
                   raise_if_not_found=False):
            continue
        try:
            view = View.create({
                "name": "dhb.student.%s.photo" % view_type,
                "model": "dhb.student",
                "inherit_id": base.id,
                "mode": "extension",
                "arch": arch,
            })
            env["ir.model.data"].create({
                "name": xmlid, "module": "dhb_accreditation",
                "model": "ir.ui.view", "res_id": view.id, "noupdate": True,
            })
            _logger.info("dhb_accreditation: photo added to the learner %s",
                         view_type)
        except Exception as error:        # noqa: BLE001
            _logger.warning("dhb_accreditation: photo on %s failed (%s)",
                            view_type, error)


def _graft_kyc_docs(env):
    """Put the identity documents inside the KYC group on the learner form."""
    View = env["ir.ui.view"]
    base = View.search([
        ("model", "=", "dhb.student"),
        ("type", "=", "form"),
        ("mode", "=", "primary"),
    ], order="priority, id", limit=1)
    if not base or "kyc_doc_expiry" not in (base.arch_db or ""):
        _logger.info("dhb_accreditation: kyc_doc_expiry not on the learner "
                     "form; document list skipped")
        return
    if env.ref("dhb_accreditation.view_dhb_student_kyc_docs",
               raise_if_not_found=False):
        return
    try:
        view = View.create({
            "name": "dhb.student.form.kyc.documents",
            "model": "dhb.student",
            "inherit_id": base.id,
            "mode": "extension",
            "arch": KYC_DOCS,
        })
        env["ir.model.data"].create({
            "name": "view_dhb_student_kyc_docs",
            "module": "dhb_accreditation",
            "model": "ir.ui.view", "res_id": view.id, "noupdate": True,
        })
        _logger.info("dhb_accreditation: identity document list added")
    except Exception as error:            # noqa: BLE001
        _logger.warning("dhb_accreditation: document list failed (%s)", error)


def _graft_kyc(env):
    """Make the KYC status bar usable.

    dhb_student renders kyc_status as a statusbar without clickable="1", so
    the stages cannot be clicked - the field could only be set from the shell.
    This flips it to clickable and adds explicit buttons, because a labelled
    "ID checked - pass" button is clearer than clicking a stage name, and it
    also stamps the verification date and posts a note to the chatter, which
    is what an auditor actually wants to see.
    """
    View = env["ir.ui.view"]
    base = View.search([
        ("model", "=", "dhb.student"),
        ("type", "=", "form"),
        ("mode", "=", "primary"),
    ], order="priority, id", limit=1)
    if not base or "kyc_status" not in (base.arch_db or ""):
        _logger.info("dhb_accreditation: no kyc_status on the learner form; "
                     "KYC buttons skipped")
        return
    for arch, xmlid in ((KYC_HEADER, "view_dhb_student_kyc_clickable"),
                        (KYC_BUTTONS, "view_dhb_student_kyc_buttons")):
        if env.ref("dhb_accreditation.%s" % xmlid, raise_if_not_found=False):
            continue
        try:
            view = View.create({
                "name": "dhb.student.form.%s" % xmlid,
                "model": "dhb.student",
                "inherit_id": base.id,
                "mode": "extension",
                "arch": arch,
            })
            env["ir.model.data"].create({
                "name": xmlid, "module": "dhb_accreditation",
                "model": "ir.ui.view", "res_id": view.id, "noupdate": True,
            })
            _logger.info("dhb_accreditation: %s applied", xmlid)
        except Exception as error:        # noqa: BLE001
            _logger.warning("dhb_accreditation: %s failed (%s)",
                            xmlid, error)


def _graft_tab(env, model, arch, xmlid_name, page_only_arch=None):
    """Attach an evidence tab to whatever form view the host module defines.

    The host modules were written independently, so their view XML IDs are not
    known at build time and the base form is discovered at run time.

    Some of those forms have no <notebook> at all (dhb.student and
    dhb.enrollment are laid out as flat groups). Rather than skip the tab, a
    notebook is created inside the <sheet> first and the page goes into it.
    This is additive - uninstalling this module removes the inherited view and
    the host form returns to exactly what it was.
    """
    View = env["ir.ui.view"]
    candidates = View.search([
        ("model", "=", model),
        ("type", "=", "form"),
        ("mode", "=", "primary"),
    ], order="priority, id")
    base = candidates.filtered(
        lambda v: "<notebook" in (v.arch_db or ""))[:1] or candidates[:1]
    if not base:
        _logger.info("dhb_accreditation: no primary form view for %s; "
                     "evidence tab skipped", model)
        return

    arch_db = base.arch_db or ""
    if "<notebook" not in arch_db:
        if "<sheet" not in arch_db:
            _logger.info("dhb_accreditation: %s form has neither notebook nor "
                         "sheet; evidence tab skipped", model)
            return
        page = page_only_arch or arch
        inner = page.split("<data>", 1)[-1].rsplit("</data>", 1)[0]
        inner = inner.replace(
            '<xpath expr="//notebook" position="inside">', "")
        inner = inner.replace("</xpath>", "")
        arch = ('<?xml version="1.0"?>\n<data>\n'
                '  <xpath expr="//sheet" position="inside">\n'
                '    <notebook>%s</notebook>\n'
                '  </xpath>\n</data>' % inner)

    if env.ref("dhb_accreditation.%s" % xmlid_name, raise_if_not_found=False):
        return
    try:
        view = View.create({
            "name": "%s.form.dhb.evidence" % model,
            "model": model,
            "inherit_id": base.id,
            "mode": "extension",
            "arch": arch,
        })
        env["ir.model.data"].create({
            "name": xmlid_name,
            "module": "dhb_accreditation",
            "model": "ir.ui.view",
            "res_id": view.id,
            "noupdate": True,
        })
        _logger.info("dhb_accreditation: evidence tab added to %s", model)
    except Exception as error:            # noqa: BLE001 - never block install
        _logger.warning("dhb_accreditation: could not add evidence tab to "
                        "%s (%s); the Accreditation menus still show "
                        "everything", model, error)


def post_init_hook(env):
    """Seed organisation evidence, then graft the evidence tabs."""
    env["dhb.evidence.requirement"].search([])._cron_generate_all_records()
    _graft_tab(env, "dhb.enrollment", ENROLLMENT_TAB,
               "view_dhb_enrollment_form_evidence")
    _graft_tab(env, "dhb.training_batch", BATCH_TAB,
               "view_dhb_batch_form_evidence")
    _graft_tab(env, "dhb.student", STUDENT_TAB,
               "view_dhb_student_form_evidence")
    _graft_tab(env, "res.partner", PARTNER_TAB,
               "view_res_partner_form_learner")
    _graft_kyc(env)
    _graft_kyc_docs(env)
    _graft_photo(env)
