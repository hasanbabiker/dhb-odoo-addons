# -*- coding: utf-8 -*-
from . import models


def post_init_hook(env):
    """Generate the organisation-scope evidence placeholders at install time.

    Without this the organisation rows (insurance, policies, licences,
    premises evidence) would not appear until the nightly cron first runs,
    and the accreditation report would look emptier than reality on day one.
    """
    env["dhb.evidence.requirement"].search([])._cron_generate_all_records()
