# -*- coding: utf-8 -*-
import logging

from . import models

_logger = logging.getLogger(__name__)

EVIDENCE_LIST = """
    <list decoration-danger="days_overdue &gt; 0"
          decoration-success="state == 'approved'"
          decoration-muted="state == 'na'">
        <field name="requirement_id"/>
        <field name="level"/>
        <field name="date_due"/>
        <field name="days_overdue"/>
        <field name="state" widget="badge"/>
    </list>
"""

ENROLLMENT_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_evidence">
      <group>
        <group>
          <field name="evidence_total_count"/>
          <field name="evidence_missing_count"/>
        </group>
        <group>
          <field name="evidence_complete_rate"/>
        </group>
      </group>
      <button name="action_generate_evidence" type="object"
              string="Refresh Evidence List" class="btn-secondary"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST

BATCH_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_batch_evidence">
      <group>
        <group string="Tutors">
          <field name="tutor_employee_id"/>
          <field name="co_tutor_employee_id"/>
          <field name="ratio_compliant"/>
        </group>
        <group string="NEBOSH Sitting">
          <field name="sitting_id"/>
          <field name="exam_window_start" readonly="1"/>
          <field name="exam_window_end" readonly="1"/>
          <field name="evidence_missing_count"/>
        </group>
      </group>
      <button name="action_generate_evidence" type="object"
              string="Refresh Evidence List" class="btn-secondary"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST


STUDENT_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_student_evidence">
      <group>
        <group>
          <field name="partner_id"/>
          <field name="evidence_total_count"/>
        </group>
        <group>
          <field name="evidence_missing_count"/>
          <field name="evidence_complete_rate"/>
        </group>
      </group>
      <button name="action_create_contact" type="object"
              string="Create Contact" class="btn-secondary"
              invisible="partner_id"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST

PARTNER_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Learner File" name="dhb_learner_file">
      <field name="dhb_student_ids" readonly="1">
        <list>
          <field name="name"/>
          <field name="kyc_status"/>
          <field name="enrollment_count"/>
          <field name="evidence_missing_count"/>
          <field name="evidence_complete_rate"/>
        </list>
      </field>
      <button name="action_view_learner_file" type="object"
              string="Open learner file" class="btn-secondary"/>
    </page>
  </xpath>
</data>
"""


def _graft_tab(env, model, arch, xmlid_name):
    """Attach an evidence tab to whatever form view the host module defines.

    The host modules (dhb_enrollment, dhb_training_batch) were written
    independently, so their view XML IDs are not known at build time. Rather
    than hard-code a guess that would break the install, the base form view is
    discovered at run time. If no suitable view exists, or its arch has no
    notebook to graft onto, the tab is skipped - the data stays fully
    reachable from the Accreditation menus either way.
    """
    View = env["ir.ui.view"]
    base = View.search([
        ("model", "=", model),
        ("type", "=", "form"),
        ("mode", "=", "primary"),
    ], order="priority, id", limit=1)
    if not base:
        _logger.info("dhb_accreditation: no primary form view for %s; "
                     "evidence tab skipped", model)
        return
    if "<notebook" not in (base.arch_db or ""):
        _logger.info("dhb_accreditation: form view for %s has no notebook; "
                     "evidence tab skipped", model)
        return
    if env.ref("dhb_accreditation.%s" % xmlid_name, raise_if_not_found=False):
        return
    try:
        view = View.create({
            "name": "%s.form.dhb.evidence" % model,
            "model": model,
            "inherit_id": base.id,
            "mode": "extension",
            "arch": arch,
        })
        env["ir.model.data"].create({
            "name": xmlid_name,
            "module": "dhb_accreditation",
            "model": "ir.ui.view",
            "res_id": view.id,
            "noupdate": True,
        })
        _logger.info("dhb_accreditation: evidence tab added to %s", model)
    except Exception as error:            # noqa: BLE001 - never block install
        _logger.warning("dhb_accreditation: could not add evidence tab to "
                        "%s (%s); the Accreditation menus still show "
                        "everything", model, error)


def post_init_hook(env):
    """Seed organisation evidence, then graft the evidence tabs."""
    env["dhb.evidence.requirement"].search([])._cron_generate_all_records()
    _graft_tab(env, "dhb.enrollment", ENROLLMENT_TAB,
               "view_dhb_enrollment_form_evidence")
    _graft_tab(env, "dhb.training_batch", BATCH_TAB,
               "view_dhb_batch_form_evidence")
    _graft_tab(env, "dhb.student", STUDENT_TAB,
               "view_dhb_student_form_evidence")
    _graft_tab(env, "res.partner", PARTNER_TAB,
               "view_res_partner_form_learner")
