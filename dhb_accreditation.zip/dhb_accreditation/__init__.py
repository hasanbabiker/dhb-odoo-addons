# -*- coding: utf-8 -*-
import logging

from . import models

_logger = logging.getLogger(__name__)

EVIDENCE_LIST = """
    <list decoration-danger="days_overdue &gt; 0"
          decoration-success="state == 'approved'"
          decoration-muted="state == 'na'">
        <field name="requirement_id"/>
        <field name="level"/>
        <field name="date_due"/>
        <field name="days_overdue"/>
        <field name="state" widget="badge"/>
    </list>
"""

ENROLLMENT_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_evidence">
      <group>
        <group>
          <field name="evidence_total_count"/>
          <field name="evidence_missing_count"/>
        </group>
        <group>
          <field name="evidence_complete_rate"/>
        </group>
      </group>
      <button name="action_generate_evidence" type="object"
              string="Refresh Evidence List" class="btn-secondary"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST

BATCH_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_batch_evidence">
      <group>
        <group string="Tutors">
          <field name="tutor_employee_id"/>
          <field name="co_tutor_employee_id"/>
          <field name="ratio_compliant"/>
        </group>
        <group string="NEBOSH Sitting">
          <field name="sitting_id"/>
          <field name="exam_window_start" readonly="1"/>
          <field name="exam_window_end" readonly="1"/>
          <field name="evidence_missing_count"/>
        </group>
      </group>
      <button name="action_generate_evidence" type="object"
              string="Refresh Evidence List" class="btn-secondary"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST


STUDENT_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Accreditation Evidence" name="dhb_student_evidence">
      <group>
        <group>
          <field name="partner_id"/>
          <field name="evidence_total_count"/>
        </group>
        <group>
          <field name="evidence_missing_count"/>
          <field name="evidence_complete_rate"/>
        </group>
      </group>
      <button name="action_create_contact" type="object"
              string="Create Contact" class="btn-secondary"
              invisible="partner_id"/>
      <field name="evidence_ids" readonly="1">%s</field>
    </page>
  </xpath>
</data>
""" % EVIDENCE_LIST

PARTNER_TAB = """<?xml version="1.0"?>
<data>
  <xpath expr="//notebook" position="inside">
    <page string="Learner File" name="dhb_learner_file">
      <field name="dhb_student_ids" readonly="1">
        <list>
          <field name="name"/>
          <field name="kyc_status"/>
          <field name="enrollment_count"/>
          <field name="evidence_missing_count"/>
          <field name="evidence_complete_rate"/>
        </list>
      </field>
      <button name="action_view_learner_file" type="object"
              string="Open learner file" class="btn-secondary"/>
    </page>
  </xpath>
</data>
"""


def _graft_tab(env, model, arch, xmlid_name, page_only_arch=None):
    """Attach an evidence tab to whatever form view the host module defines.

    The host modules were written independently, so their view XML IDs are not
    known at build time and the base form is discovered at run time.

    Some of those forms have no <notebook> at all (dhb.student and
    dhb.enrollment are laid out as flat groups). Rather than skip the tab, a
    notebook is created inside the <sheet> first and the page goes into it.
    This is additive - uninstalling this module removes the inherited view and
    the host form returns to exactly what it was.
    """
    View = env["ir.ui.view"]
    candidates = View.search([
        ("model", "=", model),
        ("type", "=", "form"),
        ("mode", "=", "primary"),
    ], order="priority, id")
    base = candidates.filtered(
        lambda v: "<notebook" in (v.arch_db or ""))[:1] or candidates[:1]
    if not base:
        _logger.info("dhb_accreditation: no primary form view for %s; "
                     "evidence tab skipped", model)
        return

    arch_db = base.arch_db or ""
    if "<notebook" not in arch_db:
        if "<sheet" not in arch_db:
            _logger.info("dhb_accreditation: %s form has neither notebook nor "
                         "sheet; evidence tab skipped", model)
            return
        page = page_only_arch or arch
        inner = page.split("<data>", 1)[-1].rsplit("</data>", 1)[0]
        inner = inner.replace(
            '<xpath expr="//notebook" position="inside">', "")
        inner = inner.replace("</xpath>", "")
        arch = ('<?xml version="1.0"?>\n<data>\n'
                '  <xpath expr="//sheet" position="inside">\n'
                '    <notebook>%s</notebook>\n'
                '  </xpath>\n</data>' % inner)

    if env.ref("dhb_accreditation.%s" % xmlid_name, raise_if_not_found=False):
        return
    try:
        view = View.create({
            "name": "%s.form.dhb.evidence" % model,
            "model": model,
            "inherit_id": base.id,
            "mode": "extension",
            "arch": arch,
        })
        env["ir.model.data"].create({
            "name": xmlid_name,
            "module": "dhb_accreditation",
            "model": "ir.ui.view",
            "res_id": view.id,
            "noupdate": True,
        })
        _logger.info("dhb_accreditation: evidence tab added to %s", model)
    except Exception as error:            # noqa: BLE001 - never block install
        _logger.warning("dhb_accreditation: could not add evidence tab to "
                        "%s (%s); the Accreditation menus still show "
                        "everything", model, error)


def post_init_hook(env):
    """Seed organisation evidence, then graft the evidence tabs."""
    env["dhb.evidence.requirement"].search([])._cron_generate_all_records()
    _graft_tab(env, "dhb.enrollment", ENROLLMENT_TAB,
               "view_dhb_enrollment_form_evidence")
    _graft_tab(env, "dhb.training_batch", BATCH_TAB,
               "view_dhb_batch_form_evidence")
    _graft_tab(env, "dhb.student", STUDENT_TAB,
               "view_dhb_student_form_evidence")
    _graft_tab(env, "res.partner", PARTNER_TAB,
               "view_res_partner_form_learner")
