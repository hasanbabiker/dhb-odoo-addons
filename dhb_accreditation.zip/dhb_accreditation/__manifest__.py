# -*- coding: utf-8 -*-
{
    "name": "DHB Accreditation & Evidence Manager",
    "summary": "NEBOSH / IOSH accreditation evidence, learner file checks and audit action tracking",
    "description": """
DHB Training and Consulting - Accreditation Evidence Manager
============================================================

Single place for every piece of evidence required by NEBOSH (Learning Partner
Programme C021 v12) and IOSH, plus learner-file completeness checking.

Features
--------
* Evidence *requirements* library (body / principle / level / scope).
* Evidence *records* auto-generated for every enrolment, course and tutor.
* Weekly learner evidence gap report by e-mail.
* Fortnightly accreditation evidence gap report, split Corporate / Silver / Gold.
* Audit action register with a mandatory 'impact measured' final stage.
* Organisation document register (insurance, policies, licences) with
  90 / 30 / 7 day expiry reminders.
""",
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Services/Training",
    "version": "19.0.1.0.0",
    "license": "LGPL-3",
    "depends": [
        "base",
        "mail",
        "hr",
        "dhb_student",
        "dhb_enrollment",
        "dhb_training_batch",
    ],
    "data": [
        "security/dhb_security.xml",
        "security/ir.model.access.csv",
        "data/dhb_principle_data.xml",
        "data/dhb_exam_sitting_data.xml",
        "data/dhb_requirement_data.xml",
        "data/dhb_org_document_data.xml",
        "data/dhb_audit_action_data.xml",
        "data/ir_cron_data.xml",
        "views/dhb_principle_views.xml",
        "views/dhb_requirement_views.xml",
        "views/dhb_evidence_views.xml",
        "views/dhb_bridge_views.xml",
        "views/dhb_sitting_views.xml",
        "views/dhb_audit_action_views.xml",
        "views/dhb_org_document_views.xml",
        "views/dhb_menus.xml",
    ],
    "post_init_hook": "post_init_hook",
    "application": True,
    "installable": True,
}
