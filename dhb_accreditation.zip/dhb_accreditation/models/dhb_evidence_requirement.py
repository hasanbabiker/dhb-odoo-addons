# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import api, fields, models

from .dhb_principle import BODY_SELECTION, LEVEL_SELECTION

SCOPE_SELECTION = [
    ("learner", "Learner"),
    ("course", "Course"),
    ("tutor", "Tutor"),
    ("org", "Organisation"),
]


class DhbEvidenceRequirement(models.Model):
    """A definition of one piece of evidence the organisation must be able to
    produce. Adding a new requirement here is all that is needed - the records
    for learners, courses and tutors are generated from these definitions.
    """
    _name = "dhb.evidence.requirement"
    _description = "Evidence Requirement"
    _order = "body, principle_id, level, sequence, id"

    name = fields.Char(string="Requirement", required=True, translate=True)
    code = fields.Char(string="Code", required=True)
    sequence = fields.Integer(string="Sequence", default=10)
    active = fields.Boolean(string="Active", default=True)

    body = fields.Selection(BODY_SELECTION, string="Awarding Body",
                            required=True, default="nebosh")
    principle_id = fields.Many2one(
        "dhb.principle", string="Principle", ondelete="restrict")
    level = fields.Selection(
        LEVEL_SELECTION, string="Status Level", required=True,
        default="corporate",
        help="The lowest accreditation status that requires this evidence. "
             "Gold requirements are the ones that lift the file above Silver.")
    scope = fields.Selection(
        SCOPE_SELECTION, string="Applies To", required=True, default="org",
        help="Learner  - one record per enrolment.\n"
             "Course   - one record per course.\n"
             "Tutor    - one record per active tutor.\n"
             "Organisation - a single standing record.")

    qualification_ids = fields.Many2many(
        "dhb.qualification", string="Qualifications",
        help="Leave empty to apply to every qualification of this body.")

    deadline_days = fields.Integer(
        string="Due Within (days)", default=0,
        help="Days from enrolment / course start by which this evidence must "
             "exist. 0 means it is due immediately.")
    has_expiry = fields.Boolean(string="Expires")
    validity_months = fields.Integer(string="Valid For (months)", default=12)

    description = fields.Text(string="Guidance", translate=True)

    record_ids = fields.One2many(
        "dhb.evidence.record", "requirement_id", string="Evidence Records")
    missing_count = fields.Integer(
        string="Missing", compute="_compute_counts")
    record_count = fields.Integer(
        string="Records", compute="_compute_counts")

    _code_uniq = models.Constraint(
        "unique (code)",
        "The requirement code must be unique.",
    )

    @api.depends("record_ids", "record_ids.state")
    def _compute_counts(self):
        for record in self:
            records = record.record_ids
            record.record_count = len(records)
            record.missing_count = len(
                records.filtered(lambda r: r.state == "missing"))

    def applies_to_qualification(self, qualification):
        """A requirement with no qualifications set applies to all of them."""
        self.ensure_one()
        if not self.qualification_ids:
            return True
        return qualification in self.qualification_ids

    # ------------------------------------------------------------------
    # Record preparation
    # ------------------------------------------------------------------
    def _due_date_from(self, base_date):
        self.ensure_one()
        if not base_date:
            return False
        return base_date + timedelta(days=self.deadline_days or 0)

    def _prepare_record_vals_for_enrolment(self, enrolment):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "enrolment_id": enrolment.id,
            "course_id": enrolment.course_id.id,
            "qualification_id": enrolment.qualification_id.id,
            "date_due": self._due_date_from(enrolment.date_enrol),
            "state": "missing",
        }

    def _prepare_record_vals_for_course(self, course):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "course_id": course.id,
            "qualification_id": course.qualification_id.id,
            "date_due": self._due_date_from(course.date_start),
            "state": "missing",
        }

    def _prepare_record_vals_for_employee(self, employee):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "employee_id": employee.id,
            "date_due": fields.Date.context_today(self),
            "state": "missing",
        }

    def _prepare_record_vals_for_org(self):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "date_due": fields.Date.context_today(self),
            "state": "missing",
        }

    def action_generate_records(self):
        """Generate any still-missing evidence placeholders for the selected
        requirements across every enrolment, course and tutor.
        """
        Evidence = self.env["dhb.evidence.record"]
        for requirement in self:
            if requirement.scope == "learner":
                domain = [("body", "=", requirement.body),
                          ("state", "not in", ["withdrawn"])]
                for enrolment in self.env["dhb.enrolment"].search(domain):
                    if not requirement.applies_to_qualification(
                            enrolment.qualification_id):
                        continue
                    if Evidence.search_count([
                            ("requirement_id", "=", requirement.id),
                            ("enrolment_id", "=", enrolment.id)]):
                        continue
                    Evidence.create(
                        requirement._prepare_record_vals_for_enrolment(
                            enrolment))
            elif requirement.scope == "course":
                domain = [("body", "=", requirement.body),
                          ("state", "!=", "cancel")]
                for course in self.env["dhb.course"].search(domain):
                    if not requirement.applies_to_qualification(
                            course.qualification_id):
                        continue
                    if Evidence.search_count([
                            ("requirement_id", "=", requirement.id),
                            ("course_id", "=", course.id)]):
                        continue
                    Evidence.create(
                        requirement._prepare_record_vals_for_course(course))
            elif requirement.scope == "tutor":
                employees = self.env["hr.employee"].search(
                    [("dhb_is_tutor", "=", True)])
                for employee in employees:
                    if Evidence.search_count([
                            ("requirement_id", "=", requirement.id),
                            ("employee_id", "=", employee.id)]):
                        continue
                    Evidence.create(
                        requirement._prepare_record_vals_for_employee(
                            employee))
            else:
                if not Evidence.search_count([
                        ("requirement_id", "=", requirement.id),
                        ("scope", "=", "org")]):
                    Evidence.create(
                        requirement._prepare_record_vals_for_org())
        return True

    @api.model
    def _cron_generate_all_records(self):
        self.search([]).action_generate_records()
        return True

    @api.depends("code", "name")
    def _compute_display_name(self):
        for record in self:
            record.display_name = "[%s] %s" % (record.code or "", record.name or "")
