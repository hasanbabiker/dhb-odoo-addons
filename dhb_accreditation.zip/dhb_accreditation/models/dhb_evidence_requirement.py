# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import api, fields, models

from .dhb_principle import BODY_SELECTION, LEVEL_SELECTION

SCOPE_SELECTION = [
    ("learner", "Learner"),
    ("course", "Course"),
    ("tutor", "Tutor"),
    ("org", "Organisation"),
]


class DhbEvidenceRequirement(models.Model):
    """A definition of one piece of evidence the organisation must be able to
    produce. Adding a new requirement here is all that is needed - the records
    for learners, courses and tutors are generated from these definitions.
    """
    _name = "dhb.evidence.requirement"
    _description = "Evidence Requirement"
    _order = "body, principle_id, level, sequence, id"

    name = fields.Char(string="Requirement", required=True, translate=True)
    code = fields.Char(string="Code", required=True)
    sequence = fields.Integer(string="Sequence", default=10)
    active = fields.Boolean(string="Active", default=True)

    body = fields.Selection(BODY_SELECTION, string="Awarding Body",
                            required=True, default="nebosh")
    principle_id = fields.Many2one(
        "dhb.principle", string="Principle", ondelete="restrict")
    level = fields.Selection(
        LEVEL_SELECTION, string="Status Level", required=True,
        default="corporate",
        help="The lowest accreditation status that requires this evidence. "
             "Gold requirements are the ones that lift the file above Silver.")
    scope = fields.Selection(
        SCOPE_SELECTION, string="Applies To", required=True, default="org",
        help="Learner  - one record per enrolment.\n"
             "Course   - one record per course.\n"
             "Tutor    - one record per active tutor.\n"
             "Organisation - a single standing record.")

    qualification_codes = fields.Char(
        string="Qualification Codes",
        help="Comma-separated codes this requirement applies to, matching the "
             "values used on dhb.enrollment (igc, idip, ienvm, fire, "
             "construction, psm, iosh_ms). Leave empty to apply to every "
             "qualification of this body.")

    deadline_days = fields.Integer(
        string="Due Within (days)", default=0,
        help="Days from enrolment / course start by which this evidence must "
             "exist. 0 means it is due immediately.")
    has_expiry = fields.Boolean(string="Expires")
    validity_months = fields.Integer(string="Valid For (months)", default=12)

    description = fields.Text(string="Guidance", translate=True)

    record_ids = fields.One2many(
        "dhb.evidence.record", "requirement_id", string="Evidence Records")
    missing_count = fields.Integer(
        string="Missing", compute="_compute_counts")
    record_count = fields.Integer(
        string="Records", compute="_compute_counts")

    _code_uniq = models.Constraint(
        "unique (code)",
        "The requirement code must be unique.",
    )

    @api.depends("record_ids", "record_ids.state")
    def _compute_counts(self):
        for record in self:
            records = record.record_ids
            record.record_count = len(records)
            record.missing_count = len(
                records.filtered(lambda r: r.state == "missing"))

    def applies_to_qualification_code(self, code):
        """A requirement with no codes set applies to every qualification."""
        self.ensure_one()
        if not self.qualification_codes:
            return True
        allowed = [c.strip() for c in self.qualification_codes.split(",")
                   if c.strip()]
        return code in allowed

    # ------------------------------------------------------------------
    # Record preparation
    # ------------------------------------------------------------------
    def _due_date_from(self, base_date):
        self.ensure_one()
        if not base_date:
            return False
        return base_date + timedelta(days=self.deadline_days or 0)

    def _prepare_record_vals_for_enrollment(self, enrollment):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "enrollment_id": enrollment.id,
            "batch_id": enrollment.batch_id.id or False,
            "qualification": enrollment.qualification,
            "date_due": self._due_date_from(enrollment.enrollment_date),
            "state": "missing",
        }

    def _prepare_record_vals_for_batch(self, batch):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "batch_id": batch.id,
            "qualification": batch.qualification,
            "date_due": self._due_date_from(batch.start_date),
            "state": "missing",
        }

    def _prepare_record_vals_for_employee(self, employee):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "employee_id": employee.id,
            "date_due": fields.Date.context_today(self),
            "state": "missing",
        }

    def _prepare_record_vals_for_org(self):
        self.ensure_one()
        return {
            "requirement_id": self.id,
            "date_due": fields.Date.context_today(self),
            "state": "missing",
        }

    def action_generate_records(self):
        """Fill in any still-missing placeholders across every enrollment,
        batch and tutor this requirement applies to."""
        Evidence = self.env["dhb.evidence.record"]
        for requirement in self:
            if requirement.scope == "learner":
                enrollments = self.env["dhb.enrollment"].search(
                    [("enrollment_status", "!=", "withdrawn")])
                for enrollment in enrollments:
                    if enrollment._dhb_body() != requirement.body:
                        continue
                    if not requirement.applies_to_qualification_code(
                            enrollment.qualification):
                        continue
                    if Evidence.search_count([
                            ("requirement_id", "=", requirement.id),
                            ("enrollment_id", "=", enrollment.id)]):
                        continue
                    Evidence.create(
                        requirement._prepare_record_vals_for_enrollment(
                            enrollment))
            elif requirement.scope == "course":
                batches = self.env["dhb.training_batch"].search(
                    [("batch_status", "!=", "cancelled")])
                for batch in batches:
                    body = "iosh" if (batch.qualification or "").startswith(
                        "iosh") else "nebosh"
                    if body != requirement.body:
                        continue
                    if not requirement.applies_to_qualification_code(
                            batch.qualification):
                        continue
                    if Evidence.search_count([
                            ("requirement_id", "=", requirement.id),
                            ("batch_id", "=", batch.id)]):
                        continue
                    Evidence.create(
                        requirement._prepare_record_vals_for_batch(batch))
            elif requirement.scope == "tutor":
                employees = self.env["hr.employee"].search(
                    [("dhb_is_tutor", "=", True)])
                for employee in employees:
                    if Evidence.search_count([
                            ("requirement_id", "=", requirement.id),
                            ("employee_id", "=", employee.id)]):
                        continue
                    Evidence.create(
                        requirement._prepare_record_vals_for_employee(
                            employee))
            else:
                if not Evidence.search_count([
                        ("requirement_id", "=", requirement.id),
                        ("scope", "=", "org")]):
                    Evidence.create(
                        requirement._prepare_record_vals_for_org())
        return True

    @api.model
    def _cron_generate_all_records(self):
        self.search([]).action_generate_records()
        return True

    @api.depends("code", "name")
    def _compute_display_name(self):
        for record in self:
            record.display_name = "[%s] %s" % (record.code or "", record.name or "")
