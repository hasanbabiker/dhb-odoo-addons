# -*- coding: utf-8 -*-
from odoo import _, api, fields, models

DELIVERY_SELECTION = [
    ("face", "Face to face"),
    ("virtual", "Virtual"),
    ("elearning", "E-learning"),
    ("blended", "Blended"),
]


class DhbCourse(models.Model):
    _name = "dhb.course"
    _description = "Course Run"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_start desc, id desc"

    name = fields.Char(string="Course Reference", required=True,
                       copy=False, tracking=True)
    qualification_id = fields.Many2one(
        "dhb.qualification", string="Qualification",
        required=True, tracking=True)
    body = fields.Selection(
        related="qualification_id.body", string="Awarding Body", store=True)
    delivery_mode = fields.Selection(
        DELIVERY_SELECTION, string="Delivery Mode",
        required=True, default="virtual", tracking=True)
    date_start = fields.Date(string="Start Date", required=True, tracking=True)
    date_end = fields.Date(string="End Date", tracking=True)
    tutor_id = fields.Many2one(
        "hr.employee", string="Lead Tutor", tracking=True)
    language = fields.Selection(
        [("ar", "Arabic"), ("en", "English")],
        string="Language", default="ar")

    state = fields.Selection(
        [("draft", "Planned"),
         ("running", "Running"),
         ("done", "Completed"),
         ("cancel", "Cancelled")],
        string="Status", default="draft", tracking=True)

    enrolment_ids = fields.One2many(
        "dhb.enrolment", "course_id", string="Learners")
    enrolment_count = fields.Integer(
        string="Learner Count", compute="_compute_enrolment_count")

    evidence_ids = fields.One2many(
        "dhb.evidence.record", "course_id", string="Course Evidence")
    evidence_missing_count = fields.Integer(
        string="Missing Evidence", compute="_compute_evidence_counts")
    evidence_total_count = fields.Integer(
        string="Total Evidence", compute="_compute_evidence_counts")

    note = fields.Text(string="Notes")

    _name_uniq = models.Constraint(
        "unique (name)",
        "The course reference must be unique.",
    )

    @api.depends("enrolment_ids")
    def _compute_enrolment_count(self):
        for record in self:
            record.enrolment_count = len(record.enrolment_ids)

    @api.depends("evidence_ids", "evidence_ids.state")
    def _compute_evidence_counts(self):
        for record in self:
            evidence = record.evidence_ids
            record.evidence_total_count = len(evidence)
            record.evidence_missing_count = len(
                evidence.filtered(lambda r: r.state == "missing"))

    @api.model_create_multi
    def create(self, vals_list):
        courses = super().create(vals_list)
        courses.action_generate_evidence()
        return courses

    def action_generate_evidence(self):
        """Create the missing evidence placeholders for this course."""
        Evidence = self.env["dhb.evidence.record"]
        Requirement = self.env["dhb.evidence.requirement"]
        for course in self:
            requirements = Requirement.search([
                ("scope", "=", "course"),
                ("body", "=", course.body),
            ])
            existing = course.evidence_ids.mapped("requirement_id")
            for requirement in requirements:
                if requirement in existing:
                    continue
                if not requirement.applies_to_qualification(
                        course.qualification_id):
                    continue
                Evidence.create(
                    requirement._prepare_record_vals_for_course(course))
        return True

    def action_view_evidence(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Course Evidence"),
            "res_model": "dhb.evidence.record",
            "view_mode": "list,form",
            "domain": [("course_id", "=", self.id)],
            "context": {"default_course_id": self.id},
        }

    def action_view_enrolments(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learners"),
            "res_model": "dhb.enrolment",
            "view_mode": "list,form",
            "domain": [("course_id", "=", self.id)],
            "context": {"default_course_id": self.id},
        }
