# -*- coding: utf-8 -*-
"""Scheduled gap reports.

Two different levels of checking, deliberately kept separate:

* Weekly  - learner files. Fast moving, chased per person, per course.
* 15-day  - accreditation evidence. Slower, organisation level, and split by
            Corporate / Silver / Gold so the gap between the status held and
            the evidence held is visible before an inspector points it out.
"""
from odoo import _, api, fields, models
from odoo.tools import html_escape

PARAM_RECIPIENTS = "dhb_accreditation.report_emails"

CSS = """
<style>
 table.dhb { border-collapse: collapse; width: 100%; font-size: 13px;
             font-family: Arial, sans-serif; }
 table.dhb th { background: #1a3d7c; color: #fff; text-align: left;
                padding: 6px 8px; }
 table.dhb td { border-bottom: 1px solid #e0e0e0; padding: 5px 8px; }
 tr.late td { background: #fdecea; }
 h2 { font-family: Arial, sans-serif; color: #1a3d7c; }
 h3 { font-family: Arial, sans-serif; color: #333; margin-bottom: 4px; }
 .gold { color: #b8860b; font-weight: bold; }
 .ok { color: #1e7e34; }
</style>
"""


class DhbGapReport(models.AbstractModel):
    _name = "dhb.gap.report"
    _description = "Accreditation Gap Reports"

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @api.model
    def _get_recipients(self):
        param = self.env["ir.config_parameter"].sudo().get_param(
            PARAM_RECIPIENTS, "")
        emails = [e.strip() for e in param.replace(";", ",").split(",")
                  if e.strip()]
        if not emails:
            company = self.env.company
            if company.email:
                emails = [company.email]
        return emails

    @api.model
    def _send(self, subject, body_html):
        recipients = self._get_recipients()
        if not recipients:
            return False
        mail = self.env["mail.mail"].sudo().create({
            "subject": subject,
            "body_html": body_html,
            "email_to": ",".join(recipients),
            "auto_delete": False,
        })
        mail.send()
        return True

    # ------------------------------------------------------------------
    # Weekly learner report
    # ------------------------------------------------------------------
    @api.model
    def _build_learner_report(self):
        Evidence = self.env["dhb.evidence.record"]
        missing = Evidence.search([
            ("state", "in", ["missing", "expired"]),
            ("scope", "=", "learner"),
            ("enrollment_id.enrollment_status", "not in", ["withdrawn"]),
        ], order="batch_id, days_overdue desc")

        if not missing:
            return None, 0

        by_batch = {}
        for record in missing:
            by_batch.setdefault(record.batch_id, []).append(record)

        parts = [CSS, "<h2>Weekly Learner Evidence Check</h2>"]
        parts.append("<p>%s missing items across %s batch(es), "
                     "as at %s.</p>" % (
                         len(missing), len(by_batch),
                         fields.Date.context_today(self)))

        for batch, records in by_batch.items():
            parts.append("<h3>%s &mdash; %s</h3>" % (
                html_escape(batch.name or _("No batch assigned")),
                html_escape(batch.qualification or "")))
            parts.append('<table class="dhb"><tr>'
                         "<th>Learner</th><th>Booking Ref</th>"
                         "<th>Missing Evidence</th><th>Due</th>"
                         "<th>Days Overdue</th></tr>")
            for record in records:
                row_class = "late" if record.days_overdue > 0 else ""
                parts.append(
                    '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td>'
                    "<td>%s</td><td>%s</td></tr>" % (
                        row_class,
                        html_escape(record.student_id.name or ""),
                        html_escape(
                            record.enrollment_id.exam_booking_ref or "-"),
                        html_escape(record.requirement_id.name or ""),
                        record.date_due or "-",
                        record.days_overdue or ""))
            parts.append("</table>")

        return "".join(parts), len(missing)

    @api.model
    def _cron_learner_report(self):
        body, count = self._build_learner_report()
        if not body:
            body = (CSS + "<h2>Weekly Learner Evidence Check</h2>"
                    '<p class="ok">No missing learner evidence. '
                    "All files complete.</p>")
        self._send("DHB - Weekly Learner Evidence Check (%s gaps)" % count,
                   body)
        return True

    # ------------------------------------------------------------------
    # Fortnightly accreditation report
    # ------------------------------------------------------------------
    @api.model
    def _build_accreditation_report(self):
        Evidence = self.env["dhb.evidence.record"]
        Principle = self.env["dhb.principle"]

        parts = [CSS, "<h2>Accreditation Evidence Status</h2>"]
        parts.append("<p>As at %s. DHB holds <b>Gold</b> Learning Partner "
                     "status, so the Gold column is the one that matters.</p>"
                     % fields.Date.context_today(self))

        # --- coverage per principle, split by level ---------------------
        parts.append('<table class="dhb"><tr><th>Principle</th>'
                     "<th>Corporate</th><th>Silver</th><th>Gold</th>"
                     "<th>Missing</th></tr>")
        for principle in Principle.search([], order="body, sequence"):
            cells = []
            for level in ("corporate", "silver", "gold"):
                total = Evidence.search_count([
                    ("principle_id", "=", principle.id),
                    ("level", "=", level),
                    ("state", "!=", "na")])
                held = Evidence.search_count([
                    ("principle_id", "=", principle.id),
                    ("level", "=", level),
                    ("state", "in", ["uploaded", "approved"])])
                label = "%s/%s" % (held, total) if total else "-"
                if level == "gold" and total and held < total:
                    label = '<span class="gold">%s</span>' % label
                cells.append(label)
            missing = Evidence.search_count([
                ("principle_id", "=", principle.id),
                ("state", "in", ["missing", "expired"])])
            parts.append("<tr><td>%s %s</td><td>%s</td><td>%s</td>"
                         "<td>%s</td><td>%s</td></tr>" % (
                             html_escape(principle.code or ""),
                             html_escape(principle.name or ""),
                             cells[0], cells[1], cells[2], missing or ""))
        parts.append("</table>")

        # --- open action points -----------------------------------------
        actions = self.env["dhb.audit.action"].search(
            [("stage", "!=", "impact")], order="deadline")
        parts.append("<h3>Open Action Points (%s)</h3>" % len(actions))
        if actions:
            parts.append('<table class="dhb"><tr><th>Body</th>'
                         "<th>Action</th><th>Deadline</th><th>Age (days)</th>"
                         "<th>Stage</th></tr>")
            for action in actions:
                row_class = "late" if action.is_overdue else ""
                parts.append(
                    '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td>'
                    "<td>%s</td><td>%s</td></tr>" % (
                        row_class,
                        html_escape(
                            dict(action._fields["body"].selection).get(
                                action.body, "")),
                        html_escape(action.name or ""),
                        action.deadline or "-",
                        action.age_days if action.age_days > 0 else "",
                        html_escape(
                            dict(action._fields["stage"].selection).get(
                                action.stage, ""))))
            parts.append("</table>")

        # --- expiring documents -----------------------------------------
        documents = self.env["dhb.org.document"].search(
            [("state", "in", ["expired", "expiring"])], order="date_expiry")
        parts.append("<h3>Documents Expired or Expiring (%s)</h3>"
                     % len(documents))
        if documents:
            parts.append('<table class="dhb"><tr><th>Document</th>'
                         "<th>Type</th><th>Expiry</th><th>Status</th></tr>")
            for document in documents:
                row_class = "late" if document.state == "expired" else ""
                parts.append(
                    '<tr class="%s"><td>%s</td><td>%s</td><td>%s</td>'
                    "<td>%s</td></tr>" % (
                        row_class,
                        html_escape(document.name or ""),
                        html_escape(
                            dict(document._fields["doc_type"].selection).get(
                                document.doc_type, "")),
                        document.date_expiry or "-",
                        html_escape(
                            dict(document._fields["state"].selection).get(
                                document.state, ""))))
            parts.append("</table>")

        return "".join(parts)

    @api.model
    def _cron_accreditation_report(self):
        body = self._build_accreditation_report()
        self._send("DHB - Accreditation Evidence Status", body)
        return True
