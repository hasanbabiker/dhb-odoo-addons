# -*- coding: utf-8 -*-
"""Bridge onto the existing DHB models.

This module deliberately creates NO learner, course or enrolment models of its
own. dhb.student / dhb.enrollment / dhb.training_batch already exist and are
the single source of truth; evidence records hang off them.

One additive field is introduced: dhb.training_batch.tutor_employee_id.
The existing trainer_name is a free-text Char, which makes per-tutor pass-rate
analysis impossible - and that analysis is an explicit NEBOSH Principle 4
requirement. trainer_name is left untouched.
"""
from odoo import _, api, fields, models


class DhbEnrollment(models.Model):
    _inherit = "dhb.enrollment"

    evidence_ids = fields.One2many(
        "dhb.evidence.record", "enrollment_id", string="Accreditation Evidence")
    evidence_total_count = fields.Integer(
        string="Evidence Required", compute="_compute_evidence_counts", store=True)
    evidence_missing_count = fields.Integer(
        string="Evidence Missing", compute="_compute_evidence_counts", store=True)
    evidence_complete_rate = fields.Float(
        string="File Complete %", compute="_compute_evidence_counts", store=True)

    @api.depends("evidence_ids", "evidence_ids.state")
    def _compute_evidence_counts(self):
        for record in self:
            evidence = record.evidence_ids
            total = len(evidence.filtered(lambda r: r.state != "na"))
            missing = len(evidence.filtered(
                lambda r: r.state in ("missing", "expired")))
            record.evidence_total_count = total
            record.evidence_missing_count = missing
            record.evidence_complete_rate = (
                100.0 * (total - missing) / total) if total else 0.0

    @api.model_create_multi
    def create(self, vals_list):
        enrollments = super().create(vals_list)
        enrollments.action_generate_evidence()
        return enrollments

    def action_generate_evidence(self):
        """Create one 'missing' placeholder per learner-scope requirement.

        The gap is created up front so the weekly report can show it, instead
        of being discovered at audit time.
        """
        Evidence = self.env["dhb.evidence.record"]
        Requirement = self.env["dhb.evidence.requirement"]
        for enrollment in self:
            body = enrollment._dhb_body()
            requirements = Requirement.search([
                ("scope", "=", "learner"), ("body", "=", body)])
            existing = enrollment.evidence_ids.mapped("requirement_id")
            for requirement in requirements:
                if requirement in existing:
                    continue
                if not requirement.applies_to_qualification_code(
                        enrollment.qualification):
                    continue
                Evidence.create(
                    requirement._prepare_record_vals_for_enrollment(enrollment))
        self._sync_kyc_evidence()
        return True

    def _dhb_body(self):
        """IOSH qualifications are prefixed iosh_; everything else is NEBOSH."""
        self.ensure_one()
        return "iosh" if (self.qualification or "").startswith("iosh") \
            else "nebosh"

    def _sync_kyc_evidence(self):
        """Auto-satisfy the ID-check evidence from the existing KYC workflow.

        dhb.student already carries kyc_status and blocks enrolment until it
        passes, so asking a user to upload the same proof again would be
        duplicate data entry.
        """
        today = fields.Date.context_today(self)
        for enrollment in self:
            records = enrollment.evidence_ids.filtered(
                lambda r: r.requirement_id.code in ("LRN-ID", "LRN-IOSH-ID"))
            if not records:
                continue
            if enrollment.student_id.kyc_status == "passed":
                records.filtered(lambda r: r.state == "missing").write({
                    "state": "approved",
                    "date_provided": today,
                    "date_expiry": enrollment.student_id.kyc_doc_expiry,
                    "reference": _("Auto-verified from KYC (%s)",
                                   enrollment.student_id.kyc_doc_type or "-"),
                })
            elif enrollment.student_id.kyc_status == "expired":
                records.filtered(lambda r: r.state == "approved").write(
                    {"state": "expired"})

    @api.model
    def _cron_sync_kyc_evidence(self):
        self.search([]) ._sync_kyc_evidence()
        return True

    def action_view_evidence(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learner Evidence"),
            "res_model": "dhb.evidence.record",
            "view_mode": "list,form",
            "domain": [("enrollment_id", "=", self.id)],
            "context": {"default_enrollment_id": self.id},
        }


class DhbTrainingBatch(models.Model):
    _inherit = "dhb.training_batch"

    tutor_employee_id = fields.Many2one(
        "hr.employee", string="Tutor (linked)", tracking=True,
        help="Links the batch to an employee record so per-tutor pass-rate "
             "analysis is possible. NEBOSH Principle 4 requires monitoring of "
             "tutors to include pass-rate analysis of their own learners. "
             "The free-text Trainer field is left unchanged.")
    co_tutor_employee_id = fields.Many2one(
        "hr.employee", string="Co-Tutor (linked)")

    evidence_ids = fields.One2many(
        "dhb.evidence.record", "batch_id", string="Batch Evidence")
    evidence_missing_count = fields.Integer(
        string="Evidence Missing", compute="_compute_batch_evidence", store=True)

    ratio_compliant = fields.Boolean(
        string="Within 1:20 Ratio", compute="_compute_ratio_compliant",
        store=True,
        help="NEBOSH requires no more than 20 learners to 1 tutor.")

    @api.depends("evidence_ids", "evidence_ids.state")
    def _compute_batch_evidence(self):
        for record in self:
            record.evidence_missing_count = len(
                record.evidence_ids.filtered(
                    lambda r: r.state in ("missing", "expired")))

    @api.depends("current_learner_count", "co_trainer_name",
                 "co_tutor_employee_id")
    def _compute_ratio_compliant(self):
        for record in self:
            tutors = 2 if (record.co_trainer_name
                           or record.co_tutor_employee_id) else 1
            record.ratio_compliant = record.current_learner_count <= 20 * tutors

    @api.model_create_multi
    def create(self, vals_list):
        batches = super().create(vals_list)
        batches.action_generate_evidence()
        return batches

    def action_generate_evidence(self):
        Evidence = self.env["dhb.evidence.record"]
        Requirement = self.env["dhb.evidence.requirement"]
        for batch in self:
            body = "iosh" if (batch.qualification or "").startswith("iosh") \
                else "nebosh"
            requirements = Requirement.search([
                ("scope", "=", "course"), ("body", "=", body)])
            existing = batch.evidence_ids.mapped("requirement_id")
            for requirement in requirements:
                if requirement in existing:
                    continue
                if not requirement.applies_to_qualification_code(
                        batch.qualification):
                    continue
                Evidence.create(
                    requirement._prepare_record_vals_for_batch(batch))
        return True

    def action_view_evidence(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Batch Evidence"),
            "res_model": "dhb.evidence.record",
            "view_mode": "list,form",
            "domain": [("batch_id", "=", self.id)],
            "context": {"default_batch_id": self.id},
        }


class HrEmployeeTutorStats(models.Model):
    _inherit = "hr.employee"

    dhb_batch_ids = fields.One2many(
        "dhb.training_batch", "tutor_employee_id", string="Batches Taught")
    dhb_batch_count = fields.Integer(
        string="Batches", compute="_compute_dhb_tutor_stats")
    dhb_pass_rate = fields.Float(
        string="Tutor Pass Rate %", compute="_compute_dhb_tutor_stats",
        help="Pass rate across every learner this tutor has taught. "
             "Required evidence for NEBOSH Principle 4.")
    dhb_learners_assessed = fields.Integer(
        string="Learners Assessed", compute="_compute_dhb_tutor_stats")

    @api.depends("dhb_batch_ids.enrollment_ids.result")
    def _compute_dhb_tutor_stats(self):
        passing = ("pass", "credit", "distinction")
        for employee in self:
            enrollments = employee.dhb_batch_ids.mapped("enrollment_ids")
            sat = enrollments.filtered(
                lambda e: e.result in passing + ("fail",))
            passed = sat.filtered(lambda e: e.result in passing)
            employee.dhb_batch_count = len(employee.dhb_batch_ids)
            employee.dhb_learners_assessed = len(sat)
            employee.dhb_pass_rate = (
                100.0 * len(passed) / len(sat)) if sat else 0.0


class DhbStudentLink(models.Model):
    """Link the learner file to a contact, and roll its evidence up.

    Learners belong in dhb.student - that model already carries KYC, data
    retention and Moodle progress, and the accreditation evidence hangs off
    dhb.enrollment which points here. res.partner stays what Odoo means it to
    be: the accounting/contact record. partner_id keeps the two joined so
    invoicing still works.
    """
    _inherit = "dhb.student"

    partner_id = fields.Many2one(
        "res.partner", string="Contact", tracking=True, index=True,
        help="The accounting/contact record for this learner. Invoices and "
             "payments live there; the learner file lives here.")

    evidence_ids = fields.One2many(
        "dhb.evidence.record", "student_id", string="Accreditation Evidence")
    evidence_total_count = fields.Integer(
        string="Evidence Required", compute="_compute_student_evidence")
    evidence_missing_count = fields.Integer(
        string="Evidence Missing", compute="_compute_student_evidence")
    evidence_complete_rate = fields.Float(
        string="File Complete %", compute="_compute_student_evidence")

    @api.depends("evidence_ids", "evidence_ids.state")
    def _compute_student_evidence(self):
        for student in self:
            evidence = student.evidence_ids
            total = len(evidence.filtered(lambda r: r.state != "na"))
            missing = len(evidence.filtered(
                lambda r: r.state in ("missing", "expired")))
            student.evidence_total_count = total
            student.evidence_missing_count = missing
            student.evidence_complete_rate = (
                100.0 * (total - missing) / total) if total else 0.0

    def action_create_contact(self):
        """Create the matching res.partner for learners that lack one."""
        Partner = self.env["res.partner"]
        for student in self.filtered(lambda s: not s.partner_id):
            student.partner_id = Partner.create({
                "name": student.name,
                "email": student.email or False,
                "phone": student.phone or False,
                "country_id": student.country_of_residence_id.id or False,
            }).id
        return True

    def action_view_evidence(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learner Evidence"),
            "res_model": "dhb.evidence.record",
            "view_mode": "list,form",
            "domain": [("student_id", "=", self.id)],
        }


class ResPartnerLearner(models.Model):
    _inherit = "res.partner"

    dhb_student_ids = fields.One2many(
        "dhb.student", "partner_id", string="Learner Files")
    dhb_student_count = fields.Integer(
        string="Learner File Count", compute="_compute_dhb_student_count")

    @api.depends("dhb_student_ids")
    def _compute_dhb_student_count(self):
        for partner in self:
            partner.dhb_student_count = len(partner.dhb_student_ids)

    def action_view_learner_file(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learner File"),
            "res_model": "dhb.student",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
            "context": {"default_partner_id": self.id,
                        "default_name": self.name,
                        "default_email": self.email},
        }
