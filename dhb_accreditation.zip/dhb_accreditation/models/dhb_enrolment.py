# -*- coding: utf-8 -*-
from odoo import _, api, fields, models


class DhbEnrolment(models.Model):
    _name = "dhb.enrolment"
    _description = "Learner Enrolment"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_enrol desc, id desc"
    _rec_name = "name"

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True, tracking=True)
    course_id = fields.Many2one(
        "dhb.course", string="Course", required=True,
        ondelete="cascade", tracking=True)
    qualification_id = fields.Many2one(
        related="course_id.qualification_id", string="Qualification",
        store=True)
    body = fields.Selection(
        related="course_id.body", string="Awarding Body", store=True)
    learner_number = fields.Char(string="Learner Number", tracking=True)
    date_enrol = fields.Date(
        string="Enrolment Date", default=fields.Date.context_today,
        required=True)

    state = fields.Selection(
        [("draft", "Registered"),
         ("active", "Studying"),
         ("assessed", "Assessed"),
         ("complete", "Completed"),
         ("withdrawn", "Withdrawn")],
        string="Status", default="draft", tracking=True)
    withdrawal_reason = fields.Text(
        string="Reason Not Completed",
        help="Required for Gold: reasons must be recorded when learners do "
             "not complete a qualification.")

    evidence_ids = fields.One2many(
        "dhb.evidence.record", "enrolment_id", string="Learner Evidence")
    evidence_missing_count = fields.Integer(
        string="Missing", compute="_compute_evidence_counts", store=True)
    evidence_total_count = fields.Integer(
        string="Required", compute="_compute_evidence_counts", store=True)
    evidence_complete_rate = fields.Float(
        string="Complete %", compute="_compute_evidence_counts", store=True)

    name = fields.Char(
        string="Name", compute="_compute_name", store=True)

    _learner_course_uniq = models.Constraint(
        "unique (partner_id, course_id)",
        "This learner is already enrolled on this course.",
    )

    @api.depends("partner_id.name", "course_id.name")
    def _compute_name(self):
        for record in self:
            record.name = "%s / %s" % (
                record.partner_id.name or "", record.course_id.name or "")

    @api.depends("evidence_ids", "evidence_ids.state")
    def _compute_evidence_counts(self):
        for record in self:
            evidence = record.evidence_ids
            total = len(evidence)
            missing = len(evidence.filtered(lambda r: r.state == "missing"))
            record.evidence_total_count = total
            record.evidence_missing_count = missing
            record.evidence_complete_rate = (
                100.0 * (total - missing) / total) if total else 0.0

    @api.model_create_multi
    def create(self, vals_list):
        enrolments = super().create(vals_list)
        enrolments.action_generate_evidence()
        return enrolments

    def action_generate_evidence(self):
        """Create one 'missing' evidence placeholder per learner requirement.

        This is the heart of the system: the gap is created up front, so the
        weekly report can show it, rather than being discovered at audit time.
        """
        Evidence = self.env["dhb.evidence.record"]
        Requirement = self.env["dhb.evidence.requirement"]
        for enrolment in self:
            requirements = Requirement.search([
                ("scope", "=", "learner"),
                ("body", "=", enrolment.body),
            ])
            existing = enrolment.evidence_ids.mapped("requirement_id")
            for requirement in requirements:
                if requirement in existing:
                    continue
                if not requirement.applies_to_qualification(
                        enrolment.qualification_id):
                    continue
                Evidence.create(
                    requirement._prepare_record_vals_for_enrolment(enrolment))
        return True

    def action_view_evidence(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learner Evidence"),
            "res_model": "dhb.evidence.record",
            "view_mode": "list,form",
            "domain": [("enrolment_id", "=", self.id)],
            "context": {"default_enrolment_id": self.id},
        }
