# -*- coding: utf-8 -*-
from dateutil.relativedelta import relativedelta

from odoo import _, api, fields, models

DOC_TYPE_SELECTION = [
    ("insurance", "Insurance"),
    ("policy", "Policy"),
    ("licence", "Material Licence"),
    ("agreement", "Agreement"),
    ("certificate", "Certificate"),
    ("other", "Other"),
]

REMINDER_DAYS = (90, 30, 7)


class DhbOrgDocument(models.Model):
    """Standing documents that expire: insurance, policies, licences.

    The insurance line in the August 2025 EQA report was dated 04/08/2022 and
    nothing flagged it. This model exists so that cannot happen again.
    """
    _name = "dhb.org.document"
    _description = "Organisation Document"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_expiry, id"

    name = fields.Char(string="Document", required=True, tracking=True)
    doc_type = fields.Selection(
        DOC_TYPE_SELECTION, string="Type", required=True,
        default="policy", tracking=True)
    reference = fields.Char(string="Reference / Number")
    issuer = fields.Char(string="Issued By")

    date_issue = fields.Date(string="Issue / Creation Date", tracking=True)
    date_expiry = fields.Date(string="Expiry / Review Date", tracking=True)
    review_months = fields.Integer(
        string="Review Cycle (months)", default=12,
        help="Used to propose the next review date when the document is "
             "renewed.")

    responsible_id = fields.Many2one(
        "res.users", string="Responsible",
        default=lambda self: self.env.user, tracking=True)
    attachment_ids = fields.Many2many(
        "ir.attachment", string="Files")
    note = fields.Text(string="Notes")
    active = fields.Boolean(string="Active", default=True)

    state = fields.Selection(
        [("valid", "Valid"),
         ("expiring", "Expiring Soon"),
         ("expired", "Expired"),
         ("unknown", "No Expiry Set")],
        string="Status", compute="_compute_state", store=True, index=True)
    days_to_expiry = fields.Integer(
        string="Days to Expiry", compute="_compute_state", store=True)
    last_reminder_days = fields.Integer(
        string="Last Reminder Threshold", default=0, copy=False)

    @api.depends("date_expiry")
    def _compute_state(self):
        today = fields.Date.context_today(self)
        for record in self:
            if not record.date_expiry:
                record.state = "unknown"
                record.days_to_expiry = 0
                continue
            delta = (record.date_expiry - today).days
            record.days_to_expiry = delta
            if delta < 0:
                record.state = "expired"
            elif delta <= REMINDER_DAYS[0]:
                record.state = "expiring"
            else:
                record.state = "valid"

    def action_renew(self):
        """Roll the review date forward by the review cycle.

        The base is whichever is later: the current expiry date or today.
        Rolling forward from a stale date would leave a document that expired
        three years ago still expired after 'renewing' it.
        """
        for record in self:
            today = fields.Date.context_today(record)
            base = max(record.date_expiry, today) if record.date_expiry \
                else today
            record.write({
                "date_issue": today,
                "date_expiry": base + relativedelta(
                    months=record.review_months or 12),
                "last_reminder_days": 0,
            })
        return True

    @api.model
    def _cron_expiry_reminders(self):
        """Raise an activity on the responsible user at 90 / 30 / 7 days."""
        today = fields.Date.context_today(self)
        documents = self.search([("date_expiry", "!=", False)])
        for document in documents:
            delta = (document.date_expiry - today).days
            threshold = None
            for days in REMINDER_DAYS:
                if delta <= days:
                    threshold = days
                    break
            if threshold is None:
                continue
            if document.last_reminder_days == threshold:
                continue
            if delta < 0:
                summary = _("EXPIRED: %s", document.name)
            else:
                summary = _("%s expires in %s days", document.name, delta)
            document.activity_schedule(
                "mail.mail_activity_data_todo",
                summary=summary,
                user_id=(document.responsible_id.id
                         or self.env.user.id),
            )
            document.last_reminder_days = threshold
        return True


class HrEmployee(models.Model):
    _inherit = "hr.employee"

    dhb_is_tutor = fields.Boolean(
        string="Is a Tutor",
        help="Tick to generate the tutor evidence file for this person.")
    dhb_evidence_ids = fields.One2many(
        "dhb.evidence.record", "employee_id", string="Tutor Evidence")
    dhb_evidence_missing_count = fields.Integer(
        string="Missing Evidence", compute="_compute_dhb_evidence_counts")

    @api.depends("dhb_evidence_ids", "dhb_evidence_ids.state")
    def _compute_dhb_evidence_counts(self):
        for employee in self:
            employee.dhb_evidence_missing_count = len(
                employee.dhb_evidence_ids.filtered(
                    lambda r: r.state == "missing"))

    def action_generate_tutor_evidence(self):
        Evidence = self.env["dhb.evidence.record"]
        Requirement = self.env["dhb.evidence.requirement"]
        requirements = Requirement.search([("scope", "=", "tutor")])
        for employee in self.filtered("dhb_is_tutor"):
            existing = employee.dhb_evidence_ids.mapped("requirement_id")
            for requirement in requirements:
                if requirement in existing:
                    continue
                Evidence.create(
                    requirement._prepare_record_vals_for_employee(employee))
        return True

    @api.model_create_multi
    def create(self, vals_list):
        employees = super().create(vals_list)
        tutors = employees.filtered("dhb_is_tutor")
        if tutors:
            tutors.action_generate_tutor_evidence()
        return employees

    def write(self, vals):
        result = super().write(vals)
        if vals.get("dhb_is_tutor"):
            self.action_generate_tutor_evidence()
        return result
