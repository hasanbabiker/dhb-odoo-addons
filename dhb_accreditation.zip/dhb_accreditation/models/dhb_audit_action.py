# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .dhb_principle import BODY_SELECTION

STAGE_SELECTION = [
    ("open", "Open"),
    ("done", "Actioned"),
    ("submitted", "Submitted to Body"),
    ("closed", "Closure Confirmed"),
    ("impact", "Impact Measured"),
]


class DhbAuditAction(models.Model):
    """One row per action point raised by NEBOSH, IOSH or an internal audit.

    The final stage is deliberately 'Impact Measured' and not 'Closed'.
    Silver-level evidence is an action plan; Gold-level evidence is proof that
    the action was completed *and that its impact was demonstrated*. A register
    without an impact field can only ever read as Silver.
    """
    _name = "dhb.audit.action"
    _description = "Audit Action Point"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "deadline, id"

    name = fields.Char(string="Action", required=True, tracking=True)
    body = fields.Selection(
        BODY_SELECTION + [("internal", "Internal Audit")],
        string="Raised By", required=True, default="nebosh", tracking=True)
    source_report = fields.Char(
        string="Source Report",
        help="e.g. '1708 P3 and P4 audit - 24/07/2024'")
    report_date = fields.Date(string="Report Date", tracking=True)
    principle_id = fields.Many2one("dhb.principle", string="Principle")

    deadline = fields.Date(string="Original Deadline", tracking=True)
    responsible_id = fields.Many2one(
        "res.users", string="Responsible",
        default=lambda self: self.env.user, tracking=True)

    stage = fields.Selection(
        STAGE_SELECTION, string="Stage", default="open",
        required=True, tracking=True, group_expand="_group_expand_stage")
    priority = fields.Selection(
        [("0", "Normal"), ("1", "High"), ("2", "Critical")],
        string="Priority", default="0", tracking=True)

    date_actioned = fields.Date(string="Date Actioned")
    date_submitted = fields.Date(string="Date Submitted to Body")
    date_closed = fields.Date(string="Date Closure Confirmed")
    impact_evidence = fields.Text(
        string="Impact Evidence",
        help="What measurably changed. Required to reach the final stage.")

    attachment_ids = fields.Many2many(
        "ir.attachment", string="Supporting Files")
    note = fields.Html(string="Detail")

    age_days = fields.Integer(
        string="Age (days)", compute="_compute_age_days", store=True)
    is_overdue = fields.Boolean(
        string="Overdue", compute="_compute_age_days", store=True)

    @api.depends("deadline", "stage")
    def _compute_age_days(self):
        today = fields.Date.context_today(self)
        for record in self:
            if record.deadline:
                record.age_days = (today - record.deadline).days
            else:
                record.age_days = 0
            record.is_overdue = bool(
                record.deadline
                and record.deadline < today
                and record.stage != "impact")

    @api.model
    def _group_expand_stage(self, stages, domain):
        return [key for key, _label in STAGE_SELECTION]

    @api.constrains("stage", "impact_evidence")
    def _check_impact_evidence(self):
        for record in self:
            if record.stage == "impact" and not record.impact_evidence:
                raise UserError(_(
                    "Record the impact evidence before moving '%s' to the "
                    "Impact Measured stage. Without it the action reads as "
                    "Silver-level evidence, not Gold.", record.name))

    def action_set_actioned(self):
        self.write({"stage": "done",
                    "date_actioned": fields.Date.context_today(self)})

    def action_set_submitted(self):
        self.write({"stage": "submitted",
                    "date_submitted": fields.Date.context_today(self)})

    def action_set_closed(self):
        self.write({"stage": "closed",
                    "date_closed": fields.Date.context_today(self)})

    def action_set_impact(self):
        self.write({"stage": "impact"})
