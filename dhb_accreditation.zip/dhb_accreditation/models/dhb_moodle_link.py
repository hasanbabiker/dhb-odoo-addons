# -*- coding: utf-8 -*-
"""Join the two halves of the system.

Moodle, contacts and invoicing all hang off res.partner. The accreditation
file - identity, evidence, KYC - hangs off dhb.student. One learner therefore
has two records that know nothing about each other, and the Moodle progress
fields on dhb.student sit permanently empty even though the data exists.

This bridge copies the Moodle identifiers across the partner_id link, so the
learner file shows the platform progress that NEBOSH Principle 5 asks for.

Nothing here touches moodle_connector or dhb_student. Every field is guarded:
if moodle_connector is not installed, the sync quietly does nothing rather
than failing.
"""
import logging

from odoo import _, api, fields, models

_logger = logging.getLogger(__name__)

# fields moodle_connector adds to res.partner, copied onto the learner file
PARTNER_TO_STUDENT = {
    "moodle_user_id": "moodle_user_id",
}


class DhbStudentMoodleLink(models.Model):
    _inherit = "dhb.student"

    moodle_username = fields.Char(
        string="Moodle Username", compute="_compute_moodle_from_partner",
        store=True, readonly=True)
    moodle_enrolment_count = fields.Integer(
        string="Moodle Enrolments", compute="_compute_moodle_from_partner",
        store=True, readonly=True)
    moodle_linked = fields.Boolean(
        string="On the Platform", compute="_compute_moodle_from_partner",
        store=True, readonly=True,
        help="True once the learner file is joined to a contact that has a "
             "Moodle account.")

    @api.depends("partner_id")
    def _compute_moodle_from_partner(self):
        """Pull the platform identifiers through the contact link."""
        partner_fields = self.env["res.partner"]._fields
        has_username = "moodle_username" in partner_fields
        has_count = "moodle_enrolment_count" in partner_fields
        has_uid = "moodle_user_id" in partner_fields
        for student in self:
            partner = student.partner_id
            student.moodle_username = (
                partner.moodle_username if partner and has_username else False)
            student.moodle_enrolment_count = (
                partner.moodle_enrolment_count
                if partner and has_count else 0)
            student.moodle_linked = bool(
                partner and has_uid and partner.moodle_user_id)

    def _sync_moodle_ids(self):
        """Copy the raw Moodle ids onto the learner file.

        moodle_user_id already exists on dhb.student but is never populated,
        because moodle_connector only writes to res.partner. This fills it in
        so the field finally means something.
        """
        partner_fields = self.env["res.partner"]._fields
        for student in self:
            partner = student.partner_id
            if not partner:
                continue
            values = {}
            for source, target in PARTNER_TO_STUDENT.items():
                if source not in partner_fields:
                    continue
                value = partner[source]
                if value and student[target] != value:
                    values[target] = value
            if values:
                student.write(values)
        return True

    def _dhb_autolink_contact(self):
        """Join every learner file to a contact, without being asked.

        Leaving the link optional is what let the two halves drift apart in
        the first place, so this runs by itself: match on e-mail if a contact
        already exists, otherwise create one. Either way the learner ends up
        as a single connected record.
        """
        Partner = self.env["res.partner"]
        for student in self.filtered(lambda s: not s.partner_id):
            partner = False
            if student.email:
                partner = Partner.search(
                    [("email", "=ilike", student.email)], order="id", limit=1)
            if not partner:
                partner = Partner.create({
                    "name": student.name,
                    "email": student.email or False,
                    "phone": student.phone or False,
                    "country_id": student.country_of_residence_id.id or False,
                    "image_1920": student.image_1920 or False,
                })
                _logger.info("dhb_accreditation: created a contact for %s",
                             student.name)
            student.partner_id = partner.id
        self._sync_moodle_ids()
        return True

    def action_link_contact_by_email(self):
        """Kept so the button still works if anyone reaches for it."""
        return self._dhb_autolink_contact()

    @api.model
    def _cron_sync_moodle(self):
        """Nightly: link anything still loose, then refresh the ids."""
        self.search([("partner_id", "=", False)])._dhb_autolink_contact()
        self.search([("partner_id", "!=", False)])._sync_moodle_ids()
        return True

    @api.model_create_multi
    def create(self, vals_list):
        students = super().create(vals_list)
        students._dhb_autolink_contact()
        return students

    # learner field -> contact field, kept in step after the link is made
    STUDENT_TO_PARTNER = {
        "name": "name",
        "email": "email",
        "phone": "phone",
        "image_1920": "image_1920",
    }

    def _push_to_contact(self, changed):
        """Carry learner details onto the contact it is linked to.

        The contact is created from the learner file, so anything filled in
        afterwards - a photograph, a corrected name - would otherwise only
        exist on one side.
        """
        for student in self.filtered("partner_id"):
            values = {}
            for source, target in self.STUDENT_TO_PARTNER.items():
                if source not in changed:
                    continue
                value = student[source]
                if value and student.partner_id[target] != value:
                    values[target] = value
            if values:
                student.partner_id.write(values)
        return True

    def write(self, vals):
        result = super().write(vals)
        if "partner_id" in vals:
            self._sync_moodle_ids()
        if "email" in vals:
            self._dhb_autolink_contact()
        touched = set(vals) & set(self.STUDENT_TO_PARTNER)
        if touched:
            self._push_to_contact(touched)
        return result

    def action_create_contact(self):
        result = super().action_create_contact()
        self._sync_moodle_ids()
        return result


class ResPartnerMoodleLink(models.Model):
    _inherit = "res.partner"

    def write(self, vals):
        """When Moodle updates the contact, push it to the learner file."""
        result = super().write(vals)
        if any(key in vals for key in PARTNER_TO_STUDENT):
            students = self.env["dhb.student"].search(
                [("partner_id", "in", self.ids)])
            if students:
                students._sync_moodle_ids()
        return result
