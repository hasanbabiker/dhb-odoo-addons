# -*- coding: utf-8 -*-
"""Join the two halves of the system.

Moodle, contacts and invoicing all hang off res.partner. The accreditation
file - identity, evidence, KYC - hangs off dhb.student. One learner therefore
has two records that know nothing about each other, and the Moodle progress
fields on dhb.student sit permanently empty even though the data exists.

This bridge copies the Moodle identifiers across the partner_id link, so the
learner file shows the platform progress that NEBOSH Principle 5 asks for.

Nothing here touches moodle_connector or dhb_student. Every field is guarded:
if moodle_connector is not installed, the sync quietly does nothing rather
than failing.
"""
import logging

from odoo import _, api, fields, models

_logger = logging.getLogger(__name__)

# fields moodle_connector adds to res.partner, copied onto the learner file
PARTNER_TO_STUDENT = {
    "moodle_user_id": "moodle_user_id",
}


class DhbStudentMoodleLink(models.Model):
    _inherit = "dhb.student"

    moodle_username = fields.Char(
        string="Moodle Username", compute="_compute_moodle_from_partner",
        store=True, readonly=True)
    moodle_enrolment_count = fields.Integer(
        string="Moodle Enrolments", compute="_compute_moodle_from_partner",
        store=True, readonly=True)
    moodle_linked = fields.Boolean(
        string="On the Platform", compute="_compute_moodle_from_partner",
        store=True, readonly=True,
        help="True once the learner file is joined to a contact that has a "
             "Moodle account.")

    @api.depends("partner_id")
    def _compute_moodle_from_partner(self):
        """Pull the platform identifiers through the contact link."""
        partner_fields = self.env["res.partner"]._fields
        has_username = "moodle_username" in partner_fields
        has_count = "moodle_enrolment_count" in partner_fields
        has_uid = "moodle_user_id" in partner_fields
        for student in self:
            partner = student.partner_id
            student.moodle_username = (
                partner.moodle_username if partner and has_username else False)
            student.moodle_enrolment_count = (
                partner.moodle_enrolment_count
                if partner and has_count else 0)
            student.moodle_linked = bool(
                partner and has_uid and partner.moodle_user_id)

    def _sync_moodle_ids(self):
        """Copy the raw Moodle ids onto the learner file.

        moodle_user_id already exists on dhb.student but is never populated,
        because moodle_connector only writes to res.partner. This fills it in
        so the field finally means something.
        """
        partner_fields = self.env["res.partner"]._fields
        for student in self:
            partner = student.partner_id
            if not partner:
                continue
            values = {}
            for source, target in PARTNER_TO_STUDENT.items():
                if source not in partner_fields:
                    continue
                value = partner[source]
                if value and student[target] != value:
                    values[target] = value
            if values:
                student.write(values)
        return True

    def action_link_contact_by_email(self):
        """Join a learner file to the contact that shares its e-mail.

        Records created before the two halves were joined have no partner_id.
        Rather than asking someone to pair them by hand, match on e-mail -
        which is how the same person ends up in both places to begin with.
        """
        Partner = self.env["res.partner"]
        matched = 0
        for student in self.filtered(lambda s: not s.partner_id and s.email):
            partner = Partner.search(
                [("email", "=ilike", student.email)],
                order="id", limit=1)
            if partner:
                student.partner_id = partner.id
                matched += 1
        self._sync_moodle_ids()
        _logger.info("dhb_accreditation: linked %s learner file(s) by e-mail",
                     matched)
        return True

    @api.model
    def _cron_sync_moodle(self):
        """Keep the learner files in step with the platform, nightly."""
        students = self.search([("partner_id", "!=", False)])
        students._sync_moodle_ids()
        return True

    def write(self, vals):
        result = super().write(vals)
        if "partner_id" in vals:
            self._sync_moodle_ids()
        return result

    def action_create_contact(self):
        result = super().action_create_contact()
        self._sync_moodle_ids()
        return result


class ResPartnerMoodleLink(models.Model):
    _inherit = "res.partner"

    def write(self, vals):
        """When Moodle updates the contact, push it to the learner file."""
        result = super().write(vals)
        if any(key in vals for key in PARTNER_TO_STUDENT):
            students = self.env["dhb.student"].search(
                [("partner_id", "in", self.ids)])
            if students:
                students._sync_moodle_ids()
        return result
