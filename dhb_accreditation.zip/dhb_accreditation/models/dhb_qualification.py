# -*- coding: utf-8 -*-
from odoo import api, fields, models

from .dhb_principle import BODY_SELECTION


class DhbQualification(models.Model):
    _name = "dhb.qualification"
    _description = "Accredited Qualification"
    _order = "body, sequence, id"

    name = fields.Char(string="Qualification", required=True)
    code = fields.Char(string="Code", required=True)
    body = fields.Selection(BODY_SELECTION, string="Awarding Body",
                            required=True, default="nebosh")
    sequence = fields.Integer(string="Sequence", default=10)
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text(string="Notes")

    _code_uniq = models.Constraint(
        "unique (code)",
        "The qualification code must be unique.",
    )

    @api.depends("code")
    def _compute_display_name(self):
        for record in self:
            record.display_name = record.code or ""
