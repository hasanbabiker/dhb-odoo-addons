# -*- coding: utf-8 -*-
from dateutil.relativedelta import relativedelta

from odoo import api, fields, models


STATE_SELECTION = [
    ("missing", "Missing"),
    ("uploaded", "Uploaded"),
    ("approved", "Approved"),
    ("expired", "Expired"),
    ("na", "Not Applicable"),
]


class DhbEvidenceRecord(models.Model):
    _name = "dhb.evidence.record"
    _description = "Evidence Record"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "state, date_due, id"
    _rec_name = "name"

    requirement_id = fields.Many2one(
        "dhb.evidence.requirement", string="Requirement",
        required=True, ondelete="restrict")
    scope = fields.Selection(
        related="requirement_id.scope", string="Scope", store=True)
    body = fields.Selection(
        related="requirement_id.body", string="Awarding Body", store=True)
    principle_id = fields.Many2one(
        "dhb.principle", related="requirement_id.principle_id",
        string="Principle", store=True)
    level = fields.Selection(
        related="requirement_id.level", string="Status Level", store=True)

    enrolment_id = fields.Many2one(
        "dhb.enrolment", string="Enrolment", ondelete="cascade", index=True)
    partner_id = fields.Many2one(
        related="enrolment_id.partner_id", string="Learner", store=True)
    course_id = fields.Many2one(
        "dhb.course", string="Course", ondelete="cascade", index=True)
    employee_id = fields.Many2one(
        "hr.employee", string="Tutor", ondelete="cascade", index=True)
    qualification_id = fields.Many2one(
        "dhb.qualification", string="Qualification", index=True)

    state = fields.Selection(
        STATE_SELECTION, string="Status", default="missing",
        required=True, tracking=True, index=True)

    date_due = fields.Date(string="Due Date", index=True)
    date_provided = fields.Date(string="Date Provided")
    date_expiry = fields.Date(string="Expiry Date", index=True)
    days_overdue = fields.Integer(
        string="Days Overdue", compute="_compute_days_overdue",
        store=True, index=True)

    attachment_ids = fields.Many2many(
        "ir.attachment", string="Evidence Files")
    attachment_count = fields.Integer(
        string="Files", compute="_compute_attachment_count")
    reference = fields.Char(
        string="Reference / Location",
        help="Where the evidence lives if it is not attached here.")
    note = fields.Text(string="Notes")

    name = fields.Char(
        string="Name", compute="_compute_name", store=True)

    @api.depends("requirement_id.name", "partner_id.name",
                 "course_id.name", "employee_id.name")
    def _compute_name(self):
        for record in self:
            subject = (record.partner_id.name
                       or record.course_id.name
                       or record.employee_id.name
                       or "")
            label = record.requirement_id.name or ""
            record.name = ("%s - %s" % (label, subject)
                           if subject else label)

    @api.depends("attachment_ids")
    def _compute_attachment_count(self):
        for record in self:
            record.attachment_count = len(record.attachment_ids)

    @api.depends("date_due", "state")
    def _compute_days_overdue(self):
        today = fields.Date.context_today(self)
        for record in self:
            if record.state == "missing" and record.date_due \
                    and record.date_due < today:
                record.days_overdue = (today - record.date_due).days
            else:
                record.days_overdue = 0

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def action_mark_uploaded(self):
        today = fields.Date.context_today(self)
        for record in self:
            values = {"state": "uploaded", "date_provided": today}
            if record.requirement_id.has_expiry \
                    and record.requirement_id.validity_months:
                values["date_expiry"] = today + relativedelta(
                    months=record.requirement_id.validity_months)
            record.write(values)
        return True

    def action_approve(self):
        self.write({"state": "approved"})
        return True

    def action_reset(self):
        self.write({"state": "missing", "date_provided": False})
        return True

    def action_not_applicable(self):
        self.write({"state": "na"})
        return True

    @api.model
    def _cron_learner_report(self):
        """Cron entry point (kept on a concrete model)."""
        return self.env["dhb.gap.report"]._cron_learner_report()

    @api.model
    def _cron_accreditation_report(self):
        """Cron entry point (kept on a concrete model)."""
        return self.env["dhb.gap.report"]._cron_accreditation_report()

    @api.model
    def _cron_flag_expired(self):
        """Move approved/uploaded evidence past its expiry date to Expired."""
        today = fields.Date.context_today(self)
        expired = self.search([
            ("state", "in", ["uploaded", "approved"]),
            ("date_expiry", "!=", False),
            ("date_expiry", "<", today),
        ])
        expired.write({"state": "expired"})
        return len(expired)
