# -*- coding: utf-8 -*-
"""NEBOSH assessment timetable.

The published timetable carries fourteen dates per sitting. Four of them are
hard cut-offs - miss one and the learner loses a whole sitting:

  * exam booking deadline
  * enrolment extension / learner transfer request deadline
  * registration closing date
  * EAR request submission deadline

Those four are what the reminder cron watches.
"""
from datetime import timedelta

from odoo import _, api, fields, models

# (field name, label, days before which to warn)
CRITICAL_DEADLINES = [
    ("booking_deadline", "Exam booking deadline"),
    ("extension_deadline", "Enrolment extension / learner transfer deadline"),
    ("registration_closing", "Registration closing date"),
    ("ear_deadline", "EAR request submission deadline"),
]

REMINDER_DAYS = (30, 14, 7, 3)


class DhbExamSitting(models.Model):
    _name = "dhb.exam.sitting"
    _description = "NEBOSH Assessment Sitting"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "assessment_date, unit"
    _rec_name = "display_name"

    unit = fields.Char(string="Unit", required=True, index=True)
    assessment_date = fields.Date(
        string="Assessment / Paper Release Date", required=True, index=True)
    year = fields.Integer(string="Year", compute="_compute_period", store=True)
    month = fields.Char(string="Month", compute="_compute_period", store=True)

    # --- pre-assessment ---
    setup_form_available = fields.Date(string="Online Exam Setup Form Available")
    booking_deadline = fields.Date(string="Exam Booking Deadline", index=True)
    extension_deadline = fields.Date(
        string="Enrolment Extension / Transfer Deadline", index=True)
    registration_closing = fields.Date(
        string="Registration Closing Date", index=True)
    login_details_sent = fields.Date(string="Login Details Sent")

    # --- submission ---
    digital_open = fields.Date(string="Digital Submission Opens")
    digital_closing = fields.Date(string="Digital Submission Closes")
    lp_download_available = fields.Date(string="LP Download Available")
    lp_download_closing = fields.Date(string="LP Download Closes")
    practical_deadline = fields.Date(string="Practical Submission Deadline")
    closing_interview_deadline = fields.Date(
        string="Closing Interview / PD Deadline")

    # --- results ---
    results_due = fields.Date(string="Results Due By", index=True)
    ear_deadline = fields.Date(string="EAR Request Deadline", index=True)
    ear_declaration = fields.Date(string="EAR Declaration Date")

    batch_ids = fields.One2many(
        "dhb.training_batch", "sitting_id", string="Batches")
    batch_count = fields.Integer(
        string="Batches", compute="_compute_batch_count")

    last_reminder_days = fields.Integer(default=0, copy=False)
    active = fields.Boolean(default=True)
    note = fields.Text(string="Notes")

    display_name = fields.Char(
        string="Name", compute="_compute_display_name", store=True)

    _unit_date_uniq = models.Constraint(
        "unique (unit, assessment_date)",
        "This unit already has a sitting on that date.",
    )

    @api.depends("unit", "assessment_date")
    def _compute_display_name(self):
        for record in self:
            record.display_name = "%s - %s" % (
                record.unit or "", record.assessment_date or "")

    @api.depends("assessment_date")
    def _compute_period(self):
        for record in self:
            if record.assessment_date:
                record.year = record.assessment_date.year
                record.month = record.assessment_date.strftime("%b")
            else:
                record.year = 0
                record.month = False

    @api.depends("batch_ids")
    def _compute_batch_count(self):
        for record in self:
            record.batch_count = len(record.batch_ids)

    def action_view_batches(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Batches"),
            "res_model": "dhb.training_batch",
            "view_mode": "list,form",
            "domain": [("sitting_id", "=", self.id)],
            "context": {"default_sitting_id": self.id},
        }

    # ------------------------------------------------------------------
    # Reminders
    # ------------------------------------------------------------------
    @api.model
    def _cron_deadline_reminders(self):
        """Warn at 30 / 14 / 7 / 3 days before each hard cut-off.

        Only sittings that at least one batch is attached to are chased, so
        the inbox does not fill with dates that are irrelevant to DHB.
        """
        today = fields.Date.context_today(self)
        horizon = today + timedelta(days=max(REMINDER_DAYS))
        rows = []

        sittings = self.search([("batch_ids", "!=", False)])
        for sitting in sittings:
            for fname, label in CRITICAL_DEADLINES:
                deadline = sitting[fname]
                if not deadline or deadline < today or deadline > horizon:
                    continue
                delta = (deadline - today).days
                threshold = next(
                    (d for d in sorted(REMINDER_DAYS) if delta <= d), None)
                if threshold is None:
                    continue
                rows.append((sitting, label, deadline, delta))

        if not rows:
            return True

        rows.sort(key=lambda r: r[2])
        parts = [
            "<h2>NEBOSH Deadlines Approaching</h2>",
            "<p>As at %s. These are hard cut-offs on sittings that DHB has "
            "batches booked into.</p>" % today,
            '<table style="border-collapse:collapse;font-family:Arial;'
            'font-size:13px;width:100%">',
            '<tr style="background:#1a3d7c;color:#fff;text-align:left">'
            "<th style='padding:6px'>Unit</th>"
            "<th style='padding:6px'>Sitting</th>"
            "<th style='padding:6px'>Deadline</th>"
            "<th style='padding:6px'>Date</th>"
            "<th style='padding:6px'>Days Left</th>"
            "<th style='padding:6px'>Batches</th></tr>",
        ]
        for sitting, label, deadline, delta in rows:
            shade = "#fdecea" if delta <= 7 else "#ffffff"
            batches = ", ".join(sitting.batch_ids.mapped("name")) or "-"
            parts.append(
                '<tr style="background:%s">'
                "<td style='padding:5px'>%s</td>"
                "<td style='padding:5px'>%s</td>"
                "<td style='padding:5px'>%s</td>"
                "<td style='padding:5px'>%s</td>"
                "<td style='padding:5px'><b>%s</b></td>"
                "<td style='padding:5px'>%s</td></tr>"
                % (shade, sitting.unit, sitting.assessment_date,
                   label, deadline, delta, batches))
        parts.append("</table>")

        self.env["dhb.gap.report"]._send(
            "DHB - NEBOSH deadlines approaching (%s)" % len(rows),
            "".join(parts))
        return True


class DhbTrainingBatchSitting(models.Model):
    _inherit = "dhb.training_batch"

    sitting_id = fields.Many2one(
        "dhb.exam.sitting", string="NEBOSH Sitting", tracking=True,
        help="Linking the batch to a published sitting pulls the exam window "
             "through automatically and puts the batch on the deadline "
             "reminder list.")

    @api.onchange("sitting_id")
    def _onchange_sitting_id(self):
        for record in self:
            if not record.sitting_id:
                continue
            record.exam_window_start = record.sitting_id.assessment_date
            record.exam_window_end = (
                record.sitting_id.digital_closing
                or record.sitting_id.closing_interview_deadline
                or record.sitting_id.assessment_date)
