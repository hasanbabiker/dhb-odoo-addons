# -*- coding: utf-8 -*-
"""Identity documents held for a learner.

A learner may present more than one document - passport plus residence visa,
or a driving licence alongside a national ID. dhb.student carries a single
kyc_doc_type field, which cannot hold more than one, so the documents live
here instead and the original field is left untouched.

Access is restricted to Accreditation Managers. A scan of someone's passport
is the most sensitive record in the system, and NEBOSH requires secure storage
of learners' personal information - it should not be visible to every user who
can open a learner file.
"""
from odoo import _, api, fields, models
from odoo.exceptions import UserError

DOC_TYPE = [
    ("passport", "Passport"),
    ("national_id", "National ID"),
    ("residence_visa", "Residence Visa"),
    ("driving_licence", "Driving Licence"),
    ("other", "Other"),
]


class DhbIdDocument(models.Model):
    _name = "dhb.id.document"
    _description = "Learner Identity Document"
    _order = "student_id, doc_type"
    _rec_name = "display_name"

    student_id = fields.Many2one(
        "dhb.student", string="Learner", required=True,
        ondelete="cascade", index=True)
    doc_type = fields.Selection(
        DOC_TYPE, string="Document Type", required=True, default="passport")
    doc_number = fields.Char(string="Document Number")
    date_expiry = fields.Date(string="Expiry Date")
    issuing_country_id = fields.Many2one(
        "res.country", string="Issuing Country")

    attachment = fields.Binary(string="Scan / Photo", attachment=True)
    attachment_filename = fields.Char(string="Filename")

    date_checked = fields.Date(
        string="Date Checked", default=fields.Date.context_today)
    checked_by_id = fields.Many2one(
        "res.users", string="Checked By",
        default=lambda self: self.env.user)
    note = fields.Char(string="Note")

    display_name = fields.Char(
        string="Name", compute="_compute_display_name", store=True)

    @api.depends("doc_type", "doc_number", "student_id.name")
    def _compute_display_name(self):
        labels = dict(DOC_TYPE)
        for record in self:
            record.display_name = "%s %s" % (
                labels.get(record.doc_type, ""), record.doc_number or "")


class DhbStudentIdDocuments(models.Model):
    _inherit = "dhb.student"

    id_document_ids = fields.One2many(
        "dhb.id.document", "student_id", string="Identity Documents",
        groups="dhb_accreditation.group_dhb_manager")
    id_document_count = fields.Integer(
        string="Documents Held", compute="_compute_id_document_count",
        groups="dhb_accreditation.group_dhb_manager")

    @api.depends("id_document_ids")
    def _compute_id_document_count(self):
        for student in self:
            student.id_document_count = len(student.id_document_ids)

    def action_kyc_passed(self):
        """Refuse to confirm the check when nothing has been uploaded.

        IOSH asked for a register confirming the trainer had seen the
        learner's photo ID. A confirmation with no document attached is an
        assertion, not a record - so the button blocks until at least one
        document with a scan is on file.
        """
        for student in self:
            documents = student.sudo().id_document_ids
            if not documents.filtered("attachment"):
                raise UserError(_(
                    "Upload the identity document before confirming the "
                    "check for %s.\n\nAdd it under KYC > Identity documents. "
                    "A confirmation with nothing attached is not evidence "
                    "an auditor can accept.", student.name))
        return super().action_kyc_passed()
