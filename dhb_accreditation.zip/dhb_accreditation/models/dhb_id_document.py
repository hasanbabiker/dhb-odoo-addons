# -*- coding: utf-8 -*-
"""Identity proof held for a learner.

Deliberately one field, not a workflow. The tutor uploads the scan at
enrolment time and that is the whole task - no status bar, no stages, no
buttons. Uploading the file is itself the record that the document was seen,
so kyc_status is set behind the scenes and the enrolment gate opens.

That upload is what IOSH asked for in May 2024: a register confirming the
trainer had seen the learner's photo ID. It is kept restricted to
Accreditation Managers, because a scan of someone's passport is the most
sensitive record in the system and NEBOSH requires secure storage of
learners' personal information.
"""
from odoo import api, fields, models


class DhbStudentIdProof(models.Model):
    _inherit = "dhb.student"

    id_proof = fields.Binary(
        string="ID Document", attachment=True,
        groups="dhb_accreditation.group_dhb_manager",
        help="Passport, national ID, residence visa or driving licence. "
             "Uploading it records that the document was seen and checked.")
    id_proof_filename = fields.Char(
        string="ID Filename", groups="dhb_accreditation.group_dhb_manager")

    image_1920 = fields.Image(
        string="Photo", max_width=1920, max_height=1920,
        help="Learner photograph, so a tutor can recognise them in a "
             "virtual session.")
    image_128 = fields.Image(
        string="Photo (thumbnail)", related="image_1920",
        max_width=128, max_height=128, store=True)

    @api.model_create_multi
    def create(self, vals_list):
        students = super().create(vals_list)
        students._dhb_apply_id_proof()
        return students

    def write(self, vals):
        result = super().write(vals)
        if "id_proof" in vals:
            self._dhb_apply_id_proof()
        return result

    def _dhb_apply_id_proof(self):
        """Uploading the scan is the check. Removing it undoes the check."""
        today = fields.Date.context_today(self)
        for student in self:
            has_proof = bool(student.sudo().id_proof)
            if has_proof and student.kyc_status != "passed":
                student.sudo().write({
                    "kyc_status": "passed",
                    "kyc_verified_date": fields.Datetime.now(),
                })
                student.message_post(
                    body=self.env._("ID document uploaded and checked."))
            elif not has_proof and student.kyc_status == "passed":
                student.sudo().write({"kyc_status": "not_started",
                                      "kyc_verified_date": False})
            student.enrollment_ids._sync_kyc_evidence()
        return True
