# -*- coding: utf-8 -*-
from odoo import api, fields, models

BODY_SELECTION = [
    ("nebosh", "NEBOSH"),
    ("iosh", "IOSH"),
]

LEVEL_SELECTION = [
    ("corporate", "Corporate"),
    ("silver", "Silver"),
    ("gold", "Gold"),
]


class DhbPrinciple(models.Model):
    _name = "dhb.principle"
    _description = "Learning Excellence Principle / Audit Section"
    _order = "body, sequence, id"

    name = fields.Char(string="Name", required=True, translate=True)
    code = fields.Char(string="Code", required=True)
    body = fields.Selection(BODY_SELECTION, string="Awarding Body",
                            required=True, default="nebosh")
    sequence = fields.Integer(string="Sequence", default=10)
    description = fields.Text(string="Description", translate=True)
    active = fields.Boolean(string="Active", default=True)

    requirement_ids = fields.One2many(
        "dhb.evidence.requirement", "principle_id", string="Requirements")
    requirement_count = fields.Integer(
        string="Requirement Count", compute="_compute_requirement_count")

    _code_uniq = models.Constraint(
        "unique (code)",
        "The principle code must be unique.",
    )

    def _compute_requirement_count(self):
        data = self.env["dhb.evidence.requirement"]._read_group(
            [("principle_id", "in", self.ids)],
            groupby=["principle_id"], aggregates=["__count"])
        mapped = {principle.id: count for principle, count in data}
        for record in self:
            record.requirement_count = mapped.get(record.id, 0)

    @api.depends("code", "name")
    def _compute_display_name(self):
        for record in self:
            record.display_name = "%s - %s" % (record.code or "", record.name or "")
