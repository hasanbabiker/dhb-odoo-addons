{
    "name": "DHB Contracts",
    "version": "19.0.1.0.0",
    "summary": "Training agreements with companies, and the seats they bought",
    "description": """
DHB Contracts
=============

The centre sells two different things. A learner who pays for themselves is
an admission - one person, one course, one invoice. A company that signs for
fifty places over a year is a contract, and everything difficult about it
comes from the gap between what was agreed and what has happened since.

So this app produces two numbers and chases one date:

* **Seats left**, counted from the enrolment records and never typed. There
  is no editable "seats used" field anywhere here. A figure a person can
  type is the figure that gets quoted in a meeting, and it is the one that
  has drifted.

* **Not yet invoiced**, from the invoices actually posted against the
  contract, so nobody has to add up a folder to answer it.

* **The end date**, watched nightly. A contract that expired three weeks ago
  with eleven places unused is a conversation to have before the date, and
  the office cannot watch dates by remembering them.

Enrolling a learner against a contract happens on the batch, where the
tutor, the dates and the attendance already live - not on a second screen
here. This app warns when that enrolment would go over the seats agreed or
fall outside the dates paid for, and then counts it.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Education",
    "license": "LGPL-3",
    "depends": [
        "base", "mail", "contacts",
        # The place on a batch is what consumes a seat, and the course is
        # what a contract line is agreed for.
        "dhb_batch",
        # Only for the invoice link and the "not yet invoiced" figure.
        "account",
    ],
    "data": [
        "security/contract_groups.xml",
        "security/ir.model.access.csv",
        "data/contract_data.xml",
        "views/contract_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
