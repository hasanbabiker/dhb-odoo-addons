"""A training agreement with a company.

The centre sells two different things and they are not the same record. A
learner who pays for themselves is an admission: one person, one course, one
invoice, done. A company that signs for fifty places over a year is a
contract - and everything difficult about it comes from the gap between what
was agreed and what has actually happened since.

So the one number this module exists to produce is **seats left**, and it is
counted, never typed. A contracted figure is what somebody wrote down once; a
consumed figure is what the enrolment records say today. When those two
disagree - and they always do - the typed one is the one people quote in a
meeting, and it is the wrong one. There is no "seats used" field here for
anybody to edit.

The second thing it produces is time. A contract that expired three weeks ago
with eleven places unused is a conversation the centre wants to have before
the date, not after it, and the office cannot watch dates by remembering
them.
"""

from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbContract(models.Model):
    _name = "dhb.contract"
    _description = "Training contract"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_start desc, id desc"

    name = fields.Char(
        string="Reference", required=True, copy=False, readonly=True,
        default=lambda self: _("New"))
    title = fields.Char(
        string="Title", tracking=True,
        help="What the client calls it. Our reference is ours; this is the "
             "name that appears in their emails.")
    active = fields.Boolean(default=True)

    partner_id = fields.Many2one(
        "res.partner", string="Client", required=True, index=True,
        tracking=True, ondelete="restrict",
        domain="[('is_company', '=', True)]")
    contact_id = fields.Many2one(
        "res.partner", string="Signatory", tracking=True,
        help="The person who signs and who is chased when something is "
             "needed.")
    client_reference = fields.Char(
        string="Their reference",
        help="Their purchase order or contract number. The office quotes it "
             "on every invoice, and hunting for it in an email thread is "
             "where an afternoon goes.")

    user_id = fields.Many2one(
        "res.users", string="Owner", tracking=True,
        default=lambda self: self.env.user)

    # ------------------------------------------------------------------
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("sent", "Sent to client"),
            ("signed", "Signed"),
            ("closed", "Closed"),
            ("cancelled", "Cancelled"),
        ],
        default="draft", required=True, index=True, tracking=True,
        group_expand="_group_expand_state")

    date_signed = fields.Date(string="Signed on", tracking=True)
    date_start = fields.Date(string="Valid from", tracking=True)
    date_end = fields.Date(string="Valid until", tracking=True)

    signed_copy = fields.Binary(string="Signed copy", attachment=True)
    signed_copy_name = fields.Char(string="File name")

    line_ids = fields.One2many(
        "dhb.contract.line", "contract_id", string="What was agreed",
        copy=True)

    currency_id = fields.Many2one(
        "res.currency", required=True,
        default=lambda self: self.env.company.currency_id)

    # ------------------------------------------------------------------
    # Seats. Contracted is agreed; used is counted; left is the difference.
    #
    # seats_used has no setter anywhere on purpose. The moment a person can
    # type it, it becomes the figure that is quoted, and it drifts from the
    # enrolment records silently - which is exactly the failure this module
    # is meant to prevent.
    seats_total = fields.Integer(
        string="Seats agreed", compute="_compute_seats", store=True)
    seats_used = fields.Integer(
        string="Seats used", compute="_compute_seats", store=True)
    seats_left = fields.Integer(
        string="Seats left", compute="_compute_seats", store=True)

    # copy=False, and it is not a detail. A One2many copies by default in
    # Odoo, so "Renew" would have duplicated every learner's place on every
    # batch - silently, and only visible later as a register with each name
    # on it twice. The same for the invoices below.
    registration_ids = fields.One2many(
        "dhb.batch.line", "contract_id", string="Learners", copy=False)

    amount_total = fields.Monetary(
        string="Contract value", compute="_compute_amounts", store=True)
    amount_invoiced = fields.Monetary(
        string="Invoiced", compute="_compute_invoiced", store=True)
    amount_uninvoiced = fields.Monetary(
        string="Not yet invoiced", compute="_compute_invoiced", store=True)

    invoice_ids = fields.One2many(
        "account.move", "contract_id", string="Invoices", copy=False,
        domain=[("move_type", "in", ("out_invoice", "out_refund"))])
    invoice_count = fields.Integer(compute="_compute_invoice_count")

    # ------------------------------------------------------------------
    # The alert is stored, and that is what makes it findable.
    #
    # Storage costs something honest here: the value depends on today's
    # date, so it goes stale overnight by itself. That is what the nightly
    # cron is for. The alternative - computing it fresh on every read - is
    # not available, because a filter or a facet on a non-stored computed
    # field does not load slowly, it refuses to load the view at all.
    alert_state = fields.Selection(
        [
            ("ok", "Fine"),
            ("soon", "Ending soon"),
            ("expired", "Expired with seats unused"),
            ("overbooked", "More learners than seats"),
        ],
        string="Needs attention", compute="_compute_alert", store=True,
        index=True)
    alert_note = fields.Char(
        string="What is wrong", compute="_compute_alert", store=True)

    # Time-based, so it is deliberately NOT stored - and it is computed on
    # its own, away from alert_state. One method must never fill a stored
    # and a non-stored field together: reading the cheap one would then
    # quietly write the expensive one, and a read that writes is a bug that
    # only shows up under load.
    days_left = fields.Integer(
        string="Days left", compute="_compute_days_left")

    note = fields.Text(string="Internal notes")

    _unique_reference = models.Constraint(
        "unique(name)", "That contract reference is already used.")

    # ==================================================================
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "dhb.contract") or _("New")
        return super().create(vals_list)

    @api.model
    def _group_expand_state(self, states, domain):
        return ["draft", "sent", "signed"]

    # registration_ids.active is in here for a reason that is easy to miss:
    # archiving a place removes it from the One2many but does not trigger a
    # recompute unless `active` is a dependency. Without it, archiving a
    # duplicate enrolment leaves the header saying 10 used while the
    # Learners tab lists 9 - two numbers for one fact, on one screen.
    @api.depends("line_ids.seats", "registration_ids.state",
                 "registration_ids.active", "registration_ids.contract_id")
    def _compute_seats(self):
        for contract in self:
            contract.seats_total = sum(contract.line_ids.mapped("seats"))
            # A cancelled place is a place given back. Counting it as used
            # is how a client ends up told there is nothing left on a
            # contract with room on it.
            contract.seats_used = len(contract.registration_ids.filtered(
                lambda line: line.state != "cancel"))
            contract.seats_left = contract.seats_total - contract.seats_used

    @api.depends("line_ids.subtotal")
    def _compute_amounts(self):
        for contract in self:
            contract.amount_total = sum(contract.line_ids.mapped("subtotal"))

    @api.depends("invoice_ids.state", "invoice_ids.currency_id",
                 "invoice_ids.amount_total_in_currency_signed",
                 "currency_id", "amount_total")
    def _compute_invoiced(self):
        """In the contract's currency, not the company's.

        amount_total_signed looks like the obvious field and is the wrong
        one: it is denominated in the company currency. On an AED company
        with a contract written in dollars, a $10,000 contract invoiced in
        full would read "invoiced 36,730" and "not yet invoiced -26,730" -
        a fully settled contract shown as badly over-billed.
        """
        for contract in self:
            invoiced = 0.0
            for move in contract.invoice_ids.filtered(
                    lambda m: m.state == "posted"):
                amount = move.amount_total_in_currency_signed
                if move.currency_id and contract.currency_id \
                        and move.currency_id != contract.currency_id:
                    amount = move.currency_id._convert(
                        amount, contract.currency_id,
                        move.company_id or self.env.company,
                        move.invoice_date or move.date
                        or fields.Date.context_today(contract))
                invoiced += amount
            contract.amount_invoiced = invoiced
            contract.amount_uninvoiced = contract.amount_total - invoiced

    def _compute_invoice_count(self):
        for contract in self:
            contract.invoice_count = len(contract.invoice_ids)

    @api.depends("date_end")
    def _compute_days_left(self):
        today = fields.Date.context_today(self)
        for contract in self:
            contract.days_left = (contract.date_end - today).days \
                if contract.date_end else 0

    @api.depends("date_end", "state", "seats_total", "seats_used")
    def _compute_alert(self):
        today = fields.Date.context_today(self)
        for contract in self:
            state, note = "ok", False
            if contract.state == "signed":
                left = contract.seats_left
                if left < 0:
                    state = "overbooked"
                    note = _("%s more learners than the contract allows") \
                        % abs(left)
                elif contract.date_end and contract.date_end < today:
                    if left > 0:
                        state = "expired"
                        note = _("Ended %(when)s with %(left)s seats unused",
                                 when=contract.date_end, left=left)
                elif contract.date_end:
                    days = (contract.date_end - today).days
                    if days <= 30:
                        state = "soon"
                        note = _("Ends in %(days)s days, %(left)s seats "
                                 "still unused", days=days, left=left) \
                            if left > 0 else _("Ends in %s days") % days
            contract.alert_state = state
            contract.alert_note = note

    @api.depends("name", "partner_id", "title")
    def _compute_display_name(self):
        for contract in self:
            label = contract.title or contract.partner_id.display_name or ""
            contract.display_name = "%s - %s" % (contract.name, label) \
                if label else contract.name

    # ==================================================================
    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        if self.partner_id and self.contact_id.parent_id != self.partner_id:
            self.contact_id = False

    @api.constrains("date_start", "date_end")
    def _check_dates(self):
        for contract in self:
            if contract.date_start and contract.date_end \
                    and contract.date_end < contract.date_start:
                raise UserError(_(
                    "%s ends before it starts.") % contract.display_name)

    # ==================================================================
    def action_send(self):
        for contract in self:
            if not contract.line_ids:
                raise UserError(_(
                    "%s has nothing agreed on it yet, so there is nothing "
                    "to send.") % contract.display_name)
        self.write({"state": "sent"})

    def action_sign(self):
        for contract in self:
            if not contract.date_start or not contract.date_end:
                raise UserError(_(
                    "%s needs a start and an end date before it is signed. "
                    "A contract with no end never appears in anything that "
                    "chases it.") % contract.display_name)
            contract.write({
                "state": "signed",
                "date_signed": contract.date_signed
                               or fields.Date.context_today(contract),
            })

    def action_close(self):
        self.write({"state": "closed"})

    def action_cancel(self):
        for contract in self:
            if contract.seats_used:
                raise UserError(_(
                    "%(name)s already has %(used)s learners enrolled against "
                    "it. Cancelling it would leave them on batches paid for "
                    "by a contract that does not exist - close it instead.",
                    name=contract.display_name, used=contract.seats_used))
        self.write({"state": "cancelled"})

    def action_back_to_draft(self):
        self.write({"state": "draft"})

    def action_renew(self):
        """A copy of the agreement, forward by the same length.

        Renewal is the commonest thing that happens to a contract that
        works, and retyping fourteen fields is how a renewal gets a wrong
        price on it.
        """
        self.ensure_one()
        if not self.date_start or not self.date_end:
            raise UserError(_("Set the dates before renewing."))
        length = relativedelta(self.date_end, self.date_start)
        new = self.copy({
            "date_start": self.date_end + relativedelta(days=1),
            "date_end": self.date_end + relativedelta(days=1) + length,
            "date_signed": False,
            "state": "draft",
            "client_reference": False,
            "signed_copy": False,
            "signed_copy_name": False,
        })
        new.message_post(body=_(
            "Renewed from %s.") % self._get_html_link())
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.contract",
            "res_id": new.id,
            "view_mode": "form",
        }

    def action_open_learners(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learners on %s") % self.display_name,
            "res_model": "dhb.batch.line",
            "view_mode": "list,form",
            "domain": [("contract_id", "=", self.id)],
            "context": {"default_contract_id": self.id},
        }

    def action_open_invoices(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Invoices for %s") % self.display_name,
            "res_model": "account.move",
            "view_mode": "list,form",
            "domain": [("id", "in", self.invoice_ids.ids)],
            "context": {
                "default_contract_id": self.id,
                "default_partner_id": self.partner_id.id,
                "default_move_type": "out_invoice",
            },
        }

    # ==================================================================
    @api.model
    def _cron_refresh_alerts(self):
        """Move the clock forward for everything that watches a date.

        alert_state is stored so it can be filtered, and it is computed from
        today's date, so nothing recomputes it on its own. Without this it
        would be correct on the day it was written and wrong every day
        after - which is worse than no alert, because it looks like one.
        """
        live = self.search([("state", "=", "signed")])
        if not live:
            return
        for field in ("alert_state", "alert_note"):
            self.env.add_to_compute(self._fields[field], live)
        live.flush_recordset(["alert_state", "alert_note"])

        # Told once, not every night. A contract that ends in 29 days would
        # otherwise raise 29 activities, and an inbox with 29 copies of the
        # same warning is an inbox where the warning is ignored.
        for contract in live.filtered(
                lambda c: c.alert_state in ("soon", "expired", "overbooked")):
            if contract.activity_ids:
                continue
            contract.activity_schedule(
                "mail.mail_activity_data_todo",
                user_id=(contract.user_id or self.env.user).id,
                summary=contract.alert_note or _("Contract needs attention"))
