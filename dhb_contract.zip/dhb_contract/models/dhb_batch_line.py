"""The one field that makes a seat countable.

Everything the contract knows about consumption comes from here. A place on
a batch either points at a contract or it does not, and the contract counts
the ones that point at it.

This is a single Many2one on an existing model rather than a table of its
own, which is deliberate: a "contract seat" record would be a second place
recording that a person is on a course, and the two would drift.
"""

import pytz

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbBatchLine(models.Model):
    _inherit = "dhb.batch.line"

    contract_id = fields.Many2one(
        "dhb.contract", string="Under contract", index=True,
        ondelete="restrict", tracking=True,
        help="Set when the learner's place is paid for by a company "
             "agreement rather than by the learner.")
    contract_partner_id = fields.Many2one(
        related="contract_id.partner_id", string="Sponsor", store=True,
        index=True)

    @api.onchange("contract_id")
    def _onchange_contract_id(self):
        """Say it before the seat is taken, not after the month is billed."""
        contract = self.contract_id
        if not contract:
            return
        if contract.state != "signed":
            return {"warning": {
                "title": _("Not signed yet"),
                "message": _(
                    "%(name)s is %(state)s. Enrolling against an unsigned "
                    "contract is how a place gets given away and never "
                    "invoiced.",
                    name=contract.display_name,
                    state=dict(contract._fields["state"].selection).get(
                        contract.state, contract.state)),
            }}
        if contract.seats_left <= 0:
            return {"warning": {
                "title": _("No seats left"),
                "message": _(
                    "%(name)s has %(used)s of %(total)s places used. This "
                    "one would go over the agreement.",
                    name=contract.display_name, used=contract.seats_used,
                    total=contract.seats_total),
            }}

    @api.model
    def _local_date(self, when, tz_name):
        """The calendar date the batch starts on, where it is taught.

        Datetimes are stored in UTC, so the plain conversion is wrong by
        one day for a fifth of the timetable: a class at 2am Dubai time on
        the first of January is 10pm on the thirty-first of December in UTC,
        and the contract window check would refuse a learner whose course
        is squarely inside the period the client paid for.
        """
        when = fields.Datetime.to_datetime(when)
        zone = pytz.timezone(tz_name or self.env.user.tz or "UTC")
        return pytz.utc.localize(when).astimezone(zone).date()

    @api.constrains("contract_id", "event_id")
    def _check_contract_dates(self):
        """A place cannot be taken outside the window that was paid for."""
        for line in self:
            contract = line.contract_id
            start = line.event_id.date_begin
            if not contract or not start:
                continue
            start = line._local_date(start, line.event_id.date_tz)
            if contract.date_start and start < contract.date_start:
                raise UserError(_(
                    "%(batch)s starts on %(start)s, before %(contract)s "
                    "begins on %(opens)s.",
                    batch=line.event_id.display_name, start=start,
                    contract=contract.display_name,
                    opens=contract.date_start))
            if contract.date_end and start > contract.date_end:
                raise UserError(_(
                    "%(batch)s starts on %(start)s, after %(contract)s ends "
                    "on %(until)s. Either the batch is wrong or the "
                    "contract needs renewing.",
                    batch=line.event_id.display_name, start=start,
                    contract=contract.display_name,
                    until=contract.date_end))
