"""Which agreement an invoice belongs to.

One field, on the invoice, pointing back. The alternative - a table linking
contracts to invoices - would be a third record to keep in step with two that
already exist, and the link would be missing on exactly the invoices somebody
raised in a hurry.
"""

from odoo import models, fields


class AccountMove(models.Model):
    _inherit = "account.move"

    contract_id = fields.Many2one(
        "dhb.contract", string="Training contract", index=True,
        ondelete="set null", copy=False,
        help="Set when this invoice bills work done under a company "
             "agreement. It is what makes 'how much of the contract is "
             "still uninvoiced' answerable.")
