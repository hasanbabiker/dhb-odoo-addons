"""One course, so many places, at this price.

A contract is rarely one number. A company signs for twenty IGC places and
eight IOSH ones at different prices, and a single "seats" field on the
contract cannot say that - so when the twenty run out and the eight have not
been touched, nobody can see it.
"""

from odoo import models, fields, api, _


class DhbContractLine(models.Model):
    _name = "dhb.contract.line"
    _description = "Contract line"
    _order = "contract_id, sequence, id"

    contract_id = fields.Many2one(
        "dhb.contract", string="Contract", required=True, index=True,
        ondelete="cascade")
    sequence = fields.Integer(default=10)

    course_id = fields.Many2one(
        "dhb.course", string="Course", required=True, ondelete="restrict")
    seats = fields.Integer(string="Seats", default=1, required=True)
    price_unit = fields.Monetary(string="Price per seat")
    currency_id = fields.Many2one(
        related="contract_id.currency_id", readonly=True)

    subtotal = fields.Monetary(
        string="Subtotal", compute="_compute_subtotal", store=True)

    # Not stored, and it is not shown in any filter for that reason. The
    # figure is read off the enrolment records through two relations; a
    # stored copy of it would be a third place for the same fact to live,
    # and the day the three disagree is the day nobody trusts any of them.
    seats_used = fields.Integer(
        string="Used", compute="_compute_seats_used")
    seats_left = fields.Integer(
        string="Left", compute="_compute_seats_used")

    note = fields.Char(string="Note")

    @api.depends("seats", "price_unit")
    def _compute_subtotal(self):
        for line in self:
            line.subtotal = (line.seats or 0) * (line.price_unit or 0.0)

    @api.depends("course_id", "contract_id.registration_ids.state",
                 "contract_id.registration_ids.event_id")
    def _compute_seats_used(self):
        for line in self:
            used = line.contract_id.registration_ids.filtered(
                lambda reg: reg.state != "cancel"
                and reg.event_id.course_id == line.course_id)
            line.seats_used = len(used)
            line.seats_left = (line.seats or 0) - len(used)

    @api.onchange("course_id")
    def _onchange_course_id(self):
        """The course's own price, as a starting point and nothing more.

        A contract price is negotiated, so this is only ever a default - but
        a default beats an empty box, which is where a zero gets left.
        """
        if self.course_id and not self.price_unit:
            self.price_unit = self.course_id.list_price

    @api.depends("course_id", "seats")
    def _compute_display_name(self):
        for line in self:
            line.display_name = _("%(seats)s x %(course)s",
                                  seats=line.seats,
                                  course=line.course_id.display_name or "")
