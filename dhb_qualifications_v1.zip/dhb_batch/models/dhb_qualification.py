from odoo import models, fields, api, _

from .constants import AWARDING_BODIES


class DhbQualification(models.Model):
    """What the awarding body awards. Not what the centre sells.

    These two were one record until now, and the cost of that showed up the
    moment somebody asked an ordinary question: can we run the IGC both in a
    classroom and on Zoom? A single record cannot answer it, because it has
    one length, one lecture count and one fee - and a fifteen-day classroom
    IGC and a self-paced one are not the same product at any of them.

    So they separate:

        Qualification   what NEBOSH awards - the syllabus, its units, its
                        edition, how long a registration lasts. Theirs.
        Course          what we sell - a qualification in one language and
                        one mode, with its own length and price. Ours.
        Batch           a course with a start date.

    One qualification, several courses, many batches. And the catalogue
    grows by what the centre actually offers rather than by multiplication:
    two modes of the IGC in Arabic is two courses, not eight.
    """

    _name = "dhb.qualification"
    _description = "Qualification"
    _order = "sequence, code"

    name = fields.Char(
        required=True, translate=False,
        help="The official title, exactly as the awarding body writes it. "
             "It goes on a certificate and on every form they receive, so a "
             "shortened version here is a query from them later.")
    code = fields.Char(
        required=True, copy=False,
        help="Short - IGC, DI1. Used wherever the full title will not fit.")
    _unique_code = models.Constraint(
        "unique(code)", "Another qualification already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    awarding_body = fields.Selection(
        AWARDING_BODIES, string="Awarded by", default="nebosh", required=True)
    level = fields.Char(
        help="As the awarding body states it - \"Level 3\", \"Level 6\".")
    spec_edition = fields.Char(
        string="Syllabus edition",
        help="\"IG 6th Edition\". Material written for an older edition is "
             "material that has to be replaced, and this is where the "
             "Documents app learns which edition is current.")
    material_licence = fields.Char(
        string="Material licence",
        help="The licence number under which the centre holds the awarding "
             "body's material for this qualification.")

    guided_hours = fields.Integer(
        string="Guided learning hours",
        help="The taught time the awarding body specifies. A course may "
             "deliver more, never meaningfully less.")
    private_study_hours = fields.Integer(string="Private study hours")

    registration_validity_months = fields.Integer(
        string="Registration valid for (months)", default=60,
        help="How long a learner has to complete after registering. NEBOSH "
             "gives five years; after it the registration lapses and the "
             "units already passed are lost.")

    entry_requirement = fields.Text(
        string="Entry requirements",
        help="In the awarding body's words. Read at admission.")
    prerequisite_ids = fields.Many2many(
        "dhb.qualification", "dhb_qualification_prerequisite_rel",
        "qualification_id", "prerequisite_id", string="Requires first",
        help="A Diploma that requires the Certificate says so here, and "
             "admissions can check it instead of remembering it.")

    course_ids = fields.One2many(
        "dhb.course", "qualification_id", string="Courses")
    course_count = fields.Integer(compute="_compute_course_count")

    note = fields.Text(string="Internal notes")

    # The key the old selection field used - igc, di1, emc. Kept so the four
    # modules that still read that selection keep working while it is
    # retired in a later pass. It is a bridge, and it is meant to be
    # removed; saying so here is the difference between a bridge and a
    # second source of truth nobody remembers to delete.
    selection_key = fields.Char(
        string="Legacy key", copy=False,
        help="Maps to the qualification selection the older modules still "
             "read. Do not rely on it in anything new.")

    @api.depends("course_ids")
    def _compute_course_count(self):
        for qualification in self:
            qualification.course_count = len(qualification.course_ids)

    @api.depends("name", "code")
    def _compute_display_name(self):
        for qualification in self:
            qualification.display_name = "[%s] %s" % (
                qualification.code, qualification.name) \
                if qualification.code else (qualification.name or "")

    def action_open_courses(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Courses of %s") % self.display_name,
            "res_model": "dhb.course",
            "view_mode": "list,form",
            "domain": [("qualification_id", "=", self.id)],
            "context": {"default_qualification_id": self.id},
        }
