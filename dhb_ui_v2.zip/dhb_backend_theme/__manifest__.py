# -*- coding: utf-8 -*-
{
    "name": "DHB Backend Theme",
    "version": "19.0.2.0.0",
    "category": "Theme/Backend",
    "summary": "DHB brand colours, logo and a cleaner back-office look.",
    "description": """
DHB Backend Theme
=================

Restyles the Odoo back office in DHB's colours without touching the way Odoo
works:

* Navy and blue palette taken from the DHB logo.
* DHB logo in the navbar, on the login page and as the browser favicon.
* Dark table headers and clearer status badges.
* Removes the "Powered by Odoo" promotion from the login page.

Deliberately conservative: it only changes styling, so Odoo upgrades will not
break it. Replacing Odoo's whole menu structure with a fixed sidebar is a much
deeper change and is not part of this module.
""",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "depends": ["web"],
    "data": [
        "views/webclient_templates.xml",
    ],
    "assets": {
        "web._assets_primary_variables": [
            ("prepend", "dhb_backend_theme/static/src/scss/variables.scss"),
        ],
        "web.assets_backend": [
            "dhb_backend_theme/static/src/scss/backend.scss",
            "dhb_backend_theme/static/src/scss/system.scss",
        ],
        "web.assets_frontend": [
            "dhb_backend_theme/static/src/scss/login.scss",
        ],
    },
    "post_init_hook": "_dhb_theme_post_init",
    "installable": True,
    "application": False,
    "auto_install": False,
}
