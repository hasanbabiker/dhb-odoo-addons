# -*- coding: utf-8 -*-
import base64
import logging
import os

_logger = logging.getLogger(__name__)


def _dhb_theme_post_init(env):
    """Set the company logo from the bundled brand assets.

    Done in Python rather than XML data so it runs once at install and does not
    fight the user if they later upload something else.

    The favicon is NOT set here. Odoo 19 has no favicon field on the company —
    the tab icon comes from a static file — so it is replaced in the layout
    template instead. This used to try both, silently skip the favicon when
    the field was missing, and then log that it had applied it.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    images = os.path.join(here, "static", "src", "img")
    company = env.company

    def _read(name):
        path = os.path.join(images, name)
        if not os.path.exists(path):
            return None
        with open(path, "rb") as handle:
            return base64.b64encode(handle.read())

    logo = _read("logo_login.png")
    if not logo:
        _logger.warning(
            "DHB theme: logo_login.png is missing, the company logo was "
            "left as it was.")
        return
    company.sudo().write({"logo": logo})
    _logger.info("DHB theme: company logo applied to %s.", company.name)
