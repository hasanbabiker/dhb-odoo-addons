from odoo import models, fields


class InviteIdentity(models.Model):
    """The learner's identity, shown on the application that decides it.

    All of this already lives on the contact. It is mirrored here because
    of where the decision happens: somebody accepts or rejects from the
    application screen, and until now the identity document they are
    supposed to be checking was one record away. A check that costs a
    detour is a check that quietly stops happening.

    Related rather than copied, so there is still one version of the truth.
    The number is writable — it is the one field staff routinely have to
    fill in from the document itself, and it is a strong identifier the
    duplicate check relies on.
    """

    _inherit = "dhb.registration.invite"

    partner_legal_name = fields.Char(
        related="partner_id.legal_name", string="Full legal name",
        readonly=True)
    partner_date_of_birth = fields.Date(
        related="partner_id.date_of_birth", string="Date of birth",
        readonly=True)
    partner_nationality = fields.Many2one(
        related="partner_id.nationality_id", string="Nationality",
        readonly=True)
    partner_id_document_type = fields.Selection(
        related="partner_id.id_document_type", string="Document",
        readonly=True)
    partner_id_document_number = fields.Char(
        related="partner_id.id_document_number", string="Document number",
        readonly=False,
    )
    partner_id_document_file = fields.Binary(
        related="partner_id.id_document_file", string="Identity document",
        readonly=True)
    partner_id_document_filename = fields.Char(
        related="partner_id.id_document_filename", readonly=True)
    partner_image = fields.Image(
        related="partner_id.image_1920", string="Photograph", readonly=True)
