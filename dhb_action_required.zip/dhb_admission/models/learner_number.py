import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

SEQUENCE = "dhb.learner.number"


class ResPartnerDhbNumber(models.Model):
    """DHB's own learner number, issued the moment a place is confirmed.

    Not the NEBOSH learner number: that one belongs to the awarding body, a
    learner can arrive already carrying one from another centre, and it says
    nothing about this centre. This is DHB's own reference — the number that
    goes on an attendance certificate, a letter, or the top of a file.

    It lives on the contact, not on the registration, because a learner who
    takes IGC and then the Diploma is one person with one number. And it is
    issued at enrolment rather than at application, because a number given to
    somebody who never joins is a gap in the series that has to be explained.
    """

    _inherit = "res.partner"

    dhb_learner_number = fields.Char(
        string="DHB learner number", copy=False, index=True, readonly=True,
        tracking=True,
        help="Issued automatically when the learner's first place is "
             "confirmed. It never changes and is never reused.",
    )
    dhb_number_issued_on = fields.Date(
        string="Number issued on", copy=False, readonly=True)

    _unique_dhb_learner_number = models.Constraint(
        "unique(dhb_learner_number)",
        "Two contacts cannot share the same DHB learner number.",
    )

    # ------------------------------------------------------------------
    def _assign_dhb_number(self):
        """Give this learner a number, once. Returns it either way."""
        self.ensure_one()
        if self.dhb_learner_number:
            return self.dhb_learner_number

        number = self.env["ir.sequence"].sudo().next_by_code(SEQUENCE)
        if not number:
            # Never let a missing sequence cost an enrolment.
            _logger.warning(
                "No %s sequence: partner %s was not numbered", SEQUENCE, self.id)
            return False

        self.sudo().write({
            "dhb_learner_number": number,
            "dhb_number_issued_on": fields.Date.today(),
        })
        self.message_post(body=_("DHB learner number issued: %s") % number)
        return number

    def action_assign_dhb_number(self):
        """The manual button, for learners who arrived some other way.

        The 235 already on the platform never went through admissions, so
        nothing ever issued them a number.
        """
        numbered = 0
        for partner in self:
            if partner.dhb_learner_number:
                continue
            if not partner.is_learner:
                raise UserError(_(
                    "%s is not marked as a learner, so a learner number would "
                    "be wrong.") % partner.display_name)
            if partner._assign_dhb_number():
                numbered += 1
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Done"),
                "message": _("%s learner(s) numbered.") % numbered,
                "type": "success",
                "next": {"type": "ir.actions.act_window_close"},
            },
        }

    @api.model
    def _cron_number_unnumbered_learners(self):
        """Catch anyone confirmed on a cohort who still has no number."""
        confirmed = self.env["dhb.batch.line"].search([
            ("state", "in", ("open", "done")),
        ])
        partners = confirmed.mapped("partner_id").filtered(
            lambda p: p.is_learner and not p.dhb_learner_number)
        for partner in partners:
            partner._assign_dhb_number()
        if partners:
            _logger.info("Numbered %s learner(s)", len(partners))
        return True


class RegistrationInviteDhbNumber(models.Model):
    """Enrolment is the moment the number is due."""

    _inherit = "dhb.registration.invite"

    dhb_learner_number = fields.Char(
        related="partner_id.dhb_learner_number", string="DHB number",
        readonly=True, store=True,
    )

    def action_enrol(self):
        result = super().action_enrol()
        for application in self:
            if application.state != "enrolled" or not application.partner_id:
                continue
            try:
                application.partner_id._assign_dhb_number()
            except Exception as exc:  # noqa: BLE001
                # A number is administrative; the enrolment is the real thing.
                _logger.exception(
                    "Could not issue a DHB number for application %s",
                    application.id)
                application.message_post(body=_(
                    "The learner is enrolled, but no DHB number could be "
                    "issued: %s") % exc)
        return result
