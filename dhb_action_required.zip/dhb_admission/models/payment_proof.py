from odoo import models, fields, api, _
from odoo.exceptions import UserError


class PaymentProof(models.Model):
    """A receipt the learner sends back, before the accountant sees the bank.

    Learners in the Gulf pay by bank transfer and send a screenshot the same
    minute. That screenshot is not a payment - only the bank statement is -
    but it is what lets the centre hold a place on the same day. Keeping it as
    its own record, with who checked it and when, separates "the learner says
    they paid" from "the money arrived", which is the distinction an auditor
    and an accountant both care about.
    """

    _name = "dhb.payment.proof"
    _description = "Proof of payment sent by a learner"
    _order = "uploaded_on desc, id desc"
    _rec_name = "display_name"
    _inherit = ["mail.thread"]

    display_name = fields.Char(compute="_compute_display_name", store=True)

    application_id = fields.Many2one(
        "dhb.registration.invite", string="Application", required=True,
        ondelete="cascade", index=True,
    )
    partner_id = fields.Many2one(
        "res.partner", string="Learner",
        related="application_id.partner_id", store=True,
    )
    event_id = fields.Many2one(
        "dhb.batch", string="Cohort",
        related="application_id.event_id", store=True,
    )

    kind = fields.Selection(
        [
            ("deposit", "Deposit"),
            ("balance", "Balance"),
            ("full", "Whole fee"),
            ("other", "Other"),
        ],
        string="Covers", default="deposit", required=True,
    )
    currency_id = fields.Many2one(
        "res.currency", related="application_id.currency_id", readonly=True)
    amount = fields.Monetary(
        string="Amount stated", currency_field="currency_id",
        help="What the learner says they sent. It is their claim, not a "
             "posted figure.",
    )
    paid_on = fields.Date(string="Paid on")
    reference = fields.Char(string="Transfer reference")

    file = fields.Binary(string="Receipt", attachment=True, required=True)
    filename = fields.Char(string="File name")

    uploaded_on = fields.Datetime(
        string="Uploaded", default=fields.Datetime.now, readonly=True)
    uploaded_ip = fields.Char(string="From IP", readonly=True)
    uploaded_by_learner = fields.Boolean(
        string="Sent by the learner", readonly=True,
        help="False when a member of staff attached it on the learner's "
             "behalf.",
    )

    state = fields.Selection(
        [
            ("pending", "Waiting to be checked"),
            ("accepted", "Accepted"),
            ("rejected", "Rejected"),
        ],
        default="pending", required=True, index=True, tracking=True,
    )
    checked_by = fields.Many2one("res.users", string="Checked by", readonly=True)
    checked_on = fields.Datetime(string="Checked on", readonly=True)
    note = fields.Text(string="Note")

    @api.depends("partner_id.name", "kind", "amount", "paid_on")
    def _compute_display_name(self):
        kinds = dict(self._fields["kind"].selection)
        for proof in self:
            parts = [proof.partner_id.name or _("Payment proof")]
            parts.append(kinds.get(proof.kind, ""))
            if proof.paid_on:
                parts.append(proof.paid_on.strftime("%d/%m/%Y"))
            proof.display_name = " - ".join(p for p in parts if p)

    def action_accept(self):
        """Mark the receipt as believed, and say so on the invoice.

        This does not register a payment in accounting. Posting money against
        an invoice belongs to whoever reconciles the bank, and doing it from a
        screenshot would put figures in the ledger that the statement has not
        confirmed. What it does is leave a note on the invoice so the person
        reconciling knows what to look for.
        """
        for proof in self:
            proof.write({
                "state": "accepted",
                "checked_by": self.env.user.id,
                "checked_on": fields.Datetime.now(),
            })
            invoice = proof._target_invoice()
            if invoice:
                invoice.message_post(body=_(
                    "The learner sent a receipt for %(amount)s"
                    "%(reference)s, accepted by %(user)s. Still to be "
                    "reconciled against the bank."
                ) % {
                    "amount": proof.amount or "",
                    "reference": _(" (reference %s)") % proof.reference
                                 if proof.reference else "",
                    "user": self.env.user.name,
                })
            proof.application_id.message_post(body=_(
                "Payment proof accepted: %s") % proof.display_name)
        return True

    def action_reject(self):
        for proof in self:
            if not (proof.note or "").strip():
                raise UserError(_(
                    "Write what is wrong with the receipt before rejecting "
                    "it. The learner will ask."
                ))
            proof.write({
                "state": "rejected",
                "checked_by": self.env.user.id,
                "checked_on": fields.Datetime.now(),
            })
            proof.application_id.message_post(body=_(
                "Payment proof rejected: %s") % proof.note)
        return True

    def _target_invoice(self):
        self.ensure_one()
        application = self.application_id
        if self.kind == "balance":
            return application.balance_invoice_id
        return application.invoice_id
