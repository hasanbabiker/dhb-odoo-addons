from odoo import models, fields, api, _


class DhbBatchApplications(models.Model):
    """How many people have applied to this batch, shown on the batch itself.

    The count lives here rather than on dhb.batch because the application is
    this side of the system: the batch module knows nothing about admissions
    and must not, or the two would depend on each other.
    """

    _inherit = "dhb.batch"

    application_count = fields.Integer(
        string="Applications", compute="_compute_application_count",
    )

    @api.depends("registration_ids")
    def _compute_application_count(self):
        invites = self.env["dhb.registration.invite"]
        if not self.ids:
            for batch in self:
                batch.application_count = 0
            return
        groups = invites._read_group(
            [("event_id", "in", self.ids)], ["event_id"], ["__count"],
        )
        counts = {batch.id: count for batch, count in groups}
        for batch in self:
            batch.application_count = counts.get(batch.id, 0)

    # Deliberately not called action_open_applications: that name already
    # belongs to the stage change that opens a batch for applications, and
    # two methods of the same name on one model is a bug that only shows
    # itself when somebody presses the wrong button.
    def action_view_applications(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Applications - %s") % self.display_name,
            "res_model": "dhb.registration.invite",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }
