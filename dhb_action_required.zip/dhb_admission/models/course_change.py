from odoo import models, fields, api, _
from odoo.exceptions import UserError

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"


class DhbCourseChangeRequest(models.Model):
    """A learner asking to move from one cohort to another.

    The commonest request a training centre gets, and the one most often
    handled in WhatsApp: "I cannot make January, put me on the March course."
    Done by hand it leaves two half-true records — a seat still held on a
    cohort the learner will not attend, and a seat on another that nobody
    invoiced.

    It carries one thing OpenEduCat's equivalent does not, because it is not
    a fact about software. Moving a learner between two DHB cohorts is an
    internal matter — unless the two cohorts sit DIFFERENT NEBOSH sittings
    and the learner has already been entered for the first one. Then the
    centre is changing an exam entry at the awarding body, and the date that
    governs it is the new sitting's registration closing.

    This is deliberately NOT the sitting's "transfer deadline": that one is
    for a learner transferring in from another Learning Partner, which is a
    different thing entirely and is not what this screen does.
    """

    _name = "dhb.course.change.request"
    _description = "Course change request"
    _order = "create_date desc"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char(string="Request", readonly=True, copy=False, default="/")

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True, tracking=True,
        domain="[('is_learner', '=', True)]",
    )
    application_id = fields.Many2one(
        "dhb.registration.invite", string="Application", tracking=True,
        help="The admission this learner came in on. Moving the cohort moves "
             "it too, so their paperwork follows them.",
    )

    from_event_id = fields.Many2one(
        "dhb.batch", string="Current course", required=True, tracking=True)
    to_event_id = fields.Many2one(
        "dhb.batch", string="Requested course", required=True, tracking=True)
    from_registration_id = fields.Many2one(
        "dhb.batch.line", string="Current place", readonly=True)
    to_registration_id = fields.Many2one(
        "dhb.batch.line", string="New place", readonly=True, copy=False)

    reason = fields.Text(string="Reason for the change", required=True)

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("fee", "Fee"),
            ("approved", "Approved"),
            ("rejected", "Rejected"),
            ("cancel", "Cancelled"),
        ],
        default="draft", required=True, tracking=True, index=True,
    )

    # --- what the awarding body says ------------------------------------
    nebosh_entered = fields.Boolean(
        string="Entered with NEBOSH", compute="_compute_nebosh",
        help="The centre has already registered this learner with NEBOSH for "
             "the current course.",
    )
    from_sitting_id = fields.Many2one(
        "dhb.nebosh.sitting", string="Current sitting",
        compute="_compute_nebosh")
    to_sitting_id = fields.Many2one(
        "dhb.nebosh.sitting", string="New sitting", compute="_compute_nebosh")
    sitting_changes = fields.Boolean(
        string="The exam sitting changes", compute="_compute_nebosh",
        help="Both cohorts sit the same NEBOSH assessment, or they do not. "
             "If they do, nothing about the exam entry changes.",
    )
    new_registration_closing = fields.Date(
        string="New sitting closes", compute="_compute_nebosh")
    past_registration_closing = fields.Boolean(compute="_compute_nebosh")
    target_full = fields.Boolean(
        string="Requested course is full", compute="_compute_target")
    target_register_id = fields.Many2one(
        "dhb.admission.register", string="Intake", compute="_compute_target")

    # --- money ----------------------------------------------------------
    currency_id = fields.Many2one(
        "res.currency", string="Currency",
        default=lambda self: self.env.company.currency_id,
    )
    old_fee = fields.Monetary(
        string="Fee already agreed", currency_field="currency_id")
    amount_paid = fields.Monetary(
        string="Paid so far", currency_field="currency_id",
        compute="_compute_money", store=True,
    )
    new_fee = fields.Monetary(
        string="Fee for the new course", currency_field="currency_id")
    change_fee = fields.Monetary(
        string="Transfer fee", currency_field="currency_id",
        default=lambda self: self._default_change_fee(),
        help="What the centre charges for moving somebody. NEBOSH's own "
             "transfer fee, where one applies, is separate and is set here "
             "too.",
    )
    amount_due = fields.Monetary(
        string="Learner owes", currency_field="currency_id",
        compute="_compute_money", store=True)
    amount_refund = fields.Monetary(
        string="Owed back to the learner", currency_field="currency_id",
        compute="_compute_money", store=True)

    invoice_id = fields.Many2one(
        "account.move", string="Difference invoice", readonly=True, copy=False)
    invoice_payment_state = fields.Selection(
        related="invoice_id.payment_state", string="Payment", readonly=True)

    # --- the decision ---------------------------------------------------
    approved_by = fields.Many2one("res.users", string="Approved by", readonly=True)
    approved_on = fields.Datetime(string="Approved on", readonly=True)
    rejection_reason = fields.Text(string="Why it was refused")
    override_reason = fields.Text(
        string="Why it was allowed anyway",
        help="Required when the move goes against a deadline or a full class.",
    )

    # ------------------------------------------------------------------
    @api.model
    def _default_change_fee(self):
        value = self.env["ir.config_parameter"].sudo().get_param(
            "dhb_admission.course_change_fee", "0")
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    @api.model_create_multi
    def create(self, vals_list):
        for values in vals_list:
            if values.get("name", "/") == "/":
                values["name"] = self.env["ir.sequence"].next_by_code(
                    "dhb.course.change.request") or "/"
        return super().create(vals_list)

    # ------------------------------------------------------------------
    # what the record knows about itself
    # ------------------------------------------------------------------
    @api.depends("application_id.nebosh_entry_done",
                 "from_event_id.nebosh_sitting_id",
                 "to_event_id.nebosh_sitting_id.registration_closing")
    def _compute_nebosh(self):
        today = fields.Date.today()
        for request in self:
            request.nebosh_entered = bool(
                request.application_id.nebosh_entry_done)
            from_sitting = request.from_event_id.nebosh_sitting_id
            to_sitting = request.to_event_id.nebosh_sitting_id
            request.from_sitting_id = from_sitting
            request.to_sitting_id = to_sitting
            request.sitting_changes = bool(
                from_sitting and to_sitting and from_sitting != to_sitting)
            closing = to_sitting.registration_closing if to_sitting else False
            request.new_registration_closing = closing
            request.past_registration_closing = bool(closing and closing < today)

    @api.depends("to_event_id")
    def _compute_target(self):
        Register = self.env["dhb.admission.register"]
        for request in self:
            register = Register.search([
                ("event_id", "=", request.to_event_id.id),
                ("state", "in", ("draft", "published")),
            ], limit=1)
            request.target_register_id = register
            request.target_full = bool(register and register.is_full)

    @api.depends("application_id.invoice_id.amount_total",
                 "application_id.invoice_id.amount_residual",
                 "application_id.invoice_id.state",
                 "application_id.balance_invoice_id.amount_total",
                 "application_id.balance_invoice_id.amount_residual",
                 "application_id.balance_invoice_id.state",
                 "new_fee", "change_fee")
    def _compute_money(self):
        for request in self:
            paid = 0.0
            application = request.application_id
            for invoice in (application.invoice_id | application.balance_invoice_id):
                if invoice.state == "posted":
                    paid += (invoice.amount_total or 0.0) - (
                        invoice.amount_residual or 0.0)
            request.amount_paid = max(paid, 0.0)

            owed = (request.new_fee or 0.0) + (request.change_fee or 0.0) \
                - request.amount_paid
            request.amount_due = owed if owed > 0 else 0.0
            request.amount_refund = -owed if owed < 0 else 0.0

    # ------------------------------------------------------------------
    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        """Find what they are on now, so nobody types it in wrong."""
        if not self.partner_id:
            return
        registration = self.env["dhb.batch.line"].search([
            ("partner_id", "=", self.partner_id._origin.id),
            ("state", "in", ("draft", "open")),
        ], order="create_date desc", limit=1)
        if registration:
            self.from_registration_id = registration
            self.from_event_id = registration.event_id
        application = self.env["dhb.registration.invite"].search([
            ("partner_id", "=", self.partner_id._origin.id),
            ("state", "in", ("accepted", "enrolled")),
        ], order="create_date desc", limit=1)
        if application:
            self.application_id = application
            self.old_fee = application.course_fee
            self.currency_id = application.currency_id

    @api.onchange("to_event_id")
    def _onchange_to_event_id(self):
        """Price the new course from its own intake, not from memory."""
        if self.to_event_id and self.target_register_id:
            self.new_fee = self.target_register_id.course_fee or self.new_fee

    @api.constrains("from_event_id", "to_event_id")
    def _check_events(self):
        for request in self:
            if request.from_event_id == request.to_event_id:
                raise UserError(_(
                    "The current and requested courses are the same."))

    # ------------------------------------------------------------------
    # the pipeline
    # ------------------------------------------------------------------
    def action_request_fee(self):
        for request in self:
            if request.state != "draft":
                raise UserError(_("Only a draft request moves to the fee step."))
            request.state = "fee"
        return True

    def action_create_invoice(self):
        """Invoice the difference, if the learner owes one."""
        for request in self:
            if request.invoice_id:
                raise UserError(_("This request already has its invoice."))
            if request.amount_due <= 0:
                raise UserError(_(
                    "Nothing is owed on this change, so there is no invoice "
                    "to raise."))
            if not request.application_id:
                raise UserError(_(
                    "Link the application first — the invoice is raised "
                    "against it so the learner's account stays in one place."))
            invoice = request.application_id._create_fee_invoice(
                request.amount_due, _("course change"))
            request.invoice_id = invoice.id
        return True

    def _check_before_approval(self):
        self.ensure_one()
        if not (self.reason or "").strip():
            raise UserError(_("Write why the learner is moving."))

        blockers = []
        # Only a change of SITTING touches the awarding body. Two cohorts on
        # the same sitting are an internal seat move and nothing more.
        if self.nebosh_entered and self.sitting_changes:
            if self.past_registration_closing:
                blockers.append(_(
                    "This learner is entered with NEBOSH for %(old)s, the new "
                    "course sits a different assessment, and registration for "
                    "it closed on %(date)s."
                ) % {"old": self.from_sitting_id.name or self.from_event_id.name,
                     "date": self.new_registration_closing})
            else:
                blockers.append(_(
                    "This learner is entered with NEBOSH for %(old)s and the "
                    "new course sits %(new)s. Their exam entry has to be "
                    "changed with NEBOSH as well — the seat moving here does "
                    "not move it there."
                ) % {"old": self.from_sitting_id.name or _("another sitting"),
                     "new": self.to_sitting_id.name or _("a different sitting")})
        if self.target_full:
            blockers.append(_(
                "%s has no places left.") % self.to_event_id.name)

        if blockers and not (self.override_reason or "").strip():
            raise UserError(
                "\n\n".join(blockers) + "\n\n" + _(
                    "Write the reason this is being allowed anyway before "
                    "approving."))
        if blockers and not self.env.user.has_group(MANAGER_GROUP):
            raise UserError(
                "\n\n".join(blockers) + "\n\n" + _(
                    "Only a DHB Attendance Manager can approve it."))

    def action_approve(self):
        for request in self:
            if request.state not in ("draft", "fee"):
                raise UserError(_("Only an open request can be approved."))
            request._check_before_approval()
            request._do_move()
            request.write({
                "state": "approved",
                "approved_by": self.env.user.id,
                "approved_on": fields.Datetime.now(),
            })
        return True

    def _do_move(self):
        """Release the old seat, take the new one, and move the paperwork."""
        self.ensure_one()
        Registration = self.env["dhb.batch.line"]

        old = self.from_registration_id or Registration.search([
            ("partner_id", "=", self.partner_id.id),
            ("event_id", "=", self.from_event_id.id),
        ], limit=1)
        was_confirmed = bool(old and old.state in ("open", "done"))
        if old and old.state != "cancel":
            old.action_cancel()

        new = Registration.search([
            ("partner_id", "=", self.partner_id.id),
            ("event_id", "=", self.to_event_id.id),
        ], limit=1)
        if not new:
            new = Registration.create({
                "event_id": self.to_event_id.id,
                "partner_id": self.partner_id.id,
                "email": self.partner_id.email,
                "name": self.partner_id.legal_name or self.partner_id.name,
            })
        if was_confirmed and new.state == "draft":
            new.action_confirm()
        self.to_registration_id = new.id

        application = self.application_id
        if application:
            application.write({
                "event_id": self.to_event_id.id,
                "register_id": self.target_register_id.id or False,
                "registration_id": new.id,
                "course_fee": self.new_fee or application.course_fee,
            })
            application.message_post(body=_(
                "Moved from %(old)s to %(new)s (%(ref)s). Reason: %(reason)s"
            ) % {
                "old": self.from_event_id.name,
                "new": self.to_event_id.name,
                "ref": self.name,
                "reason": self.reason,
            })
            # Put them on the new course's platform course. The old
            # enrolment is deliberately left alone: removing it would erase
            # whatever they had already done there.
            if was_confirmed:
                try:
                    application._release_lms_access()
                except Exception:  # noqa: BLE001
                    application.message_post(body=_(
                        "The platform could not be updated for the new "
                        "course. Enrol them there by hand."))

        self.message_post(body=_(
            "%(learner)s moved from %(old)s to %(new)s."
        ) % {
            "learner": self.partner_id.display_name,
            "old": self.from_event_id.name,
            "new": self.to_event_id.name,
        })
        return True

    def action_reject(self):
        for request in self:
            if not (request.rejection_reason or "").strip():
                raise UserError(_(
                    "Write why the change is refused. The learner will ask."))
            request.state = "rejected"
            request.message_post(body=_(
                "Refused: %s") % request.rejection_reason)
        return True

    def action_cancel(self):
        self.write({"state": "cancel"})
        return True

    def action_draft(self):
        for request in self:
            if request.state == "approved":
                raise UserError(_(
                    "This change has already been made. Raise a new request "
                    "to move the learner back, so both moves are on record."))
            request.state = "draft"
        return True

    def action_open_application(self):
        self.ensure_one()
        if not self.application_id:
            raise UserError(_("No application is linked to this request."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.registration.invite",
            "res_id": self.application_id.id,
            "view_mode": "form",
        }
