from odoo import models, fields, api, _

# An application only blocks a batch once it has been accepted. Before that
# it is somebody thinking about applying, and a batch is not waiting on them.
LIVE_STATES = ("accepted", "enrolled")


class BatchAdmissionBlockers(models.Model):
    """What admissions knows is missing on a batch.

    Counted by reading the applications rather than by searching on their
    fields: some of what matters here is computed from the learner's contact
    and from invoices, and a domain that happens to work today would fail
    silently the day one of those stops being stored. Reading is a few rows
    per batch and cannot be wrong.
    """

    _inherit = "dhb.batch"

    missing_identity_count = fields.Integer(
        compute="_compute_admission_blockers")
    unsigned_declaration_count = fields.Integer(
        compute="_compute_admission_blockers")
    unpaid_count = fields.Integer(compute="_compute_admission_blockers")

    def _live_applications(self):
        self.ensure_one()
        if not self.id:
            return self.env["dhb.registration.invite"]
        return self.env["dhb.registration.invite"].search([
            ("event_id", "=", self.id),
            ("state", "in", LIVE_STATES),
        ])

    def _compute_admission_blockers(self):
        for batch in self:
            applications = batch._live_applications()
            batch.missing_identity_count = len(applications.filtered(
                lambda a: not a.partner_id or not a.partner_id.id_document_file))
            batch.unsigned_declaration_count = len(applications.filtered(
                lambda a: a.declaration_state != "signed"))
            batch.unpaid_count = len(applications.filtered(
                lambda a: a.amount_outstanding > 0))

    def _batch_blockers(self):
        items = super()._batch_blockers()
        if self.missing_identity_count:
            items.append({
                "label": _("with no identity document"),
                "count": self.missing_identity_count,
            })
        if self.unsigned_declaration_count:
            items.append({
                "label": _("with no signed declaration"),
                "count": self.unsigned_declaration_count,
            })
        if self.unpaid_count:
            items.append({
                "label": _("with a fee still to settle"),
                "count": self.unpaid_count,
            })
        return items

    # ------------------------------------------------------------------
    def _open_applications(self, ids, title):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "%s - %s" % (title, self.display_name),
            "res_model": "dhb.registration.invite",
            "view_mode": "list,form",
            "domain": [("id", "in", ids)],
        }

    def action_open_missing_identity(self):
        applications = self._live_applications().filtered(
            lambda a: not a.partner_id or not a.partner_id.id_document_file)
        return self._open_applications(
            applications.ids, _("No identity document"))

    def action_open_unsigned_declaration(self):
        applications = self._live_applications().filtered(
            lambda a: a.declaration_state != "signed")
        return self._open_applications(
            applications.ids, _("Declaration not signed"))

    def action_open_unpaid(self):
        applications = self._live_applications().filtered(
            lambda a: a.amount_outstanding > 0)
        return self._open_applications(applications.ids, _("Fee outstanding"))
