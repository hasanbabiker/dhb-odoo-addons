from datetime import timedelta

import pytz
from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

from .constants import LANGUAGES, QUALIFICATIONS, STUDY_MODES


def _tz_get(self):
    return [
        (tz, tz)
        for tz in sorted(
            pytz.all_timezones,
            key=lambda tz: tz if not tz.startswith("Etc/") else "_",
        )
    ]


class DhbBatch(models.Model):
    """A cohort of learners taking one qualification together.

    The field names on the relation side are deliberately the ones the rest
    of the system already uses - `registration_ids` here, `event_id` on the
    place. Nobody sees a technical field name; what people read on screen is
    the label. Keeping the names means the nine modules that read the cohort
    today keep working when they are pointed at this model, instead of
    needing two hundred edits that each carry their own chance of a typo.
    """

    _name = "dhb.batch"
    _description = "Batch"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_begin desc, id desc"

    # Generated from the course, the month and the group number, so every
    # batch in the database is named the same way by whoever creates it.
    # Still writable: a name nobody can correct is its own kind of trap.
    name = fields.Char(
        string="Batch", required=True, tracking=True, index="trigram",
        compute="_compute_batch_name", store=True, readonly=False,
        help="Filled in from the course and the start date. Change it only "
             "if you have a reason to.",
    )
    code = fields.Char(
        string="Reference", tracking=True, index=True, copy=False,
        compute="_compute_batch_name", store=True, readonly=False,
        help="Built as COURSE-YYMM-Gn, and used on registers and file names.",
    )
    # An empty Char is stored as NULL, and Postgres allows many NULLs in a
    # unique index, so this constrains only the codes that are actually set.
    _unique_code = models.Constraint(
        "unique(code)",
        "Another batch already uses that reference.",
    )

    state = fields.Selection(
        [
            ("planned", "Planned"),
            ("open", "Open for applications"),
            ("running", "Running"),
            ("exams", "Exams"),
            ("done", "Finished"),
            ("cancelled", "Cancelled"),
        ],
        string="Stage", default="planned", required=True, tracking=True,
        index=True, group_expand="_group_expand_state",
        help="Where the batch is in its life. The board is grouped by this, "
             "so one glance answers which cohorts are live.",
    )

    date_begin = fields.Datetime(
        string="Starts", required=True, tracking=True, index=True,
        default=lambda self: fields.Datetime.now(),
    )
    date_end = fields.Datetime(string="Ends", required=True, tracking=True)
    date_tz = fields.Selection(
        _tz_get, string="Time zone", required=True,
        default=lambda self: self.env.user.tz or "Asia/Dubai",
    )
    duration_days = fields.Integer(
        string="Days", compute="_compute_duration_days", store=True,
    )

    # ------------------------------------------------------------------
    # What is being taught. These lived in the attendance module until
    # the cohort became a model of its own; they describe the batch, and
    # the course catalogue fills them in.
    course_id = fields.Many2one(
        "dhb.course", string="Course", tracking=True, index=True,
        help="Pick the course and the rest of this section fills itself.",
    )
    group_code = fields.Char(
        string="Group", help="Group 1, Group 2 ... within the same month.")

    qualification = fields.Selection(
        QUALIFICATIONS, string="Qualification", index=True)
    delivery_language = fields.Selection(
        LANGUAGES, string="Language of delivery")
    delivery_mode = fields.Selection(
        STUDY_MODES, string="Study mode", default="virtual",
        help="The four modes NEBOSH accepts. Open/Distance Learning was "
             "withdrawn and is no longer an option.")
    in_company = fields.Boolean(
        string="Delivered at the client's site",
        help="A place, not a study mode. A course at a client site is still "
             "Full Time or Part Time.",
    )

    seats_limited = fields.Boolean(
        string="Limit the places", default=False,
        help="Turn this on to cap how many learners the batch takes.",
    )
    seats_max = fields.Integer(
        string="Places", help="Maximum number of learners on this batch.",
    )
    # Kept under this name because a stored compute in the attendance module
    # depends on it. The label is what people read.
    seats_taken = fields.Integer(
        string="Registered", compute="_compute_seats", store=True,
    )
    seats_available = fields.Integer(
        string="Places left", compute="_compute_seats", store=True,
    )
    is_full = fields.Boolean(compute="_compute_seats", store=True)

    # The three numbers a coordinator actually looks for on a board: who has
    # not confirmed yet, who is on the batch, and who has been marked as
    # having attended. Stored so the board can sort and group by them.
    count_draft = fields.Integer(
        string="Unconfirmed", compute="_compute_seats", store=True)
    count_registered = fields.Integer(
        string="On the batch", compute="_compute_seats", store=True)
    count_attended = fields.Integer(
        string="Attended", compute="_compute_seats", store=True)

    registration_ids = fields.One2many(
        "dhb.batch.line", "event_id", string="Learners",
    )

    user_id = fields.Many2one(
        "res.users", string="Coordinator", tracking=True,
        default=lambda self: self.env.user,
        help="Who runs this batch day to day.",
    )
    address_id = fields.Many2one(
        "res.partner", string="Venue",
        domain="[('is_company', '=', True)]",
        help="Where it is held. Leave empty for a batch delivered online.",
    )
    # Without the domain this offered every contact in the database, which
    # in a training centre means it offered the learners - a list of two
    # hundred people to pick a room from.
    company_id = fields.Many2one(
        "res.company", string="Company", required=True,
        default=lambda self: self.env.company,
    )

    description = fields.Html(string="Description")
    note = fields.Html(
        string="Internal notes",
        help="Not shown to learners.",
    )
    active = fields.Boolean(default=True)

    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        """Let the generator fill a name the form left blank.

        A computed field that is also writable loses to any value the client
        sends - and a form with an empty name box sends an empty string. The
        result is a required-field error on a field the system was supposed
        to fill in. Dropping the empty value hands it back to the compute.
        """
        for vals in vals_list:
            if not vals.get("name"):
                vals.pop("name", None)
            if not vals.get("code"):
                vals.pop("code", None)
        return super().create(vals_list)

    # ------------------------------------------------------------------
    @api.depends("course_id", "date_begin", "group_code")
    def _compute_batch_name(self):
        for batch in self:
            course = batch.course_id
            if not course or not batch.date_begin:
                batch.name = batch.name or _("New batch")
                batch.code = batch.code or False
                continue
            when = fields.Datetime.context_timestamp(batch, batch.date_begin)
            group = (batch.group_code or "1").strip()
            # The course code, not its full name: a batch title is read in
            # lists, cards, dropdowns and on an invoice line, and
            # "NEBOSH International General Certificate - September 2026 -
            # Group 1" is cut off in every one of them.
            batch.name = "%s - %s - Group %s" % (
                course.code, when.strftime("%B %Y"), group)
            batch.code = "%s-%s-G%s" % (
                course.code, when.strftime("%y%m"), group)

    def _suggest_group_code(self):
        """The next free group number for this course in this month.

        Two batches of the same course starting in the same month are the
        normal case, not the exception - a morning group and an evening one.
        Guessing the number saves the one field people get wrong.
        """
        self.ensure_one()
        if not self.course_id or not self.date_begin:
            return "1"
        when = fields.Datetime.context_timestamp(self, self.date_begin)
        first = when.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        last = first + relativedelta(months=1)
        taken = self.search_count([
            ("course_id", "=", self.course_id.id),
            ("date_begin", ">=", first.replace(tzinfo=None)),
            ("date_begin", "<", last.replace(tzinfo=None)),
            ("id", "!=", self._origin.id or 0),
        ])
        return str(taken + 1)

    def _apply_course_defaults(self):
        """Copy what the course knows onto the batch.

        Written as one method other modules extend rather than a pile of
        onchanges, so the attendance module can add its own fields to the
        same press without this one knowing they exist.
        """
        for batch in self:
            course = batch.course_id
            if not course:
                continue
            batch.qualification = course.qualification
            batch.delivery_language = course.delivery_language
            batch.delivery_mode = course.delivery_mode
            if batch.date_begin and course.duration_days > 0:
                batch.date_end = batch.date_begin + timedelta(
                    days=course.duration_days - 1)
            if not batch.description:
                batch.description = course.description

    @api.onchange("course_id", "date_begin")
    def _onchange_course_id(self):
        if self.course_id and not self.group_code:
            self.group_code = self._suggest_group_code()
        self._apply_course_defaults()

    # ------------------------------------------------------------------
    # What is standing in this batch's way, gathered from every module that
    # knows something about it. Deliberately a list of named obstacles with
    # counts, not a readiness percentage: nobody can act on "87% ready", and
    # everybody can act on "4 learners with no identity document".
    blocker_summary = fields.Char(
        string="Needs attention", compute="_compute_blockers")
    blocker_count = fields.Integer(compute="_compute_blockers")
    is_ready = fields.Boolean(
        string="Nothing outstanding", compute="_compute_blockers")

    def _batch_blockers(self):
        """Return [{"label": str, "count": int}, ...].

        Empty here. Each module adds its own by calling super() and appending
        - the same shape as _apply_course_defaults, so this model never has
        to know what a NEBOSH sitting or a signed declaration is.
        """
        self.ensure_one()
        return []

    def _compute_blockers(self):
        for batch in self:
            items = batch._batch_blockers() if batch.id else []
            batch.blocker_count = sum(item["count"] for item in items)
            batch.blocker_summary = " \u00b7 ".join(
                "%s %s" % (item["count"], item["label"]) for item in items
            ) or False
            batch.is_ready = not items

    # ------------------------------------------------------------------
    # Every number this model shows is a door to the rows behind it.
    def _open_lines(self, states, title):
        self.ensure_one()
        domain = [("event_id", "=", self.id)]
        if states:
            domain.append(("state", "in", states))
        return {
            "type": "ir.actions.act_window",
            "name": "%s - %s" % (title, self.display_name),
            "res_model": "dhb.batch.line",
            "view_mode": "list,form",
            "domain": domain,
            "context": {"default_event_id": self.id},
        }

    def action_open_unconfirmed(self):
        return self._open_lines(["draft"], _("Unconfirmed"))

    def action_open_registered(self):
        return self._open_lines(["open"], _("On the batch"))

    def action_open_attended(self):
        return self._open_lines(["done"], _("Attended"))

    # ------------------------------------------------------------------
    @api.model
    def _group_expand_state(self, states, domain):
        """Show every stage as a column, including the empty ones.

        A board that hides "Exams" until a batch reaches it makes the stage
        look like it does not exist.
        """
        return [key for key, _label in self._fields["state"].selection]

    @api.depends("date_begin", "date_end")
    def _compute_duration_days(self):
        for batch in self:
            if batch.date_begin and batch.date_end:
                delta = batch.date_end - batch.date_begin
                batch.duration_days = delta.days + 1
            else:
                batch.duration_days = 0

    @api.depends("registration_ids.state", "seats_max", "seats_limited")
    def _compute_seats(self):
        for batch in self:
            lines = batch.registration_ids
            batch.count_draft = len(lines.filtered(
                lambda line: line.state == "draft"))
            batch.count_registered = len(lines.filtered(
                lambda line: line.state == "open"))
            batch.count_attended = len(lines.filtered(
                lambda line: line.state == "done"))
            taken = len(lines.filtered(
                lambda line: line.state in ("draft", "open", "done")))
            batch.seats_taken = taken
            if batch.seats_limited and batch.seats_max:
                batch.seats_available = max(batch.seats_max - taken, 0)
                batch.is_full = taken >= batch.seats_max
            else:
                batch.seats_available = 0
                batch.is_full = False

    @api.constrains("date_begin", "date_end")
    def _check_dates(self):
        for batch in self:
            if batch.date_begin and batch.date_end \
                    and batch.date_end < batch.date_begin:
                raise ValidationError(_(
                    "%s ends before it starts.") % batch.display_name)

    @api.constrains("seats_limited", "seats_max")
    def _check_seats(self):
        for batch in self:
            if batch.seats_limited and batch.seats_max <= 0:
                raise ValidationError(_(
                    "%s limits the places but the number of places is not "
                    "set.") % batch.display_name)

    @api.depends("name", "code")
    def _compute_display_name(self):
        for batch in self:
            batch.display_name = \
                "[%s] %s" % (batch.code, batch.name) if batch.code \
                else (batch.name or "")

    # ------------------------------------------------------------------
    def action_open_applications(self):
        self.write({"state": "open"})

    def action_start(self):
        self.write({"state": "running"})

    def action_exams(self):
        self.write({"state": "exams"})

    def action_finish(self):
        self.write({"state": "done"})

    def action_cancel(self):
        self.write({"state": "cancelled"})

    def action_back_to_planned(self):
        self.write({"state": "planned"})

    def action_open_learners(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Learners on %s") % self.display_name,
            "res_model": "dhb.batch.line",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }
