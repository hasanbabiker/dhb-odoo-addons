{
    "name": "DHB Results",
    "version": "19.0.1.0.0",
    "summary": "What came back from the awarding body, and the one deadline "
               "nobody was watching",
    "description": """
DHB Results
===========

**This module adds no table.** The results already live in
``dhb.nebosh.result``, filled by the URN importer. A second store for the
same fact would mean two marks for one learner and nobody able to say which
is right.

What was missing was not a place to keep results. It was a place to look at
them - grouped by unit, by qualification, by month, with the marks as a
chart rather than a column - and one deadline nobody was watching.

That deadline is the reason this exists. A NEBOSH Enquiry About Result has a
published cut-off, and when it passes the learner's right to a re-mark is
gone: no appeal, no discretion. The date was already on every result row and
nothing ever read it. Now a list shows the windows still open, worst first,
and a nightly job raises an activity when one is days away.

Two menus and nothing else. The exam entries, units and sittings already
have a home in the Exams app, and the URN importer one under Awarding
Bodies; repeating them here would give each of them two doors.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Education",
    "license": "LGPL-3",
    "depends": [
        "base", "mail",
        # For dhb.nebosh.result itself.
        "dhb_learner",
    ],
    # No ir.model.access.csv: this module declares no model of its own, so
    # the rights on dhb.nebosh.result are the ones that already govern it.
    "data": [
        "views/result_views.xml",
        "views/menus.xml",
    ],
    "post_init_hook": "_create_ear_cron",
    "installable": True,
    "application": True,
    "auto_install": False,
}
