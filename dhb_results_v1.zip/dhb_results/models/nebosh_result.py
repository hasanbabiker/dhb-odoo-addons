"""What came back from the awarding body, and what we must do about it.

This module adds **no table**. The results already live in
``dhb.nebosh.result``, filled by the URN importer, and a second store for
the same fact would mean two marks for one learner with nobody able to say
which is right. What was missing was not a place to keep results - it was a
place to look at them, and one deadline nobody was watching.

That deadline is the whole reason this module exists. A NEBOSH Enquiry About
Result has a published cut-off, and when it passes the learner's right to a
re-mark is gone: there is no appeal against the deadline and no discretion
behind it. The date was already recorded on every result row and nothing in
the system ever looked at it. Now something does, every morning.
"""

from odoo import models, fields, api, _


# When a deadline moves from "note it" to "do it today". Three days is a
# working margin: an enquiry needs the learner told, a decision from them,
# and a form submitted - none of which happens in an afternoon.
URGENT_DAYS = 3
SOON_DAYS = 10


class DhbNeboshResult(models.Model):
    # The activity mixin is named here rather than assumed.
    #
    # `activity_schedule` below belongs to mail.activity.mixin, and the
    # result model may or may not already carry it - the columns give no
    # answer, because activities live in their own table. Assuming wrongly
    # would not fail the install; it would fail at three in the morning
    # inside the cron, which is the worst place to find out. Naming it is
    # free when it is already there and correct when it is not.
    _inherit = ["dhb.nebosh.result", "mail.thread", "mail.activity.mixin"]

    # Non-stored: it is a countdown, and a countdown that is written down is
    # wrong by morning.
    ear_days_left = fields.Integer(
        string="Days to EAR deadline", compute="_compute_ear")

    # Stored, because it has to be a filter and a facet on the left of the
    # screen - a deadline nobody can search for is a deadline nobody finds.
    # Being stored and time-based, it is refreshed by the cron below; see
    # the comment there for why that runs where it does.
    ear_state = fields.Selection(
        [
            ("none", "No deadline recorded"),
            ("requested", "Enquiry submitted"),
            ("open", "Open"),
            ("soon", "Closing soon"),
            ("urgent", "Closes within days"),
            ("expired", "Deadline passed"),
        ],
        string="Enquiry window", compute="_compute_ear", store=True,
        index=True, default="none",
    )

    @api.depends("ear_deadline", "ear_requested")
    def _compute_ear(self):
        today = fields.Date.context_today(self)
        for result in self:
            deadline = result.ear_deadline
            result.ear_days_left = (deadline - today).days if deadline else 0
            if result.ear_requested:
                result.ear_state = "requested"
            elif not deadline:
                result.ear_state = "none"
            elif deadline < today:
                result.ear_state = "expired"
            elif (deadline - today).days <= URGENT_DAYS:
                result.ear_state = "urgent"
            elif (deadline - today).days <= SOON_DAYS:
                result.ear_state = "soon"
            else:
                result.ear_state = "open"

    # ------------------------------------------------------------------
    @api.model
    def _cron_ear_deadlines(self):
        """Refresh the window, then chase the ones about to close.

        The refresh comes first here, and that is safe only because nothing
        below searches on write_date. Assigning to a stored computed field
        outside a compute context issues a real write, and a write stamps
        write_date - which is exactly how a reminder elsewhere in this
        system was silently disabled for good. Worth stating rather than
        remembering.
        """
        open_windows = self.search([
            ("ear_requested", "=", False),
            ("ear_deadline", "!=", False),
        ])
        if open_windows:
            open_windows._compute_ear()

        closing = open_windows.filtered(
            lambda r: r.ear_state in ("urgent", "soon"))
        for result in closing:
            result._raise_ear_activity()

    def _raise_ear_activity(self):
        """One open activity per result, never a second every night."""
        self.ensure_one()
        todo = self.env.ref("mail.mail_activity_data_todo")
        if self.env["mail.activity"].search_count([
            ("res_model", "=", self._name),
            ("res_id", "=", self.id),
            ("activity_type_id", "=", todo.id),
        ]):
            return
        self.activity_schedule(
            "mail.mail_activity_data_todo",
            date_deadline=self.ear_deadline,
            summary=_("EAR deadline: %s") % (self.partner_id.display_name or ""),
            note=_(
                "The enquiry window on %(unit)s closes on %(date)s - "
                "%(days)s days. After that the mark cannot be challenged at "
                "all: there is no appeal against the deadline.",
                unit=self.unit_code or _("this unit"),
                date=self.ear_deadline,
                days=self.ear_days_left,
            ),
        )
