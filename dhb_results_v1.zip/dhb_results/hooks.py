"""Create the nightly job without guessing an external id.

`<field name="model_id" ref="..."/>` needs the xmlid of the ir.model record
for dhb.nebosh.result - which belongs to whichever module declares that
model, not to this one. Guessing it wrong does not degrade gracefully: the
install fails and rolls back on a live database. Looking the model up by
name cannot be wrong.
"""

from odoo import api, SUPERUSER_ID


CRON_XMLID = "dhb_results.cron_ear_deadlines"


def _create_ear_cron(env):
    if env.ref(CRON_XMLID, raise_if_not_found=False):
        return
    cron = env["ir.cron"].create({
        "name": "Results: enquiry deadlines closing",
        "model_id": env["ir.model"]._get_id("dhb.nebosh.result"),
        "state": "code",
        "code": "model._cron_ear_deadlines()",
        "interval_number": 1,
        "interval_type": "days",
        "active": True,
    })
    module, name = CRON_XMLID.split(".")
    env["ir.model.data"].create({
        "module": module,
        "name": name,
        "model": "ir.cron",
        "res_id": cron.id,
        "noupdate": True,
    })
