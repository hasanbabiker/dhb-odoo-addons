# -*- coding: utf-8 -*-
"""Keep the awarding-body learner numbers in step with Moodle.

Moodle stores them as custom profile fields, which arrive in a separate
'customfields' list rather than as ordinary user keys. The short names are
configurable because every Moodle site names its own fields.
"""

import logging

from odoo import _, api, fields, models

from odoo.addons.moodle_connector.models.moodle_api import MoodleAPI, MoodleError

_logger = logging.getLogger(__name__)

DEFAULT_NEBOSH_SHORTNAME = "nebosh_no"
DEFAULT_IOSH_SHORTNAME = "iosh_no"


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    moodle_nebosh_field = fields.Char(
        "Moodle NEBOSH Field", default=DEFAULT_NEBOSH_SHORTNAME,
        config_parameter="dhb_learner.moodle_nebosh_field",
        help="Short name of the custom profile field in Moodle that holds the "
             "NEBOSH learner number.")
    moodle_iosh_field = fields.Char(
        "Moodle IOSH Field", default=DEFAULT_IOSH_SHORTNAME,
        config_parameter="dhb_learner.moodle_iosh_field",
        help="Short name of the custom profile field in Moodle that holds the "
             "IOSH learner number. Leave empty if the field does not exist.")


class ResPartner(models.Model):
    _inherit = "res.partner"

    def _moodle_number_fields(self):
        params = self.env["ir.config_parameter"].sudo()
        return {
            "nebosh_learner_number": params.get_param(
                "dhb_learner.moodle_nebosh_field", DEFAULT_NEBOSH_SHORTNAME),
            "iosh_learner_number": params.get_param(
                "dhb_learner.moodle_iosh_field", DEFAULT_IOSH_SHORTNAME),
        }

    def _pull_learner_numbers(self, moodle_user):
        """Copy the awarding-body numbers from Moodle onto the contact.

        An existing value in Odoo is never overwritten: Odoo is the system of
        record once a number has been entered here.
        """
        self.ensure_one()
        values = {}
        for odoo_field, shortname in self._moodle_number_fields().items():
            if not shortname or self[odoo_field]:
                continue
            value = MoodleAPI.custom_field(moodle_user, shortname)
            if value:
                values[odoo_field] = value
        if values:
            self.sudo().write(values)
        return bool(values)

    def _push_learner_numbers(self, instance):
        """Send the numbers held in Odoo up to Moodle."""
        self.ensure_one()
        if not self.moodle_user_id:
            return False
        custom = [
            {"type": shortname, "value": self[odoo_field]}
            for odoo_field, shortname in self._moodle_number_fields().items()
            if shortname and self[odoo_field]
        ]
        if not custom:
            return False
        url, token, verify = instance._args()
        try:
            MoodleAPI.update_user(url, token, {
                "id": self.moodle_user_id,
                "customfields": custom,
            }, verify_ssl=verify)
        except MoodleError as err:
            self.message_post(body=_("Could not send the learner numbers to "
                                     "Moodle: %s")
                              % (err.args[0] if err.args else err))
            return False
        return True

    def action_sync_learner_numbers(self):
        """Two-way: pull anything missing here, then push what Odoo holds."""
        instance = self.env["moodle.instance"].search(
            [("state", "=", "connected")], limit=1)
        if not instance:
            return False
        url, token, verify = instance._args()
        pulled = pushed = 0
        for partner in self.filtered("email"):
            moodle_user = MoodleAPI.get_user_by_email(
                url, token, partner.email.strip().lower(),
                verify_ssl=verify) or {}
            if moodle_user and partner._pull_learner_numbers(moodle_user):
                pulled += 1
            if partner._push_learner_numbers(instance):
                pushed += 1
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "type": "success",
                "title": _("Learner numbers"),
                "message": _("%(pulled)s pulled from Moodle, %(pushed)s sent up.",
                             pulled=pulled, pushed=pushed),
                "sticky": False,
            },
        }


class MoodleEnrolment(models.Model):
    _inherit = "moodle.enrolment"

    @api.model
    def _pull_for_course(self, course):
        """Pick up learner numbers while the enrolment sync is already
        walking every user in the course."""
        count = super()._pull_for_course(course)
        try:
            self._pull_numbers_for_course(course)
        except MoodleError as err:
            _logger.info("Moodle: learner numbers unavailable for %s (%s)",
                         course.display_name, err)
        return count

    @api.model
    def _pull_numbers_for_course(self, course):
        url, token, verify = course.instance_id._args()
        users = MoodleAPI.enrolled_users(url, token, course.moodle_id,
                                         verify_ssl=verify)
        by_id = {u.get("id"): u for u in users}
        for enrolment in course.enrolment_ids.filtered("partner_id"):
            moodle_user = by_id.get(enrolment.moodle_user_id)
            if moodle_user:
                enrolment.partner_id._pull_learner_numbers(moodle_user)
        return True
