# -*- coding: utf-8 -*-
from . import res_partner
from . import res_config_settings
from . import moodle_enrol_wizard
from . import moodle_profile_sync
