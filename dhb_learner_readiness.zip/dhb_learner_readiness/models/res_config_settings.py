# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    sign_template_ar_id = fields.Many2one(
        "sign.template", string="Arabic Agreement Template",
        config_parameter="dhb_learner.sign_template_ar")
    sign_template_en_id = fields.Many2one(
        "sign.template", string="English Agreement Template",
        config_parameter="dhb_learner.sign_template_en")

    def action_open_certificate_types(self):
        return self.env["ir.actions.act_window"]._for_xml_id(
            "dhb_learner_readiness.action_learner_certificate_type")
