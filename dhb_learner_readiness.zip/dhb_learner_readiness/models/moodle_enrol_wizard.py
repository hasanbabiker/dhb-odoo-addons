# -*- coding: utf-8 -*-
"""Block enrolment until the learner file is complete, and pull the detailed
grade items that the base connector summarises away.
"""

import logging

from odoo import _, api, fields, models

from odoo.addons.moodle_connector.models.moodle_api import MoodleAPI, MoodleError

_logger = logging.getLogger(__name__)


class MoodleEnrolWizard(models.TransientModel):
    _inherit = "moodle.enrol.wizard"

    def action_enrol(self):
        # Readiness first: a blocked learner never reaches Moodle.
        self.partner_ids._check_learner_ready()
        return super().action_enrol()


class MoodleEnrolment(models.Model):
    _inherit = "moodle.enrolment"

    grade_item_ids = fields.One2many(
        "moodle.grade.item", "enrolment_id", string="Assessments")
    assessments_passed = fields.Integer(compute="_compute_assessment_stats",
                                        store=True)
    assessments_total = fields.Integer(compute="_compute_assessment_stats",
                                       store=True)

    @api.depends("grade_item_ids.passed")
    def _compute_assessment_stats(self):
        for record in self:
            items = record.grade_item_ids
            record.assessments_total = len(items)
            record.assessments_passed = len(items.filtered("passed"))

    @api.model
    def _pull_for_course(self, course):
        """Extend the base sync with per-assessment grade items."""
        count = super()._pull_for_course(course)
        try:
            self._pull_grade_items(course)
        except MoodleError as err:
            _logger.info("Moodle: grade items unavailable for %s (%s)",
                         course.display_name, err)
        return count

    @api.model
    def _pull_grade_items(self, course):
        """Store every assessment separately, not just the course total."""
        url, token, verify = course.instance_id._args()
        body = MoodleAPI.call(
            url, token, "gradereport_user_get_grade_items",
            {"courseid": course.moodle_id}, verify_ssl=verify) or {}

        Item = self.env["moodle.grade.item"]
        by_user = {e.moodle_user_id: e for e in course.enrolment_ids}

        for usergrade in body.get("usergrades") or []:
            enrolment = by_user.get(usergrade.get("userid"))
            if not enrolment:
                continue
            existing = {i.moodle_item_id: i for i in enrolment.grade_item_ids}
            sequence = 10
            for item in usergrade.get("gradeitems") or []:
                # The unnamed 'course' item is the total; the base module
                # already stores it on the enrolment itself.
                if item.get("itemtype") == "course" or not item.get("itemname"):
                    continue
                raw = item.get("graderaw")
                values = {
                    "enrolment_id": enrolment.id,
                    "moodle_item_id": item.get("id"),
                    "name": item.get("itemname"),
                    "item_module": item.get("itemmodule") or item.get("itemtype"),
                    "sequence": sequence,
                    "grade": raw or 0.0,
                    "grade_max": item.get("grademax") or 0.0,
                    # graderaw is null when the learner never attempted it,
                    # which is not the same as scoring zero.
                    "attempted": raw is not None,
                }
                sequence += 10
                record = existing.get(item.get("id"))
                if record:
                    record.write(values)
                else:
                    Item.create(values)
        return True
