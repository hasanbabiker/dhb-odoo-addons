# -*- coding: utf-8 -*-
{
    "name": "Learner Readiness File",
    "version": "19.0.1.0.1",
    "category": "Services/Training",
    "summary": "A learner is only enrolled once their ID, payment and signed "
               "agreement are all in place.",
    "description": """
Learner Readiness File
======================

Turns three separate checks into one status on the contact form:

* **Identity** - document type, number, expiry and a scanned copy. An expired
  document does not count as valid.
* **Payment** - computed from the customer's own invoices. Any amount actually
  paid satisfies the check.
* **Signed agreement** - sent through Odoo Sign in Arabic or English. The link
  to the signed document is stored on the contact.

Enrolment into Moodle is blocked until all three pass. A Moodle administrator
can override with a recorded reason, so the block never stops real work.
""",
    "author": "",
    "website": "",
    "license": "LGPL-3",
    "depends": ["moodle_connector", "account", "sign"],
    "data": [
        "security/ir.model.access.csv",
        "data/certificate_types.xml",
        "views/res_partner_views.xml",
        "views/res_config_settings_views.xml",
        "views/learner_menus.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
