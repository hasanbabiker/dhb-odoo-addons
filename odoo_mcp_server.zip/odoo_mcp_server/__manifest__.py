# -*- coding: utf-8 -*-
{
    "name": "MCP Server for Odoo",
    "version": "19.0.1.0.0",
    "category": "Productivity/Tools",
    "summary": "Run a Model Context Protocol server inside Odoo so Claude, "
               "Cursor and other MCP clients can query and edit your data.",
    "description": """
MCP Server for Odoo
===================

Turns your Odoo instance into an MCP server. No separate daemon: the endpoints
run inside the normal Odoo workers.

Endpoints
---------
* ``/mcp``            Streamable HTTP transport (current MCP spec)
* ``/mcp/sse``        legacy HTTP+SSE transport
* ``/mcp/health``     liveness probe
* ``/.well-known/oauth-protected-resource`` and
  ``/.well-known/oauth-authorization-server`` for OAuth discovery

Authentication
--------------
* **Bearer token** - generated per user in Odoo, stored hashed.
* **OAuth 2.1** - authorization code + PKCE + dynamic client registration,
  which is what Claude's custom connectors expect.

Safety model
------------
Every call runs as the Odoo user the token belongs to, through the normal ORM,
so access rights and record rules apply unchanged. On top of that, no model is
reachable until you explicitly add it to the MCP allowlist, with per-operation
flags, a field blacklist and an optional extra domain.
""",
    "author": "",
    "website": "",
    "license": "LGPL-3",
    "depends": ["base", "base_setup", "web"],
    "data": [
        "security/mcp_security.xml",
        "security/ir.model.access.csv",
        "data/mcp_data.xml",
        "views/mcp_templates.xml",
        "views/mcp_model_access_views.xml",
        "views/mcp_token_views.xml",
        "views/mcp_log_views.xml",
        "views/mcp_oauth_views.xml",
        "views/res_config_settings_views.xml",
        "views/mcp_menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
