# -*- coding: utf-8 -*-
"""The MCP protocol implementation.

``mcp.server`` is an AbstractModel so that other modules can extend the tool
set simply by overriding ``_mcp_tools`` and adding a ``_tool_<name>`` method.
"""

import json
import logging
import time

from odoo import _, api, models
from odoo.exceptions import AccessError, UserError, ValidationError

from .mcp_model_access import and_domains

_logger = logging.getLogger(__name__)

SERVER_NAME = "odoo-mcp-server"
SERVER_VERSION = "1.0.0"

# Spec revisions this server understands. The client's version is echoed back
# when we support it, otherwise we answer with our preferred one.
SUPPORTED_PROTOCOL_VERSIONS = ["2025-06-18", "2025-03-26", "2024-11-05"]
PREFERRED_PROTOCOL_VERSION = "2025-06-18"

# JSON-RPC error codes
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603

MAX_LIMIT = 500

# Method names that are really the ORM, reachable through the method tool
# and bypassing every check in it.
FORBIDDEN_METHODS = {
    "write", "create", "unlink", "copy", "copy_data", "browse", "search",
    "search_read", "search_fetch", "read", "read_group", "fields_get",
    "_read_group", "formatted_read_group", "load", "export_data",
    "with_user", "sudo", "with_context", "with_env", "check_access",
    "name_create", "default_get", "toggle_active", "action_archive",
    "action_unarchive", "web_save", "web_read", "onchange",
}


class McpServer(models.AbstractModel):
    _name = "mcp.server"
    _description = "MCP Server"

    # ==================================================================
    # dispatch
    # ==================================================================
    @api.model
    # Private on purpose. A public method on a model is callable over
    # /web/dataset/call_kw by any logged-in user, which skipped the enabled
    # switch, the token, the rate limit and the batch cap all at once.
    def _dispatch(self, message, token=None, remote_addr=None):
        """Handle a single JSON-RPC message. Returns a dict, or None for
        notifications (which must get no response body)."""
        if not isinstance(message, dict):
            return self._error(None, INVALID_REQUEST, _("Message must be an object."))

        method = message.get("method")
        message_id = message.get("id")
        params = message.get("params") or {}

        if method is None:
            return self._error(message_id, INVALID_REQUEST, _("Missing method."))
        # Notifications carry no id and expect no answer.
        if message_id is None:
            self._handle_notification(method, params)
            return None

        started = time.time()
        handler = {
            "initialize": self._handle_initialize,
            "ping": lambda p: {},
            "tools/list": self._handle_tools_list,
            "tools/call": self._handle_tools_call,
            "resources/list": self._handle_resources_list,
            "resources/templates/list": lambda p: {"resourceTemplates": []},
            "resources/read": self._handle_resources_read,
            "prompts/list": self._handle_prompts_list,
            "prompts/get": self._handle_prompts_get,
            "logging/setLevel": lambda p: {},
        }.get(method)

        if handler is None:
            return self._error(message_id, METHOD_NOT_FOUND,
                               _("Unknown method: %s") % method)

        try:
            result = handler(params)
            response = {"jsonrpc": "2.0", "id": message_id, "result": result}
            success, error_message = True, False
        except (AccessError, UserError, ValidationError) as err:
            message_text = err.args[0] if err.args else str(err)
            response = self._error(message_id, INVALID_PARAMS, message_text)
            success, error_message = False, message_text
        except Exception as err:  # noqa: BLE001
            # The full exception goes to the server log, never to the client.
            # Odoo's internal errors carry table names, constraint names and
            # file paths, and handing those to whoever is on the other end of
            # an internet endpoint is free reconnaissance.
            _logger.exception("MCP: unhandled error on %s", method)
            response = self._error(
                message_id, INTERNAL_ERROR,
                _("Something went wrong handling that request. The details "
                  "are in the Odoo server log."))
            success, error_message = False, str(err)

        self._log_call(token, method, params, started, success,
                       error_message, remote_addr)
        return response

    def _handle_notification(self, method, params):
        if method not in ("notifications/initialized", "notifications/cancelled"):
            _logger.debug("MCP: ignoring notification %s", method)

    @staticmethod
    def _error(message_id, code, message, data=None):
        error = {"code": code, "message": message}
        if data:
            error["data"] = data
        return {"jsonrpc": "2.0", "id": message_id, "error": error}

    def _log_call(self, token, method, params, started, success,
                  error_message, remote_addr):
        params = params or {}
        arguments = params.get("arguments") if method == "tools/call" else None
        self.env["mcp.request.log"]._log({
            "token_id": token.id if token else False,
            "user_id": self.env.uid,
            "method": method,
            "tool_name": params.get("name") if method == "tools/call" else False,
            "model_name": (arguments or {}).get("model"),
            "arguments": json.dumps(arguments, default=str)[:4000] if arguments else False,
            "duration_ms": int((time.time() - started) * 1000),
            "success": success,
            "error_message": (error_message or "")[:500] or False,
            "remote_addr": remote_addr,
        })

    # ==================================================================
    # handshake
    # ==================================================================
    @api.model
    def _handle_initialize(self, params):
        requested = params.get("protocolVersion")
        version = requested if requested in SUPPORTED_PROTOCOL_VERSIONS \
            else PREFERRED_PROTOCOL_VERSION
        return {
            "protocolVersion": version,
            "capabilities": {
                "tools": {"listChanged": False},
                "resources": {"subscribe": False, "listChanged": False},
                "prompts": {"listChanged": False},
                "logging": {},
            },
            "serverInfo": {
                "name": SERVER_NAME,
                "title": self.env.company.name or "Odoo",
                "version": SERVER_VERSION,
            },
            "instructions": self._instructions(),
        }

    @api.model
    def _instructions(self):
        models_config = self.env["mcp.model.access"].sudo().search([])
        lines = [
            "This server exposes a live Odoo %s database." % self.env.company.name,
            "Only the models listed by odoo_list_models are reachable; any other "
            "model returns an access error.",
            "Call odoo_get_model_schema before writing to a model you have not "
            "written to yet, so you use the right field names and selection values.",
            "Domains use Odoo's polish-notation list syntax, "
            "e.g. [['state','=','sale'],['amount_total','>',1000]].",
        ]
        if models_config:
            lines.append("Available models: %s." % ", ".join(
                models_config.mapped("model_name")[:50]))
        return "\n".join(lines)

    # ==================================================================
    # tools
    # ==================================================================
    @api.model
    def _mcp_tools(self):
        """Tool definitions. Override and extend in your own module."""
        return [
            {
                "name": "odoo_list_models",
                "description": (
                    "List the Odoo models this connector may use, with what "
                    "each one is for and which operations are allowed. Call "
                    "this first when you do not know the model name."),
                "inputSchema": {"type": "object", "properties": {}},
            },
            {
                "name": "odoo_get_model_schema",
                "description": (
                    "Describe the fields of one Odoo model: type, label, "
                    "whether it is required, selection values and the related "
                    "model for relational fields."),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string",
                                  "description": "Technical model name, e.g. res.partner"},
                        "fields": {
                            "type": "array", "items": {"type": "string"},
                            "description": "Optional subset of field names to describe."},
                    },
                    "required": ["model"],
                },
            },
            {
                "name": "odoo_search",
                "description": (
                    "Search records and read their fields in one call. Returns "
                    "the matching records as JSON."),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "domain": {
                            "type": "array",
                            "description": "Odoo domain, e.g. [['name','ilike','acme']]. "
                                           "Empty list matches everything.",
                            "default": []},
                        "fields": {"type": "array", "items": {"type": "string"},
                                   "description": "Fields to return. Omit for a sensible default set."},
                        "limit": {"type": "integer", "default": 20},
                        "offset": {"type": "integer", "default": 0},
                        "order": {"type": "string",
                                  "description": "e.g. 'create_date desc'"},
                    },
                    "required": ["model"],
                },
            },
            {
                "name": "odoo_count",
                "description": "Count the records matching a domain, without reading them.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "domain": {"type": "array", "default": []},
                    },
                    "required": ["model"],
                },
            },
            {
                "name": "odoo_read",
                "description": "Read specific records by id.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "ids": {"type": "array", "items": {"type": "integer"}},
                        "fields": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["model", "ids"],
                },
            },
            {
                "name": "odoo_aggregate",
                "description": (
                    "Group and aggregate records - the tool to use for "
                    "dashboards, totals and 'sales per month' style questions. "
                    "Wraps Odoo's read_group."),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "domain": {"type": "array", "default": []},
                        "fields": {
                            "type": "array", "items": {"type": "string"},
                            "description": "Measures, e.g. ['amount_total:sum']"},
                        "groupby": {
                            "type": "array", "items": {"type": "string"},
                            "description": "e.g. ['partner_id'] or ['date_order:month']"},
                        "limit": {"type": "integer", "default": 100},
                    },
                    "required": ["model", "fields", "groupby"],
                },
            },
            {
                "name": "odoo_create",
                "description": "Create one record and return its id.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "values": {"type": "object",
                                   "description": "Field name to value mapping."},
                    },
                    "required": ["model", "values"],
                },
            },
            {
                "name": "odoo_update",
                "description": "Update existing records.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "ids": {"type": "array", "items": {"type": "integer"}},
                        "values": {"type": "object"},
                    },
                    "required": ["model", "ids", "values"],
                },
            },
            {
                "name": "odoo_delete",
                "description": "Delete records. Irreversible; ask the user first.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "ids": {"type": "array", "items": {"type": "integer"}},
                    },
                    "required": ["model", "ids"],
                },
            },
            {
                "name": "odoo_call_method",
                "description": (
                    "Call a business method on records, e.g. action_confirm on "
                    "a sale order. Only methods an administrator explicitly "
                    "allowed for that model can be called."),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                        "ids": {"type": "array", "items": {"type": "integer"}},
                        "method": {"type": "string"},
                        "kwargs": {"type": "object", "default": {}},
                    },
                    "required": ["model", "ids", "method"],
                },
            },
            {
                "name": "odoo_search_everywhere",
                "description": (
                    "Free-text search across every exposed model at once. Use "
                    "it when the user names something without saying what it "
                    "is - a company, a reference, a product."),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "limit_per_model": {"type": "integer", "default": 5},
                    },
                    "required": ["query"],
                },
            },
        ]

    @api.model
    def _handle_tools_list(self, params):
        return {"tools": self._mcp_tools()}

    @api.model
    def _handle_tools_call(self, params):
        name = params.get("name")
        arguments = params.get("arguments") or {}
        known = {tool["name"] for tool in self._mcp_tools()}
        if name not in known:
            raise UserError(_("Unknown tool: %s") % name)
        handler = getattr(self, "_tool_%s" % name, None)
        if handler is None:
            raise UserError(_("Tool %s has no implementation.") % name)
        try:
            payload = handler(**arguments)
        except TypeError as err:
            raise UserError(_("Bad arguments for %(tool)s: %(err)s",
                              tool=name, err=err))
        except (AccessError, UserError, ValidationError) as err:
            # Report tool failures inside the result so the model can recover,
            # rather than as a protocol-level error.
            return {
                "content": [{"type": "text",
                             "text": err.args[0] if err.args else str(err)}],
                "isError": True,
            }
        text = payload if isinstance(payload, str) else json.dumps(
            payload, indent=2, default=str, ensure_ascii=False)
        return {"content": [{"type": "text", "text": text}], "isError": False}

    # ------------------------------------------------------------------
    # helpers shared by the tools
    # ------------------------------------------------------------------
    @api.model
    def _model_and_config(self, model_name, operation):
        if operation != "read" and not self.env.context.get("mcp_allow_write"):
            raise AccessError(_(
                "Write operations are disabled on this Odoo instance."))
        config = self.env["mcp.model.access"]._get_for(model_name, operation)
        if model_name not in self.env:
            raise UserError(_("Model %s does not exist.") % model_name)
        return self.env[model_name], config

    @api.model
    def _default_fields(self, model, config):
        """A small readable field set, so answers stay compact by default."""
        allowed = set(config.allowed_fields(model))
        preferred = [
            "id", "name", "display_name", "state", "partner_id", "user_id",
            "date", "date_order", "create_date", "amount_total", "email",
            "phone", "default_code", "list_price", "ref", "active",
        ]
        chosen = [f for f in preferred if f in allowed]
        if "id" not in chosen:
            chosen.insert(0, "id")
        return chosen or sorted(allowed)[:15]

    @api.model
    def _clamp(self, limit, config):
        ceiling = min(config.max_limit or 100, MAX_LIMIT)
        try:
            limit = int(limit)
        except (TypeError, ValueError):
            limit = 20
        return max(1, min(limit, ceiling))

    @api.model
    def _serialise(self, records, field_names):
        rows = records.read(field_names)
        for row in rows:
            for key, value in list(row.items()):
                if isinstance(value, tuple) and len(value) == 2:
                    row[key] = {"id": value[0], "name": value[1]}
                elif isinstance(value, bytes):
                    row[key] = "<binary %d bytes>" % len(value)
        return rows

    # ------------------------------------------------------------------
    # tool implementations
    # ------------------------------------------------------------------
    @api.model
    def _tool_odoo_list_models(self):
        configs = self.env["mcp.model.access"].sudo().search([])
        out = []
        for config in configs:
            if config.model_name not in self.env:
                continue
            operations = [
                label for label, flag in [
                    ("read", config.allow_read), ("create", config.allow_create),
                    ("update", config.allow_write), ("delete", config.allow_unlink),
                ] if flag
            ]
            out.append({
                "model": config.model_name,
                "label": config.model_id.name,
                "description": config.description or "",
                "operations": operations,
                "callable_methods": sorted(config.methods()),
            })
        return {"models": out, "count": len(out)}

    @api.model
    def _tool_odoo_get_model_schema(self, model=None, fields=None):
        record_set, config = self._model_and_config(model, "read")
        allowed = set(config.allowed_fields(record_set))
        names = [f for f in (fields or sorted(allowed)) if f in allowed]
        described = record_set.fields_get(names)
        out = {}
        for name, meta in described.items():
            entry = {
                "type": meta.get("type"),
                "label": meta.get("string"),
                "required": meta.get("required", False),
                "readonly": meta.get("readonly", False),
            }
            if meta.get("relation"):
                entry["relation"] = meta["relation"]
            if meta.get("selection"):
                entry["selection"] = [s[0] for s in meta["selection"]]
            if meta.get("help"):
                entry["help"] = meta["help"]
            out[name] = entry
        return {
            "model": model,
            "description": config.description or config.model_id.name,
            "fields": out,
        }

    @api.model
    def _tool_odoo_search(self, model=None, domain=None, fields=None,
                          limit=20, offset=0, order=None):
        record_set, config = self._model_and_config(model, "read")
        allowed = set(config.allowed_fields(record_set))
        field_names = [f for f in (fields or [])
                       if f in allowed] or self._default_fields(record_set, config)
        config.check_domain(record_set, domain)
        order = config.check_order(record_set, order)
        full_domain = and_domains(domain, config.get_domain())
        limit = self._clamp(limit, config)
        records = record_set.search(
            full_domain, limit=limit, offset=int(offset or 0), order=order)
        total = record_set.search_count(full_domain)
        return {
            "model": model,
            "total_matching": total,
            "returned": len(records),
            "records": self._serialise(records, field_names),
        }

    @api.model
    def _tool_odoo_count(self, model=None, domain=None):
        record_set, config = self._model_and_config(model, "read")
        config.check_domain(record_set, domain)
        total = record_set.search_count(and_domains(domain, config.get_domain()))
        return {"model": model, "count": total}

    @api.model
    def _tool_odoo_read(self, model=None, ids=None, fields=None):
        record_set, config = self._model_and_config(model, "read")
        allowed = set(config.allowed_fields(record_set))
        field_names = [f for f in (fields or [])
                       if f in allowed] or self._default_fields(record_set, config)
        records = record_set.browse(config.clamp_ids(ids)).exists()
        if config.get_domain():
            records = records.filtered_domain(config.get_domain())
        return {"model": model, "records": self._serialise(records, field_names)}

    @api.model
    def _tool_odoo_aggregate(self, model=None, domain=None, fields=None,
                             groupby=None, limit=100):
        record_set, config = self._model_and_config(model, "read")
        groups = config.check_groupby(record_set, groupby)
        aggregates = config.check_aggregates(record_set, fields, _("aggregate"))
        config.check_domain(record_set, domain)
        limit = self._clamp(limit, config)
        domain_full = and_domains(domain, config.get_domain())
        if hasattr(record_set, "formatted_read_group"):
            # Odoo 18+ API. Aggregate specs look like 'amount_total:sum'.
            rows = record_set.formatted_read_group(
                domain_full, groupby=groups, aggregates=aggregates, limit=limit)
        else:
            rows = record_set.read_group(
                domain_full, aggregates, groups, limit=limit, lazy=False)
        for row in rows:
            for key, value in list(row.items()):
                if isinstance(value, tuple) and len(value) == 2:
                    row[key] = {"id": value[0], "name": value[1]}
            row.pop("__domain", None)
            row.pop("__extra_domain", None)
        return {"model": model, "groups": rows}

    @api.model
    def _tool_odoo_create(self, model=None, values=None):
        record_set, config = self._model_and_config(model, "create")
        cleaned = config.check_values(record_set, values)
        if not cleaned:
            raise UserError(_("No writable field was supplied."))
        record = record_set.create(cleaned)
        return {"model": model, "id": record.id,
                "display_name": record.display_name}

    @api.model
    def _tool_odoo_update(self, model=None, ids=None, values=None):
        record_set, config = self._model_and_config(model, "write")
        cleaned = config.check_values(record_set, values)
        if not cleaned:
            raise UserError(_("No writable field was supplied."))
        records = record_set.browse(config.clamp_ids(ids)).exists()
        if config.get_domain():
            records = records.filtered_domain(config.get_domain())
        if not records:
            raise UserError(_("No record matched those ids."))
        records.write(cleaned)
        return {"model": model, "updated": records.ids}

    @api.model
    def _tool_odoo_delete(self, model=None, ids=None):
        record_set, config = self._model_and_config(model, "unlink")
        records = record_set.browse(config.clamp_ids(ids)).exists()
        if config.get_domain():
            records = records.filtered_domain(config.get_domain())
        deleted = records.ids
        records.unlink()
        return {"model": model, "deleted": deleted}

    @api.model
    def _tool_odoo_call_method(self, model=None, ids=None, method=None, kwargs=None):
        record_set, config = self._model_and_config(model, "write")
        if method not in config.methods():
            raise UserError(_(
                "Method '%(method)s' is not allowed on %(model)s. Allowed: %(allowed)s.",
                method=method, model=model,
                allowed=", ".join(sorted(config.methods())) or _("none")))
        if method.startswith("_"):
            raise UserError(_("Private methods cannot be called."))
        # An administrator typing `write` or `copy` into the allowed methods
        # list would hand the client a write path that skips every value
        # check this module makes - so these names are refused whatever the
        # configuration says.
        if method in FORBIDDEN_METHODS:
            raise UserError(_(
                "'%s' is an ORM operation, not a business action. Use the "
                "create, update or delete tools, which check what they are "
                "given.") % method)
        if not ids:
            raise UserError(_(
                "Calling a method needs the records to call it on."))
        records = record_set.browse(config.clamp_ids(ids)).exists()
        # The extra domain applied to update and delete but not here, so a
        # method call reached records the same configuration kept out of
        # every other tool.
        if config.get_domain():
            records = records.filtered_domain(config.get_domain())
        if ids and not records:
            raise UserError(_("No record matched those ids."))
        result = getattr(records, method)(**(kwargs or {}))
        if hasattr(result, "_name"):  # a recordset came back
            result = {"model": result._name, "ids": result.ids}
        return {"model": model, "method": method, "result": result}

    @api.model
    def _tool_odoo_search_everywhere(self, query=None, limit_per_model=5):
        if not query:
            raise UserError(_("Give me something to search for."))
        results = []
        # A ceiling on how many models one question may scan. Each model
        # costs a leading-wildcard ilike, which no index can serve, and the
        # fallback path costs a second one - so an unbounded allowlist turned
        # a single call into dozens of full table scans, repeatable at the
        # rate limit.
        for config in self.env["mcp.model.access"].sudo().search(
                [("allow_read", "=", True)], limit=15, order="model_name"):
            name = config.model_name
            if name not in self.env:
                continue
            record_set = self.env[name]
            try:
                records = record_set.search(
                    and_domains([("display_name", "ilike", query)],
                                config.get_domain()),
                    limit=self._clamp(limit_per_model, config))
            except Exception:
                # Not every model supports searching on display_name.
                try:
                    records = record_set.search(
                        and_domains([("name", "ilike", query)],
                                    config.get_domain()),
                        limit=self._clamp(limit_per_model, config))
                except Exception:
                    continue
            if records:
                results.append({
                    "model": name,
                    "matches": [{"id": r.id, "display_name": r.display_name}
                                for r in records],
                })
        return {"query": query, "results": results}

    # ==================================================================
    # resources
    # ==================================================================
    @api.model
    def _handle_resources_list(self, params):
        resources = [{
            "uri": "odoo://models",
            "name": "Exposed Odoo models",
            "description": "The models this connector may read or write.",
            "mimeType": "application/json",
        }]
        for config in self.env["mcp.model.access"].sudo().search([]):
            resources.append({
                "uri": "odoo://schema/%s" % config.model_name,
                "name": "%s schema" % config.model_name,
                "description": config.description or config.model_id.name,
                "mimeType": "application/json",
            })
        return {"resources": resources}

    @api.model
    def _handle_resources_read(self, params):
        uri = params.get("uri") or ""
        if uri == "odoo://models":
            payload = self._tool_odoo_list_models()
        elif uri.startswith("odoo://schema/"):
            payload = self._tool_odoo_get_model_schema(
                model=uri[len("odoo://schema/"):])
        else:
            raise UserError(_("Unknown resource: %s") % uri)
        return {"contents": [{
            "uri": uri,
            "mimeType": "application/json",
            "text": json.dumps(payload, indent=2, default=str, ensure_ascii=False),
        }]}

    # ==================================================================
    # prompts
    # ==================================================================
    @api.model
    def _mcp_prompts(self):
        return [
            {
                "name": "odoo_report",
                "description": "Build a short report from Odoo data.",
                "arguments": [
                    {"name": "topic", "description": "What to report on",
                     "required": True},
                    {"name": "period", "description": "e.g. this quarter",
                     "required": False},
                ],
            },
            {
                "name": "odoo_explain_record",
                "description": "Explain one record and its context in plain language.",
                "arguments": [
                    {"name": "model", "required": True},
                    {"name": "record_id", "required": True},
                ],
            },
        ]

    @api.model
    def _handle_prompts_list(self, params):
        return {"prompts": self._mcp_prompts()}

    @api.model
    def _handle_prompts_get(self, params):
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if name == "odoo_report":
            text = (
                "Using the Odoo tools, put together a report on %(topic)s%(period)s. "
                "Start with odoo_list_models to find the right model, use "
                "odoo_aggregate for the totals rather than reading every record, "
                "and end with the three findings that matter most."
            ) % {
                "topic": arguments.get("topic", "the business"),
                "period": (" for %s" % arguments["period"]) if arguments.get("period") else "",
            }
        elif name == "odoo_explain_record":
            text = (
                "Read record %(id)s of %(model)s with odoo_read, follow its main "
                "relations, and explain in plain language what this record is, "
                "what state it is in and what would normally happen next."
            ) % {"id": arguments.get("record_id"), "model": arguments.get("model")}
        else:
            raise UserError(_("Unknown prompt: %s") % name)
        return {
            "description": name,
            "messages": [{
                "role": "user",
                "content": {"type": "text", "text": text},
            }],
        }
