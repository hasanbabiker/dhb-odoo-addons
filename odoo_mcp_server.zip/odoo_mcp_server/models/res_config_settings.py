# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    mcp_enabled = fields.Boolean(
        "Enable MCP Server",
        config_parameter="mcp_server.enabled",
        help="When off, every MCP endpoint answers 503.")
    mcp_oauth_enabled = fields.Boolean(
        "Sign in with Odoo (OAuth)",
        config_parameter="mcp_server.oauth_enabled", default=True,
        help="Lets MCP clients such as Claude register themselves and send "
             "the user through the normal Odoo login. Recommended.")
    mcp_allow_write = fields.Boolean(
        "Allow Write Operations",
        config_parameter="mcp_server.allow_write",
        help="Master switch. When off, create, update, delete and method "
             "calls are refused even for models that allow them.")
    mcp_rate_limit = fields.Integer(
        "Requests per Minute per Token",
        config_parameter="mcp_server.rate_limit", default=120)
    mcp_token_lifetime = fields.Integer(
        "OAuth Token Lifetime (hours)",
        config_parameter="mcp_server.token_lifetime", default=720)
    mcp_log_retention_days = fields.Integer(
        "Log Retention (days)",
        config_parameter="mcp_server.log_retention_days", default=30)

    mcp_endpoint_url = fields.Char(
        "MCP Endpoint", readonly=True, compute="_compute_mcp_urls")
    mcp_connector_url = fields.Char(
        "Connector URL for Claude", readonly=True, compute="_compute_mcp_urls")

    @api.depends("company_id")
    def _compute_mcp_urls(self):
        base = self.env["ir.config_parameter"].sudo().get_param("web.base.url") or ""
        for record in self:
            record.mcp_endpoint_url = "%s/mcp" % base
            record.mcp_connector_url = "%s/mcp" % base

    def action_open_mcp_models(self):
        return self.env["ir.actions.act_window"]._for_xml_id(
            "odoo_mcp_server.action_mcp_model_access")
