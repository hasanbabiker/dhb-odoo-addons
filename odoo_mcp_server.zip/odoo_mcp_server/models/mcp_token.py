# -*- coding: utf-8 -*-

import secrets
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import AccessDenied, UserError

from werkzeug.security import check_password_hash, generate_password_hash

PREFIX_LENGTH = 12
SECRET_LENGTH = 40


class McpToken(models.Model):
    _name = "mcp.token"
    _description = "MCP Access Token"
    _order = "create_date desc"

    name = fields.Char("Label", required=True, default="MCP token")
    user_id = fields.Many2one(
        "res.users", string="Runs As", required=True,
        default=lambda self: self.env.user, ondelete="cascade",
        help="Every request made with this token executes as this user, "
             "with that user's access rights and record rules.")
    token_prefix = fields.Char(readonly=True, index=True, copy=False)
    token_hash = fields.Char(readonly=True, copy=False, groups="base.group_system")
    # Hashing the token at rest is undone by keeping the plaintext in the
    # same row, so the preview now has a clock on it and the nightly cron
    # wipes it.
    #
    # No groups= here, deliberately. Restricting the field to managers
    # looked safer and broke the thing it was guarding: an MCP user creates
    # their own token, presses Generate, and could no longer read the secret
    # they had just made - and the form's `invisible="not token_preview"`
    # then referred to a field the client was never sent, which throws
    # before the form draws. The record rule already limits a user to their
    # own rows, which is the protection that matters; the clock below is
    # what stops the plaintext living in the table for ever.
    token_preview = fields.Char("Token", readonly=True, copy=False,
                                help="Shown once, right after creation, and "
                                     "cleared within the hour.")
    preview_expiry = fields.Datetime(readonly=True, copy=False)

    source = fields.Selection(
        [("manual", "Manual"), ("oauth", "OAuth")],
        default="manual", required=True, readonly=True)
    client_id = fields.Many2one("mcp.oauth.client", string="OAuth Client",
                                ondelete="cascade", readonly=True)
    refresh_prefix = fields.Char(readonly=True, index=True, copy=False)
    refresh_hash = fields.Char(readonly=True, copy=False, groups="base.group_system")
    refresh_expiry = fields.Datetime("Refresh Expires On", readonly=True)

    scope = fields.Char(default="mcp")
    expiry = fields.Datetime("Expires On")
    active = fields.Boolean(default=True)
    last_used = fields.Datetime(readonly=True)
    use_count = fields.Integer(readonly=True)

    # ==================================================================
    # issuance
    # ==================================================================
    @api.model
    def _new_secret(self):
        return "%s.%s" % (
            secrets.token_urlsafe(PREFIX_LENGTH)[:PREFIX_LENGTH],
            secrets.token_urlsafe(SECRET_LENGTH),
        )

    @api.model
    def _issue(self, user, name="MCP token", source="manual", client=None,
               scope="mcp", lifetime_hours=None, with_refresh=False):
        raw = self._new_secret()
        prefix, _sep, _rest = raw.partition(".")
        values = {
            "name": name,
            "user_id": user.id,
            "token_prefix": prefix,
            "token_hash": generate_password_hash(raw),
            "source": source,
            "scope": scope,
            "client_id": client.id if client else False,
        }
        if lifetime_hours:
            values["expiry"] = fields.Datetime.now() + timedelta(hours=lifetime_hours)
        raw_refresh = None
        if with_refresh:
            raw_refresh = self._new_secret()
            values["refresh_prefix"] = raw_refresh.partition(".")[0]
            values["refresh_hash"] = generate_password_hash(raw_refresh)
            # A refresh token outlives the access token by design, but not
            # forever: thirty days past the access token's own life.
            values["refresh_expiry"] = fields.Datetime.now() + timedelta(
                hours=(lifetime_hours or 24) + 720)
        token = self.sudo().create(values)
        return token, raw, raw_refresh

    def _check_may_manage(self):
        """These are public methods, and sudo() inside one is a door.

        `browse()` performs no access check and `sudo()` skips the record
        rule, so before this existed any logged-in user could call
        action_revoke over /web/dataset/call_button on every token id in the
        database and take the whole integration down - or call
        action_generate on somebody else's token, rotating their secret and
        writing the new plaintext where they could read it.
        """
        manager = self.env.user.has_group("odoo_mcp_server.group_mcp_manager")
        for record in self:
            if not manager and record.user_id != self.env.user:
                raise AccessDenied()

    def action_generate(self):
        """Button on the form: create the secret and show it once."""
        self._check_may_manage()
        for record in self:
            raw = self._new_secret()
            record.sudo().write({
                "token_prefix": raw.partition(".")[0],
                "token_hash": generate_password_hash(raw),
                "token_preview": raw,
                "preview_expiry": fields.Datetime.now() + timedelta(hours=1),
            })
        return True

    def action_clear_preview(self):
        self._check_may_manage()
        self.sudo().write({"token_preview": False, "preview_expiry": False})
        return True

    def action_revoke(self):
        self._check_may_manage()
        self.sudo().write({
            "active": False, "token_preview": False, "preview_expiry": False})
        return True

    # ==================================================================
    # verification
    # ==================================================================
    @api.model
    def _verify(self, raw_token):
        """Return the matching active token record, or raise AccessDenied."""
        if not raw_token or "." not in raw_token:
            raise AccessDenied()
        prefix = raw_token.partition(".")[0]
        candidates = self.sudo().search([
            ("token_prefix", "=", prefix), ("active", "=", True),
        ])
        now = fields.Datetime.now()
        for token in candidates:
            if token.expiry and token.expiry <= now:
                continue
            if check_password_hash(token.token_hash, raw_token):
                # Checked on every request, not only when the token record
                # is written. The constraint below fires when a token is
                # saved; archiving the *user* never touches the token, so
                # without this a departing employee's token kept working -
                # which is exactly the moment it matters.
                if not token.user_id.active:
                    raise AccessDenied()
                token.write({
                    "last_used": now,
                    "use_count": token.use_count + 1,
                })
                return token
        raise AccessDenied()

    @api.model
    def _verify_refresh(self, raw_token):
        if not raw_token or "." not in raw_token:
            raise AccessDenied()
        prefix = raw_token.partition(".")[0]
        candidates = self.sudo().search([
            ("refresh_prefix", "=", prefix), ("active", "=", True),
        ])
        now = fields.Datetime.now()
        for token in candidates:
            if check_password_hash(token.refresh_hash, raw_token):
                # The refresh token used to have no clock at all: only the
                # access token expired, so a stolen refresh token kept
                # minting thirty-day access tokens until the purge cron
                # happened to reach the row.
                if token.refresh_expiry and token.refresh_expiry <= now:
                    raise AccessDenied()
                if not token.user_id.active:
                    raise AccessDenied()
                return token
        raise AccessDenied()

    # ==================================================================
    # housekeeping
    # ==================================================================
    @api.model
    def _cron_purge_expired(self):
        now = fields.Datetime.now()
        cutoff = now - timedelta(days=7)
        self.sudo().search([
            ("expiry", "!=", False), ("expiry", "<", cutoff),
        ]).unlink()
        # Plaintext previews do not wait for the user to press "I saved it".
        stale = self.sudo().search([
            ("token_preview", "!=", False),
            ("preview_expiry", "!=", False),
            ("preview_expiry", "<", now),
        ])
        if stale:
            stale.write({"token_preview": False, "preview_expiry": False})

    @api.constrains("user_id")
    def _check_user_active(self):
        for token in self:
            if not token.user_id.active:
                raise UserError(_("Cannot issue a token for an archived user."))
