# -*- coding: utf-8 -*-
"""What an MCP client may touch, and the checks that make that mean something.

The original version of this file had an allowlist that did not hold. It
gated the model name passed to ``self.env[...]`` and nothing else, which
left three ways straight past it:

* a nested x2many command wrote to a completely different model,
* a dotted domain path read through to one,
* and the extra domain was concatenated rather than ANDed, so a leading
  ``'|'`` from the client turned every restriction into an alternative.

So the rule here is now: **the allowlist gates the ORM graph, not one
name.** Every model a request can reach - through a write command, through
a domain hop, through an order clause - has to be on the list in its own
right, for the operation being attempted.
"""

import ast

from odoo import _, api, fields, models
from odoo.exceptions import AccessError, ValidationError

# Models an MCP client must never touch, whatever the configuration says.
#
# Two kinds of thing are here. The first is anything that grants access:
# permissions, rules, groups, API keys, and the token tables themselves. The
# second is anything that executes: ir.cron and ir.actions.server both take
# a `state='code'` payload that Odoo runs as superuser, so write access to
# either is a shell on the server.
HARD_BLOCKED_MODELS = {
    # access and secrets
    "ir.config_parameter",
    "ir.model.access",
    "ir.rule",
    "res.groups",
    "res.users.apikeys",
    "res.users.apikeys.description",
    "ir.mail_server",
    # this module's own tables
    "mcp.token",
    "mcp.oauth.client",
    "mcp.oauth.code",
    "mcp.request.log",
    # arbitrary code execution
    "ir.cron",
    "ir.actions.server",
    # arbitrary markup rendered to every user
    "ir.ui.view",
    # every uploaded file in the database: invoices, ID scans, learner
    # documents. Blocked deliberately rather than left to configuration,
    # because `datas` carries the file itself.
    "ir.attachment",
    # xml ids: the map from names to records, and a way to rewrite them
    "ir.model.data",
    "ir.logging",
    # Installing or upgrading a module is arbitrary code, and
    # button_immediate_install is a perfectly ordinary method name to type
    # into an allowlist without thinking.
    "ir.module.module",
    # The schema itself: renaming or deleting a field breaks the database.
    "ir.model",
    "ir.model.fields",
    # A mail template is a QWeb expression evaluated server side.
    "mail.template",
    "ir.filters",
}

# Never returned in a payload and never written, on any model.
GLOBAL_FIELD_BLACKLIST = {
    "password", "password_crypt", "new_password", "password_hash",
    "api_key", "secret", "totp_secret", "access_token", "refresh_token",
    "key", "key_hash", "client_secret", "client_secret_hash",
    # The one that mattered: Odoo keeps the outgoing mail password here, and
    # the original list did not have it.
    "smtp_pass", "smtp_user",
    # A signup token is a password reset link waiting to be used.
    "signup_token", "signup_type",
    "oauth_access_token", "oauth_uid",
    "webhook_secret", "consumer_key", "private_key",
}

# An exact list ages badly - every module adds its own credential field. A
# suffix rule catches the ones nobody thought of.
SECRET_SUFFIXES = (
    "_password", "_passwd", "_pass", "_secret", "_token", "_key",
    "_apikey", "_credentials",
)

# Aggregate functions a client may ask for. The point of the list is what it
# leaves out: array_agg returns every value in the group as a list, which
# turns one aggregate call into a full export of a column and walks straight
# past max_limit.
ALLOWED_AGGREGATES = {
    "count", "count_distinct", "sum", "avg", "min", "max",
    "bool_and", "bool_or",
}

# `date_order:month` uses the same `field:qualifier` syntax as
# `amount_total:sum`, and it means something entirely different. Checking a
# groupby against the aggregate list rejected every time series - which is
# most of what anybody asks an aggregate tool for.
ALLOWED_GRANULARITIES = {
    "year", "quarter", "month", "week", "day", "hour", "minute", "second",
    "day_of_week", "iso_week_number", "month_number", "quarter_number",
    "year_number", "hour_number", "day_of_month",
}

DOMAIN_OPERATORS = {"&", "|", "!"}

# Comparison operators a leaf may use. The list is here because of what it
# leaves out: Odoo's `any` and `not any` take *a whole sub-domain* as their
# value, and a sub-domain is a second query on another model that nothing
# above was looking at. They are handled separately below, recursively, with
# the comodel's own configuration - not accepted blindly.
SCALAR_OPERATORS = {
    "=", "!=", ">", ">=", "<", "<=", "=?",
    "like", "not like", "ilike", "not ilike", "=like", "=ilike",
    "in", "not in",
}
# These two walk a hierarchy, and with a string on the right they make the
# comodel search its own display_name - so the value has to be ids.
HIERARCHY_OPERATORS = {"child_of", "parent_of"}
SUBDOMAIN_OPERATORS = {"any", "not any"}

# How deep a dotted domain path may go. Each hop is checked against the
# allowlist anyway; this only stops a pathological chain.
MAX_DOMAIN_DEPTH = 3

# The most records any single call may touch, whatever a model is configured
# for.
HARD_MAX_RECORDS = 500


def is_secret_field(name):
    """True for a field whose value is a credential, by name."""
    name = (name or "").lower()
    return name in GLOBAL_FIELD_BLACKLIST or name.endswith(SECRET_SUFFIXES)


def and_domains(client_domain, extra_domain):
    """Both, always - never one or the other.

    The bug this replaces was ``a + b``. Odoo domains are prefix notation,
    so concatenating a client domain that begins with ``'|'`` produces
    ``['|', <client leaf>, <extra leaf>]`` - the administrator's restriction
    becomes the alternative branch, and four characters from the client
    remove it. Explicit '&' in front of both is the only form that cannot be
    rewritten from outside.
    """
    left = list(client_domain or [])
    right = list(extra_domain or [])
    if not left:
        return right
    if not right:
        return left
    return ["&"] + left + right


class McpModelAccess(models.Model):
    _name = "mcp.model.access"
    _description = "MCP Model Access"
    _order = "model_name"
    _rec_name = "model_name"

    active = fields.Boolean(default=True)
    model_id = fields.Many2one(
        "ir.model", string="Model", required=True, ondelete="cascade")
    model_name = fields.Char(related="model_id.model", store=True, index=True)
    description = fields.Char(
        "Description for the AI",
        help="Shown to the MCP client. A clear sentence here noticeably "
             "improves how well the assistant picks the right model.")

    allow_read = fields.Boolean("Read", default=True)
    allow_create = fields.Boolean("Create")
    allow_write = fields.Boolean("Update")
    allow_unlink = fields.Boolean("Delete")

    field_blacklist = fields.Char(
        "Hidden Fields",
        help="Comma separated field names that are never returned nor written.")
    field_whitelist = fields.Char(
        "Allowed Fields",
        help="If set, only these fields are readable. Leave empty for all "
             "fields except the hidden ones.")
    extra_domain = fields.Char(
        "Extra Domain", default="[]",
        help="Always ANDed with whatever domain the client sends. "
             "Example: [('company_id', '=', 1)]")
    allowed_methods = fields.Char(
        "Callable Methods",
        help="Comma separated method names the client may invoke on this "
             "model, e.g. action_confirm. Leave empty to forbid all method "
             "calls, which is the safe default.")
    max_limit = fields.Integer("Max Records per Call", default=100)

    # models.Constraint, not _sql_constraints: Odoo 19 ignores the old
    # attribute with a warning in the log, so the uniqueness this was meant
    # to give never existed. Two rows for one model would have made which
    # one wins a matter of row order.
    _model_uniq = models.Constraint(
        "unique(model_id)", "This model is already configured.")

    @api.constrains("model_id")
    def _check_not_blocked(self):
        for record in self:
            if record.model_name in HARD_BLOCKED_MODELS:
                raise ValidationError(_(
                    "%s can never be exposed over MCP.") % record.model_name)

    @api.constrains("extra_domain")
    def _check_domain(self):
        for record in self:
            if not record.extra_domain:
                continue
            try:
                parsed = ast.literal_eval(record.extra_domain)
                assert isinstance(parsed, list)
            except Exception:
                raise ValidationError(_(
                    "The extra domain of %s is not a valid Odoo domain.")
                    % record.model_name)

    # ------------------------------------------------------------------
    @api.model
    def _get_for(self, model_name, operation=None):
        """Return the config for ``model_name``, raising if it is not allowed."""
        if model_name in HARD_BLOCKED_MODELS:
            raise AccessError(_("Model %s is not exposed over MCP.") % model_name)
        config = self.sudo().search([("model_name", "=", model_name)], limit=1)
        if not config:
            raise AccessError(_(
                "Model %s is not exposed over MCP. An administrator has to add "
                "it under MCP Server > Exposed Models.") % model_name)
        if operation:
            flag = {
                "read": config.allow_read,
                "create": config.allow_create,
                "write": config.allow_write,
                "unlink": config.allow_unlink,
            }.get(operation, False)
            if not flag:
                raise AccessError(_(
                    "Operation '%(op)s' is not enabled for %(model)s over MCP.",
                    op=operation, model=model_name))
        return config

    def get_domain(self):
        """Fail closed. A restriction that cannot be parsed is not no
        restriction - swallowing the error turned a typo in the settings
        into an open database."""
        self.ensure_one()
        try:
            parsed = ast.literal_eval(self.extra_domain or "[]") or []
        except Exception:
            raise AccessError(_(
                "The extra domain configured for %s cannot be read, so no "
                "request will be served for it until an administrator fixes "
                "it.") % self.model_name)
        if not isinstance(parsed, list):
            raise AccessError(_(
                "The extra domain configured for %s is not a domain.")
                % self.model_name)
        return parsed

    def hidden_fields(self):
        self.ensure_one()
        names = {
            name.strip() for name in (self.field_blacklist or "").split(",")
            if name.strip()
        }
        return names | GLOBAL_FIELD_BLACKLIST

    def is_hidden(self, name):
        """Hidden by this model's own list, by the global one, or by shape."""
        self.ensure_one()
        return name in self.hidden_fields() or is_secret_field(name)

    def allowed_fields(self, model):
        """Resolve the readable field names for this model."""
        self.ensure_one()
        whitelist = {
            name.strip() for name in (self.field_whitelist or "").split(",")
            if name.strip()
        }
        available = {name for name in model._fields if not self.is_hidden(name)}
        if whitelist:
            return sorted(whitelist & available)
        return sorted(available)

    # ==================================================================
    # The three checks the old allowlist was missing.
    # ==================================================================
    def check_values(self, model, values):
        """Return the writable subset, refusing anything that writes elsewhere.

        The hole this closes: ``{'name': 'x', 'user_ids': [(0, 0, {...})]}``
        looks like a write to one allowlisted field and is in fact a *create*
        on the comodel - in that example res.users, with a groups_id command
        nested inside it. Neither the allowlist nor the create flag nor the
        field blacklist of the comodel was ever consulted, because nothing
        looked past the top-level key.

        Rather than try to validate commands recursively - which means
        reimplementing Odoo's write semantics and getting one case wrong -
        relational multi-value writes are refused outright. Setting a
        many2one by id is still fine, because an integer cannot carry a
        payload.
        """
        self.ensure_one()
        whitelist = {
            name.strip() for name in (self.field_whitelist or "").split(",")
            if name.strip()
        }
        cleaned = {}
        for name, value in (values or {}).items():
            if self.is_hidden(name):
                continue
            if whitelist and name not in whitelist:
                continue
            field = model._fields.get(name)
            if field is None:
                raise AccessError(_(
                    "%(model)s has no field called %(field)s.",
                    model=model._name, field=name))
            if field.type in ("one2many", "many2many"):
                raise AccessError(_(
                    "%(field)s links to other records, and writing through it "
                    "would create, change or delete rows in %(comodel)s "
                    "without that model being checked. Edit %(comodel)s "
                    "directly instead.",
                    field=name, comodel=field.comodel_name or _("another model")))
            if isinstance(value, (list, dict, tuple)):
                raise AccessError(_(
                    "The value for %s has to be a plain value, not a list or "
                    "a structure.") % name)
            # A binary or image field stores its payload as an ir.attachment
            # row, and the value is a base64 string - so it looks like a
            # plain write and lands in a model that is hard-blocked.
            if field.type in ("binary", "image"):
                raise AccessError(_(
                    "%s is a file, and files are stored as attachments, "
                    "which are not writable over MCP.") % name)
            # Delegation: res.users writes its `email` and `name` straight
            # through to res.partner, product.product to product.template,
            # hr.employee to resource.resource. The field is a plain char on
            # this model and the row that changes is on another one - so the
            # other model has to be allowlisted for writing in its own
            # right, exactly as if it had been named.
            owner = getattr(field, "inherited_field", None)
            if field.inherited and owner is not None:
                target = owner.model_name
                if target != model._name:
                    self._get_for(target, "write")
            cleaned[name] = value
        return cleaned

    # kept as an alias so older call sites keep working
    def filter_values(self, values):
        self.ensure_one()
        model = self.env[self.model_name]
        return self.check_values(model, values)

    # ------------------------------------------------------------------
    def check_domain(self, model, domain):
        """Every field named in a domain, including through dots.

        Two separate holes lived here. The first is that the field blacklist
        was applied to the fields *returned* and never to the fields
        *searched*, so a hidden field was still a yes/no oracle: ask for a
        count with ``[('comment', 'ilike', 'IBAN')]`` and read the answer off
        the number, one character at a time. The second is that a dotted path
        walks to another model, and that model was never checked at all -
        ``user_ids.groups_id.name`` reaches res.groups, which is on the hard
        block list.
        """
        self.ensure_one()
        items = list(domain or [])
        if not items:
            return items
        # Parsed as a structure, not scanned as a flat list.
        #
        # The flat scan missed two things at once. It never looked at the
        # operator, so `('id', 'any', [<a whole second domain>])` slipped a
        # complete unchecked query past every field check - which is how a
        # blacklisted field became a yes/no oracle again and how a
        # hard-blocked model became readable. And it never checked that the
        # prefix notation balanced, so a client domain of exactly `['!']`
        # left a deficit that the '&' joining it to the administrator's
        # extra domain paid for out of the administrator's own conditions,
        # negating the first of them.
        position = self._walk_expression(model, items, 0)
        if position != len(items):
            raise AccessError(_(
                "That domain is malformed: it has more conditions than its "
                "operators join together."))
        return items

    def _walk_expression(self, model, items, position):
        """Consume exactly one expression, returning where it ended."""
        self.ensure_one()
        if position >= len(items):
            raise AccessError(_(
                "That domain is malformed: an operator has nothing to "
                "operate on."))
        item = items[position]
        if isinstance(item, str):
            if item == "!":
                return self._walk_expression(model, items, position + 1)
            if item in ("&", "|"):
                position = self._walk_expression(model, items, position + 1)
                return self._walk_expression(model, items, position)
            raise AccessError(_("Unknown domain operator %s.") % item)
        self._check_leaf(model, item)
        return position + 1

    def _check_leaf(self, model, leaf):
        self.ensure_one()
        if not isinstance(leaf, (list, tuple)) or len(leaf) != 3:
            raise AccessError(_(
                "A domain condition has to be a field, an operator and a "
                "value."))
        path, operator, value = str(leaf[0]), leaf[1], leaf[2]
        target_model, field = self._resolve_path(model, path, _("searched"))

        if not isinstance(operator, str):
            raise AccessError(_("A domain operator has to be text."))
        operator = operator.strip().lower()

        if operator in SUBDOMAIN_OPERATORS:
            if field is None or not field.comodel_name:
                raise AccessError(_(
                    "'%s' can only be used on a field that links to another "
                    "model.") % operator)
            # The hop is a read on the comodel, so it needs that model's own
            # permission - and the sub-domain is then validated against that
            # model's own configuration, blacklist and all.
            comodel_config = self._get_for(field.comodel_name, "read")
            comodel = self.env[field.comodel_name]
            sub = list(value or [])
            if sub:
                comodel_config.check_domain(comodel, sub)
            return
        if operator in HIERARCHY_OPERATORS:
            # With text on the right, Odoo turns these into a display_name
            # search on the comodel. Ids only.
            values = value if isinstance(value, (list, tuple)) else [value]
            for item in values:
                if not isinstance(item, int) or isinstance(item, bool):
                    raise AccessError(_(
                        "'%s' needs record ids, not names.") % operator)
            return
        if operator not in SCALAR_OPERATORS:
            raise AccessError(_("Unknown domain operator %s.") % operator)
        if isinstance(value, dict):
            raise AccessError(_("A domain value cannot be a structure."))

    def check_order(self, model, order):
        """Ordering by a hidden field leaks it by bisection, so check it too."""
        self.ensure_one()
        if not order:
            return None
        for term in str(order).split(","):
            name = term.strip().split(" ")[0]
            if not name:
                continue
            self._check_field_path(model, name, _("used for sorting"))
        return order

    def _check_field_path(self, model, path, what):
        self._resolve_path(model, path, what)

    def _resolve_path(self, model, path, what):
        """Walk a dotted path, checking the allowlist at every hop.

        Returns ``(model, field)`` for the last segment, so a caller can ask
        what the path actually landed on - which is what makes the ``any``
        check above possible.
        """
        self.ensure_one()
        parts = [p for p in path.split(".") if p]
        if not parts:
            raise AccessError(_("An empty field name cannot be %s.") % what)
        if len(parts) > MAX_DOMAIN_DEPTH:
            raise AccessError(
                _("%s goes too deep. At most %s levels are allowed.")
                % (path, MAX_DOMAIN_DEPTH))

        config = self
        current = model
        for index, name in enumerate(parts):
            # Odoo's own pseudo-fields; they carry no data of their own.
            if name in ("id", "parent_path"):
                return current, None
            if config.is_hidden(name):
                raise AccessError(_(
                    "%(field)s is hidden on %(model)s and cannot be %(what)s.",
                    field=name, model=current._name, what=what))
            field = current._fields.get(name)
            if field is None:
                raise AccessError(_(
                    "%(model)s has no field called %(field)s.",
                    model=current._name, field=name))
            if index == len(parts) - 1:
                return current, field
            if not field.comodel_name:
                raise AccessError(_(
                    "%s is not a link, so nothing can follow it.") % name)
            # The hop itself needs permission. This is the line that makes
            # the allowlist cover the graph rather than one name.
            config = self._get_for(field.comodel_name, "read")
            current = self.env[field.comodel_name]
        return current, None

    # ------------------------------------------------------------------
    def check_groupby(self, model, specs):
        """Fields to group by, with an optional date granularity."""
        self.ensure_one()
        allowed = set(self.allowed_fields(model))
        out = []
        for spec in (specs or []):
            spec = str(spec)
            name, _sep, qualifier = spec.partition(":")
            name = name.strip()
            if name not in allowed:
                raise AccessError(_("Cannot group by %s.") % name)
            qualifier = (qualifier or "").strip()
            if qualifier and qualifier not in ALLOWED_GRANULARITIES:
                raise AccessError(_(
                    "%(qualifier)s is not a grouping granularity. Allowed: "
                    "%(allowed)s.",
                    qualifier=qualifier,
                    allowed=", ".join(sorted(ALLOWED_GRANULARITIES))))
            out.append(spec)
        return out

    def check_aggregates(self, model, specs, what):
        """Field plus function, both checked.

        ``email:array_agg`` was accepted because only the part before the
        colon was looked at. One call then returned every address in the
        table inside a single group, with max_limit applied to the number of
        groups rather than to the rows behind them.
        """
        self.ensure_one()
        allowed = set(self.allowed_fields(model))
        out = []
        for spec in (specs or []):
            spec = str(spec)
            name, _sep, func = spec.partition(":")
            name = name.strip()
            func = (func or "").strip()
            if name == "__count" or spec == "__count":
                out.append(spec)
                continue
            if name not in allowed:
                raise AccessError(_("Cannot %(what)s %(field)s.",
                                    what=what, field=name))
            if func and func.split("(")[0] not in ALLOWED_AGGREGATES:
                raise AccessError(_(
                    "%(func)s is not an allowed aggregate. Allowed: "
                    "%(allowed)s.",
                    func=func, allowed=", ".join(sorted(ALLOWED_AGGREGATES))))
            out.append(spec)
        return out

    def clamp_ids(self, ids):
        """A ceiling on ids, not only on search.

        max_limit was enforced on search and aggregate and nowhere else, so
        read, update, delete and method calls took an unbounded list - which
        made `delete` with half a million ids a single well-formed request.
        """
        self.ensure_one()
        # Bounded by the module's own ceiling as well as the configured
        # one, so an administrator who types 100000 into Max Records does
        # not thereby authorise a hundred-thousand-row unlink in one call.
        ceiling = max(1, min(self.max_limit or 100, HARD_MAX_RECORDS))
        cleaned = []
        for value in (ids or []):
            try:
                cleaned.append(int(value))
            except (TypeError, ValueError):
                raise AccessError(_("%s is not a record id.") % value)
        if len(cleaned) > ceiling:
            raise AccessError(_(
                "%(count)s ids were given and the limit for %(model)s is "
                "%(max)s. Ask for fewer at a time.",
                count=len(cleaned), model=self.model_name, max=ceiling))
        return cleaned

    def methods(self):
        self.ensure_one()
        return {
            name.strip() for name in (self.allowed_methods or "").split(",")
            if name.strip()
        }
