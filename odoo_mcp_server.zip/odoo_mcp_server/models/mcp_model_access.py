# -*- coding: utf-8 -*-

import ast

from odoo import _, api, fields, models
from odoo.exceptions import AccessError, ValidationError

# Models an MCP client must never touch, whatever the configuration says.
HARD_BLOCKED_MODELS = {
    "ir.config_parameter",
    "ir.attachment.access",
    "res.users.apikeys",
    "res.users.apikeys.description",
    "mcp.token",
    "mcp.oauth.client",
    "mcp.request.log",
    "ir.model.access",
    "ir.rule",
    "res.groups",
}

# Never returned in a payload, on any model.
GLOBAL_FIELD_BLACKLIST = {
    "password", "password_crypt", "new_password", "api_key", "secret",
    "totp_secret", "access_token", "key", "key_hash", "client_secret_hash",
}


class McpModelAccess(models.Model):
    _name = "mcp.model.access"
    _description = "MCP Model Access"
    _order = "model_name"
    _rec_name = "model_name"

    active = fields.Boolean(default=True)
    model_id = fields.Many2one(
        "ir.model", string="Model", required=True, ondelete="cascade")
    model_name = fields.Char(related="model_id.model", store=True, index=True)
    description = fields.Char(
        "Description for the AI",
        help="Shown to the MCP client. A clear sentence here noticeably "
             "improves how well the assistant picks the right model.")

    allow_read = fields.Boolean("Read", default=True)
    allow_create = fields.Boolean("Create")
    allow_write = fields.Boolean("Update")
    allow_unlink = fields.Boolean("Delete")

    field_blacklist = fields.Char(
        "Hidden Fields",
        help="Comma separated field names that are never returned nor written.")
    field_whitelist = fields.Char(
        "Allowed Fields",
        help="If set, only these fields are readable. Leave empty for all "
             "fields except the hidden ones.")
    extra_domain = fields.Char(
        "Extra Domain", default="[]",
        help="Always ANDed with whatever domain the client sends. "
             "Example: [('company_id', '=', 1)]")
    allowed_methods = fields.Char(
        "Callable Methods",
        help="Comma separated method names the client may invoke on this "
             "model, e.g. action_confirm. Leave empty to forbid all method "
             "calls, which is the safe default.")
    max_limit = fields.Integer("Max Records per Call", default=100)

    _sql_constraints = [
        ("model_uniq", "unique(model_id)", "This model is already configured."),
    ]

    @api.constrains("model_id")
    def _check_not_blocked(self):
        for record in self:
            if record.model_name in HARD_BLOCKED_MODELS:
                raise ValidationError(_(
                    "%s can never be exposed over MCP.") % record.model_name)

    @api.constrains("extra_domain")
    def _check_domain(self):
        for record in self:
            if not record.extra_domain:
                continue
            try:
                parsed = ast.literal_eval(record.extra_domain)
                assert isinstance(parsed, list)
            except Exception:
                raise ValidationError(_(
                    "The extra domain of %s is not a valid Odoo domain.")
                    % record.model_name)

    # ------------------------------------------------------------------
    @api.model
    def _get_for(self, model_name, operation=None):
        """Return the config for ``model_name``, raising if it is not allowed."""
        if model_name in HARD_BLOCKED_MODELS:
            raise AccessError(_("Model %s is not exposed over MCP.") % model_name)
        config = self.sudo().search([("model_name", "=", model_name)], limit=1)
        if not config:
            raise AccessError(_(
                "Model %s is not exposed over MCP. An administrator has to add "
                "it under MCP Server > Exposed Models.") % model_name)
        if operation:
            flag = {
                "read": config.allow_read,
                "create": config.allow_create,
                "write": config.allow_write,
                "unlink": config.allow_unlink,
            }.get(operation, False)
            if not flag:
                raise AccessError(_(
                    "Operation '%(op)s' is not enabled for %(model)s over MCP.",
                    op=operation, model=model_name))
        return config

    def get_domain(self):
        self.ensure_one()
        try:
            return ast.literal_eval(self.extra_domain or "[]") or []
        except Exception:
            return []

    def hidden_fields(self):
        self.ensure_one()
        names = {
            name.strip() for name in (self.field_blacklist or "").split(",")
            if name.strip()
        }
        return names | GLOBAL_FIELD_BLACKLIST

    def allowed_fields(self, model):
        """Resolve the readable field names for this model."""
        self.ensure_one()
        hidden = self.hidden_fields()
        whitelist = {
            name.strip() for name in (self.field_whitelist or "").split(",")
            if name.strip()
        }
        available = set(model._fields)
        if whitelist:
            return sorted((whitelist & available) - hidden)
        return sorted(available - hidden)

    def filter_values(self, values):
        """Strip fields the client is not allowed to write."""
        self.ensure_one()
        hidden = self.hidden_fields()
        whitelist = {
            name.strip() for name in (self.field_whitelist or "").split(",")
            if name.strip()
        }
        cleaned = {k: v for k, v in (values or {}).items() if k not in hidden}
        if whitelist:
            cleaned = {k: v for k, v in cleaned.items() if k in whitelist}
        return cleaned

    def methods(self):
        self.ensure_one()
        return {
            name.strip() for name in (self.allowed_methods or "").split(",")
            if name.strip()
        }
