# -*- coding: utf-8 -*-

from datetime import timedelta

from odoo import api, fields, models


class McpRequestLog(models.Model):
    _name = "mcp.request.log"
    _description = "MCP Request Log"
    _order = "create_date desc"
    _rec_name = "method"

    token_id = fields.Many2one("mcp.token", ondelete="set null", index=True)
    user_id = fields.Many2one("res.users", index=True)
    method = fields.Char("JSON-RPC Method", index=True)
    tool_name = fields.Char(index=True)
    model_name = fields.Char("Odoo Model", index=True)
    arguments = fields.Text()
    duration_ms = fields.Integer("Duration (ms)")
    success = fields.Boolean(default=True, index=True)
    error_message = fields.Char()
    record_count = fields.Integer()
    remote_addr = fields.Char()

    @api.model
    def _log(self, values):
        try:
            return self.sudo().create(values)
        except Exception:  # logging must never break a request
            return self.browse()

    @api.model
    def _rate_limited(self, token, max_per_minute):
        """True when the token has already burned its budget for this minute."""
        if not max_per_minute:
            return False
        since = fields.Datetime.now() - timedelta(minutes=1)
        count = self.sudo().search_count([
            ("token_id", "=", token.id),
            ("create_date", ">=", since),
        ])
        return count >= max_per_minute

    @api.model
    def _cron_purge(self):
        days = int(self.env["ir.config_parameter"].sudo().get_param(
            "mcp_server.log_retention_days", 30))
        cutoff = fields.Datetime.now() - timedelta(days=days)
        self.sudo().search([("create_date", "<", cutoff)]).unlink()
