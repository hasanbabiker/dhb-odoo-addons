# -*- coding: utf-8 -*-

import base64
import hashlib
import secrets
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

CODE_LIFETIME_SECONDS = 300


class McpOauthClient(models.Model):
    """A client registered through RFC 7591 dynamic client registration.

    Claude's custom connectors register themselves this way; there is no
    manual step for the administrator.
    """
    _name = "mcp.oauth.client"
    _description = "MCP OAuth Client"
    _order = "create_date desc"

    name = fields.Char("Client Name", required=True)
    client_id = fields.Char(required=True, readonly=True, index=True, copy=False)
    redirect_uris = fields.Text("Redirect URIs", required=True,
                                help="One per line.")
    logo_uri = fields.Char()
    client_uri = fields.Char()
    scope = fields.Char(default="mcp")
    is_public = fields.Boolean(
        "Public Client", default=True,
        help="Public clients use PKCE instead of a client secret. "
             "Claude Desktop registers as a public client.")
    active = fields.Boolean(default=True)
    token_ids = fields.One2many("mcp.token", "client_id", string="Tokens")

    _client_uniq = models.Constraint(
        "unique(client_id)", "That client id is already registered.")

    @api.model_create_multi
    def create(self, vals_list):
        for values in vals_list:
            values.setdefault("client_id", secrets.token_urlsafe(24))
        return super().create(vals_list)

    def uris(self):
        self.ensure_one()
        return [u.strip() for u in (self.redirect_uris or "").splitlines() if u.strip()]

    def check_redirect_uri(self, uri):
        self.ensure_one()
        return uri in self.uris()

    def action_revoke_tokens(self):
        self.token_ids.action_revoke()
        return True


class McpOauthCode(models.Model):
    _name = "mcp.oauth.code"
    _description = "MCP OAuth Authorization Code"
    _order = "create_date desc"
    _rec_name = "code"

    code = fields.Char(required=True, readonly=True, index=True, copy=False)
    client_id = fields.Many2one("mcp.oauth.client", required=True,
                                ondelete="cascade")
    user_id = fields.Many2one("res.users", required=True, ondelete="cascade")
    redirect_uri = fields.Char(required=True)
    code_challenge = fields.Char()
    code_challenge_method = fields.Selection(
        [("S256", "S256"), ("plain", "plain")], default="S256")
    scope = fields.Char(default="mcp")
    resource = fields.Char()
    expiry = fields.Datetime(required=True)
    used = fields.Boolean(default=False)

    @api.model
    def _issue(self, client, user, redirect_uri, code_challenge,
               method="S256", scope="mcp", resource=None):
        return self.sudo().create({
            "code": secrets.token_urlsafe(32),
            "client_id": client.id,
            "user_id": user.id,
            "redirect_uri": redirect_uri,
            "code_challenge": code_challenge,
            "code_challenge_method": method or "S256",
            "scope": scope or "mcp",
            "resource": resource,
            "expiry": fields.Datetime.now() + timedelta(seconds=CODE_LIFETIME_SECONDS),
        })

    def verify_pkce(self, code_verifier):
        self.ensure_one()
        if not self.code_challenge:
            # PKCE is mandatory in OAuth 2.1; refuse codes issued without it.
            return False
        if self.code_challenge_method == "plain":
            # Refused rather than honoured. The discovery document says S256
            # only, the authorize endpoint now enforces it, and a code
            # record that somehow carries "plain" is one that was not issued
            # through either - so it does not get verified.
            return False
        digest = hashlib.sha256((code_verifier or "").encode()).digest()
        expected = base64.urlsafe_b64encode(digest).decode().rstrip("=")
        return secrets.compare_digest(self.code_challenge, expected)

    def is_valid(self):
        self.ensure_one()
        return not self.used and self.expiry > fields.Datetime.now()

    @api.model
    def _cron_purge(self):
        self.sudo().search([
            ("expiry", "<", fields.Datetime.now() - timedelta(hours=1)),
        ]).unlink()

    @api.constrains("redirect_uri")
    def _check_redirect(self):
        for record in self:
            if not record.client_id.check_redirect_uri(record.redirect_uri):
                raise ValidationError(_("Redirect URI not registered for this client."))
