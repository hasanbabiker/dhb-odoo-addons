# -*- coding: utf-8 -*-

import json
import logging

from odoo import http
from odoo.exceptions import AccessDenied
from odoo.http import request

from ..models.mcp_server import (
    INTERNAL_ERROR, INVALID_REQUEST, PARSE_ERROR, PREFERRED_PROTOCOL_VERSION,
    SERVER_NAME, SERVER_VERSION,
)

_logger = logging.getLogger(__name__)

JSON_HEADERS = [("Content-Type", "application/json; charset=utf-8")]


class McpController(http.Controller):

    # ==================================================================
    # helpers
    # ==================================================================
    @staticmethod
    def _param(key, default=None):
        return request.env["ir.config_parameter"].sudo().get_param(key, default)

    def _enabled(self):
        return self._param("mcp_server.enabled") in ("True", "true", "1", True)

    def _base_url(self):
        return (self._param("web.base.url") or "").rstrip("/")

    def _unauthorised(self, detail="invalid_token"):
        challenge = (
            'Bearer realm="odoo", error="%s", '
            'resource_metadata="%s/.well-known/oauth-protected-resource"'
        ) % (detail, self._base_url())
        return request.make_response(
            json.dumps({"error": detail}),
            headers=JSON_HEADERS + [("WWW-Authenticate", challenge)],
            status=401,
        )

    def _authenticate(self):
        """Return the mcp.token record for this request, or None."""
        header = request.httprequest.headers.get("Authorization") or ""
        if not header.lower().startswith("bearer "):
            return None
        raw = header[7:].strip()
        try:
            return request.env["mcp.token"].sudo()._verify(raw)
        except AccessDenied:
            return None

    @staticmethod
    def _wants_sse():
        accept = request.httprequest.headers.get("Accept") or ""
        return "text/event-stream" in accept and "application/json" not in accept

    @staticmethod
    def _as_sse(payload):
        body = "event: message\ndata: %s\n\n" % json.dumps(payload, default=str)
        return request.make_response(body, headers=[
            ("Content-Type", "text/event-stream; charset=utf-8"),
            ("Cache-Control", "no-cache, no-transform"),
            ("Connection", "keep-alive"),
            ("X-Accel-Buffering", "no"),
        ])

    # ==================================================================
    # health
    # ==================================================================
    @http.route("/mcp/health", type="http", auth="public", methods=["GET"],
                csrf=False, save_session=False)
    def mcp_health(self, **kwargs):
        body = {
            "status": "ok" if self._enabled() else "disabled",
            "server": SERVER_NAME,
            "version": SERVER_VERSION,
            "protocol": PREFERRED_PROTOCOL_VERSION,
            "transports": ["streamable-http"],
            "endpoint": "%s/mcp" % self._base_url(),
        }
        return request.make_response(
            json.dumps(body), headers=JSON_HEADERS,
            status=200 if self._enabled() else 503)

    # ==================================================================
    # Streamable HTTP transport
    # ==================================================================
    @http.route(["/mcp", "/mcp/sse", "/mcp/messages"], type="http",
                auth="public", methods=["POST", "GET", "DELETE", "OPTIONS"],
                csrf=False, save_session=False)
    def mcp_endpoint(self, **kwargs):
        method = request.httprequest.method

        if method == "OPTIONS":
            return request.make_response("", headers=[
                ("Allow", "POST, GET, DELETE, OPTIONS"),
                ("Access-Control-Allow-Methods", "POST, GET, DELETE, OPTIONS"),
                ("Access-Control-Allow-Headers",
                 "Authorization, Content-Type, Mcp-Session-Id, "
                 "MCP-Protocol-Version"),
            ])

        if not self._enabled():
            return request.make_response(
                json.dumps({"error": "MCP server is disabled"}),
                headers=JSON_HEADERS, status=503)

        token = self._authenticate()
        if not token:
            return self._unauthorised()

        if method == "DELETE":
            # End of session. We keep no server-side session state.
            return request.make_response("", status=204)

        if method == "GET":
            # The spec allows refusing the server-initiated stream. We have no
            # unsolicited notifications to push, so say so explicitly instead
            # of holding a worker open on a long-lived connection.
            return request.make_response(
                json.dumps({"error": "server-initiated stream not supported"}),
                headers=JSON_HEADERS + [("Allow", "POST, DELETE")], status=405)

        return self._handle_post(token)

    def _handle_post(self, token):
        raw = request.httprequest.get_data()
        try:
            message = json.loads(raw or b"{}")
        except ValueError:
            return self._json_error(None, PARSE_ERROR, "Invalid JSON body.")

        limit = int(self._param("mcp_server.rate_limit", 120) or 0)
        if request.env["mcp.request.log"].sudo()._rate_limited(token, limit):
            return request.make_response(
                json.dumps({"error": "rate limit exceeded"}),
                headers=JSON_HEADERS + [("Retry-After", "60")], status=429)

        try:
            request.update_env(user=token.user_id.id)
        except Exception:
            _logger.exception("MCP: could not switch to user %s", token.user_id)
            return self._json_error(None, INTERNAL_ERROR, "Could not open a session.")

        server = request.env["mcp.server"]
        remote = request.httprequest.remote_addr
        writes_allowed = self._param("mcp_server.allow_write") in (
            "True", "true", "1", True)
        server = server.with_context(mcp_allow_write=writes_allowed)

        batch = isinstance(message, list)
        messages = message if batch else [message]
        if not messages:
            return self._json_error(None, INVALID_REQUEST, "Empty batch.")

        responses = []
        for item in messages:
            if not writes_allowed and self._is_write_call(item):
                responses.append({
                    "jsonrpc": "2.0", "id": item.get("id"),
                    "result": {
                        "content": [{
                            "type": "text",
                            "text": "Write operations are disabled on this "
                                    "Odoo instance. Ask an administrator to "
                                    "turn on 'Allow Write Operations'.",
                        }],
                        "isError": True,
                    },
                })
                continue
            answer = server.dispatch(item, token=token, remote_addr=remote)
            if answer is not None:
                responses.append(answer)

        if not responses:
            # Only notifications were sent: the spec wants 202 with no body.
            return request.make_response("", status=202)

        payload = responses if batch else responses[0]
        if self._wants_sse():
            return self._as_sse(payload)
        return request.make_response(
            json.dumps(payload, default=str), headers=JSON_HEADERS)

    @staticmethod
    def _is_write_call(item):
        if not isinstance(item, dict) or item.get("method") != "tools/call":
            return False
        name = (item.get("params") or {}).get("name") or ""
        return name in (
            "odoo_create", "odoo_update", "odoo_delete", "odoo_call_method")

    @staticmethod
    def _json_error(message_id, code, text):
        body = {"jsonrpc": "2.0", "id": message_id,
                "error": {"code": code, "message": text}}
        return request.make_response(json.dumps(body), headers=JSON_HEADERS,
                                     status=400)
