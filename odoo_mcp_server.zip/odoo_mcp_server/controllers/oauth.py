# -*- coding: utf-8 -*-
"""OAuth 2.1 authorization server, scoped to the MCP endpoint.

Implements just enough of RFC 6749 / 7591 / 8414 / 9728 for MCP clients:
authorization code with mandatory PKCE, dynamic client registration, refresh
tokens, and the two discovery documents MCP clients look for.
"""

import json
import logging
from urllib.parse import urlencode, urlparse

from odoo import _, http
from odoo.exceptions import AccessDenied
from odoo.http import request

_logger = logging.getLogger(__name__)

JSON_HEADERS = [
    ("Content-Type", "application/json; charset=utf-8"),
    ("Cache-Control", "no-store"),
    ("Access-Control-Allow-Origin", "*"),
]


class McpOauthController(http.Controller):

    # ==================================================================
    # helpers
    # ==================================================================
    @staticmethod
    def _param(key, default=None):
        return request.env["ir.config_parameter"].sudo().get_param(key, default)

    def _base_url(self):
        return (self._param("web.base.url") or "").rstrip("/")

    def _oauth_enabled(self):
        return self._param("mcp_server.oauth_enabled") in ("True", "true", "1", True)

    @staticmethod
    def _json(payload, status=200):
        return request.make_response(json.dumps(payload), headers=JSON_HEADERS,
                                     status=status)

    def _oauth_error(self, error, description="", status=400):
        return self._json({"error": error, "error_description": description}, status)

    # ==================================================================
    # discovery
    # ==================================================================
    @http.route("/.well-known/oauth-protected-resource",
                type="http", auth="public", methods=["GET", "OPTIONS"],
                csrf=False, save_session=False)
    def protected_resource_metadata(self, **kwargs):
        base = self._base_url()
        return self._json({
            "resource": "%s/mcp" % base,
            "authorization_servers": [base],
            "scopes_supported": ["mcp"],
            "bearer_methods_supported": ["header"],
            "resource_name": "Odoo MCP Server",
        })

    @http.route(["/.well-known/oauth-authorization-server",
                 "/.well-known/openid-configuration"],
                type="http", auth="public", methods=["GET", "OPTIONS"],
                csrf=False, save_session=False)
    def authorization_server_metadata(self, **kwargs):
        base = self._base_url()
        return self._json({
            "issuer": base,
            "authorization_endpoint": "%s/mcp/oauth/authorize" % base,
            "token_endpoint": "%s/mcp/oauth/token" % base,
            "registration_endpoint": "%s/mcp/oauth/register" % base,
            "revocation_endpoint": "%s/mcp/oauth/revoke" % base,
            "scopes_supported": ["mcp"],
            "response_types_supported": ["code"],
            "grant_types_supported": ["authorization_code", "refresh_token"],
            "code_challenge_methods_supported": ["S256"],
            "token_endpoint_auth_methods_supported": ["none", "client_secret_post"],
        })

    # ==================================================================
    # dynamic client registration (RFC 7591)
    # ==================================================================
    @http.route("/mcp/oauth/register", type="http", auth="public",
                methods=["POST", "OPTIONS"], csrf=False, save_session=False)
    def register(self, **kwargs):
        if request.httprequest.method == "OPTIONS":
            return self._json({})
        if not self._oauth_enabled():
            return self._oauth_error("access_denied", "OAuth is disabled.", 403)
        try:
            payload = json.loads(request.httprequest.get_data() or b"{}")
        except ValueError:
            return self._oauth_error("invalid_client_metadata", "Body is not JSON.")

        redirect_uris = payload.get("redirect_uris") or []
        if not redirect_uris:
            return self._oauth_error("invalid_redirect_uri",
                                     "At least one redirect_uri is required.")
        for uri in redirect_uris:
            parsed = urlparse(uri)
            is_local = parsed.hostname in ("localhost", "127.0.0.1", "::1")
            if parsed.scheme not in ("https", "http") and not parsed.scheme:
                return self._oauth_error("invalid_redirect_uri",
                                         "Redirect URIs must be absolute.")
            if parsed.scheme == "http" and not is_local:
                return self._oauth_error(
                    "invalid_redirect_uri",
                    "Plain http redirect URIs are only accepted on localhost.")

        client = request.env["mcp.oauth.client"].sudo().create({
            "name": payload.get("client_name") or "MCP client",
            "redirect_uris": "\n".join(redirect_uris),
            "logo_uri": payload.get("logo_uri"),
            "client_uri": payload.get("client_uri"),
            "scope": payload.get("scope") or "mcp",
            "is_public": payload.get("token_endpoint_auth_method", "none") == "none",
        })
        return self._json({
            "client_id": client.client_id,
            "client_id_issued_at": int(client.create_date.timestamp()),
            "client_name": client.name,
            "redirect_uris": client.uris(),
            "grant_types": ["authorization_code", "refresh_token"],
            "response_types": ["code"],
            "token_endpoint_auth_method": "none",
        }, status=201)

    # ==================================================================
    # authorization endpoint
    # ==================================================================
    @http.route("/mcp/oauth/authorize", type="http", auth="user",
                methods=["GET"], csrf=False)
    def authorize(self, **kwargs):
        """The user is already logged into Odoo here (auth='user' takes care
        of redirecting to the login page first)."""
        if not self._oauth_enabled():
            return request.render("odoo_mcp_server.oauth_error", {
                "message": _("OAuth is disabled on this Odoo instance."),
            })

        client = request.env["mcp.oauth.client"].sudo().search(
            [("client_id", "=", kwargs.get("client_id"))], limit=1)
        if not client:
            return request.render("odoo_mcp_server.oauth_error", {
                "message": _("Unknown OAuth client."),
            })
        redirect_uri = kwargs.get("redirect_uri")
        if not client.check_redirect_uri(redirect_uri):
            return request.render("odoo_mcp_server.oauth_error", {
                "message": _("This redirect URI is not registered for the client."),
            })
        if kwargs.get("response_type") != "code":
            return self._redirect_error(redirect_uri, "unsupported_response_type",
                                        kwargs.get("state"))
        if not kwargs.get("code_challenge"):
            return self._redirect_error(
                redirect_uri, "invalid_request",
                kwargs.get("state"), "PKCE is required.")

        return request.render("odoo_mcp_server.oauth_consent", {
            "client": client,
            "user": request.env.user,
            "params": {
                "client_id": kwargs.get("client_id"),
                "redirect_uri": redirect_uri,
                "state": kwargs.get("state") or "",
                "code_challenge": kwargs.get("code_challenge"),
                "code_challenge_method": kwargs.get("code_challenge_method") or "S256",
                "scope": kwargs.get("scope") or "mcp",
                "resource": kwargs.get("resource") or "",
            },
            "models": request.env["mcp.model.access"].sudo().search([]),
        })

    @http.route("/mcp/oauth/approve", type="http", auth="user",
                methods=["POST"], csrf=True)
    def approve(self, **kwargs):
        client = request.env["mcp.oauth.client"].sudo().search(
            [("client_id", "=", kwargs.get("client_id"))], limit=1)
        redirect_uri = kwargs.get("redirect_uri")
        state = kwargs.get("state") or ""
        if not client or not client.check_redirect_uri(redirect_uri):
            return request.render("odoo_mcp_server.oauth_error", {
                "message": _("Invalid client or redirect URI."),
            })
        if kwargs.get("decision") != "allow":
            return self._redirect_error(redirect_uri, "access_denied", state)

        code = request.env["mcp.oauth.code"]._issue(
            client=client,
            user=request.env.user,
            redirect_uri=redirect_uri,
            code_challenge=kwargs.get("code_challenge"),
            method=kwargs.get("code_challenge_method") or "S256",
            scope=kwargs.get("scope") or "mcp",
            resource=kwargs.get("resource") or None,
        )
        params = {"code": code.code}
        if state:
            params["state"] = state
        return request.redirect("%s?%s" % (redirect_uri, urlencode(params)),
                                local=False)

    def _redirect_error(self, redirect_uri, error, state, description=""):
        params = {"error": error}
        if description:
            params["error_description"] = description
        if state:
            params["state"] = state
        return request.redirect("%s?%s" % (redirect_uri, urlencode(params)),
                                local=False)

    # ==================================================================
    # token endpoint
    # ==================================================================
    @http.route("/mcp/oauth/token", type="http", auth="public",
                methods=["POST", "OPTIONS"], csrf=False, save_session=False)
    def token(self, **kwargs):
        if request.httprequest.method == "OPTIONS":
            return self._json({})
        grant_type = kwargs.get("grant_type")
        if grant_type == "authorization_code":
            return self._grant_authorization_code(kwargs)
        if grant_type == "refresh_token":
            return self._grant_refresh_token(kwargs)
        return self._oauth_error("unsupported_grant_type",
                                 "Only authorization_code and refresh_token.")

    def _lifetime(self):
        return int(self._param("mcp_server.token_lifetime", 720) or 720)

    def _grant_authorization_code(self, kwargs):
        Code = request.env["mcp.oauth.code"].sudo()
        code = Code.search([("code", "=", kwargs.get("code"))], limit=1)
        if not code or not code.is_valid():
            return self._oauth_error("invalid_grant", "Code is unknown or expired.")
        if code.client_id.client_id != kwargs.get("client_id"):
            return self._oauth_error("invalid_grant", "Code was issued to another client.")
        if code.redirect_uri != kwargs.get("redirect_uri"):
            return self._oauth_error("invalid_grant", "Redirect URI mismatch.")
        if not code.verify_pkce(kwargs.get("code_verifier")):
            return self._oauth_error("invalid_grant", "PKCE verification failed.")

        code.used = True
        token, raw, raw_refresh = request.env["mcp.token"].sudo()._issue(
            user=code.user_id,
            name="%s (OAuth)" % code.client_id.name,
            source="oauth",
            client=code.client_id,
            scope=code.scope,
            lifetime_hours=self._lifetime(),
            with_refresh=True,
        )
        return self._token_response(raw, raw_refresh, token)

    def _grant_refresh_token(self, kwargs):
        McpToken = request.env["mcp.token"].sudo()
        try:
            old = McpToken._verify_refresh(kwargs.get("refresh_token"))
        except AccessDenied:
            return self._oauth_error("invalid_grant", "Unknown refresh token.")
        if old.client_id and old.client_id.client_id != kwargs.get("client_id"):
            return self._oauth_error("invalid_grant", "Client mismatch.")

        token, raw, raw_refresh = McpToken._issue(
            user=old.user_id,
            name=old.name,
            source="oauth",
            client=old.client_id,
            scope=old.scope,
            lifetime_hours=self._lifetime(),
            with_refresh=True,
        )
        old.write({"active": False})  # rotate, as OAuth 2.1 asks
        return self._token_response(raw, raw_refresh, token)

    def _token_response(self, raw, raw_refresh, token):
        return self._json({
            "access_token": raw,
            "token_type": "Bearer",
            "expires_in": self._lifetime() * 3600,
            "refresh_token": raw_refresh,
            "scope": token.scope or "mcp",
        })

    # ==================================================================
    # revocation
    # ==================================================================
    @http.route("/mcp/oauth/revoke", type="http", auth="public",
                methods=["POST", "OPTIONS"], csrf=False, save_session=False)
    def revoke(self, **kwargs):
        if request.httprequest.method == "OPTIONS":
            return self._json({})
        McpToken = request.env["mcp.token"].sudo()
        raw = kwargs.get("token") or ""
        for verifier in (McpToken._verify, McpToken._verify_refresh):
            try:
                verifier(raw).write({"active": False})
                break
            except AccessDenied:
                continue
        # RFC 7009: always answer 200, even for an unknown token.
        return self._json({})
