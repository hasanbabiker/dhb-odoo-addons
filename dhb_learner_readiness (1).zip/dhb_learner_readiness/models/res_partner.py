# -*- coding: utf-8 -*-

import logging
from datetime import date

from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = "res.partner"

    # ==================================================================
    # NEBOSH registration data (mirrors the Learner Registration Form)
    # ==================================================================
    is_learner = fields.Boolean(
        "Is a Learner", copy=False,
        help="Tick to turn on the learner file and the readiness checks.")

    nebosh_learner_number = fields.Char(
        "NEBOSH Learner Number", copy=False, index=True, tracking=True,
        help="One number per person, for life. Searchable from the Contacts "
             "search bar.")
    legal_name = fields.Char(
        "Full Legal Name", tracking=True,
        help="Exactly as it appears on the ID document. This is the name "
             "NEBOSH prints on the certificate, and it is not always the same "
             "as the display name above.")
    learner_title = fields.Selection(
        [("mr", "Mr"), ("mrs", "Mrs"), ("miss", "Miss"), ("ms", "Ms"),
         ("other", "Other"), ("na", "N/A")],
        string="Title")
    date_of_birth = fields.Date("Date of Birth")
    nationality_id = fields.Many2one("res.country", string="Nationality")
    gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("undisclosed", "Undisclosed")],
        string="Gender")
    personal_email = fields.Char(
        "Personal Email",
        help="NEBOSH asks for a personal address, not a work one.")
    phone_2 = fields.Char("Phone 2")

    # ==================================================================
    # 1) Identity
    # ==================================================================
    id_doc_type = fields.Selection(
        [
            ("passport", "Passport"),
            ("driving_licence", "Driving Licence"),
            ("national_id", "National ID Card"),
            ("birth_certificate", "Birth Certificate"),
            ("other", "Other"),
        ],
        string="ID Document Type")
    id_doc_type_other = fields.Char("Other ID Type")
    id_doc_number = fields.Char("ID Number")
    id_doc_expiry = fields.Date("ID Expires On")
    id_doc_file = fields.Binary("ID Scan", attachment=True)
    id_doc_filename = fields.Char("ID Filename")

    id_doc_expired = fields.Boolean(compute="_compute_id_state", store=True)
    id_doc_expiring_soon = fields.Boolean(compute="_compute_id_state", store=True)
    id_ok = fields.Boolean("Identity OK", compute="_compute_id_state", store=True)

    @api.depends("id_doc_file", "id_doc_type", "id_doc_number", "id_doc_expiry")
    def _compute_id_state(self):
        today = fields.Date.context_today(self)
        for partner in self:
            expired = bool(partner.id_doc_expiry and partner.id_doc_expiry < today)
            soon = bool(
                partner.id_doc_expiry
                and not expired
                and (partner.id_doc_expiry - today).days <= 60
            )
            partner.id_doc_expired = expired
            partner.id_doc_expiring_soon = soon
            # An expired document is not proof of anything.
            partner.id_ok = bool(
                partner.id_doc_file and partner.id_doc_type
                and partner.id_doc_number and not expired)

    # ==================================================================
    # 2) Payment - any amount actually paid counts
    # ==================================================================
    learner_invoiced = fields.Monetary(
        "Invoiced", compute="_compute_learner_payment",
        currency_field="learner_currency_id")
    learner_paid = fields.Monetary(
        "Paid", compute="_compute_learner_payment",
        currency_field="learner_currency_id")
    learner_due = fields.Monetary(
        "Outstanding", compute="_compute_learner_payment",
        currency_field="learner_currency_id")
    learner_currency_id = fields.Many2one(
        "res.currency", compute="_compute_learner_payment")
    payment_ok = fields.Boolean("Payment OK", compute="_compute_learner_payment")

    def _compute_learner_payment(self):
        Move = self.env["account.move"]
        for partner in self:
            partner.learner_currency_id = partner.company_id.currency_id \
                or self.env.company.currency_id
            invoices = Move.search([
                ("partner_id", "=", partner.id),
                ("move_type", "in", ("out_invoice", "out_refund")),
                ("state", "=", "posted"),
            ])
            total = sum(invoices.mapped("amount_total_signed"))
            due = sum(invoices.mapped("amount_residual_signed"))
            partner.learner_invoiced = total
            partner.learner_due = due
            partner.learner_paid = total - due
            # "Any amount paid" is enough, per DHB policy.
            partner.payment_ok = partner.learner_paid > 0

    def action_open_learner_invoices(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Invoices"),
            "res_model": "account.move",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id),
                       ("move_type", "in", ("out_invoice", "out_refund"))],
            "context": {"default_partner_id": self.id,
                        "default_move_type": "out_invoice"},
        }

    # ==================================================================
    # 3) Signed agreement (Odoo Sign)
    # ==================================================================
    sign_request_id = fields.Many2one(
        "sign.request", string="Signature Request", copy=False, readonly=True)
    sign_state = fields.Selection(
        related="sign_request_id.state", string="Signature Status", readonly=True)
    sign_language = fields.Selection(
        [("ar", "Arabic"), ("en", "English")],
        string="Agreement Language", default="ar")
    signed_document_url = fields.Char(
        "Signed Document", copy=False, readonly=True,
        help="Link to the completed, signed agreement.")
    signed_on = fields.Datetime("Signed On", copy=False, readonly=True)
    sign_ok = fields.Boolean("Agreement OK", compute="_compute_sign_ok",
                             store=True)

    @api.depends("signed_document_url", "signed_on")
    def _compute_sign_ok(self):
        for partner in self:
            partner.sign_ok = bool(partner.signed_document_url and partner.signed_on)

    def _sign_template(self):
        """Template configured in Settings, per language."""
        self.ensure_one()
        params = self.env["ir.config_parameter"].sudo()
        key = "dhb_learner.sign_template_%s" % (self.sign_language or "ar")
        template_id = params.get_param(key)
        if not template_id:
            raise UserError(_(
                "No Odoo Sign template is configured for the %s agreement. "
                "Set it under Settings > Learner File.")
                % dict(self._fields["sign_language"].selection).get(
                    self.sign_language or "ar"))
        template = self.env["sign.template"].browse(int(template_id)).exists()
        if not template:
            raise UserError(_("The configured Sign template no longer exists."))
        return template

    def action_send_agreement(self):
        """Create a Sign request for the enrolment agreement."""
        self.ensure_one()
        if not self.email:
            raise UserError(_("%s has no email address to send the agreement to.")
                            % self.display_name)
        template = self._sign_template()

        # The signer role: take the template's first role if it defines one.
        role = template.sign_item_ids.mapped("responsible_id")[:1]
        item_values = {"partner_id": self.id}
        if role:
            item_values["role_id"] = role.id

        try:
            request = self.env["sign.request"].create({
                "template_id": template.id,
                "reference": _("Enrolment agreement - %s") % self.display_name,
                "request_item_ids": [(0, 0, item_values)],
            })
        except Exception as err:  # Sign's API differs between builds
            raise UserError(_(
                "Could not create the signature request: %s\n\n"
                "Check that the template has exactly one signer role.") % err)

        self.sudo().write({"sign_request_id": request.id})
        self.message_post(body=_(
            "Enrolment agreement sent for signature (%s).")
            % dict(self._fields["sign_language"].selection)[self.sign_language])
        return {
            "type": "ir.actions.act_window",
            "res_model": "sign.request",
            "res_id": request.id,
            "view_mode": "form",
        }

    def action_check_signature(self):
        """Pull the signature status and store the link once signed."""
        for partner in self.filtered("sign_request_id"):
            request = partner.sign_request_id
            if request.state != "signed":
                partner.message_post(body=_(
                    "Signature still pending (status: %s).") % request.state)
                continue
            base = self.env["ir.config_parameter"].sudo().get_param("web.base.url")
            url = "%s/sign/document/%s/%s" % (
                base, request.id, request.access_token or "")
            partner.sudo().write({
                "signed_document_url": url,
                "signed_on": fields.Datetime.now(),
            })
            partner.message_post(body=Markup(
                "<p>%s</p><p><a href='%s' target='_blank'>%s</a></p>") % (
                _("Enrolment agreement signed."), url, _("Open signed document")))
        return True

    # ==================================================================
    # Readiness
    # ==================================================================
    readiness_state = fields.Selection(
        [("incomplete", "Incomplete"), ("ready", "Ready"),
         ("override", "Overridden")],
        string="Readiness", compute="_compute_readiness", store=True)
    readiness_missing = fields.Char(
        "Missing", compute="_compute_readiness", store=True)
    readiness_override = fields.Boolean(
        "Manager Override", copy=False, tracking=True,
        groups="moodle_connector.group_moodle_manager")
    readiness_override_reason = fields.Char(
        "Override Reason", copy=False, tracking=True,
        groups="moodle_connector.group_moodle_manager")

    @api.depends("is_learner", "id_ok", "payment_ok", "sign_ok",
                 "readiness_override")
    def _compute_readiness(self):
        for partner in self:
            if not partner.is_learner:
                partner.readiness_state = False
                partner.readiness_missing = False
                continue
            missing = []
            if not partner.id_ok:
                missing.append(_("valid ID"))
            if not partner.payment_ok:
                missing.append(_("payment"))
            if not partner.sign_ok:
                missing.append(_("signed agreement"))
            partner.readiness_missing = ", ".join(missing) or False
            if not missing:
                partner.readiness_state = "ready"
            elif partner.readiness_override:
                partner.readiness_state = "override"
            else:
                partner.readiness_state = "incomplete"

    def _check_learner_ready(self):
        """Raise unless the learner may be enrolled. Called before enrolment."""
        blocked = []
        for partner in self:
            if not partner.is_learner:
                continue
            if partner.readiness_state == "ready":
                continue
            if partner.readiness_state == "override":
                partner.message_post(body=_(
                    "Enrolled under manager override. Missing: %(missing)s. "
                    "Reason: %(reason)s",
                    missing=partner.readiness_missing or _("none"),
                    reason=partner.readiness_override_reason or _("not given")))
                continue
            blocked.append("%s (%s)" % (
                partner.display_name, partner.readiness_missing))
        if blocked:
            raise UserError(_(
                "These learners cannot be enrolled yet:\n\n%s\n\n"
                "Complete the missing items on the learner file, or ask a "
                "Moodle administrator to tick Manager Override with a reason."
            ) % "\n".join("- %s" % b for b in blocked))
        return True

    @api.constrains("readiness_override", "readiness_override_reason")
    def _check_override_reason(self):
        for partner in self:
            if partner.readiness_override and not partner.readiness_override_reason:
                raise ValidationError(_(
                    "An override needs a written reason - it is recorded in "
                    "the audit trail."))

    # ==================================================================
    # Certificates and quiz results
    # ==================================================================
    certificate_ids = fields.One2many(
        "learner.certificate", "partner_id", string="Certificates")
    certificate_count = fields.Integer(compute="_compute_learner_counts")
    quiz_result_ids = fields.One2many(
        "moodle.grade.item", "partner_id", string="Quiz Results")
    quiz_result_count = fields.Integer(compute="_compute_learner_counts")

    @api.depends("certificate_ids", "quiz_result_ids")
    def _compute_learner_counts(self):
        for partner in self:
            partner.certificate_count = len(partner.certificate_ids)
            partner.quiz_result_count = len(partner.quiz_result_ids)

    _sql_constraints = [
        ("nebosh_learner_number_uniq", "unique(nebosh_learner_number)",
         "This NEBOSH learner number is already used by another contact."),
    ]


class LearnerCertificateType(models.Model):
    _name = "learner.certificate.type"
    _description = "Certificate Type"
    _order = "sequence, name"

    name = fields.Char(required=True)
    code = fields.Char()
    awarding_body = fields.Char(default="NEBOSH")
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)


class LearnerCertificate(models.Model):
    _name = "learner.certificate"
    _description = "Learner Certificate"
    _order = "issue_date desc, id desc"
    _rec_name = "display_label"

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True,
        ondelete="cascade", index=True)
    type_id = fields.Many2one(
        "learner.certificate.type", string="Certificate", required=True)
    display_label = fields.Char(compute="_compute_display_label", store=True)

    certificate_number = fields.Char("Certificate Number")
    awarding_body = fields.Char(related="type_id.awarding_body", store=True)
    grade = fields.Char("Result", help="e.g. Pass, Credit, Distinction")
    issue_date = fields.Date()
    expiry_date = fields.Date(help="Leave empty for certificates that do not expire.")
    course_id = fields.Many2one(
        "moodle.course", string="Moodle Course",
        help="The course this certificate was earned on, if any.")

    file = fields.Binary("Certificate File", attachment=True)
    filename = fields.Char()
    note = fields.Char("Note")

    expired = fields.Boolean(compute="_compute_expired", store=True)

    @api.depends("type_id", "certificate_number", "partner_id")
    def _compute_display_label(self):
        for record in self:
            parts = [record.type_id.name or _("Certificate")]
            if record.certificate_number:
                parts.append(record.certificate_number)
            record.display_label = " - ".join(parts)

    @api.depends("expiry_date")
    def _compute_expired(self):
        today = fields.Date.context_today(self)
        for record in self:
            record.expired = bool(record.expiry_date and record.expiry_date < today)


class MoodleGradeItem(models.Model):
    _name = "moodle.grade.item"
    _description = "Moodle Grade Item"
    _order = "course_id, sequence, id"

    enrolment_id = fields.Many2one(
        "moodle.enrolment", string="Enrolment", required=True,
        ondelete="cascade", index=True)
    partner_id = fields.Many2one(
        related="enrolment_id.partner_id", store=True, index=True)
    course_id = fields.Many2one(
        related="enrolment_id.course_id", store=True, index=True)

    moodle_item_id = fields.Integer("Moodle Item ID", index=True)
    name = fields.Char("Assessment", required=True)
    item_module = fields.Char(
        "Activity Type", help="quiz, h5pactivity, assign, and so on.")
    sequence = fields.Integer(default=10)

    grade = fields.Float(digits=(16, 2))
    grade_max = fields.Float("Out Of", digits=(16, 2))
    percent = fields.Float("Percent", compute="_compute_percent", store=True,
                           digits=(16, 1))
    attempted = fields.Boolean(
        "Attempted", help="False means the learner never opened it - which is "
                          "different from scoring zero.")
    passed = fields.Boolean(compute="_compute_percent", store=True)
    pass_mark = fields.Float("Pass Mark %", default=50.0)

    _sql_constraints = [
        ("item_uniq", "unique(enrolment_id, moodle_item_id)",
         "This assessment is already recorded for that enrolment."),
    ]

    @api.depends("grade", "grade_max", "attempted", "pass_mark")
    def _compute_percent(self):
        for item in self:
            item.percent = (
                (item.grade / item.grade_max * 100.0) if item.grade_max else 0.0)
            item.passed = bool(item.attempted and item.percent >= item.pass_mark)
