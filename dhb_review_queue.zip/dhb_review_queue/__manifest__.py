{
    "name": "DHB Review Queue",
    "summary": "After each decision, open the next item that needs staff: "
               "submitted applications, then pending receipts, then paid learners to enrol.",
    "version": "19.0.1.0.0",
    "category": "Education",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "depends": ["dhb_admission"],
    "data": [],
    "installable": True,
    "application": False,
}
