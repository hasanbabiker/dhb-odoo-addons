"""Move the member of staff straight on to the next piece of work.

The queue covers only the steps that are the centre's to do. Steps that wait
on the learner (opening the link, sending the form, paying) are never in it.

    1. Submitted / under review applications  -> accept or reject
    2. Payment receipts the learner uploaded  -> accept or reject
    3. Accepted applications that are paid    -> enrol

Each queue is worked oldest first and emptied before the next one starts. When
all three are empty the user is taken back to the applications board.

Nothing here changes what the buttons do. The original method runs first via
super(); only what the button *returns* is replaced, and only when the
button was pressed on a single record and returned no action of its own.
"""
from odoo import _, api, models
from odoo.exceptions import AccessError


class DhbReviewQueue(models.AbstractModel):
    _name = "dhb.review.queue"
    _description = "DHB staff work queue"

    @api.model
    def _queues(self):
        return [
            (
                "dhb.registration.invite",
                [("state", "in", ("submitted", "review"))],
                "create_date asc, id asc",
                _("Review applications"),
            ),
            (
                "dhb.payment.proof",
                [("state", "=", "pending")],
                "uploaded_on asc, id asc",
                _("Check payment receipts"),
            ),
            (
                "dhb.registration.invite",
                [("state", "=", "accepted"),
                 ("invoice_payment_state", "in", ("paid", "in_payment"))],
                "create_date asc, id asc",
                _("Enrol paid learners"),
            ),
        ]

    @api.model
    def _search_queue(self, model, domain, order):
        if model not in self.env:
            return self.env["dhb.registration.invite"].browse(), 0
        Model = self.env[model]
        try:
            first = Model.search(domain, order=order, limit=1)
            left = Model.search_count(domain) if first else 0
        except AccessError:
            return Model.browse(), 0
        return first, left

    @api.model
    def _board_action(self):
        """The applications board the user started from."""
        action = self.env["ir.actions.act_window"].sudo().search(
            [("res_model", "=", "dhb.registration.invite"),
             ("view_mode", "ilike", "kanban")],
            order="id asc", limit=1,
        ) or self.env["ir.actions.act_window"].sudo().search(
            [("res_model", "=", "dhb.registration.invite")],
            order="id asc", limit=1,
        )
        if action:
            return action._get_action_dict() if hasattr(action, "_get_action_dict") \
                else action.read()[0]
        return {"type": "ir.actions.act_window_close"}

    @api.model
    def next_action(self):
        for model, domain, order, label in self._queues():
            record, left = self._search_queue(model, domain, order)
            if record:
                return {
                    "type": "ir.actions.act_window",
                    "name": _("%(step)s (%(left)s left)", step=label, left=left),
                    "res_model": model,
                    "res_id": record.id,
                    "views": [[False, "form"]],
                    "view_mode": "form",
                    "target": "current",
                    "context": dict(self.env.context, dhb_review_queue=True),
                }
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("All done"),
                "message": _("Nothing left to review, check or enrol."),
                "type": "success",
                "sticky": False,
                "next": self._board_action(),
            },
        }


class DhbQueueMixin(models.AbstractModel):
    _name = "dhb.review.queue.mixin"
    _description = "Open the next queued item after a decision"

    def _dhb_queue_next(self, result):
        # Keep whatever the button returned when it was used on several
        # records, from code that asked not to be redirected, or when it
        # already opens something of its own (a wizard, a document).
        if (len(self) != 1
                or self.env.context.get("dhb_no_queue")
                or isinstance(result, dict)):
            return result
        return self.env["dhb.review.queue"].next_action()


class DhbRegistrationInvite(models.Model):
    _name = "dhb.registration.invite"
    _inherit = ["dhb.registration.invite", "dhb.review.queue.mixin"]

    def action_accept(self):
        return self._dhb_queue_next(super().action_accept())

    def action_reject(self):
        return self._dhb_queue_next(super().action_reject())

    def action_enrol(self):
        return self._dhb_queue_next(super().action_enrol())


class DhbPaymentProof(models.Model):
    _name = "dhb.payment.proof"
    _inherit = ["dhb.payment.proof", "dhb.review.queue.mixin"]

    def action_accept(self):
        return self._dhb_queue_next(super().action_accept())

    def action_reject(self):
        return self._dhb_queue_next(super().action_reject())
