from odoo import models, fields, api, _

from .constants import (
    AWARDING_BODIES, LANGUAGES, QUALIFICATIONS, STUDY_MODES,
)


class DhbCourse(models.Model):
    """A course the centre offers, described once.

    Before this, every batch asked for the qualification, the language, the
    study mode, the number of lectures, the length and the fee - ten fields,
    every time, from memory. What that produces is visible in any database
    that has run a while: batches named after whoever typed them, dates left
    on their defaults, and a qualification field that is blank because the
    person creating the batch did not know which of ten codes to pick.

    A course is the answer to all of those at once. Describe it here, and a
    batch is a course plus a start date.
    """

    _name = "dhb.course"
    _description = "Course"
    _order = "sequence, name"

    name = fields.Char(
        required=True, translate=False,
        help="As it should read on a certificate, an invoice and a schedule "
             "sent to the awarding body. For example \"NEBOSH IGC - Arabic\".",
    )
    code = fields.Char(
        required=True, copy=False,
        help="Short, and used to build every batch reference. \"IGC\" gives "
             "IGC-2609-G1.",
    )
    _unique_code = models.Constraint(
        "unique(code)", "Another course already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    awarding_body = fields.Selection(
        AWARDING_BODIES, string="Awarded by", default="nebosh", required=True)
    qualification = fields.Selection(QUALIFICATIONS, string="Qualification")
    delivery_language = fields.Selection(
        LANGUAGES, string="Language of delivery", default="ar")
    delivery_mode = fields.Selection(
        STUDY_MODES, string="Study mode", default="virtual")

    duration_days = fields.Integer(
        string="Length in days", default=1,
        help="How many days a batch of this course runs. The batch works out "
             "its end date from this, so nobody has to.",
    )
    total_lectures = fields.Integer(
        string="Lectures", default=0,
        help="How many lectures the course has. Attendance is measured "
             "against it.",
    )
    max_absences = fields.Integer(
        string="Maximum absences", default=2,
        help="Above this, exam registration is blocked unless a manager "
             "records an override with a reason.",
    )

    currency_id = fields.Many2one(
        "res.currency", default=lambda self: self.env.company.currency_id)
    list_price = fields.Monetary(
        string="Fee", help="What a learner normally pays for this course.")

    description = fields.Html(
        help="Shown to applicants. Kept with the course so every batch of it "
             "says the same thing.",
    )
    note = fields.Text(string="Internal notes")

    batch_ids = fields.One2many("dhb.batch", "course_id", string="Batches")
    batch_count = fields.Integer(compute="_compute_batch_count")

    def _compute_batch_count(self):
        for course in self:
            course.batch_count = len(course.batch_ids)

    @api.depends("name", "code")
    def _compute_display_name(self):
        for course in self:
            course.display_name = "[%s] %s" % (course.code, course.name) \
                if course.code else (course.name or "")

    def action_open_batches(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Batches of %s") % self.display_name,
            "res_model": "dhb.batch",
            "view_mode": "kanban,list,form",
            "domain": [("course_id", "=", self.id)],
            "context": {"default_course_id": self.id},
        }
