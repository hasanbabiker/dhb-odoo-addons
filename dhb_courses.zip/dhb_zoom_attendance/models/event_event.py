from odoo import models, fields, api, _


class EventEvent(models.Model):
    """A cohort: one qualification, one language, one group, N lectures."""

    _inherit = "dhb.batch"

    # qualification, delivery_language, delivery_mode and in_company
    # moved to dhb_batch: they describe the cohort, not its attendance.

    tutor_ratio = fields.Float(
        string="Learners per tutor", compute="_compute_tutor_ratio", store=True,
    )
    ratio_warning = fields.Char(compute="_compute_tutor_ratio", store=True)

    tutor_ids = fields.Many2many(
        "hr.employee", string="Tutors",
        help="A cohort can be shared between tutors. The DI1 register lists "
             "three.",
    )
    total_lectures = fields.Integer(string="Total lectures", default=0)
    max_absences = fields.Integer(
        string="Maximum absences", default=2,
        help="NEBOSH condition. Above this, exam registration is blocked "
             "unless a manager records an override with a reason.",
    )
    attendance_threshold_pct = fields.Integer(
        string="Presence threshold (%)", default=75,
        help="Share of the lecture a learner must be connected for before "
             "the line counts as present.",
    )
    exam_registration_deadline = fields.Date(string="Exam registration deadline")
    camera_required = fields.Boolean(
        string="Camera required", default=False,
        help="Stated as cohort policy rather than hard-coded, so an auditor "
             "sees a written rule and any exemption carries a reason.",
    )

    zoom_session_ids = fields.One2many(
        "dhb.zoom.session", "event_id", string="Zoom sessions"
    )
    zoom_session_count = fields.Integer(compute="_compute_zoom_counts")
    pulled_session_count = fields.Integer(compute="_compute_zoom_counts")

    def _apply_course_defaults(self):
        """Add this module's fields to the course-to-batch copy.

        dhb_batch defines the method and copies what it owns; this adds the
        attendance side without dhb_batch having to know that lectures and
        absence limits exist. A new module can do the same tomorrow.
        """
        super()._apply_course_defaults()
        for batch in self:
            course = batch.course_id
            if not course:
                continue
            if course.total_lectures:
                batch.total_lectures = course.total_lectures
            if course.max_absences:
                batch.max_absences = course.max_absences

    @api.depends("zoom_session_ids.state")
    def _compute_zoom_counts(self):
        for event in self:
            sessions = event.zoom_session_ids
            event.zoom_session_count = len(sessions)
            event.pulled_session_count = len(sessions.filtered(lambda s: s.state == "pulled"))

    @api.depends("seats_taken", "tutor_ids", "delivery_mode")
    def _compute_tutor_ratio(self):
        """NEBOSH caps classroom and virtual delivery at 20 learners per tutor.

        Computed rather than left to memory: exceeding it is a finding, and it
        creeps up quietly as late registrations come in.
        """
        for event in self:
            learners = len(event.registration_ids.filtered(
                lambda r: r.state not in ("cancel",)
            ))
            tutors = len(event.tutor_ids) or 1
            ratio = learners / tutors
            event.tutor_ratio = ratio
            capped = event.delivery_mode in ("full_time", "part_time", "virtual")
            if capped and ratio > 20:
                event.ratio_warning = _(
                    "%(ratio).0f learners per tutor — NEBOSH caps this mode at 20."
                ) % {"ratio": ratio}
            else:
                event.ratio_warning = False

    def action_open_zoom_sessions(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Zoom sessions"),
            "res_model": "dhb.zoom.session",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }

    def action_open_attendance(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Attendance"),
            "res_model": "dhb.attendance.line",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }

    def action_pull_all_sessions(self):
        self.ensure_one()
        self.zoom_session_ids.filtered(
            lambda s: s.state != "pulled"
        ).action_pull_attendance()
        return True
