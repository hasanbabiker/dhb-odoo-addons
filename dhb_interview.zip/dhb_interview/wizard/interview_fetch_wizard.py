import logging
import re
from datetime import datetime, timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


def _tokens(name):
    """Comparable name tokens, ignoring titles and punctuation."""
    name = re.sub(r"[^\w\s]", " ", (name or "").lower())
    drop = {"mr", "mrs", "ms", "dr", "eng", "engineer", "prof", "al", "el", "abu"}
    return [t for t in name.split() if len(t) > 2 and t not in drop]


class InterviewFetchWizard(models.TransientModel):
    """Match a cohort's Zoom cloud recordings to its learners.

    Every interview on this account is called "<host>'s Zoom Meeting", so the
    topic carries no information. What does carry information is who was in
    the meeting: the Zoom participant list gives an email and a display name,
    which is the same pair the attendance module already matches on. The
    transcript is used as a second opinion, because a learner who joins from a
    borrowed device still says their own name during the identity check.
    """

    _name = "dhb.interview.fetch.wizard"
    _description = "Fetch interview recordings from Zoom"

    event_id = fields.Many2one(
        "event.event", string="Cohort", required=True,
        help="Interviews are matched against the learners registered on this "
             "cohort.",
    )
    date_from = fields.Date(
        string="From", required=True,
        default=lambda self: fields.Date.today() - timedelta(days=14),
    )
    date_to = fields.Date(
        string="To", required=True, default=fields.Date.today,
    )
    line_ids = fields.One2many(
        "dhb.interview.fetch.line", "wizard_id", string="Recordings")
    scanned = fields.Boolean(readonly=True)
    summary = fields.Char(readonly=True)

    def action_scan(self):
        """List the cloud recordings in the range and propose a learner."""
        self.ensure_one()
        if self.date_from > self.date_to:
            raise UserError(_("The end of the range is before its start."))
        zoom = self.env["dhb.zoom.api"]
        self.line_ids.unlink()

        registrations = self.event_id.registration_ids.filtered(
            lambda r: r.state != "cancel")
        if not registrations:
            raise UserError(_("This cohort has no learners registered."))

        # Meetings already claimed by an interview are left alone, so running
        # the wizard twice does not produce duplicates.
        claimed = set(self.env["dhb.interview"].search([
            ("zoom_meeting_uuid", "!=", False)
        ]).mapped("zoom_meeting_uuid"))

        by_email = {
            (r.email or "").strip().lower(): r
            for r in registrations if r.email
        }
        by_tokens = [(r, set(_tokens(r.partner_id.legal_name or r.name))) for r in registrations]

        meetings = zoom.list_cloud_recordings(self.date_from, self.date_to)
        lines, matched = [], 0
        for meeting in meetings:
            uuid = meeting.get("uuid")
            if uuid in claimed:
                continue
            registration, basis, transcript = self._match_meeting(
                zoom, meeting, by_email, by_tokens)
            if registration:
                matched += 1
            lines.append({
                "wizard_id": self.id,
                "zoom_meeting_id": str(meeting.get("id") or ""),
                "zoom_meeting_uuid": uuid,
                "topic": meeting.get("topic"),
                "start_time": self._parse(meeting.get("start_time")),
                "duration": meeting.get("duration") or 0,
                "has_transcript": bool(zoom.pick_recording_file(meeting, "TRANSCRIPT")),
                "registration_id": registration.id if registration else False,
                "match_basis": basis,
                "selected": bool(registration),
                "transcript_preview": (transcript or "")[:2000],
            })
        self.env["dhb.interview.fetch.line"].create(lines)
        self.scanned = True
        self.summary = _(
            "%(total)s recordings in the range, %(matched)s matched to a "
            "learner on this cohort."
        ) % {"total": len(lines), "matched": matched}
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }

    def _match_meeting(self, zoom, meeting, by_email, by_tokens):
        """Return (registration, how it was matched, transcript text)."""
        meeting_id = meeting.get("uuid") or meeting.get("id")

        # 1. participant email, the only reliable key
        try:
            participants = zoom.get_meeting_participants(meeting_id)
        except Exception:  # noqa: BLE001 - dashboard data expires after 6 months
            participants = []
        for participant in participants:
            email = (participant.get("email") or participant.get("user_email") or "").strip().lower()
            if email and email in by_email:
                return by_email[email], "email", None

        # 2. participant display name, when it is unambiguous
        names = [
            (p.get("name") or p.get("user_name") or "") for p in participants
        ]
        hits = self._score(names, by_tokens)
        if len(hits) == 1:
            return hits[0], "zoom_name", None

        # 3. the transcript of the identity check
        transcript = None
        transcript_file = zoom.pick_recording_file(meeting, "TRANSCRIPT")
        if transcript_file:
            try:
                raw = zoom.download_recording_file(transcript_file.get("download_url"))
                transcript = raw.decode("utf-8", "replace")
            except Exception:  # noqa: BLE001
                transcript = None
        if transcript:
            hits = self._score([transcript], by_tokens)
            if len(hits) == 1:
                return hits[0], "transcript", transcript
        return False, "none", transcript

    @staticmethod
    def _score(haystacks, by_tokens):
        """Registrations whose full name appears in any of the strings.

        Every token of the learner's name has to appear. A cohort holds several
        people called Ahmed, and half a name is not a match: putting one
        learner's interview on another learner's file is the one failure that
        is worse than no match at all.
        """
        blob = " ".join(_tokens(" ".join(haystacks)))
        hits = []
        for registration, tokens in by_tokens:
            if not tokens:
                continue
            if all(re.search(r"\b%s\b" % re.escape(token), blob) for token in tokens):
                hits.append(registration)
        return hits

    @staticmethod
    def _parse(value):
        if not value:
            return False
        try:
            return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            return False

    def action_apply(self):
        """Create the interviews for the ticked lines and fetch each one."""
        self.ensure_one()
        chosen = self.line_ids.filtered(lambda l: l.selected and l.registration_id)
        if not chosen:
            raise UserError(_(
                "Tick at least one recording and give it a learner."
            ))
        Interview = self.env["dhb.interview"]
        created = Interview.browse()
        for line in chosen:
            existing = Interview.search([
                ("registration_id", "=", line.registration_id.id),
            ], limit=1)
            values = {
                "zoom_meeting_id": line.zoom_meeting_id,
                "zoom_meeting_uuid": line.zoom_meeting_uuid,
                "interview_datetime": line.start_time,
                "recording_duration": line.duration,
            }
            if existing:
                existing.write(values)
                interview = existing
            else:
                values["registration_id"] = line.registration_id.id
                interview = Interview.create(values)
            created |= interview

        for interview in created:
            try:
                interview.action_fetch_recording()
            except UserError as exc:
                interview.message_post(body=_("Could not fetch from Zoom: %s") % exc)

        return {
            "type": "ir.actions.act_window",
            "name": _("Closing interviews"),
            "res_model": "dhb.interview",
            "view_mode": "list,form",
            "domain": [("id", "in", created.ids)],
        }


class InterviewFetchLine(models.TransientModel):
    _name = "dhb.interview.fetch.line"
    _description = "Zoom recording proposed as an interview"
    _order = "start_time desc"

    wizard_id = fields.Many2one(
        "dhb.interview.fetch.wizard", required=True, ondelete="cascade")
    selected = fields.Boolean(string="Use")
    zoom_meeting_id = fields.Char(string="Meeting ID", readonly=True)
    zoom_meeting_uuid = fields.Char(readonly=True)
    topic = fields.Char(readonly=True)
    start_time = fields.Datetime(string="Started (UTC)", readonly=True)
    duration = fields.Integer(string="Minutes", readonly=True)
    has_transcript = fields.Boolean(string="Transcript", readonly=True)
    registration_id = fields.Many2one("event.registration", string="Learner")
    match_basis = fields.Selection(
        [
            ("email", "Zoom email"),
            ("zoom_name", "Zoom display name"),
            ("transcript", "Named in the transcript"),
            ("none", "Not matched"),
        ],
        string="Matched on", readonly=True,
    )
    transcript_preview = fields.Text(readonly=True)
