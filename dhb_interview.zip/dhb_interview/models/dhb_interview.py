import base64
import io
import logging
import os
import re
import subprocess
import tempfile
from datetime import datetime

import pytz

from odoo import models, fields, api, _
from odoo.exceptions import UserError

from . import ai_filler, form_filler

_logger = logging.getLogger(__name__)

CERTIFICATE_QUALIFICATIONS = ("igc", "emc", "fire", "hse", "award", "psm")
DIPLOMA_QUALIFICATIONS = ("di1", "di2", "di3")
YES_NO = [("yes", "Yes"), ("no", "No")]


def _clean_vtt(raw):
    """Turn a Zoom .vtt transcript into plain speaker-tagged text."""
    lines, out, previous = (raw or "").splitlines(), [], None
    for line in lines:
        line = line.strip()
        if not line or line.upper().startswith("WEBVTT"):
            continue
        if "-->" in line:
            continue
        if re.fullmatch(r"\d+", line):
            continue
        if line.startswith("NOTE"):
            continue
        if line == previous:
            continue
        previous = line
        out.append(line)
    return "\n".join(out)


class DhbInterview(models.Model):
    """One closing interview or professional discussion, end to end.

    A record is created per learner per cohort. It holds the Zoom cloud
    recording, the transcript, the completed official form, and the state that
    the certificate gate on the registration reads.
    """

    _name = "dhb.interview"
    _description = "NEBOSH closing interview / professional discussion"
    _inherit = ["mail.thread"]
    _order = "interview_datetime desc, id desc"
    _rec_name = "display_name"

    display_name = fields.Char(compute="_compute_display_name", store=True)

    registration_id = fields.Many2one(
        "event.registration", string="Learner on cohort", required=True,
        ondelete="cascade", index=True,
    )
    partner_id = fields.Many2one(
        "res.partner", string="Learner", related="registration_id.partner_id",
        store=True, index=True,
    )
    event_id = fields.Many2one(
        "event.event", string="Cohort", related="registration_id.event_id",
        store=True, index=True,
    )
    qualification = fields.Selection(
        related="event_id.qualification", store=True, string="Qualification",
    )
    interview_deadline = fields.Date(
        related="event_id.sitting_interview_deadline", string="Interviews by",
    )

    form_type = fields.Selection(
        [
            ("as043d", "AS043d Closing Interview Record Sheet"),
            ("diploma", "Diploma Professional Discussion Record Sheet"),
        ],
        string="Form", compute="_compute_form_type", store=True, readonly=False,
        help="Chosen from the cohort's qualification: AS043d for the "
             "certificates, the Professional Discussion sheet for Diploma "
             "units. Override only if the cohort is recorded wrongly.",
    )
    unit = fields.Selection(
        [("DI1", "DI1"), ("DI2", "DI2"), ("DI3", "DI3")],
        string="Unit", compute="_compute_form_type", store=True, readonly=False,
        help="Each Diploma unit has its own professional discussion and its "
             "own record sheet.",
    )

    # --- scheduling and the meeting ------------------------------------
    interview_datetime = fields.Datetime(string="Interview (UTC)", tracking=True)
    assessment_date = fields.Date(
        string="Date of assessment", compute="_compute_assessment_date",
        store=True, readonly=False,
        help="The form asks for the date the assessment opened, which is the "
             "sitting's assessment / paper release date. Taken from the "
             "cohort's sitting so the three Diploma units cannot be mixed up.",
    )
    interviewer_name = fields.Char(
        string="Interviewer", default="Dr. Hassan Babiker", tracking=True,
    )
    lp_name = fields.Char(string="Learning Partner", default="DHB Training and Consulting")
    lp_number = fields.Char(string="LP number", default="1708")

    zoom_meeting_id = fields.Char(string="Zoom meeting ID", index=True)
    zoom_meeting_uuid = fields.Char(string="Zoom meeting UUID")
    recording_url = fields.Char(string="Recording link", help="Zoom play page.")
    recording_duration = fields.Integer(string="Duration (min)")

    video_file = fields.Binary(string="Recording", attachment=True, copy=False)
    video_filename = fields.Char(copy=False)
    transcript = fields.Text(string="Transcript", copy=False)

    # --- Part 2 --------------------------------------------------------
    intro_done = fields.Boolean(string="Interviewer introduced themself")
    structure_explained = fields.Boolean(string="Structure of the interview explained")
    id_type = fields.Selection(
        [("passport", "Passport"), ("licence", "Driver's licence"),
         ("national_id", "National ID")],
        string="Identification shown",
    )
    id_satisfactory = fields.Selection(YES_NO, string="Identification satisfactory")
    room_ok = fields.Selection(YES_NO, string="Room satisfactory")
    no_resources = fields.Selection(
        YES_NO, string="No unauthorised resources", default="yes",
        help="The interviewer's own attestation. Change it only if a concern "
             "was actually raised during the interview.",
    )
    no_assistance = fields.Selection(YES_NO, string="Nobody else in the room")
    identity_notes = fields.Text(string="Notes on the identity check")

    # --- Part 3 --------------------------------------------------------
    q1_task = fields.Char(string="Question 1 - task")
    q1_notes = fields.Text(string="Question 1 - learner's response")
    q2_task = fields.Char(string="Question 2 - task")
    q2_notes = fields.Text(string="Question 2 - learner's response")
    q3_task = fields.Char(string="Question 3 - task")
    q3_notes = fields.Text(string="Question 3 - learner's response")
    other_notes = fields.Text(string="Any other notes")
    diploma_notes = fields.Text(string="Notes on the questions asked")

    # --- output --------------------------------------------------------
    report_file = fields.Binary(string="Record sheet (Word)", attachment=True, copy=False)
    report_filename = fields.Char(copy=False)
    report_pdf = fields.Binary(string="Record sheet (PDF)", attachment=True, copy=False)
    report_pdf_filename = fields.Char(copy=False)

    state = fields.Selection(
        [
            ("draft", "Scheduled"),
            ("fetched", "Recording fetched"),
            ("filled", "Form filled"),
            ("done", "On the learner's file"),
        ],
        default="draft", required=True, index=True, tracking=True,
    )
    ai_filled = fields.Boolean(string="Filled from the transcript", readonly=True)
    missing_items = fields.Text(compute="_compute_missing_items")
    has_video = fields.Boolean(compute="_compute_evidence", store=True)
    has_report = fields.Boolean(compute="_compute_evidence", store=True)
    is_complete = fields.Boolean(
        string="Interview on file", compute="_compute_evidence", store=True,
        help="Both the recording and the completed record sheet are held.",
    )
    is_overdue = fields.Boolean(
        string="Past the deadline", compute="_compute_is_overdue",
    )

    _sql_constraints = [
        (
            "unique_registration_unit",
            "unique(registration_id, unit)",
            "This learner already has an interview recorded for this unit.",
        ),
    ]

    # ------------------------------------------------------------------
    # computes
    # ------------------------------------------------------------------
    @api.depends("partner_id.name", "unit", "event_id.name")
    def _compute_display_name(self):
        for interview in self:
            parts = [interview.partner_id.name or _("New interview")]
            if interview.unit:
                parts.append(interview.unit)
            elif interview.qualification:
                parts.append(dict(
                    self.env["event.event"]._fields["qualification"].selection
                ).get(interview.qualification, ""))
            interview.display_name = " - ".join(p for p in parts if p)

    @api.depends("qualification")
    def _compute_form_type(self):
        for interview in self:
            qualification = interview.qualification
            if qualification in DIPLOMA_QUALIFICATIONS:
                interview.form_type = "diploma"
                interview.unit = qualification.upper()
            elif qualification:
                interview.form_type = "as043d"
                interview.unit = False
            else:
                interview.form_type = interview.form_type or "as043d"
                interview.unit = interview.unit or False

    @api.depends("event_id.nebosh_sitting_id.assessment_date")
    def _compute_assessment_date(self):
        for interview in self:
            sitting = interview.event_id.nebosh_sitting_id
            if sitting.assessment_date:
                interview.assessment_date = sitting.assessment_date
            else:
                interview.assessment_date = interview.assessment_date or False

    @api.depends("video_file", "recording_url", "report_file", "state")
    def _compute_evidence(self):
        for interview in self:
            interview.has_video = bool(interview.video_file or interview.recording_url)
            interview.has_report = bool(interview.report_file)
            interview.is_complete = (
                interview.has_video and interview.has_report
                and interview.state == "done"
            )

    @api.depends("interview_deadline", "state")
    def _compute_is_overdue(self):
        today = fields.Date.today()
        for interview in self:
            interview.is_overdue = bool(
                interview.state != "done"
                and interview.interview_deadline
                and interview.interview_deadline < today
            )

    @api.depends(
        "form_type", "unit", "interview_datetime", "assessment_date",
        "partner_id.nebosh_learner_number", "partner_id.date_of_birth",
        "id_type", "id_satisfactory", "room_ok", "no_assistance",
        "q1_notes", "q2_notes", "q3_notes", "diploma_notes", "identity_notes",
    )
    def _compute_missing_items(self):
        """What the form would go to NEBOSH without.

        Listed rather than blocked: a genuinely unknown date of birth should
        not stop the record being filed, but it should be visible.
        """
        for interview in self:
            missing = []
            partner = interview.partner_id
            if not partner.nebosh_learner_number:
                missing.append(_("NEBOSH learner number"))
            if not partner.date_of_birth:
                missing.append(_("Date of birth"))
            if not interview.interview_datetime:
                missing.append(_("Date and time of the interview"))
            if not interview.assessment_date:
                missing.append(_("Date of assessment"))
            if interview.form_type == "diploma" and not interview.unit:
                missing.append(_("Unit"))
            if not interview.id_type:
                missing.append(_("Type of identification shown"))
            for field_name, label in (
                ("id_satisfactory", _("Identification satisfactory")),
                ("room_ok", _("Room satisfactory")),
                ("no_assistance", _("Nobody else in the room")),
            ):
                if not interview[field_name]:
                    missing.append(label)
            if interview.form_type == "diploma":
                if not (interview.diploma_notes or "").strip():
                    missing.append(_("Part 3 notes"))
            elif not (interview.q1_notes or "").strip():
                missing.append(_("Part 3 notes on the learner's responses"))
            interview.missing_items = "\n".join("- %s" % m for m in missing)

    # ------------------------------------------------------------------
    # dates
    # ------------------------------------------------------------------
    def _local(self):
        """The interview time in the user's timezone.

        The form is read by a NEBOSH reviewer as a wall clock time; storing UTC
        and printing UTC would put every Gulf interview four hours early.
        """
        self.ensure_one()
        if not self.interview_datetime:
            return False
        tz = pytz.timezone(self.env.user.tz or "Asia/Dubai")
        return pytz.utc.localize(self.interview_datetime).astimezone(tz)

    @staticmethod
    def _dmy(value):
        return value.strftime("%d/%m/%Y") if value else ""

    # ------------------------------------------------------------------
    # Zoom
    # ------------------------------------------------------------------
    def action_fetch_recording(self):
        """Pull the cloud recording and the audio transcript from Zoom."""
        zoom = self.env["dhb.zoom.api"]
        for interview in self:
            identifier = interview.zoom_meeting_uuid or interview.zoom_meeting_id
            if not identifier:
                raise UserError(_(
                    "Set the Zoom meeting ID on %s first, or use Fetch "
                    "interviews from Zoom to match the cohort's recordings to "
                    "learners automatically."
                ) % interview.display_name)
            payload = zoom.get_meeting_recordings(identifier)
            interview._apply_recording_payload(payload)
        return True

    def _apply_recording_payload(self, payload):
        """Store what Zoom returned for one meeting."""
        self.ensure_one()
        zoom = self.env["dhb.zoom.api"]
        values = {
            "zoom_meeting_id": str(payload.get("id") or self.zoom_meeting_id or ""),
            "zoom_meeting_uuid": payload.get("uuid") or self.zoom_meeting_uuid,
            "recording_duration": payload.get("duration") or 0,
            "recording_url": payload.get("share_url") or self.recording_url,
        }
        start = payload.get("start_time")
        if start and not self.interview_datetime:
            try:
                values["interview_datetime"] = datetime.strptime(
                    start, "%Y-%m-%dT%H:%M:%SZ")
            except ValueError:
                pass

        transcript_file = zoom.pick_recording_file(payload, "TRANSCRIPT")
        if transcript_file:
            raw = zoom.download_recording_file(transcript_file.get("download_url"))
            values["transcript"] = _clean_vtt(raw.decode("utf-8", "replace"))

        video_file = zoom.pick_recording_file(payload, "MP4")
        if video_file:
            values["recording_url"] = (
                video_file.get("play_url") or values.get("recording_url"))
            if self._store_video():
                blob = zoom.download_recording_file(video_file.get("download_url"))
                if blob:
                    values["video_file"] = base64.b64encode(blob)
                    values["video_filename"] = "%s.mp4" % (
                        self.display_name or "interview").replace("/", "-")

        if values.get("transcript") or values.get("recording_url"):
            values["state"] = "fetched" if self.state == "draft" else self.state
        self.write(values)
        if not transcript_file:
            self.message_post(body=_(
                "Zoom has the recording but no audio transcript for this "
                "meeting. Turn on Audio Transcript under Cloud Recording "
                "settings; Zoom cannot produce one after the fact."
            ))
        return True

    def _store_video(self):
        """Whether to keep the MP4 in Odoo or only link to Zoom."""
        return self.env["ir.config_parameter"].sudo().get_param(
            "dhb_interview.store_video", "False"
        ).lower() in ("1", "true", "yes")

    def action_download_video(self):
        """Keep the MP4 in the learner's file rather than only in Zoom.

        Zoom deletes cloud recordings on the account's retention schedule; the
        awarding body may ask for the interview long after that.
        """
        zoom = self.env["dhb.zoom.api"]
        for interview in self:
            identifier = interview.zoom_meeting_uuid or interview.zoom_meeting_id
            if not identifier:
                raise UserError(_("No Zoom meeting is linked to this interview."))
            payload = zoom.get_meeting_recordings(identifier)
            video_file = zoom.pick_recording_file(payload, "MP4")
            if not video_file:
                raise UserError(_("Zoom has no finished MP4 for this meeting."))
            blob = zoom.download_recording_file(video_file.get("download_url"))
            interview.write({
                "video_file": base64.b64encode(blob),
                "video_filename": "%s.mp4" % (
                    interview.display_name or "interview").replace("/", "-"),
            })
        return True

    # ------------------------------------------------------------------
    # filling
    # ------------------------------------------------------------------
    def action_fill_from_transcript(self):
        """Fill every part of the form from the transcript, in English."""
        icp = self.env["ir.config_parameter"].sudo()
        api_key = icp.get_param("dhb_interview.anthropic_api_key")
        model = icp.get_param("dhb_interview.anthropic_model") or ai_filler.DEFAULT_MODEL
        for interview in self:
            if not (interview.transcript or "").strip():
                raise UserError(_(
                    "There is no transcript on %s yet. Fetch the recording "
                    "first."
                ) % interview.display_name)
            context = {
                "learner_name": interview.partner_id.legal_name
                or interview.partner_id.name,
                "learner_number": interview.partner_id.nebosh_learner_number,
                "unit": interview.unit,
                "interviewer_name": interview.interviewer_name,
            }
            try:
                data = ai_filler.extract(
                    interview.transcript, interview.form_type,
                    context=context, api_key=api_key, model=model,
                )
            except ai_filler.AiFillError as exc:
                raise UserError(str(exc)) from exc
            interview._apply_extracted(data)
        return True

    def _apply_extracted(self, data):
        """Write back only the keys this model knows, after checking them."""
        self.ensure_one()
        if not isinstance(data, dict):
            raise UserError(_("The transcript could not be read into the form."))

        def text(key):
            value = data.get(key)
            return value.strip() if isinstance(value, str) and value.strip() else False

        def yes_no(key, default=False):
            value = data.get(key)
            return value if value in ("yes", "no") else default

        values = {
            "intro_done": bool(data.get("intro_done")),
            "structure_explained": bool(data.get("structure_explained")),
            "id_satisfactory": yes_no("id_satisfactory"),
            "room_ok": yes_no("room_ok"),
            "no_resources": yes_no("no_resources", "yes"),
            "no_assistance": yes_no("no_assistance"),
            "identity_notes": text("identity_notes"),
            "ai_filled": True,
        }
        if data.get("id_type") in ("passport", "licence", "national_id"):
            values["id_type"] = data["id_type"]
        if text("interviewer_name"):
            values["interviewer_name"] = text("interviewer_name")

        if self.form_type == "diploma":
            values["diploma_notes"] = text("diploma_notes")
            if data.get("unit") in ("DI1", "DI2", "DI3") and not self.unit:
                values["unit"] = data["unit"]
        else:
            questions = data.get("questions") or []
            for index, prefix in enumerate(("q1", "q2", "q3")):
                question = questions[index] if index < len(questions) else {}
                if not isinstance(question, dict):
                    question = {}
                task = question.get("task_number")
                notes = question.get("notes")
                values["%s_task" % prefix] = (
                    task.strip() if isinstance(task, str) and task.strip() else False)
                values["%s_notes" % prefix] = (
                    notes.strip() if isinstance(notes, str) and notes.strip() else False)
            values["other_notes"] = text("other_notes")

        # A learner number or date of birth read off the transcript is only
        # taken when the contact record has none: the registration form is the
        # better source, and a mishearing must not overwrite it.
        partner = self.partner_id
        if not partner.nebosh_learner_number and text("learner_number"):
            partner.nebosh_learner_number = text("learner_number")
        if not partner.date_of_birth and text("date_of_birth"):
            try:
                partner.date_of_birth = datetime.strptime(
                    data["date_of_birth"], "%d/%m/%Y").date()
            except (ValueError, TypeError):
                pass

        if self.state in ("draft", "fetched"):
            values["state"] = "filled"
        self.write(values)
        return True

    # ------------------------------------------------------------------
    # the form itself
    # ------------------------------------------------------------------
    def _form_data(self):
        self.ensure_one()
        partner = self.partner_id
        local = self._local()
        data = {
            "learner_name": partner.legal_name or partner.name or "",
            "learner_number": partner.nebosh_learner_number or "",
            "date_of_birth": self._dmy(partner.date_of_birth),
            "lp_name": self.lp_name or "",
            "lp_number": self.lp_number or "",
            "assessment_date": self._dmy(self.assessment_date),
            "interviewer_name": self.interviewer_name or "",
            "interview_date": local.strftime("%d/%m/%Y") if local else "",
            "interview_time": local.strftime("%H:%M") if local else "",
            "intro_done": self.intro_done,
            "structure_explained": self.structure_explained,
            "id_type": self.id_type or None,
            "id_satisfactory": self.id_satisfactory or None,
            "room_ok": self.room_ok or None,
            "no_resources": self.no_resources or None,
            "no_assistance": self.no_assistance or None,
            "identity_notes": self.identity_notes or "",
        }
        if self.form_type == "diploma":
            data["unit"] = self.unit or ""
            data["diploma_notes"] = self.diploma_notes or ""
        else:
            data["questions"] = [
                {"task_number": self.q1_task or "", "notes": self.q1_notes or ""},
                {"task_number": self.q2_task or "", "notes": self.q2_notes or ""},
                {"task_number": self.q3_task or "", "notes": self.q3_notes or ""},
            ]
            data["other_notes"] = self.other_notes or ""
        return data

    def _report_basename(self):
        self.ensure_one()
        partner = self.partner_id
        parts = [partner.nebosh_learner_number or "", partner.legal_name or partner.name or ""]
        if self.form_type == "diploma" and self.unit:
            parts.append(self.unit)
        name = " - ".join(p for p in parts if p) or "interview"
        return re.sub(r"[\\/:*?\"<>|]", "-", name)

    def action_generate_report(self):
        """Produce the completed official sheet as .docx and .pdf."""
        for interview in self:
            if not interview.form_type:
                raise UserError(_("Choose which form this interview uses."))
            basename = interview._report_basename()
            with tempfile.TemporaryDirectory() as workdir:
                docx_path = os.path.join(workdir, "%s.docx" % basename)
                try:
                    form_filler.fill_form(
                        interview.form_type, interview._form_data(), docx_path)
                except ImportError as exc:
                    raise UserError(_(
                        "python-docx is not installed in the Odoo container, "
                        "so the record sheet cannot be written."
                    )) from exc
                with open(docx_path, "rb") as handle:
                    docx_blob = handle.read()
                pdf_blob = interview._to_pdf(docx_path, workdir)

            values = {
                "report_file": base64.b64encode(docx_blob),
                "report_filename": "%s.docx" % basename,
            }
            if pdf_blob:
                values["report_pdf"] = base64.b64encode(pdf_blob)
                values["report_pdf_filename"] = "%s.pdf" % basename
            if interview.state in ("draft", "fetched"):
                values["state"] = "filled"
            interview.write(values)
        return True

    @staticmethod
    def _to_pdf(docx_path, workdir):
        """Convert through LibreOffice, which is what keeps the layout.

        A PDF rebuilt by hand would not be the awarding body's form any more.
        If LibreOffice is missing the .docx still stands on its own, so a
        failure here is logged rather than raised.
        """
        try:
            subprocess.run(
                ["soffice", "--headless", "--norestore", "--convert-to", "pdf",
                 "--outdir", workdir, docx_path],
                check=True, capture_output=True, timeout=180,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _logger.warning("LibreOffice could not convert the record sheet: %s", exc)
            return None
        pdf_path = os.path.splitext(docx_path)[0] + ".pdf"
        if not os.path.exists(pdf_path):
            return None
        with open(pdf_path, "rb") as handle:
            return handle.read()

    # ------------------------------------------------------------------
    # filing
    # ------------------------------------------------------------------
    def action_file_on_learner(self):
        """Attach the evidence to the contact record and close the interview."""
        attachment_model = self.env["ir.attachment"]
        for interview in self:
            if not interview.report_file:
                raise UserError(_(
                    "Generate the record sheet before filing the interview."
                ))
            if not (interview.video_file or interview.recording_url):
                raise UserError(_(
                    "NEBOSH asks for the recording as well as the sheet. Fetch "
                    "the Zoom recording first."
                ))
            basename = interview._report_basename()
            to_attach = [
                ("%s.docx" % basename, interview.report_file,
                 "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
            ]
            if interview.report_pdf:
                to_attach.append(("%s.pdf" % basename, interview.report_pdf,
                                  "application/pdf"))
            if interview.video_file:
                to_attach.append((interview.video_filename or "%s.mp4" % basename,
                                  interview.video_file, "video/mp4"))
            for name, blob, mimetype in to_attach:
                existing = attachment_model.search([
                    ("res_model", "=", "res.partner"),
                    ("res_id", "=", interview.partner_id.id),
                    ("name", "=", name),
                ], limit=1)
                if existing:
                    existing.write({"datas": blob})
                else:
                    attachment_model.create({
                        "name": name,
                        "datas": blob,
                        "mimetype": mimetype,
                        "res_model": "res.partner",
                        "res_id": interview.partner_id.id,
                    })
            interview.message_post(body=_(
                "Interview filed on the learner's record: %s") % basename)
            interview.state = "done"
        return True

    def action_open_transcript(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Transcript"),
            "res_model": "dhb.interview",
            "res_id": self.id,
            "view_mode": "form",
            "views": [(self.env.ref("dhb_interview.view_interview_transcript_form").id, "form")],
            "target": "new",
        }

    # ------------------------------------------------------------------
    # cron
    # ------------------------------------------------------------------
    @api.model
    def _cron_fetch_recordings(self):
        """Pick up cloud recordings for interviews that have a meeting but no
        transcript yet. Zoom finishes processing well after the meeting ends,
        so this runs on a schedule rather than at the moment of the call."""
        pending = self.search([
            ("state", "in", ("draft", "fetched")),
            "|", ("zoom_meeting_id", "!=", False), ("zoom_meeting_uuid", "!=", False),
            ("transcript", "in", (False, "")),
        ], limit=50)
        for interview in pending:
            try:
                interview.action_fetch_recording()
            except UserError as exc:
                _logger.info("Interview %s not ready: %s", interview.id, exc)
            except Exception:  # noqa: BLE001 - one bad record must not stop the run
                _logger.exception("Fetching interview %s failed", interview.id)
        return True

    @api.model
    def _cron_fill_and_generate(self):
        """Fill and produce the sheet for anything that has a transcript."""
        if not self.env["ir.config_parameter"].sudo().get_param(
                "dhb_interview.anthropic_api_key"):
            return True
        pending = self.search([
            ("state", "=", "fetched"),
            ("transcript", "!=", False),
            ("ai_filled", "=", False),
        ], limit=20)
        for interview in pending:
            try:
                interview.action_fill_from_transcript()
                interview.action_generate_report()
            except UserError as exc:
                _logger.info("Interview %s could not be filled: %s", interview.id, exc)
            except Exception:  # noqa: BLE001
                _logger.exception("Filling interview %s failed", interview.id)
        return True
