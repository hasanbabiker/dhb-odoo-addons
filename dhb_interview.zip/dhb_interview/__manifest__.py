{
    "name": "DHB Interview Records",
    "version": "19.0.1.1.2",
    "summary": "NEBOSH closing interview and professional discussion: Zoom cloud "
               "recording, transcript, official record sheet, certificate gate",
    "description": """
DHB Interview Records
=====================

NEBOSH requires a closing interview for certificate learners (IGC, EMC, FIRE)
and a professional discussion for Diploma learners. The session, the recording
and the filing are the same; the name and the record sheet differ, and the
module uses the right one of each from the cohort's qualification.

The Learning Partner must keep both the recording and the completed record
sheet on the learner's file.

This module does the whole loop:

1. Pulls the cloud recording and the audio transcript from Zoom after the
   meeting ends.
2. Matches each recording to a learner in the cohort by looking for the
   learner's name in the transcript of the identity check.
3. Fills the correct official form - AS043d for IG / IGC / EMC / FIRE, the
   Professional Discussion Record Sheet for Diploma units - in English, keeping
   the awarding body's file byte-for-byte except for the answer cells and the
   checkboxes.
4. Files the video and the completed sheet against the learner.
5. Raises a red warning on the registration when a certificate is requested
   before the interview is on file. A manager may override it with a written
   reason; anyone else cannot.

Local recordings are not supported on purpose: NEBOSH asks for the evidence to
survive the trainer's laptop.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["event", "contacts", "mail", "dhb_zoom_attendance", "dhb_learner"],
    "external_dependencies": {"python": ["docx"]},
    "data": [
        "security/ir.model.access.csv",
        "data/ir_cron.xml",
        "views/interview_views.xml",
        "wizard/interview_fetch_wizard_views.xml",
        "views/event_registration_views.xml",
        "views/res_partner_views.xml",
        "views/event_views.xml",
        "views/res_config_settings_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
