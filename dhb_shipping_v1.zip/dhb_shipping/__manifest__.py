{
    "name": "DHB Shipping",
    "version": "19.0.1.0.0",
    "summary": "Every parcel that leaves the centre, and the couriers that "
               "carry them",
    "description": """
DHB Shipping
============

A shipment carries a recipient, an address, a weight, a carrier and a
tracking number. **It does not know what is in the envelope.** Certificates
raise them today; learner packs, printed materials and ID cards will raise
the same record tomorrow without a line here changing.

The direction of the dependency is the design: the thing being shipped
knows that it ships, and Shipping does not know what a certificate is.

**Carriers are records, not a list in the code.** A courier the centre
starts using next month is added in a minute with its own tracking link.
What a developer adds is not the carrier but the automation - booking and
tracking without leaving Odoo. Aramex has it. DHL does not yet, and works
perfectly well without it: booked on their portal, airway bill pasted in,
tracking link live. The only thing missing is a button.

Aramex is booked and tracked against the UAT service until somebody
deliberately switches to live in Settings, because a shipment on the live
service is a courier booked and a bill incurred.

Three refusals are built in, and each cost somebody money once:

* **It will not book twice.** Once a shipment has a tracking number the
  button is gone.
* **It will not send an incomplete address.** Every carrier rejects one
  with a numeric code that arrives after the call; this says "no city on
  Ahmed Ali" before it.
* **It will not decide a parcel arrived from a hopeful word.** Only the
  carrier's own delivered codes close a shipment - "delivered" as a
  substring also matches "delivery attempted".
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Education",
    "license": "LGPL-3",
    "depends": ["base", "mail", "contacts", "base_setup"],
    "data": [
        "security/shipping_groups.xml",
        "security/ir.model.access.csv",
        "data/shipping_data.xml",
        "views/shipment_views.xml",
        "views/carrier_views.xml",
        "views/res_config_settings_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}
