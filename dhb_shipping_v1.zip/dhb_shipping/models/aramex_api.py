"""The Aramex Last Mile API, as thin a wrapper as it can honestly be.

Three services are used: the rate calculator before a parcel is sent, the
shipping service to create it and get an airway bill, and the tracking
service to find out where it went. All three are JSON over POST to the same
host, and all three carry the same ClientInfo block.

Two things about this API decide how the code below is written:

  * **It answers 200 when it fails.** An authentication failure, a missing
    address line and a country that does not exist all come back as HTTP
    200 with `HasErrors: true` and a `Notifications` array. Code that checks
    the status code and moves on will record a shipment that does not
    exist. Every call here goes through _check(), which turns that array
    into a UserError a person can read.

  * **It is real.** A shipment created against the production host is a
    courier booked and a bill incurred. So the module starts in test mode
    against ws.uat.aramex.net, and going live is a deliberate switch in
    Settings, not a default.
"""

import json
import logging
from datetime import datetime

import requests

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

HOSTS = {
    "test": "https://ws.uat.aramex.net",
    "live": "https://ws.aramex.net",
}

PATHS = {
    "create": "/ShippingAPI.V2/Shipping/Service_1_0.svc/json/CreateShipments",
    "label": "/ShippingAPI.V2/Shipping/Service_1_0.svc/json/PrintLabel",
    "rate": "/ShippingAPI.V2/RateCalculator/Service_1_0.svc/json/CalculateRate",
    "track": "/ShippingAPI.V2/Tracking/Service_1_0.svc/json/TrackShipments",
    # FetchCountry, singular. FetchCountries returns 404, and this is the
    # endpoint behind the "Test the connection" button - the first thing
    # anybody presses after typing the credentials in.
    "country": "/ShippingAPI.V2/Location/Service_1_0.svc/json/FetchCountry",
}

TIMEOUT = 40


class DhbAramexApi(models.AbstractModel):
    _name = "dhb.aramex.api"
    _description = "Aramex web services"

    # ------------------------------------------------------------------
    @api.model
    def _setting(self, key, default=""):
        return (self.env["ir.config_parameter"].sudo().get_param(
            "dhb_aramex.%s" % key) or default).strip()

    @api.model
    def _mode(self):
        return self._setting("mode", "test") or "test"

    @api.model
    def _client_info(self):
        """The block every call carries.

        Read fresh each time rather than cached: credentials change, and a
        cached password is a support call that ends in "restart Odoo".
        """
        missing = [
            label for key, label in (
                ("username", "User name"),
                ("password", "Password"),
                ("account_number", "Account number"),
                ("account_pin", "Account PIN"),
                ("account_entity", "Account entity"),
                ("account_country", "Account country"),
            ) if not self._setting(key)
        ]
        if missing:
            raise UserError(_(
                "Aramex is not set up yet. Still missing: %s.\n\nSettings > "
                "DHB Aramex.") % ", ".join(missing))
        return {
            "UserName": self._setting("username"),
            "Password": self._setting("password"),
            "Version": "v1.0",
            "AccountNumber": self._setting("account_number"),
            "AccountPin": self._setting("account_pin"),
            "AccountEntity": self._setting("account_entity"),
            "AccountCountryCode": self._setting("account_country"),
            "Source": 24,
            "PreferredLanguageCode": None,
        }

    # ------------------------------------------------------------------
    @api.model
    def _post(self, service, payload, reference=""):
        url = HOSTS[self._mode()] + PATHS[service]
        payload = dict(payload)          # never mutate the caller's dict
        payload["ClientInfo"] = self._client_info()
        payload["Transaction"] = {"Reference1": reference or ""}
        try:
            response = requests.post(
                url, json=payload, timeout=TIMEOUT,
                headers={"Content-Type": "application/json"})
        except requests.exceptions.Timeout:
            raise UserError(_(
                "Aramex did not answer within %s seconds. Nothing was "
                "created - try again, and if it keeps happening the problem "
                "is between the server and Aramex, not in the data.")
                % TIMEOUT)
        except requests.exceptions.RequestException as error:
            raise UserError(_(
                "Could not reach Aramex (%(host)s).\n\n%(error)s\n\nIf this "
                "is the first attempt, the most likely cause is that this "
                "server's public address has not been added to their "
                "allowed list yet.",
                host=HOSTS[self._mode()], error=error))

        if response.status_code != 200:
            raise UserError(_(
                "Aramex answered %(code)s.\n\n%(body)s",
                code=response.status_code, body=response.text[:500]))

        try:
            body = response.json()
        except ValueError:
            raise UserError(_(
                "Aramex answered something that is not JSON:\n\n%s")
                % response.text[:500])

        # Never log the payload: it carries the password.
        _logger.info("Aramex %s (%s): HasErrors=%s",
                     service, self._mode(), body.get("HasErrors"))
        return body

    @api.model
    def _check(self, body, what):
        """Turn Aramex's own failure report into something readable.

        This is the whole reason the wrapper exists. The service answers
        HTTP 200 on failure and puts the reason in an array, so a caller
        that trusts the status code records a shipment that was never
        created and an airway bill that belongs to nobody.
        """
        if not body.get("HasErrors"):
            return body
        notes = []
        for note in (body.get("Notifications") or []):
            notes.append("%s %s" % (note.get("Code") or "",
                                    note.get("Message") or ""))
        for shipment in (body.get("Shipments") or []):
            for note in (shipment.get("Notifications") or []):
                notes.append("%s %s" % (note.get("Code") or "",
                                        note.get("Message") or ""))
        raise UserError(_(
            "Aramex refused the %(what)s:\n\n%(notes)s",
            what=what, notes="\n".join(notes) or _("no reason given")))

    # ------------------------------------------------------------------
    @api.model
    def _dotnet_date(self, when=None):
        """Aramex wants /Date(milliseconds)/ - a .NET convention, not ours."""
        when = when or datetime.utcnow()
        return "/Date(%s)/" % int(when.timestamp() * 1000)

    @api.model
    def _party(self, name, company, phone, email, line1, city, country,
               line2="", account=None):
        return {
            "Reference1": None,
            "Reference2": None,
            "AccountNumber": account,
            "PartyAddress": {
                "Line1": line1 or "",
                "Line2": line2 or "",
                "Line3": "",
                "City": city or "",
                "StateOrProvinceCode": "",
                "PostCode": "",
                "CountryCode": (country or "AE").upper(),
                "Longitude": 0,
                "Latitude": 0,
            },
            "Contact": {
                "Department": None,
                "PersonName": name or "",
                "Title": None,
                "CompanyName": company or name or "",
                "PhoneNumber1": phone or "",
                "PhoneNumber1Ext": "",
                "PhoneNumber2": "",
                "PhoneNumber2Ext": "",
                "FaxNumber": None,
                "CellPhone": phone or "",
                "EmailAddress": email or "",
                "Type": "",
            },
        }

    # ------------------------------------------------------------------
    @api.model
    def test_connection(self):
        """Ask for the country list - the cheapest call that proves login.

        Chosen deliberately over a rate quote: it creates nothing, costs
        nothing, and still fails loudly on a bad password or an address
        that has not been allowed through.
        """
        body = self._post("country", {"Code": self._setting("account_country", "AE")})
        self._check(body, _("connection test"))
        return True

    # ==================================================================
    # The two things the shipping module asks of this carrier.
    # ==================================================================
    @api.model
    def book(self, shipment):
        """Create the shipment at Aramex and write the airway bill back.

        The order of the last few lines matters more than it looks. The
        airway bill is written to the shipment BEFORE anything else is
        attempted, because by that point the courier is booked and the
        charge is real: if a later step failed and the number were lost,
        the centre would have a parcel nobody can trace and would book a
        second one for the same envelope.
        """
        shipment.ensure_one()
        partner = shipment.partner_id
        home = (self._setting("account_country") or "AE").upper()
        destination = (partner.country_id.code or home).upper()
        domestic = destination == home

        consignee = self._party(
            name=partner.name,
            company=partner.parent_id.name or partner.name,
            phone=(partner.mobile or partner.phone or "").strip(),
            email=partner.email or "",
            line1=partner.street,
            line2=partner.street2 or "",
            city=partner.city,
            country=destination,
        )
        company = self.env.company
        shipper = self._party(
            name=self._setting("shipper_name") or company.name,
            company=company.name,
            phone=self._setting("shipper_phone") or company.phone or "",
            email=company.email or "",
            line1=self._setting("shipper_line1") or company.street or "",
            city=self._setting("shipper_city") or company.city or "",
            country=home,
            account=self._setting("account_number"),
        )

        payload = {
            "Shipments": [{
                "Reference1": shipment.name,
                "Shipper": shipper,
                "Consignee": consignee,
                "ThirdParty": None,
                "ShippingDateTime": self._dotnet_date(),
                "DueDate": self._dotnet_date(),
                "Comments": shipment.contents or "",
                "PickupLocation": "Reception",
                "OperationsInstructions": "",
                "AccountingInstrcutions": "",
                "Details": {
                    "Dimensions": None,
                    "ActualWeight": {
                        "Unit": "KG",
                        "Value": shipment.weight_kg or 0.5},
                    "ChargeableWeight": None,
                    "DescriptionOfGoods": shipment.contents or "Documents",
                    "GoodsOriginCountry": home,
                    "NumberOfPieces": shipment.pieces or 1,
                    # Domestic and international are different products and
                    # the wrong one is refused, not corrected. Both are
                    # settings so they can be set to whatever this account
                    # is actually contracted for.
                    "ProductGroup": "DOM" if domestic else "EXP",
                    "ProductType": (
                        self._setting("product_domestic", "ONP") if domestic
                        else self._setting("product_international", "PPX")),
                    "PaymentType": "P",
                    "PaymentOptions": "",
                    "CustomsValueAmount": None if domestic else {
                        "CurrencyCode": "AED", "Value": 0},
                    "CashOnDeliveryAmount": None,
                    "InsuranceAmount": None,
                    "CashAdditionalAmount": None,
                    "CollectAmount": None,
                    "Services": "",
                    "Items": [],
                },
                "Attachments": [],
                "ForeignHAWB": "",
                "TransportType ": 0,
                "PickupGUID": "",
                "Number": None,
            }],
            "LabelInfo": {"ReportID": 9729, "ReportType": "URL"},
        }

        body = self._post("create", payload, reference=shipment.name)
        self._check(body, _("shipment"))

        shipments = body.get("Shipments") or []
        awb = (shipments[0].get("ID") if shipments else None)
        if not awb:
            raise UserError(_(
                "Aramex accepted the request but returned no airway bill. "
                "Nothing has been recorded here - check the Aramex portal "
                "before trying again, so the same parcel is not booked "
                "twice."))

        label = (shipments[0].get("ShipmentLabel") or {}).get("LabelURL")
        shipment.write({
            "tracking_ref": awb,
            "label_url": label or False,
            "state": "ready" if shipment.state == "draft" else shipment.state,
        })
        shipment.message_post(body=_(
            "Booked with Aramex. Airway bill <b>%s</b>.") % awb)
        return awb

    # ------------------------------------------------------------------
    # Aramex's own codes for a parcel that has arrived. Matched on the code
    # rather than on the words, because the words are written for a human
    # and change; and a substring match on "delivered" also matches
    # "delivery attempted", which would close a parcel still in a depot.
    DELIVERED_CODES = ("SH014", "SH006")
    OUT_FOR_DELIVERY_CODES = ("SH005", "SH134")
    FAILED_CODES = ("SH043", "SH044", "SH059")

    @api.model
    def track(self, shipments, raise_on_error=True):
        by_ref = {s.tracking_ref: s for s in shipments if s.tracking_ref}
        if not by_ref:
            return
        try:
            body = self._post("track", {
                "Shipments": list(by_ref),
                "GetLastTrackingUpdateOnly": True,
            })
            self._check(body, _("tracking request"))
        except UserError:
            if raise_on_error:
                raise
            _logger.warning("Aramex tracking failed for %s", list(by_ref))
            return

        now = fields.Datetime.now()
        for result in (body.get("TrackingResults") or []):
            shipment = by_ref.get(str(result.get("Key") or ""))
            if not shipment:
                continue
            updates = result.get("Value") or []
            if not updates:
                shipment.last_polled = now
                continue
            last = updates[-1]
            code = (last.get("UpdateCode") or "").strip()
            shipment.write({
                "last_status": last.get("UpdateDescription") or "",
                "last_polled": now,
            })
            if code in self.DELIVERED_CODES:
                shipment.action_delivered()
            elif code in self.OUT_FOR_DELIVERY_CODES:
                shipment.action_out_for_delivery()
            elif code in self.FAILED_CODES:
                shipment.action_failed()
            elif shipment.state in ("ready", "scheduled"):
                # Something happened to it, so it is at least on its way.
                shipment.action_in_transit()
