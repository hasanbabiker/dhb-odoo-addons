"""Where the Aramex account details live.

In ir.config_parameter rather than in a field on a record, because that is
where Odoo keeps credentials and because it keeps them out of any export,
duplicate or backup of a business record.

It is worth being plain about what this is not: the password is stored in
the database in readable form, as every Odoo integration stores its
credentials. Anyone with database access can read it. That is the reason
the account should be a service account with only the rights it needs, and
the reason these values are typed here by the centre rather than sent to
anybody.
"""

from odoo import models, fields, api, _


PARAMS = [
    "mode", "username", "password", "account_number", "account_pin",
    "account_entity", "account_country", "shipper_name", "shipper_phone",
    "shipper_line1", "shipper_city", "product_domestic",
    "product_international",
]


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    dhb_aramex_mode = fields.Selection(
        [
            ("test", "Test (UAT) - nothing real is shipped"),
            ("live", "Live - a real courier and a real bill"),
        ],
        string="Aramex environment", default="test",
        config_parameter="dhb_aramex.mode",
        help="Starts on test on purpose. A shipment created against the "
             "live service books a courier and incurs a charge.",
    )
    dhb_aramex_username = fields.Char(
        string="User name", config_parameter="dhb_aramex.username")
    dhb_aramex_password = fields.Char(
        string="Password", config_parameter="dhb_aramex.password")
    dhb_aramex_account_number = fields.Char(
        string="Account number", config_parameter="dhb_aramex.account_number")
    dhb_aramex_account_pin = fields.Char(
        string="Account PIN", config_parameter="dhb_aramex.account_pin")
    dhb_aramex_account_entity = fields.Char(
        string="Account entity", config_parameter="dhb_aramex.account_entity",
        help="The three-letter branch, for example DXB.")
    dhb_aramex_account_country = fields.Char(
        string="Account country", default="AE",
        config_parameter="dhb_aramex.account_country")

    dhb_aramex_shipper_name = fields.Char(
        string="Sender name", config_parameter="dhb_aramex.shipper_name",
        help="Left empty, the company's own name and address are used.")
    dhb_aramex_shipper_phone = fields.Char(
        string="Sender phone", config_parameter="dhb_aramex.shipper_phone")
    dhb_aramex_shipper_line1 = fields.Char(
        string="Sender address", config_parameter="dhb_aramex.shipper_line1")
    dhb_aramex_shipper_city = fields.Char(
        string="Sender city", config_parameter="dhb_aramex.shipper_city")

    dhb_aramex_product_domestic = fields.Char(
        string="Domestic product", default="ONP",
        config_parameter="dhb_aramex.product_domestic",
        help="The product code for a parcel inside the account's own "
             "country. Aramex rejects the wrong one rather than guessing.")
    dhb_aramex_product_international = fields.Char(
        string="International product", default="PPX",
        config_parameter="dhb_aramex.product_international")

    def action_aramex_test(self):
        """Prove the credentials before a real parcel depends on them."""
        self.ensure_one()
        self.env["dhb.aramex.api"].test_connection()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "type": "success",
                "title": _("Aramex answered"),
                "message": _(
                    "The credentials work against the %s service.")
                    % dict(self._fields["dhb_aramex_mode"].selection).get(
                        self.dhb_aramex_mode, self.dhb_aramex_mode),
                "sticky": False,
            },
        }
