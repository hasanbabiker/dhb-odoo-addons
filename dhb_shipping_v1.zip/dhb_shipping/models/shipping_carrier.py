"""Who carries a parcel.

A record rather than a selection list, and the difference is the whole
design. A selection means a developer adds a line of Python every time the
centre starts using a new courier - which means the centre uses whatever is
already in the list, or writes the real courier in a notes field.

So any courier can exist here, created by the office, with manual tracking.
What a developer adds is not the courier but the **automation**: a carrier
whose `integration` is set to something other than "manual" can have its
shipments booked and tracked by the system. Today exactly one can. The
others are no less usable for it - they simply need the airway bill typed
in, which is what happens now anyway.
"""

from odoo import models, fields, api, _


class DhbShippingCarrier(models.Model):
    _name = "dhb.shipping.carrier"
    _description = "Carrier"
    _order = "sequence, name"

    name = fields.Char(required=True)
    code = fields.Char(
        required=True, copy=False,
        help="Short and stable. Used in references and never shown to a "
             "learner.")
    _unique_code = models.Constraint(
        "unique(code)", "Another carrier already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    # What the system can do by itself with this carrier. "manual" is not a
    # lesser option - it is the honest one for a courier we have no account
    # with, and it is what DHL is here: they ship TO us, and their airway
    # bill is theirs to give, not ours to create.
    integration = fields.Selection(
        [
            ("manual", "Manual - tracking typed in"),
            ("aramex", "Aramex - booked and tracked automatically"),
        ],
        string="Automation", default="manual", required=True,
    )

    tracking_url = fields.Char(
        string="Tracking link",
        help="The carrier's own tracking page, with {ref} where the number "
             "goes. For example https://www.aramex.com/track/results"
             "?ShipmentNumber={ref}",
    )
    collects_from_centre = fields.Boolean(
        string="Collects from the centre", default=True,
        help="Off for a carrier we only ever receive from.")

    note = fields.Text(string="Internal notes")
    shipment_count = fields.Integer(compute="_compute_shipment_count")

    def _compute_shipment_count(self):
        counts = dict(self.env["dhb.shipment"]._read_group(
            [("carrier_id", "in", self.ids)],
            ["carrier_id"], ["__count"]))
        for carrier in self:
            carrier.shipment_count = counts.get(carrier, 0)

    def build_tracking_url(self, reference):
        """The carrier's page for one parcel, or nothing.

        Nothing rather than a broken link: a tracking URL built from an
        empty reference lands on the courier's error page, which reads as a
        lost parcel rather than as an empty field.
        """
        self.ensure_one()
        reference = (reference or "").strip()
        if not reference or not self.tracking_url:
            return False
        return self.tracking_url.replace("{ref}", reference)

    def action_open_shipments(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Shipments by %s") % self.display_name,
            "res_model": "dhb.shipment",
            "view_mode": "list,form",
            "domain": [("carrier_id", "=", self.id)],
            "context": {"default_carrier_id": self.id},
        }
