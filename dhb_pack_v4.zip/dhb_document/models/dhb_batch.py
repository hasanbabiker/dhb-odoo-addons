from odoo import models, _


class DhbBatch(models.Model):
    """A batch reaches its material through its course.

    Deliberately no document field on the batch. Material belongs to the
    course - attach it to a cohort and the same scheme of work is copied
    onto every group that ever runs, and within a year there are eleven
    copies of it, each slightly different, none of them wrong enough to
    notice.
    """

    _inherit = "dhb.batch"

    def action_open_course_documents(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Material for %s") % (
                self.course_id.display_name or self.display_name),
            "res_model": "dhb.document",
            "view_mode": "kanban,list,form",
            "domain": [
                ("course_ids", "in", self.course_id.id),
                ("state", "=", "published"),
            ],
        }
