from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError

from odoo.addons.dhb_batch.models.constants import LANGUAGES

from .document_category import CONFIDENTIALITY

# Where the material itself came from. Not the same question as who asked
# for a change: a NEBOSH past paper is the awarding body's document that we
# hold, and our scheme of work is ours.
SOURCES = [
    ("internal", "Written here"),
    ("awarding_body", "From the awarding body"),
    ("publisher", "From a publisher or supplier"),
    ("client", "From a client"),
]


class DhbDocument(models.Model):
    """An item of course material that persists across its versions.

    The distinction this model exists to make: the *document* is "the IGC
    scheme of work"; the *file* is one issue of it. People talk about the
    first and email the second, and a system that only knows about files
    ends up with eleven of them whose names end in "final".
    """

    _name = "dhb.document"
    _description = "Controlled document"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "reference, name"

    name = fields.Char(required=True, tracking=True, index="trigram")
    reference = fields.Char(
        readonly=True, copy=False, index=True, tracking=True,
        help="Given by the category when the document is created.")
    _unique_reference = models.Constraint(
        "unique(reference)", "Another document already has that reference.")

    category_id = fields.Many2one(
        "dhb.document.category", string="Category", required=True,
        index=True, tracking=True, ondelete="restrict")
    course_ids = fields.Many2many(
        "dhb.course", "dhb_document_course_rel", "document_id", "course_id",
        string="Used on",
        help="The courses this belongs to. Leave empty for material that is "
             "not tied to one - a centre policy, a template.")
    language = fields.Selection(
        LANGUAGES, string="Language", default="en",
        help="A course taught in two languages has two documents, not one "
             "with both files in it.")

    source = fields.Selection(
        SOURCES, string="Comes from", default="internal", required=True)
    external_reference = fields.Char(
        string="Their reference",
        help="The awarding body's or publisher's own number for it - a "
             "licence number, an edition, a form code such as AS043d.")

    owner_id = fields.Many2one(
        "res.users", string="Owner", tracking=True,
        default=lambda self: self.env.user,
        help="Who is answerable for this document being right and current. "
             "Reviews land on them.")

    confidentiality = fields.Selection(
        CONFIDENTIALITY, required=True, default="internal", tracking=True,
        index=True, compute="_compute_confidentiality", store=True,
        readonly=False, precompute=True,
        help="Exam-secure material is hidden from everyone outside the group "
             "allowed to hold it.")

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("review", "In review"),
            ("published", "Published"),
            ("revision", "Under revision"),
            ("obsolete", "Withdrawn"),
        ],
        default="draft", required=True, tracking=True, index=True,
        group_expand="_group_expand_state",
        help="Published means there is a current version a tutor may use.")

    version_ids = fields.One2many(
        "dhb.document.version", "document_id", string="Versions")
    version_count = fields.Integer(compute="_compute_version_count")
    current_version_id = fields.Many2one(
        "dhb.document.version", string="Current version", copy=False,
        tracking=True,
        help="The one issue a tutor may hand out today.")
    current_revision = fields.Char(
        related="current_version_id.revision", string="Revision", store=True)
    current_file = fields.Binary(
        related="current_version_id.file", string="File")
    current_filename = fields.Char(related="current_version_id.filename")
    date_published = fields.Date(
        related="current_version_id.date_effective", string="In use since",
        store=True)

    change_ids = fields.One2many(
        "dhb.document.change", "document_id", string="Change requests")
    change_open_count = fields.Integer(compute="_compute_change_counts")
    change_count = fields.Integer(compute="_compute_change_counts")

    review_months = fields.Integer(
        string="Review every (months)",
        compute="_compute_review_months", store=True, readonly=False,
        precompute=True,
        help="Zero for material that does not need reviewing.")
    last_review_date = fields.Date(
        string="Last reviewed", tracking=True,
        help="Set whenever a version is approved, and by the Reviewed button "
             "when a review finds nothing to change.")
    next_review_date = fields.Date(
        compute="_compute_next_review", store=True, index=True)
    review_due = fields.Boolean(compute="_compute_review_due")
    days_to_review = fields.Integer(compute="_compute_review_due")

    note = fields.Html(string="Internal notes")
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        "res.company", default=lambda self: self.env.company)

    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        categories = self.env["dhb.document.category"]
        for vals in vals_list:
            if not vals.get("reference") and vals.get("category_id"):
                category = categories.browse(vals["category_id"])
                vals["reference"] = category._next_reference()
        return super().create(vals_list)

    @api.depends("category_id")
    def _compute_confidentiality(self):
        for document in self:
            if document.category_id and not document.confidentiality:
                document.confidentiality = \
                    document.category_id.default_confidentiality
            elif not document.confidentiality:
                document.confidentiality = "internal"

    @api.depends("category_id")
    def _compute_review_months(self):
        for document in self:
            if document.category_id and not document.review_months:
                document.review_months = \
                    document.category_id.default_review_months

    @api.depends("version_ids")
    def _compute_version_count(self):
        for document in self:
            document.version_count = len(document.version_ids)

    @api.depends("change_ids.state")
    def _compute_change_counts(self):
        for document in self:
            document.change_count = len(document.change_ids)
            document.change_open_count = len(document.change_ids.filtered(
                lambda c: c.state in ("new", "assessed", "approved")))

    @api.depends("last_review_date", "review_months", "date_published")
    def _compute_next_review(self):
        for document in self:
            start = document.last_review_date or document.date_published
            if not start or not document.review_months:
                document.next_review_date = False
                continue
            document.next_review_date = start + relativedelta(
                months=document.review_months)

    # Not stored: it depends on today, and a stored field that depends on
    # today is wrong every morning until something writes to it.
    @api.depends("next_review_date")
    def _compute_review_due(self):
        today = fields.Date.context_today(self)
        for document in self:
            if not document.next_review_date:
                document.days_to_review = 0
                document.review_due = False
                continue
            document.days_to_review = (
                document.next_review_date - today).days
            document.review_due = document.days_to_review <= 0

    @api.model
    def _group_expand_state(self, states, domain):
        return [key for key, _label in self._fields["state"].selection]

    @api.depends("reference", "name", "current_revision")
    def _compute_display_name(self):
        for document in self:
            parts = []
            if document.reference:
                parts.append("[%s]" % document.reference)
            parts.append(document.name or "")
            if document.current_revision:
                parts.append("v%s" % document.current_revision)
            document.display_name = " ".join(part for part in parts if part)

    # ------------------------------------------------------------------
    def action_submit_review(self):
        self.write({"state": "review"})

    def action_start_revision(self):
        """Put a published document back in the workshop.

        The current version stays current while this happens. A centre that
        un-publishes a document the moment somebody spots a typo leaves its
        tutors with nothing to teach from that afternoon.
        """
        self.filtered(lambda d: d.state == "published").write(
            {"state": "revision"})

    def action_obsolete(self):
        for document in self:
            if document.change_open_count:
                raise UserError(_(
                    "%(name)s still has %(count)s change requests open. "
                    "Close or reject them first - withdrawing the document "
                    "under them leaves requests pointing at nothing.",
                    name=document.display_name,
                    count=document.change_open_count,
                ))
            document.state = "obsolete"
            document.current_version_id.filtered(
                lambda v: v.state == "approved").write({"state": "withdrawn"})
            document.message_post(body=_("Withdrawn from use."))

    def action_reinstate(self):
        self.write({"state": "draft"})

    def action_mark_reviewed(self):
        """A review that found nothing to change is still a review.

        Without this button the only way to record one is to issue a version
        that is identical to the last, which is how a document history fills
        up with noise.
        """
        today = fields.Date.context_today(self)
        for document in self:
            document.last_review_date = today
            document.message_post(body=_(
                "Reviewed on %(date)s by %(user)s. No change needed.",
                date=today, user=self.env.user.display_name,
            ))

    def action_new_version(self):
        """Open a draft of the next issue, numbered for you."""
        self.ensure_one()
        latest = self.version_ids.sorted("id", reverse=True)[:1]
        suggestion = "1.0"
        if latest and latest.revision:
            try:
                major, minor = latest.revision.split(".")[:2]
                suggestion = "%s.%s" % (major, int(minor) + 1)
            except (ValueError, IndexError):
                suggestion = "%s.1" % latest.revision
        return {
            "type": "ir.actions.act_window",
            "name": _("New version of %s") % self.display_name,
            "res_model": "dhb.document.version",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_document_id": self.id,
                "default_revision": suggestion,
            },
        }

    def action_open_versions(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Versions of %s") % self.display_name,
            "res_model": "dhb.document.version",
            "view_mode": "list,form",
            "domain": [("document_id", "=", self.id)],
            "context": {"default_document_id": self.id},
        }

    def action_open_changes(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Change requests on %s") % self.display_name,
            "res_model": "dhb.document.change",
            "view_mode": "list,form",
            "domain": [("document_id", "=", self.id)],
            "context": {"default_document_id": self.id},
        }

    def action_request_change(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Request a change to %s") % self.display_name,
            "res_model": "dhb.document.change",
            "view_mode": "form",
            "target": "new",
            "context": {"default_document_id": self.id},
        }

    # ------------------------------------------------------------------
    @api.model
    def _cron_review_due(self):
        """Raise the periodic review, rather than waiting to be asked.

        A review that exists only as a date in a field is a review that does
        not happen. This turns the date into a request with an owner, which
        is the only form of it that anybody acts on.
        """
        today = fields.Date.context_today(self)
        due = self.search([
            ("state", "in", ("published", "revision")),
            ("next_review_date", "!=", False),
            ("next_review_date", "<=", today),
        ])
        changes = self.env["dhb.document.change"]
        for document in due:
            already = document.change_ids.filtered(
                lambda c: c.origin == "review"
                and c.state in ("new", "assessed", "approved"))
            if already:
                continue
            change = changes.create({
                "name": _("Periodic review of %s") % document.name,
                "document_id": document.id,
                "origin": "review",
                "kind": "update",
                "raised_by_id": (document.owner_id or self.env.user).id,
                "description": _(
                    "This document was last reviewed on %(last)s and is due "
                    "every %(months)s months. Check it against the current "
                    "syllabus and the current material, then either issue a "
                    "new version or mark it reviewed with no change.",
                    last=document.last_review_date or _("never"),
                    months=document.review_months,
                ),
            })
            change.activity_schedule(
                "mail.mail_activity_data_todo",
                user_id=(document.owner_id or self.env.user).id,
                summary=_("Review %s") % document.display_name,
            )
