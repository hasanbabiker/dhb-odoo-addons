from odoo import models, fields, api, _

CONFIDENTIALITY = [
    ("learner", "May be given to learners"),
    ("internal", "Internal - staff and tutors"),
    ("exam", "Exam-secure"),
]


class DhbDocumentCategory(models.Model):
    """A kind of material, and the rules that come with it by default.

    Kept as a table rather than a selection list for one reason that matters
    and one that does not. The one that matters: each kind carries its own
    defaults - a model answer is exam-secure and a course handout is not, a
    past paper never needs reviewing and a scheme of work needs it every
    year - and those defaults belong next to the kind, not in a condition
    somewhere in the code. The one that does not: the centre will invent a
    new kind, and should not need us to add it.
    """

    _name = "dhb.document.category"
    _description = "Document category"
    _order = "sequence, name"

    name = fields.Char(required=True, translate=True)
    code = fields.Char(
        required=True,
        help="Two to four letters. It becomes the start of every reference "
             "in this category - TP for a training plan gives TP-001.")
    _unique_code = models.Constraint(
        "unique(code)", "Another category already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    description = fields.Text()

    default_confidentiality = fields.Selection(
        CONFIDENTIALITY, string="Normally", default="internal", required=True,
        help="What a new document of this kind is set to. It can be changed "
             "on the document.")
    default_review_months = fields.Integer(
        string="Review every (months)", default=12,
        help="Zero for material that does not need reviewing - a past paper "
             "is what it is.")

    sequence_id = fields.Many2one(
        "ir.sequence", string="Numbering", copy=False, readonly=True,
        help="Created the first time a document in this category is "
             "numbered.")

    document_ids = fields.One2many(
        "dhb.document", "category_id", string="Documents")
    document_count = fields.Integer(compute="_compute_document_count")

    @api.depends("document_ids")
    def _compute_document_count(self):
        for category in self:
            category.document_count = len(category.document_ids)

    def _next_reference(self):
        """Hand out the next reference in this category.

        A sequence per category rather than one counter with a prefix glued
        on: two people creating a document at the same moment get different
        numbers, which a count-the-rows approach cannot promise.
        """
        self.ensure_one()
        if not self.sequence_id:
            self.sudo().sequence_id = self.env["ir.sequence"].sudo().create({
                "name": _("DHB documents - %s") % self.name,
                "code": "dhb.document.%s" % (self.code or self.id),
                "prefix": "%s-" % (self.code or "DOC"),
                "padding": 3,
                "company_id": False,
            })
        return self.sequence_id.sudo().next_by_id()

    def action_open_documents(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": self.display_name,
            "res_model": "dhb.document",
            "view_mode": "kanban,list,form",
            "domain": [("category_id", "=", self.id)],
            "context": {"default_category_id": self.id},
        }
