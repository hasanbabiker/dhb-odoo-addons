from odoo import models, fields, api, _


class DhbCourse(models.Model):
    """The material a course is taught from.

    Put on the course rather than on the batch on purpose: the scheme of
    work does not change because a new group started. What a batch needs is
    a way to reach the current version of everything its course uses, which
    is the button below.
    """

    _inherit = "dhb.course"

    document_ids = fields.Many2many(
        "dhb.document", "dhb_document_course_rel", "course_id", "document_id",
        string="Material")
    document_count = fields.Integer(compute="_compute_document_count")
    document_stale_count = fields.Integer(compute="_compute_document_count")

    @api.depends("document_ids.state", "document_ids.next_review_date")
    def _compute_document_count(self):
        for course in self:
            documents = course.document_ids
            course.document_count = len(documents)
            course.document_stale_count = len(documents.filtered("review_due"))

    def action_open_documents(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Material for %s") % self.display_name,
            "res_model": "dhb.document",
            "view_mode": "kanban,list,form",
            "domain": [("course_ids", "in", self.id)],
            "context": {"default_course_ids": [(4, self.id)]},
        }
