from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class DhbDocumentVersion(models.Model):
    """One issue of a document: the file, and what changed in it.

    An approved version is frozen. Not by policy - by the write() below.
    The point of a version is that it is the thing somebody was given on a
    date, and a file that can be edited after it was issued cannot play that
    part: every learner who holds a printed copy would be holding something
    the system says does not exist.

    Correcting an approved version is done by issuing the next one.
    """

    _name = "dhb.document.version"
    _description = "Document version"
    _order = "document_id, date_effective desc, id desc"
    _inherit = ["mail.thread"]
    _rec_name = "revision"

    document_id = fields.Many2one(
        "dhb.document", string="Document", required=True, index=True,
        ondelete="cascade")
    revision = fields.Char(
        required=True, default="1.0", tracking=True,
        help="1.0, 1.1, 2.0. A small correction moves the second number, a "
             "rewrite moves the first.")
    _unique_revision = models.Constraint(
        "unique(document_id, revision)",
        "That revision already exists for this document.",
    )

    file = fields.Binary(string="File", attachment=True)
    filename = fields.Char()

    author_id = fields.Many2one(
        "res.users", string="Written by", default=lambda self: self.env.user)
    date_effective = fields.Date(
        string="Effective from", default=fields.Date.context_today,
        help="The date this version becomes the one to use.")

    summary = fields.Text(
        string="What changed", required=True,
        help="In plain words. \"Section 4 rewritten for the 6th edition\" is "
             "worth more than \"minor updates\".")

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("approved", "Approved"),
            ("superseded", "Superseded"),
            ("withdrawn", "Withdrawn"),
        ],
        default="draft", required=True, tracking=True, index=True)

    approved_by_id = fields.Many2one(
        "res.users", string="Approved by", readonly=True, copy=False)
    approval_date = fields.Date(readonly=True, copy=False)

    change_ids = fields.One2many(
        "dhb.document.change", "version_id", string="Changes delivered")
    change_count = fields.Integer(compute="_compute_change_count")

    is_current = fields.Boolean(compute="_compute_is_current", store=True)

    @api.depends("change_ids")
    def _compute_change_count(self):
        for version in self:
            version.change_count = len(version.change_ids)

    @api.depends("document_id.current_version_id")
    def _compute_is_current(self):
        for version in self:
            version.is_current = \
                version.document_id.current_version_id == version

    @api.constrains("file", "state")
    def _check_file(self):
        for version in self:
            if version.state == "approved" and not version.file:
                raise ValidationError(_(
                    "%s cannot be approved with no file on it.")
                    % version.display_name)

    # ------------------------------------------------------------------
    # Frozen fields. Listed rather than "everything", because a typo in the
    # summary of an old version should still be fixable - what must not move
    # is the file itself, its number and the date it took effect.
    FROZEN = ("file", "filename", "revision", "date_effective")

    def write(self, vals):
        locked = [
            version for version in self
            if version.state in ("approved", "superseded")
        ]
        if locked and set(vals) & set(self.FROZEN):
            raise UserError(_(
                "%(name)s has already been issued. The file, its number and "
                "its effective date cannot be changed afterwards - somebody "
                "may be holding a printed copy of it. Issue the next version "
                "instead.",
                name=locked[0].display_name,
            ))
        return super().write(vals)

    def unlink(self):
        for version in self:
            if version.state in ("approved", "superseded"):
                raise UserError(_(
                    "%s was issued and cannot be deleted. Withdraw it if it "
                    "must no longer be used - the record of it stays.")
                    % version.display_name)
        return super().unlink()

    # ------------------------------------------------------------------
    def action_approve(self):
        for version in self:
            if not version.file:
                raise UserError(_(
                    "%s has no file on it.") % version.display_name)
            document = version.document_id
            previous = document.current_version_id
            if previous and previous != version:
                # Superseded, not deleted. The old issue is what somebody was
                # given last March, and the centre has to be able to show it.
                previous.state = "superseded"
            version.write({
                "state": "approved",
                "approved_by_id": self.env.user.id,
                "approval_date": fields.Date.context_today(self),
            })
            document.write({
                "current_version_id": version.id,
                "state": "published",
                "last_review_date": fields.Date.context_today(self),
            })
            version.change_ids.filtered(
                lambda c: c.state == "approved").write({"state": "done"})
            document.message_post(body=_(
                "Version %(rev)s approved and published. %(summary)s",
                rev=version.revision, summary=version.summary or "",
            ))

    def action_withdraw(self):
        for version in self:
            version.state = "withdrawn"
            if version.document_id.current_version_id == version:
                version.document_id.current_version_id = False

    @api.depends("document_id", "revision")
    def _compute_display_name(self):
        for version in self:
            version.display_name = "%s v%s" % (
                version.document_id.reference or
                version.document_id.name or "", version.revision or "")
