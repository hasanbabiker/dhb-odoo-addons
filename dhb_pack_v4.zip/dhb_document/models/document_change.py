from odoo import models, fields, api, _
from odoo.exceptions import UserError

# Where a change came from. Recorded because the answer changes what has to
# happen next: a change the awarding body asked for has a deadline and is
# not optional; one a learner raised is evidence that the centre listens,
# and an auditor will ask to see some.
ORIGINS = [
    ("awarding_body", "Awarding body"),
    ("tutor", "Tutor"),
    ("learner", "Learner"),
    ("internal", "Internal development"),
    ("review", "Periodic review"),
    ("audit", "Audit or verification finding"),
]


class DhbDocumentChange(models.Model):
    """A request to change a controlled document.

    Nothing moves in this app without one. That is the whole point of
    control: a file that changed because somebody edited it is a file nobody
    can account for, and "who asked for this and why" is the question that
    cannot be answered a year later from the file itself.
    """

    _name = "dhb.document.change"
    _description = "Document change request"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "priority desc, date desc, id desc"

    name = fields.Char(
        string="Request", required=True, tracking=True,
        help="What is being asked for, in one line.")
    reference = fields.Char(
        readonly=True, copy=False, index=True,
        help="Given when the request is raised.")

    document_id = fields.Many2one(
        "dhb.document", string="Document", required=True, index=True,
        ondelete="cascade", tracking=True)
    category_id = fields.Many2one(
        related="document_id.category_id", store=True)
    course_ids = fields.Many2many(
        related="document_id.course_ids", string="Courses")

    origin = fields.Selection(
        ORIGINS, required=True, default="internal", tracking=True,
        index=True)
    raised_by_id = fields.Many2one(
        "res.users", string="Raised by", default=lambda self: self.env.user,
        tracking=True)
    raised_for_id = fields.Many2one(
        "res.partner", string="On behalf of",
        help="The tutor, learner or awarding-body contact who asked. Leave "
             "empty for an internal change.")
    date = fields.Date(
        string="Raised on", default=fields.Date.context_today, required=True,
        index=True)

    kind = fields.Selection(
        [
            ("correction", "Correction - something is wrong"),
            ("update", "Update - something has changed outside"),
            ("addition", "Addition - new content"),
            ("clarity", "Clarity - it is right but hard to follow"),
            ("withdrawal", "Withdrawal - it should no longer be used"),
        ],
        string="Type", default="update", required=True)
    priority = fields.Selection(
        [("0", "Normal"), ("1", "Important"), ("2", "Urgent")],
        default="0", index=True)

    description = fields.Text(
        required=True,
        help="What is wrong or missing, and where. A page or a section "
             "number saves the next person an hour.")

    state = fields.Selection(
        [
            ("new", "New"),
            ("assessed", "Assessed"),
            ("approved", "Approved"),
            ("done", "Done"),
            ("rejected", "Rejected"),
        ],
        default="new", required=True, tracking=True, index=True,
        group_expand="_group_expand_state")

    decision = fields.Text(
        string="Decision",
        help="Why it was approved or rejected. A rejected request with no "
             "reason on it comes back next month.")
    decided_by_id = fields.Many2one(
        "res.users", string="Decided by", readonly=True, copy=False)
    decision_date = fields.Date(readonly=True, copy=False)
    due_date = fields.Date(
        string="Needed by",
        help="Set this when the awarding body gave a date.")

    version_id = fields.Many2one(
        "dhb.document.version", string="Delivered in",
        help="The version that carried this change. Filled in when the "
             "request is closed.")

    notify_learners = fields.Boolean(
        string="Learners must be told",
        help="Tick when the change affects material already handed out.")
    notify_awarding_body = fields.Boolean(
        string="Awarding body must be told")

    @api.model
    def _group_expand_state(self, states, domain):
        return [key for key, _label in self._fields["state"].selection]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("reference"):
                vals["reference"] = self.env["ir.sequence"].next_by_code(
                    "dhb.document.change") or "/"
        changes = super().create(vals_list)
        for change in changes:
            # sudo, and this is the reason: mail.thread posts under
            # _mail_post_access = 'write' by default, so writing a note onto
            # the document requires permission to edit the document. A tutor
            # raising a request has read access and nothing more, and would
            # be stopped by an access error at the moment of saving - which
            # is exactly the flow this module exists to make easy. The note
            # is the system's own, not the user's.
            change.document_id.sudo().message_post(body=_(
                "Change requested (%(origin)s): %(name)s",
                origin=dict(ORIGINS).get(change.origin, change.origin),
                name=change.name,
            ))
        return changes

    # ------------------------------------------------------------------
    def action_assess(self):
        self.write({"state": "assessed"})

    def action_approve(self):
        self.write({
            "state": "approved",
            "decided_by_id": self.env.user.id,
            "decision_date": fields.Date.context_today(self),
        })
        # An approved change with nowhere to land is a change that gets
        # forgotten, so the document is put into revision at the same time.
        for change in self:
            if change.document_id.state == "published":
                change.document_id.action_start_revision()

    def action_reject(self):
        for change in self:
            if not change.decision:
                raise UserError(_(
                    "Say why %s is being rejected. A rejected request with "
                    "no reason on it is raised again next month.")
                    % change.display_name)
        self.write({
            "state": "rejected",
            "decided_by_id": self.env.user.id,
            "decision_date": fields.Date.context_today(self),
        })

    def action_done(self):
        for change in self:
            if not change.version_id:
                raise UserError(_(
                    "%s has no version against it. Closing a change without "
                    "saying which version delivered it breaks the only trail "
                    "there is.") % change.display_name)
        self.write({"state": "done"})

    def action_reset(self):
        self.write({"state": "new", "decided_by_id": False,
                    "decision_date": False})

    @api.depends("reference", "name")
    def _compute_display_name(self):
        for change in self:
            change.display_name = "[%s] %s" % (change.reference, change.name) \
                if change.reference and change.reference != "/" \
                else (change.name or "")
