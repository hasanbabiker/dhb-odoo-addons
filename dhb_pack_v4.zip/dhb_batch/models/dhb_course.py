from odoo import models, fields, api, _
from odoo.exceptions import UserError

from .constants import (
    AWARDING_BODIES, LANGUAGES, QUALIFICATIONS, STUDY_MODES,
)


class DhbCourse(models.Model):
    """A course the centre offers, described once.

    Before this, every batch asked for the qualification, the language, the
    study mode, the number of lectures, the length and the fee - ten fields,
    every time, from memory. What that produces is visible in any database
    that has run a while: batches named after whoever typed them, dates left
    on their defaults, and a qualification field that is blank because the
    person creating the batch did not know which of ten codes to pick.

    A course is the answer to all of those at once. Describe it here, and a
    batch is a course plus a start date.
    """

    _name = "dhb.course"
    _description = "Course"
    _order = "sequence, name"

    name = fields.Char(
        required=True, translate=False,
        help="As it should read on a certificate, an invoice and a schedule "
             "sent to the awarding body. For example \"NEBOSH IGC - Arabic\".",
    )
    code = fields.Char(
        required=True, copy=False,
        help="Short, and used to build every batch reference. \"IGC\" gives "
             "IGC-2609-G1.",
    )
    _unique_code = models.Constraint(
        "unique(code)", "Another course already uses that code.")

    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    # Where the course stands with us and with the awarding body. Four
    # states rather than an active/inactive flag, because two of the four
    # are real situations a flag cannot tell apart:
    #
    #   Suspended - we still hold the course, but something is wrong at the
    #     awarding body's end: an approval lapsed, a spec is being replaced.
    #     No new batch may open. The running ones carry on.
    #   Retired - we no longer sell it. The record stays because the
    #     learners who took it are still ours to account for.
    #
    # Archiving (the `active` flag above) remains what it always was, and is
    # a different question: whether the record is in the way. A retired
    # course is usually not archived - it is still consulted.
    status = fields.Selection(
        [
            ("draft", "Draft"),
            ("active", "Active"),
            ("suspended", "Suspended"),
            ("retired", "Retired"),
        ],
        default="draft", required=True, index=True,
        group_expand="_group_expand_status",
        help="A course can only be made Active once everything a batch "
             "needs is filled in.",
    )

    awarding_body = fields.Selection(
        AWARDING_BODIES, string="Awarded by", default="nebosh", required=True)
    qualification = fields.Selection(QUALIFICATIONS, string="Qualification")
    delivery_language = fields.Selection(
        LANGUAGES, string="Language of delivery", default="ar")
    delivery_mode = fields.Selection(
        STUDY_MODES, string="Study mode", default="virtual")

    duration_days = fields.Integer(
        string="Length in days", default=1,
        help="How many days a batch of this course runs. The batch works out "
             "its end date from this, so nobody has to.",
    )
    guided_hours = fields.Integer(
        string="Hours",
        help="Guided learning hours - the taught time the awarding body "
             "expects for this qualification. It is quoted on a schedule "
             "submitted for approval, and it is not the same as the number "
             "of days.",
    )
    total_lectures = fields.Integer(
        string="Lectures", default=0,
        help="How many lectures the course has. Attendance is measured "
             "against it.",
    )
    max_absences = fields.Integer(
        string="Maximum absences", default=2,
        help="Above this, exam registration is blocked unless a manager "
             "records an override with a reason.",
    )

    currency_id = fields.Many2one(
        "res.currency", default=lambda self: self.env.company.currency_id)
    list_price = fields.Monetary(
        string="Fee", help="What a learner normally pays for this course.")

    description = fields.Html(
        help="Shown to applicants. Kept with the course so every batch of it "
             "says the same thing.",
    )
    note = fields.Text(string="Internal notes")

    batch_ids = fields.One2many("dhb.batch", "course_id", string="Batches")
    batch_count = fields.Integer(compute="_compute_batch_count")

    setup_warning = fields.Char(compute="_compute_setup_warning")
    setup_ready = fields.Boolean(compute="_compute_setup_warning")

    def _compute_batch_count(self):
        for course in self:
            course.batch_count = len(course.batch_ids)

    def _setup_missing(self):
        """What still has to be filled in before batches of this course work.

        Written as a list of names rather than a score. A course that is 80%
        set up tells nobody what to do next; "Fee, Length in days" does.
        """
        self.ensure_one()
        missing = []
        if not self.duration_days:
            missing.append(_("Length in days"))
        if not self.guided_hours:
            missing.append(_("Hours"))
        if not self.total_lectures:
            missing.append(_("Lectures"))
        if not self.list_price:
            missing.append(_("Fee"))
        if not self.qualification:
            missing.append(_("Qualification"))
        if not self.delivery_language:
            missing.append(_("Language"))
        return missing

    @api.depends("duration_days", "guided_hours", "total_lectures",
                 "list_price", "qualification", "delivery_language")
    def _compute_setup_warning(self):
        for course in self:
            missing = course._setup_missing()
            course.setup_ready = not missing
            course.setup_warning = _(
                "%(count)s still to set up: %(items)s",
                count=len(missing), items=", ".join(missing),
            ) if missing else False

    @api.model
    def _group_expand_status(self, statuses, domain):
        return [key for key, _label in self._fields["status"].selection]

    # ------------------------------------------------------------------
    def action_activate(self):
        """Refuse to make a course sellable while it is not usable.

        This is one of the few places where a refusal beats a warning. A
        course with no fee and no length does not merely look unfinished:
        the batch built from it has no end date and its invoice line is
        zero, and both of those are discovered by the learner.
        """
        for course in self:
            missing = course._setup_missing()
            if missing:
                raise UserError(_(
                    "%(name)s cannot be made active yet. Still to fill in: "
                    "%(items)s.",
                    name=course.display_name, items=", ".join(missing),
                ))
            course.status = "active"

    def action_suspend(self):
        self.write({"status": "suspended"})

    def action_retire(self):
        self.write({"status": "retired"})

    def action_back_to_draft(self):
        self.write({"status": "draft"})

    def action_open_batch_wizard(self):
        """Open a batch - unless the status says the course may not run.

        This is what makes the status more than a colour on a list. A
        suspended course is one the awarding body has a problem with, and
        the batch that must not be opened is the next one, not the ones
        already running.
        """
        self.ensure_one()
        if self.status == "suspended":
            raise UserError(_(
                "%s is suspended, so no new batch of it may open. The "
                "batches already running are not affected.")
                % self.display_name)
        if self.status == "retired":
            raise UserError(_(
                "%s has been retired. Put it back to Draft and make it "
                "active again if the centre is offering it once more.")
                % self.display_name)
        if self.status == "draft":
            raise UserError(_(
                "%(name)s is still a draft. Finish setting it up and press "
                "Activate - otherwise the batch would inherit a course with "
                "%(items)s missing.",
                name=self.display_name,
                items=", ".join(self._setup_missing()) or _("nothing"),
            ))
        return {
            "type": "ir.actions.act_window",
            "name": _("Open a batch of %s") % self.display_name,
            "res_model": "dhb.course.batch.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"active_id": self.id},
        }

    @api.depends("name", "code")
    def _compute_display_name(self):
        for course in self:
            course.display_name = "[%s] %s" % (course.code, course.name) \
                if course.code else (course.name or "")

    def action_open_batches(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Batches of %s") % self.display_name,
            "res_model": "dhb.batch",
            "view_mode": "kanban,list,form",
            "domain": [("course_id", "=", self.id)],
            "context": {"default_course_id": self.id},
        }
