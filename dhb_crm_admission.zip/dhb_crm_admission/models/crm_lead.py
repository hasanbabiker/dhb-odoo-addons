import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class CrmLead(models.Model):
    """An enquiry about a course, and the one button that acts on it."""

    _inherit = "crm.lead"

    register_id = fields.Many2one(
        "dhb.admission.register", string="Intake asked about",
        help="Which admission register this enquiry is for. Picking it is "
             "what lets the button raise the application on the right cohort.",
    )
    register_event_id = fields.Many2one(
        related="register_id.event_id", string="Cohort", readonly=True)
    register_is_open = fields.Boolean(
        related="register_id.is_open", string="Intake open", readonly=True)
    register_seats_left = fields.Integer(
        related="register_id.seats_left", string="Places left", readonly=True)

    application_id = fields.Many2one(
        "dhb.registration.invite", string="Application", readonly=True,
        copy=False, index=True,
    )
    application_state = fields.Selection(
        related="application_id.state", string="Application status",
        readonly=True)
    application_url = fields.Char(
        related="application_id.url", string="Registration link", readonly=True)

    # ------------------------------------------------------------------
    def _application_values(self):
        """What the enquiry already knows, handed to the application."""
        self.ensure_one()
        register = self.register_id
        values = register._defaults_for_application()
        values.update({
            "email": (self.email_from or "").strip(),
            "learner_name": self.contact_name or self.partner_id.name or self.name,
            "lead_id": self.id,
        })
        if self.partner_id:
            values["partner_id"] = self.partner_id.id
        return values

    def action_create_application(self):
        """Turn the enquiry into an application, with its link ready to send."""
        self.ensure_one()
        if self.application_id:
            raise UserError(_(
                "This enquiry already has an application. Open it rather than "
                "raising a second one for the same person."
            ))
        if not self.register_id:
            raise UserError(_(
                "Pick the intake first. Without it the application has no "
                "cohort to sit on and no fee to copy."
            ))
        if not (self.email_from or "").strip():
            raise UserError(_(
                "This enquiry has no email address, and the registration link "
                "is sent to one. Add it to the enquiry first."
            ))

        closed = self.register_id._why_closed()
        if closed:
            raise UserError(_(
                "%s\n\nPick an intake that is open, or reopen this one."
            ) % closed)

        application = self.env["dhb.registration.invite"].create(
            self._application_values())
        self.application_id = application.id

        self.message_post(body=_(
            "Application %(ref)s raised on %(register)s.<br/>"
            "Registration link: <a href=\"%(url)s\">%(url)s</a>"
        ) % {
            "ref": application.name,
            "register": self.register_id.name,
            "url": application.url or "",
        })
        return self.action_open_application()

    def action_open_application(self):
        self.ensure_one()
        if not self.application_id:
            raise UserError(_("No application has been raised yet."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Application"),
            "res_model": "dhb.registration.invite",
            "res_id": self.application_id.id,
            "view_mode": "form",
        }

    # ------------------------------------------------------------------
    def _mark_won_from_admission(self):
        """Move the enquiry to the won stage once the learner is enrolled.

        Written against the stage flagged as won rather than calling CRM's own
        helper, because that helper pops a rainbow at the user and this runs
        from a button on a different screen.
        """
        won_stage = self.env["crm.stage"].search([("is_won", "=", True)], limit=1)
        for lead in self:
            values = {"probability": 100.0}
            if won_stage:
                values["stage_id"] = won_stage.id
            lead.write(values)
            lead.message_post(body=_(
                "Won: the learner was enrolled on %s."
            ) % (lead.register_event_id.name or _("their cohort")))
        return True
