import logging

from odoo import models, fields, _

_logger = logging.getLogger(__name__)


class RegistrationInvite(models.Model):
    """The application's side of the link back to the enquiry."""

    _inherit = "dhb.registration.invite"

    lead_id = fields.Many2one(
        "crm.lead", string="Enquiry", readonly=True, copy=False, index=True,
        help="The enquiry this application grew out of. It carries where the "
             "learner came from, which is the thing nobody can reconstruct "
             "afterwards.",
    )
    lead_source_id = fields.Many2one(
        related="lead_id.source_id", string="Source", readonly=True, store=True)
    lead_medium_id = fields.Many2one(
        related="lead_id.medium_id", string="Channel", readonly=True, store=True)
    lead_user_id = fields.Many2one(
        related="lead_id.user_id", string="Who took the enquiry", readonly=True)

    def action_enrol(self):
        result = super().action_enrol()
        for application in self:
            if application.state != "enrolled" or not application.lead_id:
                continue
            try:
                application.lead_id._mark_won_from_admission()
            except Exception as exc:  # noqa: BLE001
                # Losing the pipeline update must never cost an enrolment.
                _logger.exception(
                    "Could not mark lead %s won", application.lead_id.id)
                application.message_post(body=_(
                    "The learner is enrolled, but the enquiry could not be "
                    "marked won: %s"
                ) % exc)
        return result

    def action_open_lead(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "crm.lead",
            "res_id": self.lead_id.id,
            "view_mode": "form",
        }
