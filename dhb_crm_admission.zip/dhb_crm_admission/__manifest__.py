{
    "name": "DHB Enquiries to Admissions",
    "version": "19.0.1.0.0",
    "summary": "Record the enquiry, then turn it into an application with one "
               "button, keeping where it came from",
    "description": """
DHB Enquiries to Admissions
===========================

Ten people ask about a course this week and three enrol. Until now the system
knew about the three. The other seven existed only in a WhatsApp thread, so
nobody could answer the questions that decide where next month's marketing
money goes: how many asked, through which channel, how many converted, and who
was never followed up.

This bridges Odoo's CRM to DHB Admissions:

* An enquiry is a CRM lead, with its source, its channel and its salesperson.
* One button turns it into an application on a chosen admission register. The
  invitation link is generated and posted back on the enquiry, ready to send.
* The enquiry keeps a link to the application, so the pipeline shows how far
  each one got without anyone updating two records.
* When the application is enrolled, the enquiry is won automatically.

It is a separate module on purpose. CRM is a large app, and Admissions has to
stay installable without it - a centre that works entirely from invitations
does not need a pipeline.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["dhb_admission", "crm"],
    "data": [
        "views/crm_lead_views.xml",
        "views/invite_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
