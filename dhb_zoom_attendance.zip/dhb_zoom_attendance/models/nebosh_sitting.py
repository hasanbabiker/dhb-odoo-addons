from odoo import models, fields, api, _


class DhbNeboshSitting(models.Model):
    """One NEBOSH assessment sitting, with every published deadline.

    NEBOSH sets these dates a year or two in advance and does not move them.
    Each row carries nine deadlines, and missing any one of them costs a
    learner a sitting or the centre a fee — the transfer request window, the
    registration close, the practical submission, the closing interview, the
    EAR window. Keeping them in a spreadsheet means someone has to remember to
    look; keeping them here means the system can warn.
    """

    _name = "dhb.nebosh.sitting"
    _description = "NEBOSH assessment sitting"
    _order = "assessment_date desc, unit_code"
    _rec_name = "name"

    name = fields.Char(required=True)
    unit_code = fields.Char(string="Unit", required=True, index=True)
    year = fields.Integer(index=True)
    active = fields.Boolean(default=True)

    # The published dates, in the order NEBOSH lists them.
    assessment_date = fields.Date(string="Assessment / paper release", index=True)
    setup_form_date = fields.Date(string="Online exam set-up form available")
    booking_deadline = fields.Date(string="Exam booking deadline")
    transfer_deadline = fields.Date(
        string="Enrolment extension / transfer deadline",
        help="The last date a learner transfer request can be submitted. This "
             "is the deadline the Learner Transfer Declaration works to.",
    )
    registration_closing = fields.Date(string="Registration closing")
    login_details_date = fields.Date(string="Login details sent")
    digital_open = fields.Date(string="Digital submission opens")
    digital_closing = fields.Date(string="Digital submission closes")
    lp_download_available = fields.Date(string="LP download available")
    lp_download_closing = fields.Date(string="LP download closes")
    practical_deadline = fields.Date(string="Practical submission deadline")
    interview_deadline = fields.Date(
        string="Closing interview / professional discussion deadline",
        help="The deadline the AS043d closing interview record works to.",
    )
    results_due = fields.Date(string="Results due by")
    ear_deadline = fields.Date(
        string="EAR request deadline",
        help="Enquiry About Result. After this date a mark cannot be "
             "challenged, whatever the learner's case.",
    )
    ear_declaration = fields.Date(string="EAR declaration date")

    event_ids = fields.One2many("event.event", "nebosh_sitting_id", string="Cohorts")
    event_count = fields.Integer(compute="_compute_event_count")

    # What is next, and how long is left.
    next_deadline = fields.Date(compute="_compute_next_deadline", store=True)
    next_deadline_name = fields.Char(compute="_compute_next_deadline", store=True)
    days_to_next = fields.Integer(compute="_compute_days_to_next")
    state = fields.Selection(
        [("future", "Upcoming"), ("open", "In progress"), ("past", "Finished")],
        compute="_compute_next_deadline", store=True, index=True,
    )

    _unique_unit_date = models.Constraint(
        "unique(unit_code, assessment_date)",
        "That unit already has a sitting on that date.",
    )

    def _compute_event_count(self):
        for sitting in self:
            sitting.event_count = len(sitting.event_ids)

    @api.depends("booking_deadline", "transfer_deadline", "registration_closing",
                 "digital_closing", "practical_deadline", "interview_deadline",
                 "results_due", "ear_deadline")
    def _compute_next_deadline(self):
        today = fields.Date.today()
        labels = [
            ("booking_deadline", _("Exam booking")),
            ("transfer_deadline", _("Transfer requests")),
            ("registration_closing", _("Registration closes")),
            ("digital_closing", _("Digital submission closes")),
            ("practical_deadline", _("Practical submission")),
            ("interview_deadline", _("Closing interview")),
            ("results_due", _("Results due")),
            ("ear_deadline", _("EAR requests close")),
        ]
        for sitting in self:
            upcoming = [
                (sitting[field], label)
                for field, label in labels
                if sitting[field] and sitting[field] >= today
            ]
            if upcoming:
                date, label = min(upcoming, key=lambda item: item[0])
                sitting.next_deadline = date
                sitting.next_deadline_name = label
                sitting.state = "open" if (
                    sitting.booking_deadline and sitting.booking_deadline < today
                ) else "future"
            else:
                sitting.next_deadline = False
                sitting.next_deadline_name = False
                sitting.state = "past"

    def _compute_days_to_next(self):
        today = fields.Date.today()
        for sitting in self:
            sitting.days_to_next = (
                (sitting.next_deadline - today).days if sitting.next_deadline else 0
            )

    def action_open_events(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Cohorts"),
            "res_model": "event.event",
            "view_mode": "list,form",
            "domain": [("nebosh_sitting_id", "=", self.id)],
        }


class EventEventSitting(models.Model):
    _inherit = "event.event"

    nebosh_sitting_id = fields.Many2one(
        "dhb.nebosh.sitting", string="NEBOSH sitting",
        help="Pick the sitting and the cohort inherits all of its deadlines, "
             "rather than someone copying nine dates by hand.",
    )

    sitting_booking_deadline = fields.Date(
        related="nebosh_sitting_id.booking_deadline", string="Exam booking by", store=True)
    sitting_registration_closing = fields.Date(
        related="nebosh_sitting_id.registration_closing", string="Registration closes", store=True)
    sitting_transfer_deadline = fields.Date(
        related="nebosh_sitting_id.transfer_deadline", string="Transfers by")
    sitting_practical_deadline = fields.Date(
        related="nebosh_sitting_id.practical_deadline", string="Practical by")
    sitting_interview_deadline = fields.Date(
        related="nebosh_sitting_id.interview_deadline", string="Interviews by")
    sitting_results_due = fields.Date(
        related="nebosh_sitting_id.results_due", string="Results due")
    sitting_ear_deadline = fields.Date(
        related="nebosh_sitting_id.ear_deadline", string="EAR closes")

    deadline_warning = fields.Char(compute="_compute_deadline_warning")

    @api.depends("nebosh_sitting_id", "sitting_registration_closing",
                 "sitting_booking_deadline")
    def _compute_deadline_warning(self):
        today = fields.Date.today()
        for event in self:
            warning = False
            sitting = event.nebosh_sitting_id
            if sitting:
                if sitting.registration_closing and sitting.registration_closing < today:
                    warning = _("Registration for this sitting closed on %s.") % (
                        sitting.registration_closing.strftime("%d/%m/%Y"))
                elif sitting.registration_closing:
                    days = (sitting.registration_closing - today).days
                    if days <= 21:
                        warning = _(
                            "Registration closes in %(days)s days, on %(date)s."
                        ) % {"days": days,
                             "date": sitting.registration_closing.strftime("%d/%m/%Y")}
            event.deadline_warning = warning

    @api.onchange("qualification")
    def _onchange_qualification_sitting(self):
        """Offer only the sittings that carry this qualification's unit."""
        mapping = {
            "igc": "NG/IG1", "di1": "DN/DI1", "di2": "DN/DI2", "di3": "DN/DI3",
            "emc": "EMC", "fire": "FSC", "psm": "PSM/EAW",
        }
        code = mapping.get(self.qualification)
        if not code:
            return {}
        return {"domain": {"nebosh_sitting_id": [("unit_code", "ilike", code)]}}
