import logging
from datetime import datetime

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


def _parse_zoom_dt(value):
    """Zoom hands back ISO-8601 in UTC with a trailing Z."""
    if not value:
        return False
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
        except ValueError:
            return False


class DhbZoomSession(models.Model):
    """One Zoom meeting, tied to one numbered lecture of one cohort.

    DHB creates a separate Zoom meeting for every lecture rather than one
    recurring meeting, so the mapping from meeting ID to lecture number has to
    be stored somewhere. This is that somewhere.

    Lecture number rather than date is the anchor: a postponed lecture moves
    its date but keeps its place in the syllabus, and the awarding body counts
    lectures, not days.
    """

    _name = "dhb.zoom.session"
    _description = "Zoom session for a lecture"
    _order = "event_id, lecture_number"
    _rec_name = "display_name"

    event_id = fields.Many2one(
        "event.event", string="Cohort", required=True, ondelete="cascade", index=True
    )
    lecture_number = fields.Integer(string="Lecture no.", required=True)
    zoom_meeting_id = fields.Char(
        string="Zoom meeting ID", required=True, index=True,
        help="The numeric meeting ID, not the UUID.",
    )
    topic = fields.Char(string="Topic")
    session_date = fields.Date(string="Date", index=True)
    start_time = fields.Datetime(string="Started at (UTC)")
    end_time = fields.Datetime(string="Ended at (UTC)")
    duration_minutes = fields.Integer(string="Duration (min)")

    state = fields.Selection(
        [
            ("draft", "Not pulled"),
            ("pulled", "Pulled"),
            ("error", "Error"),
        ],
        default="draft",
        required=True,
        index=True,
    )
    last_pull = fields.Datetime(string="Last pull", readonly=True)
    pull_message = fields.Text(string="Last message", readonly=True)

    attendance_line_ids = fields.One2many(
        "dhb.attendance.line", "zoom_session_id", string="Attendance"
    )
    # Stored, because the search view filters on unmatched_count and a
    # non-stored compute has no column to search against.
    attendance_count = fields.Integer(
        compute="_compute_attendance_count", store=True
    )
    unmatched_count = fields.Integer(
        compute="_compute_attendance_count", store=True
    )

    display_name = fields.Char(compute="_compute_display_name", store=True)

    _sql_constraints = [
        (
            "unique_meeting_per_event",
            "unique(event_id, zoom_meeting_id)",
            "This Zoom meeting is already linked to this cohort.",
        ),
        (
            "unique_lecture_per_event",
            "unique(event_id, lecture_number)",
            "This cohort already has a session with that lecture number.",
        ),
    ]

    @api.depends("event_id.name", "lecture_number")
    def _compute_display_name(self):
        for record in self:
            if record.event_id:
                record.display_name = _("%(event)s — lecture %(no)s",
                                        event=record.event_id.name,
                                        no=record.lecture_number)
            else:
                record.display_name = _("Lecture %s") % record.lecture_number

    @api.depends("attendance_line_ids", "attendance_line_ids.registration_id")
    def _compute_attendance_count(self):
        for record in self:
            lines = record.attendance_line_ids
            record.attendance_count = len(lines)
            record.unmatched_count = len(lines.filtered(lambda l: not l.registration_id))

    @api.constrains("lecture_number")
    def _check_lecture_number(self):
        for record in self:
            if record.lecture_number < 1:
                raise UserError(_("Lecture number must be 1 or more."))
            total = record.event_id.total_lectures
            if total and record.lecture_number > total:
                raise UserError(_(
                    "This cohort is set to %(total)s lectures, so lecture "
                    "%(no)s is out of range. Raise the total on the cohort if "
                    "an extra lecture was genuinely added.",
                    total=total, no=record.lecture_number,
                ))

    # ------------------------------------------------------------------
    # pulling
    # ------------------------------------------------------------------
    def action_pull_attendance(self):
        for record in self:
            record._pull_one()
        return True

    def _pull_one(self):
        """Fetch participants for this meeting and write attendance lines.

        Re-pulling is safe: existing lines for this session are replaced, so a
        lecture can be pulled again after a learner's email is corrected.
        """
        self.ensure_one()
        api_client = self.env["dhb.zoom.api"]
        Line = self.env["dhb.attendance.line"]

        try:
            metrics = api_client.get_meeting_metrics(self.zoom_meeting_id)
            participants = api_client.get_meeting_participants(self.zoom_meeting_id)
        except UserError as exc:
            self.write({
                "state": "error",
                "last_pull": fields.Datetime.now(),
                "pull_message": str(exc),
            })
            return False

        qos_video = self._video_senders(api_client)

        start = _parse_zoom_dt(metrics.get("start_time"))
        end = _parse_zoom_dt(metrics.get("end_time"))
        self.write({
            "topic": metrics.get("topic") or self.topic,
            "start_time": start or self.start_time,
            "end_time": end or self.end_time,
            "duration_minutes": metrics.get("duration") or self.duration_minutes,
            "session_date": (start.date() if start else self.session_date),
        })

        self.attendance_line_ids.unlink()

        # Zoom returns one row per join. A learner who dropped and came back
        # appears several times, and those rows have to be folded together.
        by_person = {}
        for participant in participants:
            email = (participant.get("user_email") or "").strip().lower()
            name = (participant.get("name") or "").strip()
            key = email or ("name:" + name.lower())
            entry = by_person.setdefault(key, {
                "email": email,
                "name": name,
                "joins": [],
                "leaves": [],
                "duration": 0,
                "rejoins": 0,
                "device": participant.get("device"),
                "location": participant.get("location"),
                "zoom_user_id": participant.get("user_id"),
            })
            join = _parse_zoom_dt(participant.get("join_time"))
            leave = _parse_zoom_dt(participant.get("leave_time"))
            if join:
                entry["joins"].append(join)
            if leave:
                entry["leaves"].append(leave)
            entry["duration"] += int(participant.get("duration") or 0)
            entry["rejoins"] += 1

        created = 0
        for entry in by_person.values():
            line_values = {
                "zoom_session_id": self.id,
                "event_id": self.event_id.id,
                "lecture_number": self.lecture_number,
                "session_date": self.session_date,
                "zoom_name": entry["name"],
                "zoom_email": entry["email"],
                "zoom_user_id": entry["zoom_user_id"],
                "join_time": min(entry["joins"]) if entry["joins"] else False,
                "leave_time": max(entry["leaves"]) if entry["leaves"] else False,
                # Zoom reports duration in seconds on the dashboard endpoint.
                "duration_minutes": round(entry["duration"] / 60.0, 1),
                "rejoin_count": max(entry["rejoins"] - 1, 0),
                "device": entry["device"],
                "location": entry["location"],
                "camera_on": entry["email"] in qos_video if entry["email"] else False,
                "camera_source": "qos",
                "source": "zoom",
            }
            line = Line.create(line_values)
            line._match_registration()
            created += 1

        unmatched = len(self.attendance_line_ids.filtered(lambda l: not l.registration_id))
        message = _("%(created)s participants pulled, %(unmatched)s unmatched.",
                    created=created, unmatched=unmatched)
        self.write({
            "state": "pulled",
            "last_pull": fields.Datetime.now(),
            "pull_message": message,
        })
        _logger.info("Zoom pull for meeting %s: %s", self.zoom_meeting_id, message)
        return True

    def _video_senders(self, api_client):
        """Emails of participants whose QoS shows outgoing video.

        Best available proxy for "camera was on". Treated as an inference, not
        a fact: the attendance line keeps a manual override.
        """
        senders = set()
        try:
            qos_rows = api_client.get_participants_qos(self.zoom_meeting_id)
        except UserError:
            return senders

        for row in qos_rows:
            email = (row.get("user_email") or "").strip().lower()
            if not email:
                continue
            for block in row.get("user_qos") or []:
                video_in = block.get("video_input") or {}
                if any(video_in.get(field) for field in ("bitrate", "frame_rate", "resolution")):
                    senders.add(email)
                    break
        return senders

    # ------------------------------------------------------------------
    # scheduled pull
    # ------------------------------------------------------------------
    @api.model
    def _cron_pull_attendance(self):
        """Pull anything not yet pulled whose meeting has already ended.

        Deliberately conservative: it never re-pulls a session that already
        succeeded, so a hand-corrected line is not silently overwritten.
        """
        sessions = self.search([
            ("state", "in", ("draft", "error")),
            ("session_date", "<=", fields.Date.today()),
        ], limit=40)
        for session in sessions:
            try:
                session._pull_one()
                self.env.cr.commit()
            except Exception:  # noqa: BLE001 - one bad session must not stop the rest
                _logger.exception("Zoom pull failed for session %s", session.id)
                self.env.cr.rollback()
        return True
