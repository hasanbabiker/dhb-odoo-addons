from odoo import models, fields, api, _


class EventEvent(models.Model):
    """A cohort: one qualification, one language, one group, N lectures."""

    _inherit = "event.event"

    qualification = fields.Selection(
        [
            ("igc", "NEBOSH IGC"),
            ("di1", "NEBOSH Diploma DI1"),
            ("di2", "NEBOSH Diploma DI2"),
            ("di3", "NEBOSH Diploma DI3"),
            ("emc", "NEBOSH Environmental Management"),
            ("fire", "NEBOSH Fire"),
            ("hse", "NEBOSH HSE Incident Investigation"),
            ("award", "NEBOSH Health and Safety at Work Award"),
            ("psm", "NEBOSH Process Safety Management"),
            ("iosh_ms", "IOSH Managing Safely"),
        ],
        string="Qualification",
        index=True,
    )
    delivery_language = fields.Selection(
        [
            ("en", "English"),
            ("ar", "Arabic"),
            ("ru", "Russian"),
            ("tr", "Turkish"),
            ("pt", "Portuguese (European)"),
            ("es", "Spanish (European)"),
            ("fr", "French"),
        ],
        string="Language of delivery",
    )
    delivery_mode = fields.Selection(
        [
            ("classroom", "Classroom"),
            ("live_online", "Live online"),
            ("blended", "Blended"),
            ("elearning", "E-learning"),
            ("in_company", "In-company"),
        ],
        string="Delivery mode",
        default="live_online",
        help="One internal list. NEBOSH, IOSH and internal forms each use "
             "their own wording; those are mapped on output.",
    )

    tutor_ids = fields.Many2many(
        "hr.employee", string="Tutors",
        help="A cohort can be shared between tutors. The DI1 register lists "
             "three.",
    )
    group_code = fields.Char(string="Group", help="Group 1, Group 2 ...")
    total_lectures = fields.Integer(string="Total lectures", default=0)
    max_absences = fields.Integer(
        string="Maximum absences", default=2,
        help="NEBOSH condition. Above this, exam registration is blocked "
             "unless a manager records an override with a reason.",
    )
    attendance_threshold_pct = fields.Integer(
        string="Presence threshold (%)", default=75,
        help="Share of the lecture a learner must be connected for before "
             "the line counts as present.",
    )
    exam_registration_deadline = fields.Date(string="Exam registration deadline")
    camera_required = fields.Boolean(
        string="Camera required", default=False,
        help="Stated as cohort policy rather than hard-coded, so an auditor "
             "sees a written rule and any exemption carries a reason.",
    )

    zoom_session_ids = fields.One2many(
        "dhb.zoom.session", "event_id", string="Zoom sessions"
    )
    zoom_session_count = fields.Integer(compute="_compute_zoom_counts")
    pulled_session_count = fields.Integer(compute="_compute_zoom_counts")

    @api.depends("zoom_session_ids.state")
    def _compute_zoom_counts(self):
        for event in self:
            sessions = event.zoom_session_ids
            event.zoom_session_count = len(sessions)
            event.pulled_session_count = len(sessions.filtered(lambda s: s.state == "pulled"))

    def action_open_zoom_sessions(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Zoom sessions"),
            "res_model": "dhb.zoom.session",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }

    def action_open_attendance(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Attendance"),
            "res_model": "dhb.attendance.line",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.id)],
            "context": {"default_event_id": self.id},
        }

    def action_pull_all_sessions(self):
        self.ensure_one()
        self.zoom_session_ids.filtered(
            lambda s: s.state != "pulled"
        ).action_pull_attendance()
        return True
