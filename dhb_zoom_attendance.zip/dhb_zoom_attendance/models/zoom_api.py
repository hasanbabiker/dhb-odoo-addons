import base64
import logging
from datetime import datetime, timedelta

import requests

from odoo import models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

ZOOM_TOKEN_URL = "https://zoom.us/oauth/token"
ZOOM_API_BASE = "https://api.zoom.us/v2"
TIMEOUT = 30


class ZoomApi(models.AbstractModel):
    """Thin client over the Zoom Server-to-Server OAuth and Dashboard APIs.

    Credentials live in ir.config_parameter, never in the source tree. The
    access token is cached in the same place and reused until it is close to
    expiry, because Zoom rate-limits token issuance separately from API calls.
    """

    _name = "dhb.zoom.api"
    _description = "Zoom API client"

    # ------------------------------------------------------------------
    # credentials and token
    # ------------------------------------------------------------------
    def _get_credentials(self):
        icp = self.env["ir.config_parameter"].sudo()
        account_id = icp.get_param("dhb_zoom.account_id")
        client_id = icp.get_param("dhb_zoom.client_id")
        client_secret = icp.get_param("dhb_zoom.client_secret")
        if not (account_id and client_id and client_secret):
            raise UserError(_(
                "Zoom credentials are not set. Go to Settings > DHB Zoom "
                "Attendance and enter the Account ID, Client ID and Client "
                "Secret from your Server-to-Server OAuth app."
            ))
        return account_id, client_id, client_secret

    def _get_token(self, force_refresh=False):
        icp = self.env["ir.config_parameter"].sudo()
        if not force_refresh:
            token = icp.get_param("dhb_zoom.access_token")
            expiry = icp.get_param("dhb_zoom.token_expiry")
            if token and expiry:
                try:
                    if datetime.fromisoformat(expiry) > datetime.utcnow() + timedelta(minutes=2):
                        return token
                except ValueError:
                    pass

        account_id, client_id, client_secret = self._get_credentials()
        basic = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
        try:
            response = requests.post(
                ZOOM_TOKEN_URL,
                headers={"Authorization": f"Basic {basic}"},
                data={
                    "grant_type": "account_credentials",
                    "account_id": account_id,
                },
                timeout=TIMEOUT,
            )
        except requests.RequestException as exc:
            raise UserError(_("Could not reach Zoom: %s") % exc) from exc

        if response.status_code != 200:
            raise UserError(_(
                "Zoom rejected the credentials (HTTP %(code)s): %(body)s",
                code=response.status_code,
                body=response.text[:400],
            ))

        payload = response.json()
        token = payload.get("access_token")
        expires_in = int(payload.get("expires_in", 3600))
        icp.set_param("dhb_zoom.access_token", token)
        icp.set_param(
            "dhb_zoom.token_expiry",
            (datetime.utcnow() + timedelta(seconds=expires_in)).isoformat(),
        )
        return token

    # ------------------------------------------------------------------
    # generic request with one retry on 401
    # ------------------------------------------------------------------
    def _request(self, path, params=None, _retried=False):
        token = self._get_token()
        try:
            response = requests.get(
                f"{ZOOM_API_BASE}{path}",
                headers={"Authorization": f"Bearer {token}"},
                params=params or {},
                timeout=TIMEOUT,
            )
        except requests.RequestException as exc:
            raise UserError(_("Could not reach Zoom: %s") % exc) from exc

        if response.status_code == 401 and not _retried:
            self._get_token(force_refresh=True)
            return self._request(path, params=params, _retried=True)

        if response.status_code == 404:
            raise UserError(_(
                "Zoom has no record for this request. Either the meeting ID is "
                "wrong, or the meeting is older than the six months Zoom keeps "
                "dashboard data for.\n\nPath: %s"
            ) % path)

        if response.status_code != 200:
            raise UserError(_(
                "Zoom returned HTTP %(code)s for %(path)s:\n%(body)s",
                code=response.status_code,
                path=path,
                body=response.text[:400],
            ))

        return response.json()

    def _request_paged(self, path, params=None, key="participants"):
        """Follow next_page_token until Zoom stops handing them out."""
        params = dict(params or {})
        params.setdefault("page_size", 300)
        records, guard = [], 0
        while True:
            payload = self._request(path, params)
            records.extend(payload.get(key, []))
            token = payload.get("next_page_token")
            guard += 1
            if not token or guard >= 50:
                break
            params["next_page_token"] = token
        return records

    # ------------------------------------------------------------------
    # endpoints we actually use
    # ------------------------------------------------------------------
    def test_connection(self):
        """Cheapest possible authenticated call, for the Test button."""
        self._get_token(force_refresh=True)
        return self._request("/users/me")

    def list_user_meetings(self, user_id="me", date_from=None, date_to=None):
        """Past meetings for a host, via the report endpoint."""
        params = {"page_size": 300}
        if date_from:
            params["from"] = date_from.strftime("%Y-%m-%d")
        if date_to:
            params["to"] = date_to.strftime("%Y-%m-%d")
        return self._request_paged(
            f"/report/users/{user_id}/meetings", params, key="meetings"
        )

    def get_meeting_metrics(self, meeting_id):
        return self._request(f"/metrics/meetings/{meeting_id}", {"type": "past"})

    def get_meeting_participants(self, meeting_id):
        """Dashboard participants: join, leave, duration, device, location.

        Each re-entry comes back as its own row, which is what lets us count
        how many times a learner dropped and rejoined.
        """
        return self._request_paged(
            f"/metrics/meetings/{meeting_id}/participants",
            {"type": "past", "include_fields": "registrant_id"},
        )

    def get_participants_qos(self, meeting_id):
        """Quality of service, used to infer whether the camera was on.

        Zoom has no API that reports camera state. It does report video input
        statistics, and a participant who never sent video has no meaningful
        video input figures. That inference is what we store, and it can be
        overridden by hand on the attendance line.
        """
        return self._request_paged(
            f"/metrics/meetings/{meeting_id}/participants/qos",
            {"type": "past"},
        )
