from odoo import models, fields, api, _


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    dhb_zoom_account_id = fields.Char(
        string="Zoom Account ID",
        config_parameter="dhb_zoom.account_id",
    )
    dhb_zoom_client_id = fields.Char(
        string="Zoom Client ID",
        config_parameter="dhb_zoom.client_id",
    )
    dhb_zoom_client_secret = fields.Char(
        string="Zoom Client Secret",
        config_parameter="dhb_zoom.client_secret",
    )

    def action_test_zoom_connection(self):
        self.ensure_one()
        # Save first, so the test uses whatever is on screen.
        self.execute()
        info = self.env["dhb.zoom.api"].test_connection()
        message = _(
            "Connected to Zoom as %(name)s (%(email)s), account type %(type)s.",
            name=" ".join(filter(None, [info.get("first_name"), info.get("last_name")])) or "-",
            email=info.get("email") or "-",
            type=info.get("type") or "-",
        )
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Zoom connection"),
                "message": message,
                "type": "success",
                "sticky": False,
            },
        }
