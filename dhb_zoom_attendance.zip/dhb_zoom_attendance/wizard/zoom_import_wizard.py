from datetime import datetime, timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbZoomImportWizard(models.TransientModel):
    """Fetch past Zoom meetings for a date range and number them as lectures.

    Entering thirty meeting IDs by hand for every cohort is where mistakes get
    made. This lists what Zoom actually has, lets the user tick the ones that
    belong to the cohort, and numbers them by date.
    """

    _name = "dhb.zoom.import.wizard"
    _description = "Import Zoom meetings as lectures"

    event_id = fields.Many2one("event.event", string="Cohort", required=True)
    zoom_user = fields.Char(
        string="Zoom host", default="me",
        help="Leave as 'me' for the account owner, or enter the host's Zoom "
             "user ID or email.",
    )
    date_from = fields.Date(
        string="From", required=True,
        default=lambda self: fields.Date.today() - timedelta(days=30),
    )
    date_to = fields.Date(string="To", required=True, default=fields.Date.today)
    start_number = fields.Integer(
        string="First lecture number", default=1,
        help="Meetings are numbered from here, in date order.",
    )
    name_filter = fields.Char(
        string="Topic contains",
        help="Optional. Narrows the list to meetings whose topic matches.",
    )
    line_ids = fields.One2many(
        "dhb.zoom.import.line", "wizard_id", string="Meetings found"
    )

    def action_fetch(self):
        self.ensure_one()
        if self.date_from > self.date_to:
            raise UserError(_("The start date is after the end date."))
        if (self.date_to - self.date_from).days > 180:
            raise UserError(_(
                "Zoom only keeps dashboard data for six months, so a wider "
                "range will not return more."
            ))

        meetings = self.env["dhb.zoom.api"].list_user_meetings(
            self.zoom_user or "me", self.date_from, self.date_to
        )

        existing = set(self.event_id.zoom_session_ids.mapped("zoom_meeting_id"))
        needle = (self.name_filter or "").strip().lower()

        rows = []
        for meeting in meetings:
            topic = meeting.get("topic") or ""
            if needle and needle not in topic.lower():
                continue
            meeting_id = str(meeting.get("id") or "")
            if not meeting_id:
                continue
            start_raw = meeting.get("start_time") or ""
            try:
                start = datetime.strptime(start_raw, "%Y-%m-%dT%H:%M:%SZ")
            except ValueError:
                start = False
            rows.append((0, 0, {
                "zoom_meeting_id": meeting_id,
                "topic": topic,
                "start_time": start,
                "duration_minutes": meeting.get("duration") or 0,
                "participant_count": meeting.get("participants_count") or 0,
                "already_linked": meeting_id in existing,
                "selected": meeting_id not in existing,
            }))

        rows.sort(key=lambda row: row[2].get("start_time") or datetime.min)
        self.line_ids = [(5, 0, 0)] + rows

        if not rows:
            raise UserError(_(
                "Zoom returned no meetings for that host and date range. Check "
                "the host, and remember that meetings older than six months "
                "are gone from the dashboard."
            ))
        return self._reopen()

    def action_create_sessions(self):
        self.ensure_one()
        chosen = self.line_ids.filtered(lambda l: l.selected and not l.already_linked)
        if not chosen:
            raise UserError(_("Nothing is ticked."))

        Session = self.env["dhb.zoom.session"]
        number = self.start_number or 1
        created = Session.browse()
        for line in chosen.sorted(key=lambda l: l.start_time or datetime.min):
            created |= Session.create({
                "event_id": self.event_id.id,
                "lecture_number": number,
                "zoom_meeting_id": line.zoom_meeting_id,
                "topic": line.topic,
                "start_time": line.start_time,
                "session_date": line.start_time.date() if line.start_time else False,
                "duration_minutes": line.duration_minutes,
            })
            number += 1

        return {
            "type": "ir.actions.act_window",
            "name": _("Zoom sessions"),
            "res_model": "dhb.zoom.session",
            "view_mode": "list,form",
            "domain": [("id", "in", created.ids)],
        }

    def _reopen(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }


class DhbZoomImportLine(models.TransientModel):
    _name = "dhb.zoom.import.line"
    _description = "Zoom meeting found by the import wizard"
    _order = "start_time"

    wizard_id = fields.Many2one("dhb.zoom.import.wizard", ondelete="cascade")
    selected = fields.Boolean(string="Import", default=True)
    zoom_meeting_id = fields.Char(string="Meeting ID", readonly=True)
    topic = fields.Char(string="Topic", readonly=True)
    start_time = fields.Datetime(string="Start (UTC)", readonly=True)
    duration_minutes = fields.Integer(string="Minutes", readonly=True)
    participant_count = fields.Integer(string="Participants", readonly=True)
    already_linked = fields.Boolean(string="Already linked", readonly=True)
