{
    "name": "DHB Zoom Attendance",
    "version": "19.0.1.0.5",
    "summary": "Pull detailed per-lecture attendance from Zoom into event registrations",
    "description": """
DHB Zoom Attendance
===================

Pulls per-participant attendance detail from the Zoom Dashboard API into Odoo,
one line per learner per lecture.

Why this exists: Odoo's Events app stores a single `attended` flag per
registration, which suits a one-day event. A NEBOSH Diploma cohort runs 30
lectures and the awarding body asks for join time, leave time, duration and
re-entry count for each one.

Zoom Dashboard data is only available for the last six months, so Odoo is the
permanent archive.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["event", "contacts", "mail"],
    "data": [
        "security/security_groups.xml",
        "security/ir.model.access.csv",
        "data/ir_cron.xml",
        "views/zoom_session_views.xml",
        "views/attendance_views.xml",
        "wizard/zoom_import_wizard_views.xml",
        "views/event_views.xml",
        "views/res_config_settings_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
