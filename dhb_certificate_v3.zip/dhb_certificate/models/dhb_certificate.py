"""Certificates: the award, and the journey of the paper that proves it.

Three awarding bodies, three different flows, and the differences are not
cosmetic - they decide who pays, when the centre may order, and what the
office is waiting for:

  NEBOSH  The certificate is inside the course fee. On a pass NEBOSH prints
          it and ships it to the centre by DHL without being asked. The
          centre then tells the learner and usually sends it on by Aramex.
          Nothing is ordered and nothing is charged.

  IOSH    The electronic certificate is inside the course fee. A paper copy
          is issued only if the learner asks, and then the learner pays for
          the issue and the shipping - IOSH to the centre, centre to the
          learner.

  DHB     Our own. We produce it ourselves, so there is nothing to wait for,
          nothing to order and nothing to pay. It carries a verification
          code instead, because a certificate nobody can check is a
          certificate an employer cannot trust.

One record per award. The paper's movements - the DHL parcel in, the Aramex
parcel out, the copy that went missing and was sent again - are separate
records, because a certificate that is re-sent is one certificate and two
journeys. Writing the courier and the tracking number onto the certificate
itself works exactly once, and the second time it erases the first.
"""

import secrets

from datetime import timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


# How long a certificate may sit at the centre before somebody is told to
# chase the learner. Certificates are not ours to store; an uncollected one
# is a learner who has not been reached, not a filing problem.
UNCOLLECTED_DAYS = 30

# A parcel that has been in the courier's hands longer than this has almost
# certainly gone wrong. Aramex inside the Gulf is two to four days.
IN_TRANSIT_DAYS = 14

# A paper copy asked for, invoiced, and then forgotten by everybody.
UNPAID_DAYS = 7


class DhbCertificate(models.Model):
    _name = "dhb.certificate"
    _description = "Certificate"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date_awarded desc, id desc"
    _rec_name = "name"

    name = fields.Char(
        string="Reference", required=True, copy=False, readonly=True,
        default=lambda self: _("New"),
        help="Ours, not the awarding body's. It identifies this record even "
             "before the awarding body has issued a number of its own.",
    )
    active = fields.Boolean(default=True)

    partner_id = fields.Many2one(
        "res.partner", string="Learner", required=True, index=True,
        tracking=True, ondelete="restrict",
    )
    event_id = fields.Many2one(
        "dhb.batch", string="Batch", index=True, tracking=True,
        ondelete="restrict",
        help="The cohort the learner sat with. It is what makes a parcel of "
             "forty certificates sortable.",
    )
    course_id = fields.Many2one(
        "dhb.course", string="Course", index=True, tracking=True)
    qualification_id = fields.Many2one(
        "dhb.qualification", string="Qualification", index=True,
        tracking=True,
        help="What was awarded. The certificate says this, not the course - "
             "the same qualification delivered in two languages produces one "
             "certificate, not two different ones.")

    # Stored rather than related, and for the same reason the course carries
    # its own copy: the body decides the whole flow below, and a related
    # field recomputed at the wrong moment would move a certificate from one
    # flow to another silently.
    awarding_body = fields.Selection(
        [
            ("nebosh", "NEBOSH"),
            ("iosh", "IOSH"),
            ("dhb", "DHB - our own"),
            ("other", "Other"),
        ],
        string="Awarded by", required=True, default="nebosh", index=True,
        tracking=True,
    )

    issue_type = fields.Selection(
        [
            ("electronic", "Electronic"),
            ("paper", "Paper"),
        ],
        string="Issued as", required=True, default="paper", tracking=True,
        help="What the learner is actually getting. NEBOSH issues paper and "
             "IOSH issues electronic; a paper IOSH copy is asked for with "
             "the button and is charged for.",
    )

    certificate_number = fields.Char(
        string="Certificate number", copy=False, tracking=True,
        help="The number printed by the awarding body. Blank until it "
             "arrives - it is not ours to invent.",
    )
    date_awarded = fields.Date(
        string="Awarded on", tracking=True,
        default=fields.Date.context_today,
        help="The date the qualification was achieved, which is the date "
             "printed on the certificate - not the date it reached us.",
    )
    date_at_centre = fields.Date(
        string="Arrived at the centre", readonly=True, copy=False,
        tracking=True)
    date_delivered = fields.Date(
        string="Reached the learner", readonly=True, copy=False,
        tracking=True)

    # ------------------------------------------------------------------
    # One state field, and it tracks the paper rather than the award. The
    # award itself is a fact with a date on it; what an office actually
    # needs to know every morning is where the paper has got to.
    #
    # Different bodies join this line at different points, which is why it
    # is written as one sequence rather than three: NEBOSH starts at
    # "waiting" and jumps to "at the centre" when the DHL parcel lands; IOSH
    # goes straight to "sent electronically" and only enters the middle of
    # the line if a paper copy is asked for; ours is produced here and
    # emailed.
    state = fields.Selection(
        [
            ("pending", "Waiting for the certificate"),
            ("electronic", "Sent electronically"),
            ("requested", "Paper copy requested"),
            ("ordered", "Ordered from the awarding body"),
            ("at_centre", "At the centre"),
            ("notified", "Learner told it is ready"),
            ("in_transit", "On its way to the learner"),
            ("delivered", "With the learner"),
            ("lost", "Lost"),
            ("cancelled", "Cancelled"),
        ],
        default="pending", required=True, index=True, tracking=True,
    )

    # ------------------------------------------------------------------
    # The money, and only for the case that has any: a paper copy asked for
    # from IOSH. Everything else is inside the course fee and must show
    # nothing at all here, or somebody will eventually invoice a learner for
    # a NEBOSH certificate they have already paid for.
    fee_issue = fields.Monetary(
        string="Issue fee", tracking=True,
        help="What the awarding body charges to issue the paper copy.")
    fee_shipping = fields.Monetary(
        string="Shipping fee", tracking=True,
        help="Awarding body to the centre, and the centre to the learner.")
    fee_total = fields.Monetary(
        string="Total charged", compute="_compute_fee_total", store=True)
    currency_id = fields.Many2one(
        "res.currency", default=lambda self: self.env.company.currency_id,
        required=True)
    invoice_id = fields.Many2one(
        "account.move", string="Invoice", copy=False, readonly=True,
        tracking=True)
    invoice_state = fields.Selection(
        related="invoice_id.payment_state", string="Payment", readonly=True)

    # ------------------------------------------------------------------
    # Ours only. A DHB certificate has no awarding body behind it to
    # confirm it, so it carries its own check: a code on the page and a
    # public page that confirms it. Without one, our certificate is a PDF
    # anybody can edit in a browser.
    verification_code = fields.Char(
        string="Verification code", copy=False, readonly=True, index=True)
    verification_url = fields.Char(
        compute="_compute_verification_url", string="Verification link")

    movement_ids = fields.One2many(
        "dhb.certificate.movement", "certificate_id", string="Movements")
    movement_count = fields.Integer(compute="_compute_movement_count")

    # What the reminders read, and what the list colours itself by.
    days_waiting = fields.Integer(
        compute="_compute_days_waiting", string="Days in this state")

    note = fields.Text(string="Internal notes")

    _unique_reference = models.Constraint(
        "unique(name)", "That certificate reference is already used.")

    # ==================================================================
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "dhb.certificate") or _("New")
        certificates = super().create(vals_list)
        for certificate, vals in zip(certificates, vals_list):
            certificate._sync_from_course(skip=set(vals))
        return certificates

    def write(self, vals):
        result = super().write(vals)
        if "course_id" in vals:
            self._sync_from_course(skip=set(vals) - {"course_id"})
        return result

    def _sync_from_course(self, skip=()):
        """Fill the qualification and the awarding body from the course.

        `skip` is what the caller set explicitly in this same create or
        write, and it wins. Without it the sync is not a default at all: it
        is an overwrite that silently discards what a person asked for, and
        the chatter records the discarded value as though they had typed it.

        Testing "is it empty?" instead would not work here either, because
        awarding_body is required with a default - it is never empty, so the
        sync would never fire and an IOSH course would produce a NEBOSH
        certificate.
        """
        for certificate in self:
            course = certificate.course_id
            if not course:
                continue
            if course.qualification_id and "qualification_id" not in skip:
                certificate.qualification_id = course.qualification_id
            if course.awarding_body and "awarding_body" not in skip:
                certificate.awarding_body = course.awarding_body

    @api.onchange("event_id")
    def _onchange_event_id(self):
        if self.event_id and self.event_id.course_id:
            self.course_id = self.event_id.course_id

    @api.onchange("course_id")
    def _onchange_course_id(self):
        self._sync_from_course()
        # IOSH is electronic unless somebody asks otherwise; the other two
        # are paper. Set rather than suggested, because the default that is
        # wrong three times out of four is the one that gets clicked past.
        if self.awarding_body == "iosh":
            self.issue_type = "electronic"
        elif self.awarding_body in ("nebosh", "dhb"):
            self.issue_type = "paper" if self.awarding_body == "nebosh" \
                else "electronic"

    # ==================================================================
    @api.depends("fee_issue", "fee_shipping")
    def _compute_fee_total(self):
        for certificate in self:
            certificate.fee_total = (certificate.fee_issue or 0.0) + \
                (certificate.fee_shipping or 0.0)

    @api.depends("movement_ids")
    def _compute_movement_count(self):
        for certificate in self:
            certificate.movement_count = len(certificate.movement_ids)

    @api.depends("verification_code")
    def _compute_verification_url(self):
        base = self.env["ir.config_parameter"].sudo().get_param(
            "web.base.url") or ""
        for certificate in self:
            certificate.verification_url = (
                "%s/certificate/%s" % (base, certificate.verification_code)
                if certificate.verification_code else False)

    @api.depends("state", "date_at_centre", "write_date")
    def _compute_days_waiting(self):
        today = fields.Date.context_today(self)
        for certificate in self:
            start = None
            if certificate.state == "at_centre":
                start = certificate.date_at_centre
            elif certificate.write_date:
                start = fields.Date.to_date(certificate.write_date)
            certificate.days_waiting = (today - start).days if start else 0

    # No group_expand on `state`, deliberately. Forcing every one of the ten
    # states to appear draws a board ten columns wide, eight of them empty,
    # with the right-hand ones off the edge of the screen - on the day the
    # app is installed and there is nothing in it at all. The board grows a
    # column when something reaches that state, which is also the only time
    # the column says anything.

    @api.depends("partner_id", "qualification_id")
    def _compute_display_name(self):
        for certificate in self:
            who = certificate.partner_id.display_name or _("Unnamed")
            what = certificate.qualification_id.code or ""
            certificate.display_name = "%s - %s" % (who, what) if what else who

    # ==================================================================
    # The buttons, in the order the office presses them.
    # ==================================================================
    def action_send_electronic(self):
        """The IOSH e-certificate, and our own, handed over by email."""
        for certificate in self:
            if certificate.state not in ("pending", "electronic"):
                raise UserError(_(
                    "%s is already further along than that.")
                    % certificate.display_name)
            certificate.write({
                "issue_type": "electronic",
                "state": "electronic",
                "date_delivered": fields.Date.context_today(certificate),
            })
            certificate.message_post(body=_(
                "Electronic certificate sent to the learner."))

    def action_request_paper(self):
        """A learner has asked for the paper copy IOSH does not include.

        This is the only flow in the module that charges anybody, so it is
        also the only one that raises an invoice. The invoice is left in
        draft: an amount that is going to be asked of a learner should be
        looked at by a person before it is sent.
        """
        for certificate in self:
            if certificate.awarding_body == "nebosh":
                raise UserError(_(
                    "The NEBOSH certificate is inside the course fee and "
                    "arrives on paper without being asked for. There is "
                    "nothing to request and nothing to charge."))
            if certificate.state in ("in_transit", "delivered"):
                raise UserError(_(
                    "%s has already gone to the learner.")
                    % certificate.display_name)
            if not certificate.fee_total:
                raise UserError(_(
                    "Fill in the issue fee and the shipping fee first. A "
                    "paper copy that is requested with no amount on it is a "
                    "cost the centre absorbs without noticing."))
            certificate.issue_type = "paper"
            certificate.state = "requested"
            certificate._create_fee_invoice()

    def _create_fee_invoice(self):
        """A draft invoice for the issue and the shipping.

        Each line carries a product, and that is not decoration. An invoice
        line with no product has no account to post to: Odoo's
        _compute_account_id resolves nothing and the save fails with "Field
        'Account' is required on invoice lines". The admissions module in
        this same database already hit that and refuses to invoice without a
        product configured. Rather than ask for configuration that would be
        forgotten, this module ships its own two service products.
        """
        self.ensure_one()
        if self.invoice_id:
            return self.invoice_id
        lines = []
        if self.fee_issue:
            lines.append((0, 0, {
                "product_id": self.env.ref(
                    "dhb_certificate.product_certificate_issue").id,
                "name": _("Paper certificate - issue fee (%s)")
                        % (self.qualification_id.code or self.awarding_body),
                "quantity": 1,
                "price_unit": self.fee_issue,
            }))
        if self.fee_shipping:
            lines.append((0, 0, {
                "product_id": self.env.ref(
                    "dhb_certificate.product_certificate_shipping").id,
                "name": _("Paper certificate - shipping"),
                "quantity": 1,
                "price_unit": self.fee_shipping,
            }))
        invoice = self.env["account.move"].create({
            "move_type": "out_invoice",
            "partner_id": self.partner_id.id,
            "currency_id": self.currency_id.id,
            "invoice_origin": self.name,
            "invoice_line_ids": lines,
        })
        self.invoice_id = invoice
        self.message_post(body=_(
            "Draft invoice %s raised for the paper copy.") % invoice.name)
        return invoice

    def action_order_from_body(self):
        """Ask the awarding body for the paper copy - once it is paid for.

        The refusal is the point of the button. A centre that orders before
        the learner pays is a centre that pays for certificates learners
        change their mind about, and it finds out months later.
        """
        for certificate in self:
            if certificate.state != "requested":
                raise UserError(_(
                    "%s has not been requested as a paper copy.")
                    % certificate.display_name)
            invoice = certificate.invoice_id
            if not invoice:
                raise UserError(_(
                    "There is no invoice against %s.")
                    % certificate.display_name)
            if invoice.state == "draft":
                raise UserError(_(
                    "The invoice for %s is still a draft. Confirm and send "
                    "it first.") % certificate.display_name)
            if invoice.payment_state not in ("paid", "in_payment"):
                raise UserError(_(
                    "%(name)s has not been paid for yet (%(state)s). The "
                    "copy is ordered once the learner has paid - otherwise "
                    "the centre carries the cost of a copy nobody collects.",
                    name=certificate.display_name,
                    state=invoice.payment_state or _("not paid"),
                ))
            certificate.state = "ordered"

    def action_mark_at_centre(self):
        """The parcel has landed - DHL from NEBOSH, or the IOSH copy."""
        for certificate in self:
            if certificate.state in ("delivered", "cancelled"):
                raise UserError(_(
                    "%s is already finished with.") % certificate.display_name)
            certificate.write({
                "state": "at_centre",
                "date_at_centre": fields.Date.context_today(certificate),
            })

    def action_notify_learner(self):
        """Tell the learner the certificate is here and ask how they want it."""
        for certificate in self:
            if certificate.state != "at_centre":
                raise UserError(_(
                    "%s is not at the centre, so there is nothing to tell "
                    "the learner yet.") % certificate.display_name)
            certificate.state = "notified"
            certificate.message_post(body=_(
                "Learner told the certificate is ready for collection or "
                "shipping."))

    def action_new_movement(self):
        """Record a journey: to us, to the learner, or back again."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Movement of %s") % self.display_name,
            "res_model": "dhb.certificate.movement",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_certificate_id": self.id,
                "default_partner_id": self.partner_id.id,
            },
        }

    def action_open_movements(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Movements of %s") % self.display_name,
            "res_model": "dhb.certificate.movement",
            "view_mode": "list,form",
            "domain": [("certificate_id", "=", self.id)],
            "context": {"default_certificate_id": self.id},
        }

    def action_mark_delivered(self):
        for certificate in self:
            certificate.write({
                "state": "delivered",
                "date_delivered": fields.Date.context_today(certificate),
            })

    def action_mark_lost(self):
        self.write({"state": "lost"})

    def action_cancel(self):
        self.write({"state": "cancelled"})

    def action_back_to_pending(self):
        self.write({"state": "pending"})

    # ------------------------------------------------------------------
    def action_issue_dhb(self):
        """Produce our own certificate: give it a code, then print it.

        The code is issued here rather than on creation on purpose. A code
        that exists before the certificate has been issued is a code that
        can be verified before the learner has earned anything.
        """
        for certificate in self:
            if certificate.awarding_body != "dhb":
                raise UserError(_(
                    "Only our own certificates are produced here. %s is "
                    "awarded by somebody else, and printing our own version "
                    "of it would be a forgery.") % certificate.display_name)
            if not certificate.verification_code:
                certificate.verification_code = \
                    certificate._new_verification_code()
            certificate.state = "electronic"
            certificate.date_delivered = fields.Date.context_today(certificate)
        return self.env.ref(
            "dhb_certificate.action_report_certificate").report_action(self)

    def _new_verification_code(self):
        """A code that cannot be guessed from the one before it.

        The reference (CERT/2026/0007) is ours and is sequential by design -
        0008 follows it, and that is useful. A verification code must be the
        opposite: anybody who can guess one can enumerate every certificate
        the centre has ever issued, read each learner's name and what they
        were awarded, and do it from a public page with no login. So this
        does not come from a sequence. It comes from the system's
        cryptographic random source, and it is checked for a collision
        rather than assumed to be unique.
        """
        self.ensure_one()
        year = (self.date_awarded or fields.Date.context_today(self)).year
        for _attempt in range(10):
            code = "DHB-%s-%s" % (year, secrets.token_hex(5).upper())
            if not self.sudo().search_count([("verification_code", "=", code)]):
                return code
        raise UserError(_(
            "Could not produce a unique verification code. Try again."))

    # ==================================================================
    @api.model
    def _cron_certificate_reminders(self):
        """Three things that go quiet and cost money or goodwill."""
        today = fields.Date.context_today(self)

        uncollected = self.search([
            ("state", "in", ("at_centre", "notified")),
            ("date_at_centre", "<=", today - timedelta(days=UNCOLLECTED_DAYS)),
        ])
        for certificate in uncollected:
            certificate._raise_reminder(_(
                "This certificate has been at the centre since %(date)s - "
                "%(days)s days. The learner has not collected it and has not "
                "asked for it to be sent.",
                date=certificate.date_at_centre,
                days=(today - certificate.date_at_centre).days,
            ))

        stuck = self.search([("state", "=", "in_transit")])
        for certificate in stuck:
            # The empty dates are dropped rather than trusted. date_sent is
            # editable and not required, so one movement with it cleared
            # puts False into this list - and max() on a list of dates and a
            # False raises, which would abort the whole nightly run and
            # silently stop the other two chases below as well.
            sent = [
                date for date in certificate.movement_ids.filtered(
                    lambda m: m.state == "sent").mapped("date_sent") if date
            ]
            if sent and (today - max(sent)).days >= IN_TRANSIT_DAYS:
                certificate._raise_reminder(_(
                    "Sent %(days)s days ago and not recorded as delivered. "
                    "Check the tracking number before the courier's claim "
                    "window closes.",
                    days=(today - max(sent)).days,
                ))

        unpaid = self.search([
            ("state", "=", "requested"),
            ("invoice_id", "!=", False),
            ("write_date", "<=", today - timedelta(days=UNPAID_DAYS)),
        ])
        for certificate in unpaid:
            if certificate.invoice_id.payment_state in ("paid", "in_payment"):
                continue
            certificate._raise_reminder(_(
                "A paper copy was requested and the invoice is still "
                "unpaid. Nothing has been ordered from the awarding body."))

    def _raise_reminder(self, body):
        """One open activity per certificate, never a second.

        A cron that files a new activity every night turns a reminder into
        wallpaper, and the day it matters nobody is reading it.
        """
        self.ensure_one()
        existing = self.env["mail.activity"].search_count([
            ("res_model", "=", self._name),
            ("res_id", "=", self.id),
            ("activity_type_id", "=", self.env.ref("mail.mail_activity_data_todo").id),
        ])
        if existing:
            return
        user = self.env.user
        if self.event_id and self.event_id.user_id:
            user = self.event_id.user_id
        self.activity_schedule(
            "mail.mail_activity_data_todo",
            summary=_("Certificate: %s") % self.partner_id.display_name,
            note=body,
            user_id=user.id,
        )
