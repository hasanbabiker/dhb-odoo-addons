{
    "name": "DHB Partner Centres",
    "version": "19.0.1.0.1",
    "summary": "Training centres delivering under DHB's accreditation: each "
               "sees only its own learners, DHB sees and signs off on all",
    "description": """
DHB Partner Centres
===================

Other centres run courses under DHB's NEBOSH Learning Partner number. Their
learners have to live in this database, because the accreditation answering
for those learners is DHB's. What has to be separated is not the books but
the view: a partner must see their own learners and nothing else, and must
never learn that the other centres exist.

So:

* A centre record, with its staff, its agreement dates and who invoices.
* A centre stamped automatically on every learner, application, cohort,
  intake and place, taken from whoever created it. Nobody types it, so
  nobody forgets it.
* Record rules at the database level, scoped to the partner group alone.
  Not a filter on a screen: a partner cannot reach another centre's learner
  by changing a domain, guessing a URL or exporting.
* DHB's conditions, checked on every learner a partner puts forward, and
  counted per centre so a partner falling behind is visible before it
  becomes an audit finding.
* A gate on NEBOSH entry. A partner prepares everything and asks; only DHB
  signs. No name goes to NEBOSH under DHB's number without a DHB manager
  having looked at the record.

The partner is not slowed down — they do every step up to the last press.
DHB is simply never surprised by a learner it has not seen.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["dhb_admission", "dhb_registration", "dhb_learner", "event"],
    "data": [
        "security/centre_groups.xml",
        "security/ir.model.access.csv",
        "views/partner_centre_views.xml",
        "views/invite_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
