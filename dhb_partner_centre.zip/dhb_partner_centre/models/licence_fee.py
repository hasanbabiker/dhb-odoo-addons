from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError

PRODUCT_XMLID = "dhb_partner_centre.product_centre_user_licence"


class PartnerCentreLicence(models.Model):
    """What the partner pays DHB for access to this system.

    Charged per user account the centre holds, once a year.

    The number billed is the highest the centre reached during the year, not
    the number on the day the invoice is written. Billing the closing figure
    invites the obvious: add ten accounts in January, take them out in
    December, pay for none of them. Worse, nobody would ever know it
    happened. The high-water mark is recorded as it moves, with the date it
    moved, so the invoice can say where the number came from.
    """

    _inherit = "dhb.partner.centre"

    currency_id = fields.Many2one(
        "res.currency", string="Currency",
        default=lambda self: self.env.company.currency_id,
    )
    user_fee = fields.Monetary(
        string="Fee per user account, per year", tracking=True,
        help="What the centre pays for each staff account it holds on this "
             "system, for a year.",
    )

    period_start = fields.Date(
        string="Billing year began", tracking=True,
        help="The high-water mark below is counted from this date. It is "
             "reset each time a licence invoice is issued.",
    )
    next_billing_date = fields.Date(
        string="Next invoice due", compute="_compute_next_billing_date",
        store=True,
    )

    peak_user_count = fields.Integer(
        string="Most accounts held this year", readonly=True, tracking=True,
        help="The highest number of user accounts this centre has held since "
             "the billing year began. This is the number invoiced.",
    )
    peak_user_date = fields.Date(
        string="Reached on", readonly=True,
        help="Kept so the invoice can be explained if the centre disputes "
             "the number.",
    )

    licence_invoice_ids = fields.One2many(
        "account.move", "dhb_licence_centre_id", string="Licence invoices",
    )
    licence_invoice_count = fields.Integer(
        compute="_compute_licence_invoice_count",
    )

    # ------------------------------------------------------------------
    @api.depends("period_start", "agreement_start")
    def _compute_next_billing_date(self):
        for centre in self:
            start = centre.period_start or centre.agreement_start
            centre.next_billing_date = \
                start + relativedelta(years=1) if start else False

    def _compute_licence_invoice_count(self):
        for centre in self:
            centre.licence_invoice_count = len(centre.licence_invoice_ids)

    # ------------------------------------------------------------------
    def _refresh_peak_users(self):
        """Raise the high-water mark if the centre now holds more accounts.

        Called whenever a user is created, changed or archived, and again by
        a daily job. The immediate call is what makes the figure honest: a
        daily job alone would miss an account that was added and removed
        between two runs.
        """
        today = fields.Date.today()
        for centre in self:
            current = len(centre.user_ids)
            if not centre.period_start:
                centre.period_start = centre.agreement_start or today
            if current > centre.peak_user_count:
                centre.write({
                    "peak_user_count": current,
                    "peak_user_date": today,
                })
                centre.message_post(body=_(
                    "User accounts reached %(count)s, the most this billing "
                    "year. This is the figure the next licence invoice will "
                    "use.", count=current))

    @api.model
    def _cron_refresh_peak_users(self):
        self.search([("active", "=", True)])._refresh_peak_users()

    @api.model
    def _cron_bill_due_licences(self):
        """Draft the invoice on the day it falls due - never send it.

        A draft asks somebody to look before a partner is charged. A system
        that posts and emails an invoice on its own gets one number wrong and
        the first to notice is the customer.
        """
        today = fields.Date.today()
        due = self.search([
            ("active", "=", True),
            ("user_fee", ">", 0),
            ("next_billing_date", "<=", today),
        ])
        due._refresh_peak_users()
        for centre in due:
            try:
                centre.action_bill_licence()
            except UserError as error:
                centre.message_post(body=_(
                    "The licence invoice could not be drafted: %s", error))

    # ------------------------------------------------------------------
    def action_bill_licence(self):
        self.ensure_one()
        self._refresh_peak_users()

        if not self.partner_id:
            raise UserError(_(
                "%s has no contact to invoice. Set one on the centre first.")
                % self.display_name)
        if self.user_fee <= 0:
            raise UserError(_(
                "%s has no fee per user account set, so there is nothing to "
                "invoice.") % self.display_name)

        quantity = max(self.peak_user_count, len(self.user_ids))
        if quantity <= 0:
            raise UserError(_(
                "%s holds no user accounts, so there is nothing to invoice.")
                % self.display_name)

        product = self.env.ref(PRODUCT_XMLID, raise_if_not_found=False)
        if not product:
            raise UserError(_(
                "The licence product is missing. Reinstall or upgrade the "
                "Partner Centres module to restore it."))

        today = fields.Date.today()
        period_from = self.period_start or self.agreement_start or today
        description = _(
            "System access for %(count)s user accounts\n"
            "%(start)s to %(end)s\n"
            "Charged on the most accounts held in the period, reached on "
            "%(peak_date)s.",
            count=quantity,
            start=period_from,
            end=today,
            peak_date=self.peak_user_date or today,
        )

        invoice = self.env["account.move"].create({
            "move_type": "out_invoice",
            "partner_id": self.partner_id.id,
            "invoice_date": today,
            "invoice_origin": self.display_name,
            "currency_id": self.currency_id.id or self.env.company.currency_id.id,
            "dhb_licence_centre_id": self.id,
            "invoice_line_ids": [(0, 0, {
                "product_id": product.id,
                "name": description,
                "quantity": quantity,
                "price_unit": self.user_fee,
            })],
        })

        # The new year starts now, from what the centre holds today - not
        # from the peak just billed, or the centre would pay next year for
        # accounts it has already closed.
        self.write({
            "period_start": today,
            "peak_user_count": len(self.user_ids),
            "peak_user_date": today,
        })
        self.message_post(body=_(
            "Licence invoice drafted for %(count)s user accounts.",
            count=quantity))

        return {
            "type": "ir.actions.act_window",
            "res_model": "account.move",
            "res_id": invoice.id,
            "view_mode": "form",
        }

    def action_open_licence_invoices(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Licence invoices - %s") % self.display_name,
            "res_model": "account.move",
            "view_mode": "list,form",
            "domain": [("dhb_licence_centre_id", "=", self.id)],
            "context": {"default_dhb_licence_centre_id": self.id},
        }


class AccountMove(models.Model):
    """So a licence invoice can be traced back to the centre it billed."""

    _inherit = "account.move"

    dhb_licence_centre_id = fields.Many2one(
        "dhb.partner.centre", string="Partner centre licence",
        index=True, copy=False, readonly=True,
    )


class ResUsersLicence(models.Model):
    """Catch the count the moment it changes, not a day later."""

    _inherit = "res.users"

    @api.model_create_multi
    def create(self, vals_list):
        users = super().create(vals_list)
        users.partner_centre_id._refresh_peak_users()
        return users

    def write(self, values):
        before = self.partner_centre_id
        result = super().write(values)
        (before | self.partner_centre_id)._refresh_peak_users()
        return result
