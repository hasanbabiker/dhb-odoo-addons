from odoo import models, fields, api, _


class CentreCompliance(models.Model):
    """DHB's conditions, checked on every learner a partner puts forward.

    The partner runs the course; the accreditation is DHB's. So "did they do
    it properly" cannot be a matter of trust or of asking — it has to be a
    list the system checks itself, on every learner, all the time, and shows
    without anybody requesting a report.

    Each condition is something an awarding body would ask to see.
    """

    _inherit = "dhb.registration.invite"

    centre_compliance_ok = fields.Boolean(
        string="Meets DHB's conditions", compute="_compute_centre_compliance",
        store=True, index=True,
    )
    centre_compliance_missing = fields.Text(
        string="What is missing", compute="_compute_centre_compliance",
        store=True,
    )

    @api.depends("state", "declaration_state", "policy_acceptance_count",
                 "amount_outstanding", "lms_state", "partner_id",
                 "partner_id.id_document_file", "partner_id.date_of_birth",
                 "partner_id.nebosh_learner_number")
    def _compute_centre_compliance(self):
        for application in self:
            missing = application._centre_missing_conditions()
            application.centre_compliance_missing = "\n".join(missing) or False
            application.centre_compliance_ok = not missing

    def _centre_missing_conditions(self):
        """Written as one method so the list is the same everywhere.

        The screen, the report and the NEBOSH gate all read this. If they
        each had their own idea of "complete", a learner could pass the gate
        and still show as incomplete on the dashboard.
        """
        self.ensure_one()
        if self.state not in ("accepted", "enrolled"):
            return []

        partner = self.partner_id
        missing = []

        if not partner:
            return [_("No learner is attached to this application.")]
        if not partner.legal_name and not partner.name:
            missing.append(_("The learner's full legal name"))
        if not partner.date_of_birth:
            missing.append(_("Date of birth"))
        # The document itself, not its number. DHB does not collect the
        # number, and a condition on data nobody gathers is the policy trap
        # again: every learner fails for ever, for a reason that is not
        # theirs. The registration form refuses to submit without the
        # document, so this is a condition that can actually be met.
        if not partner.id_document_file:
            missing.append(_("A copy of the identity document"))
        if self.declaration_state != "signed":
            missing.append(_("The signed learner declaration"))
        # Only when policies exist to be accepted. Left unconditional, a
        # centre with no policies published could never have a compliant
        # learner, so no partner learner could ever be signed off for
        # NEBOSH — a gate nobody could open, for a reason nobody caused.
        if not self.policy_acceptance_count and self._required_policy_count():
            missing.append(_("Acceptance of the centre's policies"))
        if self.amount_outstanding > 0:
            missing.append(_("The fee is not settled in full"))
        if self.state == "enrolled" and self.lms_state != "released":
            missing.append(_("Access to the learning platform"))
        return missing

    # ------------------------------------------------------------------
    def action_open_compliance(self):
        """Used from the centre dashboard, so the reason travels with it."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.registration.invite",
            "res_id": self.id,
            "view_mode": "form",
        }
