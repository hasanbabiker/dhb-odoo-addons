from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

CENTRE_GROUP = "dhb_partner_centre.group_dhb_centre_user"


class ResUsers(models.Model):
    """Which centre a person works for, and the rule that keeps it honest."""

    _inherit = "res.users"

    partner_centre_id = fields.Many2one(
        "dhb.partner.centre", string="Partner centre", index=True,
        help="Set this and the person sees only that centre's learners. "
             "Leave it empty for DHB's own staff, who see everything.",
    )

    # Odoo 19 renamed res.users.groups_id to group_ids. A @api.constrains on
    # a field name that no longer exists fails at registry load, so this is
    # not cosmetic.
    @api.constrains("partner_centre_id", "group_ids")
    def _check_centre_membership(self):
        """A centre user without a centre would see the wrong rows.

        The isolation rule reads the user's centre. A member of staff put in
        the partner group and left without a centre would match records whose
        centre is empty — which is DHB's own work. Better to refuse the save
        than to discover it from a partner's screen.
        """
        for user in self:
            if not user.has_group(CENTRE_GROUP):
                continue
            if not user.partner_centre_id:
                raise ValidationError(_(
                    "%s is in the Partner centre staff group but has no "
                    "centre. Give them one, or take them out of the group."
                ) % user.name)

    def _is_dhb_staff(self):
        """DHB's own people: no centre of their own."""
        self.ensure_one()
        return not self.partner_centre_id
