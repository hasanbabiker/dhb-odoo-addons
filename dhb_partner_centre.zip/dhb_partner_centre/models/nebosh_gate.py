from odoo import models, fields, api, _
from odoo.exceptions import UserError

MANAGER_GROUP = "dhb_zoom_attendance.group_dhb_attendance_manager"
CENTRE_GROUP = "dhb_partner_centre.group_dhb_centre_user"


class NeboshGate(models.Model):
    """The one step a partner cannot take on their own.

    A partner may run the course, take the fee, teach the units and chase
    the paperwork. What they may not do is put a name in front of NEBOSH,
    because that name goes in under DHB's Learning Partner number and it is
    DHB's accreditation that answers for it.

    So the partner prepares and asks; DHB looks and signs. The partner is
    not slowed down — they do everything up to the last press — and DHB is
    never surprised by a learner it has not seen.
    """

    _inherit = "dhb.registration.invite"

    dhb_review_state = fields.Selection(
        [
            ("none", "Not requested"),
            ("requested", "Waiting on DHB"),
            ("approved", "Signed off"),
            ("returned", "Sent back"),
        ],
        string="DHB sign-off", default="none", required=True,
        tracking=True, index=True, copy=False,
    )
    dhb_review_requested_on = fields.Datetime(readonly=True, copy=False)
    dhb_review_requested_by = fields.Many2one(
        "res.users", readonly=True, copy=False)
    dhb_reviewed_on = fields.Datetime(readonly=True, copy=False)
    dhb_reviewed_by = fields.Many2one("res.users", readonly=True, copy=False)
    dhb_review_note = fields.Text(
        string="DHB's note",
        help="Why it was sent back, or what the sign-off was conditional on.",
    )

    needs_dhb_signoff = fields.Boolean(
        string="Needs DHB sign-off", compute="_compute_needs_dhb_signoff",
        store=True, index=True,
    )

    # ------------------------------------------------------------------
    @api.depends("partner_centre_id", "state", "nebosh_entry_done",
                 "dhb_review_state")
    def _compute_needs_dhb_signoff(self):
        for application in self:
            application.needs_dhb_signoff = bool(
                application.partner_centre_id
                and application.state in ("accepted", "enrolled")
                and not application.nebosh_entry_done
                and application.dhb_review_state != "approved"
            )

    # ------------------------------------------------------------------
    def action_request_dhb_review(self):
        """The partner says: this one is ready, please look."""
        for application in self:
            if not application.partner_centre_id:
                raise UserError(_(
                    "This is DHB's own application; there is nobody to ask."))
            missing = application._centre_missing_conditions()
            if missing:
                raise UserError(_(
                    "This learner does not meet DHB's conditions yet:\n\n%s\n\n"
                    "Finish these first. Asking for sign-off on an incomplete "
                    "record only sends it back."
                ) % "\n".join("• %s" % line for line in missing))
            application.write({
                "dhb_review_state": "requested",
                "dhb_review_requested_on": fields.Datetime.now(),
                "dhb_review_requested_by": self.env.user.id,
            })
            application.message_post(body=_(
                "<strong>%s asked DHB to sign this learner off for NEBOSH "
                "entry.</strong>"
            ) % (application.partner_centre_id.name or self.env.user.name))
        return True

    def action_dhb_approve(self):
        """DHB looks and signs. Only DHB."""
        self._assert_dhb()
        for application in self:
            missing = application._centre_missing_conditions()
            if missing:
                raise UserError(_(
                    "Not yet. This learner is still missing:\n\n%s"
                ) % "\n".join("• %s" % line for line in missing))
            application.write({
                "dhb_review_state": "approved",
                "dhb_reviewed_on": fields.Datetime.now(),
                "dhb_reviewed_by": self.env.user.id,
            })
            application.message_post(body=_(
                "<strong>Signed off by DHB.</strong> This learner may now be "
                "entered with NEBOSH."))
        return True

    def action_dhb_return(self):
        """Send it back, with the reason. A bare refusal teaches nobody."""
        self._assert_dhb()
        for application in self:
            if not (application.dhb_review_note or "").strip():
                raise UserError(_(
                    "Write what is wrong in DHB's note first. A record sent "
                    "back without a reason comes straight back unchanged."))
            application.write({
                "dhb_review_state": "returned",
                "dhb_reviewed_on": fields.Datetime.now(),
                "dhb_reviewed_by": self.env.user.id,
            })
            application.message_post(body=_(
                "<strong>Sent back by DHB.</strong><br/>%s"
            ) % application.dhb_review_note)
        return True

    # ------------------------------------------------------------------
    def _assert_dhb(self):
        if not self.env.user.has_group(MANAGER_GROUP) \
                or self.env.user.partner_centre_id:
            raise UserError(_(
                "Only a DHB manager can sign a learner off for NEBOSH entry. "
                "This is what keeps DHB's accreditation answerable for every "
                "name submitted under it."))
        return True

    def action_mark_nebosh_entered(self):
        """The gate. A partner's learner passes only with DHB's signature."""
        for application in self:
            if application.partner_centre_id:
                if self.env.user.partner_centre_id:
                    raise UserError(_(
                        "Entering a learner with NEBOSH is DHB's step, not "
                        "the centre's. Press \"Ask DHB to sign off\" and DHB "
                        "will do it once they have checked the record."))
                if application.dhb_review_state != "approved":
                    raise UserError(_(
                        "%s has not been signed off yet. Sign it off first — "
                        "that is the check the accreditation rests on."
                    ) % (application.partner_id.display_name
                         or application.name))
        return super().action_mark_nebosh_entered()
