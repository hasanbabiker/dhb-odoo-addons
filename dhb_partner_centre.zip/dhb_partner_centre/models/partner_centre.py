from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbPartnerCentre(models.Model):
    """A training centre running courses under DHB's accreditation.

    Not a company and not a separate Learning Partner. NEBOSH knows one
    number — DHB's — and everything these centres deliver is delivered in
    DHB's name. That single fact decides the whole design: the data lives in
    one database because the accountability is one centre's, and what
    separates the partners is who may see which rows, not whose books they
    are.
    """

    _name = "dhb.partner.centre"
    _description = "Partner training centre"
    _order = "name"
    _inherit = ["mail.thread"]

    name = fields.Char(required=True, tracking=True)
    code = fields.Char(
        required=True, tracking=True,
        help="Short code used on the learner's record and in reports. "
             "Three or four letters is plenty.",
    )
    partner_id = fields.Many2one(
        "res.partner", string="Contact", tracking=True,
        help="The centre as an organisation: who is billed, who is written "
             "to when something is wrong.",
    )
    active = fields.Boolean(default=True)

    agreement_start = fields.Date(string="Agreement from", tracking=True)
    agreement_end = fields.Date(
        string="Agreement until", tracking=True,
        help="Empty means open-ended. A partnership with no end date should "
             "be a decision somebody took, not one nobody revisited.",
    )
    agreement_live = fields.Boolean(
        string="Agreement in force", compute="_compute_agreement_live",
        store=True,
    )

    user_ids = fields.One2many(
        "res.users", "partner_centre_id", string="Staff",
        help="Everyone at this centre who signs into the system. They see "
             "their own learners and nobody else's.",
    )
    user_count = fields.Integer(compute="_compute_counts")

    invoicing_mode = fields.Selection(
        [
            ("centre", "The centre invoices its own learners"),
            ("dhb", "DHB invoices the learner directly"),
        ],
        string="Who invoices", default="centre", required=True, tracking=True,
        help="Set per centre because the agreements differ. It decides "
             "whether the centre sees fee figures at all.",
    )

    note = fields.Text(string="Notes")

    # --- what the oversight screen counts -------------------------------
    learner_count = fields.Integer(compute="_compute_counts")
    application_count = fields.Integer(compute="_compute_counts")
    compliant_count = fields.Integer(compute="_compute_counts")
    missing_count = fields.Integer(compute="_compute_counts")
    awaiting_dhb_count = fields.Integer(compute="_compute_counts")
    compliance_rate = fields.Float(
        string="Compliant", compute="_compute_counts",
        help="Of the applications that have reached a decision, the share "
             "meeting every one of DHB's conditions. Held as a fraction "
             "because that is what the percentage widget expects.",
    )

    _unique_code = models.Constraint(
        "unique(code)",
        "Another centre already uses that code.",
    )

    # ------------------------------------------------------------------
    @api.depends("agreement_start", "agreement_end", "active")
    def _compute_agreement_live(self):
        today = fields.Date.today()
        for centre in self:
            centre.agreement_live = bool(
                centre.active
                and (not centre.agreement_start or centre.agreement_start <= today)
                and (not centre.agreement_end or centre.agreement_end >= today)
            )

    def _compute_counts(self):
        Invite = self.env["dhb.registration.invite"].sudo()
        Partner = self.env["res.partner"].sudo()
        for centre in self:
            centre.user_count = len(centre.user_ids)
            centre.learner_count = Partner.search_count([
                ("partner_centre_id", "=", centre.id),
                ("is_learner", "=", True),
            ])
            applications = Invite.search([
                ("partner_centre_id", "=", centre.id),
            ])
            centre.application_count = len(applications)

            decided = applications.filtered(
                lambda a: a.state in ("accepted", "enrolled"))
            compliant = decided.filtered(lambda a: a.centre_compliance_ok)
            centre.compliant_count = len(compliant)
            centre.missing_count = len(decided) - len(compliant)
            centre.compliance_rate = (
                len(compliant) / len(decided) if decided else 0.0)
            centre.awaiting_dhb_count = len(applications.filtered(
                lambda a: a.dhb_review_state == "requested"))

    # ------------------------------------------------------------------
    def action_open_applications(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("%s — applications") % self.name,
            "res_model": "dhb.registration.invite",
            "view_mode": "list,form",
            "domain": [("partner_centre_id", "=", self.id)],
            "context": {"default_partner_centre_id": self.id},
        }

    def action_open_missing(self):
        """The learners this centre has not finished properly."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("%s — conditions not met") % self.name,
            "res_model": "dhb.registration.invite",
            "view_mode": "list,form",
            "domain": [
                ("partner_centre_id", "=", self.id),
                ("state", "in", ("accepted", "enrolled")),
                ("centre_compliance_ok", "=", False),
            ],
        }

    def action_open_awaiting(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("%s — waiting on DHB") % self.name,
            "res_model": "dhb.registration.invite",
            "view_mode": "list,form",
            "domain": [
                ("partner_centre_id", "=", self.id),
                ("dhb_review_state", "=", "requested"),
            ],
        }

    def action_open_learners(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("%s — learners") % self.name,
            "res_model": "res.partner",
            "view_mode": "list,form",
            "domain": [
                ("partner_centre_id", "=", self.id),
                ("is_learner", "=", True),
            ],
        }

    # ------------------------------------------------------------------
    def write(self, values):
        if "active" in values and not values["active"]:
            for centre in self:
                if centre.user_ids:
                    raise UserError(_(
                        "%(centre)s still has %(count)s member(s) of staff "
                        "who can sign in. Move or archive their user "
                        "accounts first — archiving the centre alone would "
                        "leave them with a login and no rule deciding what "
                        "they may see."
                    ) % {"centre": centre.name,
                         "count": len(centre.user_ids)})
        return super().write(values)
