"""The public page behind the QR code on our own certificates.

An employer holding a DHB certificate has no awarding body to write to. The
code on the page and this route are what make the document checkable, and
without them our certificate is a PDF anybody can edit in a browser.

Three rules, and each of them is about not turning a verification page into
a leak:

  * It answers about one code at a time, and only a code that is handed to
    it. There is no listing and no search.
  * It says the certificate is valid, who it was awarded to, what for and
    when. Nothing else - no email address, no phone number, no batch, no
    fee. The person checking is usually an employer the learner has chosen
    to show it to, not somebody entitled to the learner's file.
  * A code that does not exist gets the same plain "not found" page as a
    code that has been cancelled, and neither reveals whether the other
    kind exists.
"""

from odoo import http
from odoo.http import request


class CertificateVerification(http.Controller):

    @http.route(
        ["/certificate/<string:code>"],
        type="http", auth="public", website=False, sitemap=False)
    def verify(self, code, **kwargs):
        # sudo() is deliberate and narrow: the page is public by design, and
        # the query is restricted to one exact code with the fields printed
        # chosen by hand below rather than by the reader's access rights.
        certificate = request.env["dhb.certificate"].sudo().search(
            [("verification_code", "=", code)], limit=1)
        valid = bool(certificate) and certificate.state not in (
            "cancelled",) and certificate.active
        return request.render(
            "dhb_certificate.certificate_verification_page",
            {
                "found": valid,
                "code": code,
                "certificate": certificate if valid else False,
            },
        )
