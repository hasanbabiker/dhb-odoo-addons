"""One journey of one certificate.

A certificate can travel more than once: NEBOSH to the centre by DHL, the
centre to the learner by Aramex, and - when a courier loses it - a second
time. Keeping the courier and the tracking number on the certificate itself
works exactly once; the second journey overwrites the first, and the
evidence that the first one happened is gone on the day it is needed.

So a movement is its own record, and the certificate carries a list of them.
"""

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbCertificateMovement(models.Model):
    _name = "dhb.certificate.movement"
    _description = "Certificate movement"
    _inherit = ["mail.thread"]
    _order = "date_sent desc, id desc"

    certificate_id = fields.Many2one(
        "dhb.certificate", string="Certificate", required=True, index=True,
        ondelete="cascade")
    partner_id = fields.Many2one(
        related="certificate_id.partner_id", string="Learner", store=True,
        readonly=True)

    direction = fields.Selection(
        [
            ("inbound", "Awarding body to the centre"),
            ("outbound", "Centre to the learner"),
            ("return", "Back to the centre"),
        ],
        string="Direction", required=True, default="outbound", tracking=True,
    )

    # The couriers actually used, plus the two ways a certificate moves
    # without a courier at all. "Collected in person" is not a courier with
    # no tracking number - it is a different event, and an office that has
    # to pick a courier for it will pick one and then wonder, months later,
    # why Aramex has no record of the parcel.
    carrier = fields.Selection(
        [
            ("dhl", "DHL"),
            ("aramex", "Aramex"),
            ("collected", "Collected in person"),
            ("email", "Email"),
            ("other", "Other"),
        ],
        string="Sent by", required=True, default="aramex", tracking=True,
    )
    tracking_ref = fields.Char(string="Tracking number", tracking=True)
    tracking_url = fields.Char(compute="_compute_tracking_url")

    date_sent = fields.Date(
        string="Sent on", default=fields.Date.context_today, tracking=True)
    date_received = fields.Date(
        string="Received on", tracking=True)
    received_by = fields.Char(
        string="Received by",
        help="Who signed for it. Worth a line when a certificate is handed "
             "to somebody other than the learner.")

    cost = fields.Monetary(string="Cost", tracking=True)
    currency_id = fields.Many2one(
        "res.currency", default=lambda self: self.env.company.currency_id,
        required=True)

    state = fields.Selection(
        [
            ("draft", "Being prepared"),
            ("sent", "On its way"),
            ("received", "Arrived"),
            ("lost", "Lost"),
        ],
        default="draft", required=True, tracking=True, index=True,
    )
    note = fields.Text()

    # ------------------------------------------------------------------
    @api.depends("carrier", "tracking_ref")
    def _compute_tracking_url(self):
        """A link that opens the courier's own page.

        Only for the two couriers the centre actually uses, and only when
        there is a number. A tracking link built from an empty reference
        lands on the courier's error page, which looks like the parcel is
        missing rather than like the field is.
        """
        for movement in self:
            ref = (movement.tracking_ref or "").strip()
            if not ref:
                movement.tracking_url = False
            elif movement.carrier == "dhl":
                movement.tracking_url = (
                    "https://www.dhl.com/ae-en/home/tracking/"
                    "tracking-express.html?submit=1&tracking-id=%s" % ref)
            elif movement.carrier == "aramex":
                movement.tracking_url = (
                    "https://www.aramex.com/ae/en/track/results"
                    "?mode=0&ShipmentNumber=%s" % ref)
            else:
                movement.tracking_url = False

    @api.onchange("direction")
    def _onchange_direction(self):
        # NEBOSH ships to the centre by DHL and the centre ships on by
        # Aramex. Defaulting to what actually happens saves a click on every
        # single record, which over a parcel of forty is forty clicks.
        if self.direction == "inbound":
            self.carrier = "dhl"
        elif self.direction == "outbound":
            self.carrier = "aramex"

    @api.constrains("date_sent", "date_received")
    def _check_dates(self):
        for movement in self:
            if movement.date_sent and movement.date_received and \
                    movement.date_received < movement.date_sent:
                raise UserError(_(
                    "A certificate cannot arrive before it was sent."))

    # ------------------------------------------------------------------
    # The movement drives the certificate's state, rather than the two being
    # kept in step by whoever remembers. An office that has to update both
    # updates one.
    def action_send(self):
        for movement in self:
            movement.write({
                "state": "sent",
                "date_sent": movement.date_sent or
                             fields.Date.context_today(movement),
            })
            if movement.direction == "outbound":
                movement.certificate_id.state = "in_transit"

    def action_receive(self):
        for movement in self:
            movement.write({
                "state": "received",
                "date_received": movement.date_received or
                                 fields.Date.context_today(movement),
            })
            certificate = movement.certificate_id
            if movement.direction == "inbound":
                certificate.write({
                    "state": "at_centre",
                    "date_at_centre": movement.date_received,
                })
            elif movement.direction == "outbound":
                certificate.write({
                    "state": "delivered",
                    "date_delivered": movement.date_received,
                })

    def action_mark_lost(self):
        for movement in self:
            movement.state = "lost"
            movement.certificate_id.state = "lost"

    @api.depends("certificate_id", "carrier", "tracking_ref")
    def _compute_display_name(self):
        for movement in self:
            carrier = dict(
                movement._fields["carrier"].selection).get(movement.carrier, "")
            movement.display_name = "%s %s" % (
                carrier, movement.tracking_ref or "")
