"""Raise the certificates for a whole batch in one pass.

A cohort of forty finishes together and is certificated together. Creating
forty records by hand is how thirty-eight get created and two are found
months later, when the learner writes to ask where theirs is.
"""

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class DhbCertificateBatchWizard(models.TransientModel):
    _name = "dhb.certificate.batch.wizard"
    _description = "Raise certificates for a batch"

    event_id = fields.Many2one(
        "dhb.batch", string="Batch", required=True)
    course_id = fields.Many2one(
        related="event_id.course_id", string="Course", readonly=True)
    awarding_body = fields.Selection(
        related="course_id.awarding_body", string="Awarded by", readonly=True)

    date_awarded = fields.Date(
        string="Awarded on", required=True,
        default=fields.Date.context_today,
        help="The date printed on the certificate. Usually the date of the "
             "result, not today.")
    issue_type = fields.Selection(
        [("electronic", "Electronic"), ("paper", "Paper")],
        string="Issued as", required=True, default="paper")

    # Only those who passed, when the system knows who passed. It does not
    # always: the exam module is optional, and a centre may be recording
    # results outside it. So this is a filter that switches itself off
    # rather than a requirement that blocks the wizard.
    passed_only = fields.Boolean(
        string="Only learners who passed", default=True)
    results_available = fields.Boolean(compute="_compute_results_available")

    line_ids = fields.One2many(
        "dhb.certificate.batch.wizard.line", "wizard_id", string="Learners")
    already_done = fields.Integer(
        compute="_compute_counts", string="Already have one")

    @api.depends_context("uid")
    def _compute_results_available(self):
        available = "dhb.exam.entry" in self.env
        for wizard in self:
            wizard.results_available = available

    @api.depends("line_ids")
    def _compute_counts(self):
        for wizard in self:
            wizard.already_done = len(
                wizard.line_ids.filtered(lambda line: line.has_certificate))

    # ------------------------------------------------------------------
    @api.onchange("event_id", "passed_only")
    def _onchange_event_id(self):
        self.line_ids = [(5, 0, 0)]
        if not self.event_id:
            return
        if self.event_id.course_id and \
                self.event_id.course_id.awarding_body == "iosh":
            self.issue_type = "electronic"

        # active_test off on purpose. A certificate that was archived is
        # still a certificate that was raised; searching with the default
        # hides it, the learner comes back unticked, and a second one is
        # raised under a second reference.
        existing = self.env["dhb.certificate"].with_context(
            active_test=False).search([
                ("event_id", "=", self.event_id.id),
            ]).mapped("partner_id").ids

        passed = self._passed_partner_ids()
        lines = []
        for place in self.event_id.registration_ids:
            if not place.partner_id or place.state == "cancel":
                continue
            if self.passed_only and passed is not None and \
                    place.partner_id.id not in passed:
                continue
            lines.append((0, 0, {
                "partner_id": place.partner_id.id,
                "has_certificate": place.partner_id.id in existing,
                "selected": place.partner_id.id not in existing,
            }))
        self.line_ids = lines

    def _passed_partner_ids(self):
        """Who passed, or None when the system cannot say.

        None and an empty set are different answers and must not be
        confused: None means "no result data exists, so do not filter",
        while an empty set means "results exist and nobody passed". Treating
        the first as the second produces an empty wizard and a user who
        concludes the batch is broken.
        """
        self.ensure_one()
        if "dhb.exam.entry" not in self.env:
            return None
        entries = self.env["dhb.exam.entry"].search([
            ("batch_id", "=", self.event_id.id),
        ])
        if not entries:
            return None
        return set(entries.filtered(
            lambda e: e.outcome == "pass").mapped("partner_id").ids)

    # ------------------------------------------------------------------
    def action_create(self):
        self.ensure_one()
        chosen = self.line_ids.filtered(
            lambda line: line.selected and not line.has_certificate)
        if not chosen:
            raise UserError(_(
                "Nobody is selected who does not already have a certificate "
                "for this batch."))
        certificates = self.env["dhb.certificate"].create([
            {
                "partner_id": line.partner_id.id,
                "event_id": self.event_id.id,
                "course_id": self.course_id.id,
                "date_awarded": self.date_awarded,
                "issue_type": self.issue_type,
            }
            for line in chosen
        ])
        return {
            "type": "ir.actions.act_window",
            "name": _("Certificates for %s") % self.event_id.display_name,
            "res_model": "dhb.certificate",
            "view_mode": "list,form",
            "domain": [("id", "in", certificates.ids)],
        }


class DhbCertificateBatchWizardLine(models.TransientModel):
    _name = "dhb.certificate.batch.wizard.line"
    _description = "Learner on the certificate wizard"

    wizard_id = fields.Many2one(
        "dhb.certificate.batch.wizard", required=True, ondelete="cascade")
    partner_id = fields.Many2one("res.partner", string="Learner")
    selected = fields.Boolean(string="Raise one", default=True)
    # Shown rather than filtered out. A learner who is missing from the list
    # with no explanation looks like a bug; a learner who is in the list,
    # ticked off, with "already has one" beside them, is an answer.
    has_certificate = fields.Boolean(
        string="Already has one", readonly=True)
