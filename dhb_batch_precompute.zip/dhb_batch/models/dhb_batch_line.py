from odoo import models, fields, api, _


class DhbBatchLine(models.Model):
    """A learner's place on a batch.

    The state codes and the two transition methods are exactly the ones the
    rest of the system already calls - draft, open, done, cancel, and
    action_confirm / action_cancel. Sixteen places in the admission,
    enrolment, interview, Moodle and attendance modules read them. Changing
    the vocabulary here would mean editing all sixteen and hoping none was
    missed, for no gain: nobody reads a state code on screen, they read its
    label, and the labels say what a training centre means.
    """

    _name = "dhb.batch.line"
    _description = "Place on a batch"
    _inherit = ["mail.thread"]
    _order = "event_id, id"
    _rec_names_search = ["name", "partner_id", "email"]

    # Named event_id on purpose - see the docstring on dhb.batch.
    event_id = fields.Many2one(
        "dhb.batch", string="Batch", required=True, index=True,
        ondelete="cascade", tracking=True,
    )
    partner_id = fields.Many2one(
        "res.partner", string="Learner", index=True, tracking=True,
    )
    name = fields.Char(string="Name", tracking=True)
    email = fields.Char(string="Email", tracking=True)
    phone = fields.Char(string="Phone", tracking=True)

    state = fields.Selection(
        [
            ("draft", "Unconfirmed"),
            ("open", "Registered"),
            ("done", "Attended"),
            ("cancel", "Cancelled"),
        ],
        string="Status", default="draft", required=True, tracking=True,
        index=True, copy=False,
    )

    company_id = fields.Many2one(
        related="event_id.company_id", store=True, readonly=True,
    )
    date_begin = fields.Datetime(
        related="event_id.date_begin", string="Batch starts", store=True,
        readonly=True,
    )
    active = fields.Boolean(default=True)

    # ------------------------------------------------------------------
    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        """Fill the contact details from the learner, without overwriting."""
        for line in self:
            partner = line.partner_id
            if not partner:
                continue
            line.name = line.name or partner.name
            line.email = line.email or partner.email
            line.phone = line.phone or partner.phone or partner.mobile

    @api.depends("partner_id", "name", "event_id")
    def _compute_display_name(self):
        for line in self:
            who = line.name or line.partner_id.display_name or _("Unnamed")
            line.display_name = "%s - %s" % (who, line.event_id.name) \
                if line.event_id else who

    # ------------------------------------------------------------------
    # The transition methods the rest of the system calls by name.
    def action_confirm(self):
        return self.write({"state": "open"})

    def action_cancel(self):
        return self.write({"state": "cancel"})

    def action_set_done(self):
        return self.write({"state": "done"})

    def action_draft(self):
        return self.write({"state": "draft"})
