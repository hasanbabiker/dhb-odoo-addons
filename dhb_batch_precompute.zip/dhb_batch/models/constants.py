"""The vocabulary a batch and a course share.

Declared once. Two copies of a selection list is two lists that drift: a
qualification added to the course catalogue and forgotten on the batch would
silently stop matching, and nothing would say so.
"""

QUALIFICATIONS = [
    ("igc", "NEBOSH IGC"),
    ("di1", "NEBOSH Diploma DI1"),
    ("di2", "NEBOSH Diploma DI2"),
    ("di3", "NEBOSH Diploma DI3"),
    ("emc", "NEBOSH Environmental Management"),
    ("fire", "NEBOSH Fire"),
    ("hse", "NEBOSH HSE Incident Investigation"),
    ("award", "NEBOSH Health and Safety at Work Award"),
    ("psm", "NEBOSH Process Safety Management"),
    ("iosh_ms", "IOSH Managing Safely"),
]

LANGUAGES = [
    ("en", "English"),
    ("ar", "Arabic"),
    ("ru", "Russian"),
    ("tr", "Turkish"),
    ("pt", "Portuguese (European)"),
    ("es", "Spanish (European)"),
    ("fr", "French"),
]

# NEBOSH recognises exactly four study modes (C026a v1). Blended and
# in-company are not among them: in-company is a *place*, and a course held
# at a client site is still Full Time or Part Time depending on its
# timetable. Offering modes the awarding body does not accept only produces
# applications it will reject.
STUDY_MODES = [
    ("full_time", "Full Time - classroom, block week"),
    ("part_time", "Part Time - classroom, half days or evenings"),
    ("virtual", "Virtual Delivery - Zoom or Teams, scheduled"),
    ("elearning", "E-Learning - self-paced on an LMS"),
]

AWARDING_BODIES = [
    ("nebosh", "NEBOSH"),
    ("iosh", "IOSH"),
    ("dhb", "DHB - our own course"),
    ("other", "Other"),
]
