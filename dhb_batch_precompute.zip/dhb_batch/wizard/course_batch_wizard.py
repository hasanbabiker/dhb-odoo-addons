from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CourseBatchWizard(models.TransientModel):
    """Open a batch of a course without visiting the batches screen.

    The whole point of the catalogue is that a batch is a course plus a date.
    Asking someone to leave the course, create a batch, find the course again
    in a dropdown and then check that everything copied across undoes most of
    that. Four fields and a button.
    """

    _name = "dhb.course.batch.wizard"
    _description = "Open a batch of this course"

    course_id = fields.Many2one(
        "dhb.course", required=True, readonly=True,
        default=lambda self: self.env.context.get("active_id"),
    )
    date_begin = fields.Datetime(
        string="Starts", required=True,
        default=lambda self: fields.Datetime.now(),
        help="Date and time of the first session.",
    )
    group_code = fields.Char(
        string="Group", compute="_compute_group_code", store=True,
        readonly=False,
        help="Suggested from the batches this course already has this month.",
    )
    user_id = fields.Many2one(
        "res.users", string="Coordinator",
        default=lambda self: self.env.user,
    )
    address_id = fields.Many2one(
        "res.partner", string="Venue", domain="[('is_company', '=', True)]",
        help="Leave empty for a batch delivered online.",
    )

    preview_name = fields.Char(compute="_compute_preview", readonly=True)
    preview_code = fields.Char(compute="_compute_preview", readonly=True)

    @api.depends("course_id", "date_begin")
    def _compute_group_code(self):
        for wizard in self:
            batch = self.env["dhb.batch"].new({
                "course_id": wizard.course_id.id,
                "date_begin": wizard.date_begin,
            })
            wizard.group_code = batch._suggest_group_code()

    @api.depends("course_id", "date_begin", "group_code")
    def _compute_preview(self):
        """Show the name before it is created, not after.

        A generated name that only appears once the record exists is a
        surprise. Shown here, it is a decision the person can still change.
        """
        for wizard in self:
            batch = self.env["dhb.batch"].new({
                "course_id": wizard.course_id.id,
                "date_begin": wizard.date_begin,
                "group_code": wizard.group_code,
            })
            batch._compute_batch_name()
            wizard.preview_name = batch.name
            wizard.preview_code = batch.code

    def action_create_batch(self):
        self.ensure_one()
        if not self.course_id:
            raise UserError(_("Pick a course first."))

        batch = self.env["dhb.batch"].create({
            "course_id": self.course_id.id,
            "date_begin": self.date_begin,
            "date_end": self.date_begin,
            "group_code": self.group_code or "1",
            "user_id": self.user_id.id,
            "address_id": self.address_id.id,
            "state": "planned",
        })
        # Everything else the course knows - including whatever other modules
        # have added to that method.
        batch._apply_course_defaults()

        return {
            "type": "ir.actions.act_window",
            "res_model": "dhb.batch",
            "res_id": batch.id,
            "view_mode": "form",
        }
