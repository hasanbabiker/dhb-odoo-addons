# -*- coding: utf-8 -*-
{
    "name": "DHB Contact Cards",
    "version": "19.0.1.0.1",
    "category": "Productivity",
    "summary": "Card view for contacts with photo, tags, country flag and "
               "quick tag filters.",
    "description": """
DHB Contact Cards
=================

Replaces the Contacts card view with a richer layout:

* Photo, full name, tags, email, phone and country with its flag.
* Quick filter buttons across the top for Moodle Learner, NEBOSH Learner,
  IOSH Learner, Instructor and Company.
* NEBOSH learner number is searchable from the same search bar.

Only the Contacts application is affected. Other places that show partner
cards keep Odoo's own layout, so nothing else in the system shifts.
""",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "depends": ["contacts"],
    "data": [
        "data/partner_tags.xml",
        "views/res_partner_kanban.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "dhb_contact_cards/static/src/scss/cards.scss",
        ],
    },
    "installable": True,
    "application": False,
    "auto_install": False,
}
