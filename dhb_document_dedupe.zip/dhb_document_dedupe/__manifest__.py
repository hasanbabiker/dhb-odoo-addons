{
    "name": "DHB · No duplicate learner files",
    "version": "18.0.1.0.0",
    "summary": "Stops the same file being filed twice for a learner, "
               "and archives the duplicates already there.",
    "author": "DHB Training and Consulting FZE",
    "license": "LGPL-3",
    "depends": ["documents"],
    "data": [
        "data/server_actions.xml",
    ],
    "installable": True,
}
