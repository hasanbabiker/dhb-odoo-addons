import base64
import hashlib
import logging

from odoo import api, models

_logger = logging.getLogger(__name__)


class DocumentsDocument(models.Model):
    """One copy of each file per learner.

    Every filing route (application upload, automatic filing, Drive copy,
    email archive) ends in documents.document.create, so the guard lives
    here rather than in each route.

    Rule, per learner (partner_id) and file content (SHA1):
      * same folder already holds it      -> nothing new is created,
                                              the existing record is returned
      * another folder of the learner has -> a shortcut is created in the
        it (e.g. the other batch)            new folder instead of a copy
      * nobody has it                      -> normal create

    Pass context dhb_allow_duplicate=True to bypass on purpose.
    """

    _inherit = "documents.document"

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    def _dhb_checksum_from_vals(self, vals):
        """SHA1 of the file in vals, the same hash ir.attachment stores."""
        if vals.get("attachment_id"):
            att = self.env["ir.attachment"].sudo().browse(vals["attachment_id"])
            return att.exists() and att.checksum or False
        content = vals.get("raw")
        if not content and vals.get("datas"):
            try:
                content = base64.b64decode(vals["datas"])
            except Exception:
                return False
        if not content:
            return False
        if isinstance(content, str):
            content = content.encode()
        return hashlib.sha1(content).hexdigest()

    def _dhb_find_same_file(self, partner_id, checksum):
        return self.sudo().search([
            ("partner_id", "=", partner_id),
            ("checksum", "=", checksum),
            ("type", "=", "binary"),
            ("shortcut_document_id", "=", False),
        ], order="id asc")

    # ------------------------------------------------------------------
    # create guard
    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        if self.env.context.get("dhb_allow_duplicate"):
            return super().create(vals_list)

        result_ids = [None] * len(vals_list)
        to_create, positions = [], []

        for i, vals in enumerate(vals_list):
            partner_id = vals.get("partner_id")
            folder_id = vals.get("folder_id")
            is_file = vals.get("type", "binary") == "binary" and not vals.get(
                "shortcut_document_id")
            checksum = (partner_id and folder_id and is_file
                        and self._dhb_checksum_from_vals(vals))
            if not checksum:
                to_create.append(vals)
                positions.append(i)
                continue

            same = self._dhb_find_same_file(partner_id, checksum)
            in_folder = same.filtered(lambda d: d.folder_id.id == folder_id)
            if in_folder:
                _logger.info("DHB dedupe: skipped %r, same file is #%s",
                             vals.get("name"), in_folder[0].id)
                result_ids[i] = in_folder[0].id
                continue

            if same:
                original = same[0]
                shortcut = self._dhb_make_shortcut(original, folder_id)
                if shortcut:
                    _logger.info("DHB dedupe: %r filed as shortcut to #%s",
                                 vals.get("name"), original.id)
                    result_ids[i] = shortcut.id
                    continue

            to_create.append(vals)
            positions.append(i)

        if to_create:
            created = super().create(to_create)
            for pos, rec in zip(positions, created):
                result_ids[pos] = rec.id

        return self.browse(result_ids)

    def _dhb_make_shortcut(self, original, folder_id):
        """Shortcut in folder_id pointing at original; existing one reused."""
        existing = self.sudo().search([
            ("shortcut_document_id", "=", original.id),
            ("folder_id", "=", folder_id),
        ], limit=1)
        if existing:
            return existing
        try:
            if hasattr(original, "action_create_shortcut"):
                return original.sudo().action_create_shortcut(folder_id)
            return super(DocumentsDocument, self.sudo()).create({
                "shortcut_document_id": original.id,
                "folder_id": folder_id,
                "name": original.name,
                "partner_id": original.partner_id.id,
            })
        except Exception:
            _logger.exception("DHB dedupe: shortcut failed, filing a copy")
            return False

    # ------------------------------------------------------------------
    # clean-up of what is already there
    # ------------------------------------------------------------------
    @api.model
    def dhb_archive_duplicates(self, dry_run=True, partner_ids=None):
        """Archive duplicates already filed. Never deletes.

        Inside one folder: keep the oldest copy, archive the rest.
        Across folders of the same learner: keep the oldest, the copies in
        other folders are replaced by shortcuts to it.

        Returns a summary dict; with dry_run nothing is changed.
        """
        domain = [("type", "=", "binary"), ("partner_id", "!=", False),
                  ("checksum", "!=", False),
                  ("shortcut_document_id", "=", False)]
        if partner_ids:
            domain.append(("partner_id", "in", partner_ids))
        docs = self.sudo().search(domain, order="id asc")

        groups = {}
        for doc in docs:
            groups.setdefault((doc.partner_id.id, doc.checksum), self.browse())
            groups[(doc.partner_id.id, doc.checksum)] |= doc

        to_archive = self.browse()
        shortcuts_needed = []
        for recs in groups.values():
            if len(recs) < 2:
                continue
            keep = recs[0]
            seen_folders = {keep.folder_id.id}
            for dup in recs[1:]:
                to_archive |= dup
                if dup.folder_id.id not in seen_folders:
                    seen_folders.add(dup.folder_id.id)
                    shortcuts_needed.append((keep, dup.folder_id.id))

        summary = {
            "learners": len({d.partner_id.id for d in to_archive}),
            "files_archived": len(to_archive),
            "shortcuts_created": len(shortcuts_needed),
            "dry_run": dry_run,
        }
        if dry_run:
            return summary

        for keep, folder_id in shortcuts_needed:
            self._dhb_make_shortcut(keep, folder_id)
        to_archive.write({"active": False})
        _logger.info("DHB dedupe clean-up: %s", summary)
        return summary

    @api.model
    def action_dhb_dedupe_preview(self):
        s = self.dhb_archive_duplicates(dry_run=True)
        return self._dhb_notify(
            "Preview: %(files_archived)s duplicate files for %(learners)s "
            "learners would be archived (%(shortcuts_created)s shortcuts). "
            "Nothing was changed." % s, "info")

    @api.model
    def action_dhb_dedupe_run(self):
        s = self.dhb_archive_duplicates(dry_run=False)
        return self._dhb_notify(
            "Done: %(files_archived)s duplicate files archived for "
            "%(learners)s learners, %(shortcuts_created)s shortcuts created. "
            "Archived files can be restored from the Archived filter." % s,
            "success")

    def _dhb_notify(self, message, kind):
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {"title": "Duplicate learner files",
                       "message": message, "type": kind, "sticky": True},
        }
