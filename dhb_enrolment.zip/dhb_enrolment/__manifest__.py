{
    "name": "DHB Enrolment Bridge",
    "version": "19.0.1.0.1",
    "summary": "Link learners already on Moodle to their Odoo cohorts",
    "description": """
DHB Enrolment Bridge
====================

Learners arrived in Odoo from Moodle as contacts, with no link to a cohort.
That link is what everything else hangs from: attendance is counted per
cohort, the closing interview belongs to a learner on a cohort, and the
certificate gate reads the cohort's deadline. Without it, 235 learners sit in
the database and no cohort has a single attendee.

Moodle already knows who is on which course. This module reads that and writes
it into Odoo:

* Adds the one web service call the Moodle client was missing -
  core_enrol_get_enrolled_users.
* Maps a Moodle course to an Odoo cohort, explicitly rather than by guessing:
  one Moodle course can feed several cohorts, and a cohort can draw from more
  than one Moodle course.
* Creates the missing event.registration records, matching each Moodle user to
  a contact by Moodle user ID first and email second.

Nothing is deleted and nothing is overwritten. A learner already registered on
the cohort is left alone, so the import can be run again safely.
    """,
    "author": "DHB Training and Consulting FZE",
    "website": "https://dhbtraining.com",
    "category": "Marketing/Events",
    "license": "LGPL-3",
    "depends": ["event", "contacts", "dhb_moodle", "dhb_zoom_attendance"],
    "data": [
        "security/ir.model.access.csv",
        "data/ir_cron.xml",
        "views/moodle_course_map_views.xml",
        "wizard/enrolment_import_wizard_views.xml",
        "views/event_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
