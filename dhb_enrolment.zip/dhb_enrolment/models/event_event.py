from odoo import models, fields, api, _


class EventEvent(models.Model):
    """The cohort's side of the Moodle link."""

    _inherit = "event.event"

    moodle_map_ids = fields.One2many(
        "dhb.moodle.course.map", "event_id", string="Moodle courses")
    moodle_map_count = fields.Integer(compute="_compute_moodle_map_count")

    @api.depends("moodle_map_ids")
    def _compute_moodle_map_count(self):
        for event in self:
            event.moodle_map_count = len(event.moodle_map_ids)

    def action_import_moodle_enrolments(self):
        """Open the import wizard already pointed at this cohort."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Import learners from Moodle"),
            "res_model": "dhb.enrolment.import.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_default_event_id": self.id},
        }

    def action_refresh_moodle_enrolments(self):
        """Re-run every Moodle course already mapped to this cohort."""
        self.ensure_one()
        return self.moodle_map_ids.action_import()
