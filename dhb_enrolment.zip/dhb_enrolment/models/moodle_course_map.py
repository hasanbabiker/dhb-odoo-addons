import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class MoodleCourseMap(models.Model):
    """Which Moodle course feeds which Odoo cohort.

    Mapped by hand rather than matched by name. A Moodle course called
    "NEBOSH IGC Arabic" may run three cohorts a year, and a cohort may draw
    from two Moodle courses when a qualification is split into units. Guessing
    from the name would put learners on the wrong cohort, and a learner on the
    wrong cohort gets the wrong deadline, the wrong attendance and eventually
    the wrong certificate.
    """

    _name = "dhb.moodle.course.map"
    _description = "Moodle course to cohort"
    _order = "event_id, moodle_course_id"
    _rec_name = "display_name"

    display_name = fields.Char(compute="_compute_display_name", store=True)

    moodle_course_id = fields.Integer(
        string="Moodle course ID", required=True, index=True)
    moodle_course_name = fields.Char(string="Moodle course")
    moodle_course_shortname = fields.Char(string="Short name")
    moodle_group = fields.Char(
        string="Group",
        help="Optional. When one Moodle course carries several cohorts, name "
             "the Moodle group that belongs to this cohort. Left empty, every "
             "learner on the course is taken.",
    )

    event_id = fields.Many2one(
        "event.event", string="Cohort", required=True,
        ondelete="cascade", index=True,
    )
    qualification = fields.Selection(
        related="event_id.qualification", store=True, readonly=True)

    active = fields.Boolean(default=True)
    last_import = fields.Datetime(string="Last import", readonly=True)
    last_result = fields.Char(string="Last result", readonly=True)
    registered_count = fields.Integer(
        string="Learners on the cohort", compute="_compute_registered_count")

    # Odoo 19 dropped _sql_constraints in favour of model attributes; a list
    # left behind is ignored with a warning and the constraint never exists.
    _unique_course_event_group = models.Constraint(
        "unique(moodle_course_id, event_id, moodle_group)",
        "That Moodle course is already mapped to this cohort.",
    )

    @api.depends("moodle_course_name", "moodle_course_id", "event_id.name",
                 "moodle_group")
    def _compute_display_name(self):
        for mapping in self:
            course = mapping.moodle_course_name or _("Moodle course %s") % (
                mapping.moodle_course_id or "?")
            if mapping.moodle_group:
                course = "%s (%s)" % (course, mapping.moodle_group)
            mapping.display_name = "%s -> %s" % (
                course, mapping.event_id.name or _("no cohort"))

    def _compute_registered_count(self):
        for mapping in self:
            mapping.registered_count = len(
                mapping.event_id.registration_ids.filtered(
                    lambda r: r.state != "cancel"))

    # ------------------------------------------------------------------
    # the import
    # ------------------------------------------------------------------
    def action_import(self):
        """Create the missing registrations for every mapping in the set."""
        summaries = [mapping._import_one() for mapping in self]
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Imported from Moodle"),
                "message": "\n".join(summaries),
                "sticky": True,
                "type": "success",
            },
        }

    def _import_one(self):
        """Pull the Moodle roll and write the registrations that are missing."""
        self.ensure_one()
        api_client = self.env["dhb.moodle.api"]
        Registration = self.env["event.registration"]
        Partner = self.env["res.partner"]

        users = api_client.get_enrolled_users(self.moodle_course_id)
        learners = [u for u in users if api_client.is_learner(u)]

        if self.moodle_group:
            wanted = self.moodle_group.strip().lower()
            learners = [
                u for u in learners
                if any((g.get("name") or "").strip().lower() == wanted
                       for g in (u.get("groups") or []))
            ]

        # Registrations already on the cohort, so a second run adds nothing.
        existing_partner_ids = set(
            self.event_id.registration_ids.filtered(
                lambda r: r.state != "cancel"
            ).mapped("partner_id").ids
        )

        created, already, missing = 0, 0, []
        for user in learners:
            partner = self._find_partner(Partner, user)
            if not partner:
                missing.append("%s <%s>" % (
                    (user.get("fullname") or "").strip(),
                    (user.get("email") or "").strip(),
                ))
                continue
            if partner.id in existing_partner_ids:
                already += 1
                continue
            Registration.create(self._registration_values(partner, user))
            existing_partner_ids.add(partner.id)
            created += 1

        result = _(
            "%(created)s registered, %(already)s already on the cohort, "
            "%(missing)s not found in Odoo."
        ) % {"created": created, "already": already, "missing": len(missing)}

        self.write({
            "last_import": fields.Datetime.now(),
            "last_result": result,
        })
        if missing:
            self.event_id.message_post(body=_(
                "Imported from Moodle course %(course)s. These learners are on "
                "the Moodle course but have no contact in Odoo, so they were "
                "not registered:<br/>%(list)s"
            ) % {
                "course": self.moodle_course_name or self.moodle_course_id,
                "list": "<br/>".join(missing[:50]),
            })
        return result

    @staticmethod
    def _find_partner(Partner, moodle_user):
        """Moodle ID first, email second.

        The Moodle user ID is the key the accounts were created with and it
        cannot be mistyped. Email is the fallback for learners created on
        Moodle directly, and it is matched case-insensitively because Moodle
        lowercases addresses and Odoo does not.
        """
        moodle_id = moodle_user.get("id")
        if moodle_id:
            partner = Partner.search([("moodle_user_id", "=", int(moodle_id))], limit=1)
            if partner:
                return partner
        email = (moodle_user.get("email") or "").strip()
        if email:
            partner = Partner.search([("email", "=ilike", email)], limit=1)
            if partner:
                # Record the Moodle ID so the next run matches on the strong key.
                if moodle_id and not partner.moodle_user_id:
                    partner.moodle_user_id = int(moodle_id)
                return partner
        return False

    def _registration_values(self, partner, moodle_user):
        self.ensure_one()
        return {
            "event_id": self.event_id.id,
            "partner_id": partner.id,
            "name": partner.name,
            "email": partner.email or (moodle_user.get("email") or "").strip(),
            "phone": partner.phone or "",
        }

    def action_open_registrations(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Attendees"),
            "res_model": "event.registration",
            "view_mode": "list,form",
            "domain": [("event_id", "=", self.event_id.id)],
            "context": {"default_event_id": self.event_id.id},
        }

    @api.model
    def _cron_import_all(self):
        """Keep cohorts in step with Moodle as late enrolments come in."""
        for mapping in self.search([("active", "=", True)]):
            try:
                mapping._import_one()
            except UserError as exc:
                _logger.info("Enrolment import skipped for %s: %s", mapping.id, exc)
            except Exception:  # noqa: BLE001 - one bad course must not stop the run
                _logger.exception("Enrolment import failed for %s", mapping.id)
        return True
