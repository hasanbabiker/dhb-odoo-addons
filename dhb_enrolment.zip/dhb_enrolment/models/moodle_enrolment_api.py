from odoo import models


class MoodleApiEnrolment(models.AbstractModel):
    """The enrolment side of the Moodle web service.

    The existing client can create a user and enrol one, but it cannot ask who
    is already on a course - and that is the only thing needed to rebuild the
    link between the learners in Odoo and their cohorts. Extending the same
    abstract model keeps one URL, one token and one error path.
    """

    _inherit = "dhb.moodle.api"

    def get_enrolled_users(self, course_id):
        """Everyone enrolled on a Moodle course, learners and teachers alike.

        Moodle returns roles with each user, so the caller can drop the
        teachers rather than registering the tutor as their own student.
        """
        return self._call(
            "core_enrol_get_enrolled_users", {"courseid": int(course_id)}
        ) or []

    def get_course_groups(self, course_id):
        """Groups on a course, for cohorts that split one Moodle course."""
        return self._call(
            "core_group_get_course_groups", {"courseid": int(course_id)}
        ) or []

    @staticmethod
    def is_learner(moodle_user):
        """Whether a Moodle enrolment row is a student rather than staff.

        Moodle's shortnames are stable across languages: student, editingteacher,
        teacher, manager, coursecreator. A user with no role at all is treated
        as a learner, because a manual enrolment sometimes carries none and
        leaving a real learner out is the worse error here.
        """
        staff = {"editingteacher", "teacher", "manager", "coursecreator"}
        roles = moodle_user.get("roles") or []
        shortnames = {(role.get("shortname") or "").lower() for role in roles}
        if not shortnames:
            return True
        return not (shortnames & staff)
